// ===================================
// TRAVEL DESTINATIONS DATA
// ===================================

const destinations = [
    {
        name: "Angkor Wat",
        country: "Cambodia",
        category: "Historical",
        image: "images/Angkor Wat Temple.jpg",
        budget: 65,

        // 1. Overview
        description: "Angkor Wat is a magnificent 12th-century temple complex in Siem Reap, Cambodia. Originally built as a Hindu temple dedicated to Vishnu, it later became an important Buddhist religious site. It is famous for its Khmer architecture, enormous stone galleries and beautiful carved decorations.",

        location: "Siem Reap Province, Northwestern Cambodia",

        history: "Angkor Wat was built during the reign of King Suryavarman II in the early 12th century. It represents the achievements of the Khmer Empire and became a symbol of Cambodian culture and national identity. The Angkor Archaeological Park was recognized as a UNESCO World Heritage Site in 1992.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Angkor Wat Temple",
                description: "Explore the iconic five towers, stone galleries and detailed bas-relief carvings."
            },
            {
                name: "Bayon Temple",
                description: "Discover the famous stone towers decorated with enormous smiling faces."
            },
            {
                name: "Ta Prohm Temple",
                description: "See ancient temple ruins surrounded by enormous tree roots."
            },
            {
                name: "Angkor Thom",
                description: "Explore the historic walled city and its impressive South Gate."
            },
            {
                name: "Banteay Kdei",
                description: "Visit a peaceful Buddhist monastery known for its atmospheric ruins."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Discover the history and achievements of the Khmer Empire.",
            "Admire magnificent ancient Khmer architecture.",
            "Experience Cambodian culture and religious heritage.",
            "Enjoy beautiful sunrise and sunset scenery.",
            "Explore one of the world's most remarkable archaeological sites."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "November to February",
            weather: "Generally cooler and drier weather, making temple exploration more comfortable.",
            recommendation: "Visit early in the morning to enjoy the sunrise and avoid the strongest afternoon heat."
        },
        // Special Natural Phenomenon
        specialExperience: {
            title: "Angkor Wat Equinox",
            dates: "Around March 20–21 and September 22–23",
            time: "Before sunrise",
            description: "Twice a year, around the equinoxes, the rising sun appears aligned with the central tower of Angkor Wat when viewed from the western entrance.",
            recommendation: "Arrive early, choose a viewing position near the western reflecting pool, and check the sunrise forecast. Cloudy weather may affect visibility."
        },

        // 5. Estimated Budget
        budgetDetails: [
            {
                item: "One-day Angkor Pass",
                cost: "$37"
            },
            {
                item: "Local transportation",
                cost: "$15–20"
            },
            {
                item: "Food and drinks",
                cost: "$8–12"
            },
            {
                item: "Other expenses",
                cost: "$5–10"
            }
        ],

        budgetNote: "Estimated one-day budget: approximately $65–79 per person. Accommodation and tour guide fees are not included.",
        // 6. Transportation and Accommodation
        transportation: [
            "Travel to Siem Reap by bus, car or plane.",
            "Use a tuk-tuk or private car to explore the temple complex.",
            "Arrange transportation with a local driver or tour operator."
        ],

        accommodation: [
            "Budget guesthouses for affordable stays.",
            "Mid-range hotels for comfortable accommodation.",
            "Luxury hotels and resorts for premium experiences."
        ],

        // 7. Suggested Itinerary
        itinerary: [
            {
                time: "5:00 AM",
                activity: "Angkor Wat Sunrise",
                description: "Arrive early to experience the famous sunrise view."
            },
            {
                time: "7:00 AM",
                activity: "Explore Angkor Wat",
                description: "Walk through the temple galleries and admire the architecture."
            },
            {
                time: "9:00 AM",
                activity: "Visit Bayon Temple",
                description: "Discover the famous smiling stone faces."
            },
            {
                time: "11:00 AM",
                activity: "Explore Ta Prohm",
                description: "Enjoy the atmospheric ruins and giant tree roots."
            },
            {
                time: "12:30 PM",
                activity: "Lunch Break",
                description: "Enjoy traditional Cambodian food at a nearby restaurant."
            },
            {
                time: "2:00 PM",
                activity: "Explore Angkor Thom",
                description: "Discover the ancient city and its historical landmarks."
            },
            {
                time: "4:00 PM",
                activity: "Return to Siem Reap",
                description: "Relax, explore the town or enjoy an evening meal."
            }
        ],

        // 8. Travel Tips
        tips: [
            "Keep your Angkor Pass available throughout your visit.",
            "Bring cash for food, drinks and other personal expenses."
        ]
    },

    // Destination 2: Bayon Temple
    {
        name: "Bayon Temple",
        country: "Cambodia",
        category: "Historical",
        image: "images/Bayon Temple.jpg",
        budget: 65,

        // 1. Overview
        description: "Bayon Temple is a famous ancient temple located at the center of Angkor Thom in Siem Reap, Cambodia. It is best known for its enormous stone faces, impressive architecture and detailed carvings.",

        location: "Angkor Thom, Siem Reap Province, Cambodia",

        history: "Bayon Temple was built in the late 12th century during the reign of King Jayavarman VII. It served as the state temple of the Khmer Empire and was originally associated with Mahayana Buddhism.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Stone Face Towers",
                description: "Admire the famous towers decorated with large smiling stone faces."
            },
            {
                name: "Bas-Relief Galleries",
                description: "Explore detailed carvings showing historical events and everyday Khmer life."
            },
            {
                name: "Angkor Thom South Gate",
                description: "Discover the impressive entrance to the ancient walled city."
            },
            {
                name: "Baphuon Temple",
                description: "Visit a nearby temple known for its impressive pyramid structure."
            },
            {
                name: "Terrace of the Elephants",
                description: "See the historic terrace decorated with detailed elephant carvings."
            }
        ],
        // 3. Why Visit?
        reasons: [
            "See the famous smiling stone faces of Bayon.",
            "Discover the achievements of King Jayavarman VII.",
            "Explore remarkable Khmer stone carvings.",
            "Learn about the history of Angkor Thom.",
            "Experience one of Cambodia's most iconic ancient temples."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "November to February",
            weather: "The cooler and drier season is generally more comfortable for exploring the temple.",
            recommendation: "Visit early in the morning to enjoy cooler temperatures and fewer crowds."
        },

        // 5. Estimated Budget
        budgetDetails: [
            {
                item: "One-day Angkor Pass",
                cost: "$37"
            },
            {
                item: "Local transportation",
                cost: "$15–20"
            },
            {
                item: "Food and drinks",
                cost: "$8–12"
            },
            {
                item: "Other expenses",
                cost: "$5–10"
            }
        ],

        budgetNote: "Estimated one-day visit budget: approximately $65–79 per person. The Angkor Pass also covers other included temples in the archaeological park.",

        // 6. Transportation and Accommodation
        transportation: [
            "Travel to Siem Reap by bus, car or plane.",
            "Use a tuk-tuk or private car to reach Angkor Thom.",
            "Explore Bayon and nearby temples with a local driver or tour guide."
        ],

        accommodation: [
            "Budget guesthouses in Siem Reap.",
            "Mid-range hotels near the town center.",
            "Luxury hotels and resorts for a more comfortable stay."
        ],

        // 7. Suggested Itinerary
        itinerary: [
            {
                time: "7:00 AM",
                activity: "Arrive at Angkor Thom",
                description: "Enter the ancient city through its impressive gates."
            },
            {
                time: "7:30 AM",
                activity: "Explore Bayon Temple",
                description: "Discover the famous smiling faces and temple galleries."
            },
            {
                time: "9:00 AM",
                activity: "Visit Baphuon Temple",
                description: "Explore another remarkable temple within Angkor Thom."
            },
            {
                time: "10:30 AM",
                activity: "Visit the Terrace of the Elephants",
                description: "Admire the detailed stone carvings and historic terrace."
            },
            {
                time: "12:00 PM",
                activity: "Lunch Break",
                description: "Enjoy Cambodian food at a nearby restaurant."
            },
            {
                time: "1:00 PM",
                activity: "Return to Siem Reap",
                description: "Relax and explore the town."
            }
        ],

        // 8. Travel Tips
        tips: [
            "Wear clothing that covers your shoulders and knees.",
            "Bring drinking water and sunscreen.",
            "Wear comfortable shoes for walking around the temple.",
            "Respect religious areas and historical structures.",
            "Keep your Angkor Pass with you during the visit.",
            "Visit early to avoid the strongest afternoon heat."
        ],

        // Special Cultural Experience
        specialExperience: {
            title: "Discover the Smiling Faces of Bayon",

            experience: "Explore the mysterious smiling stone faces carved into Bayon's towers. These remarkable faces are among the most recognizable features of Khmer architecture.",

            culturalSignificance: "The temple was built during the reign of King Jayavarman VII. Its architecture and detailed bas-reliefs provide insight into the religious beliefs, royal history and everyday life of the Khmer Empire.",
            recommendation: "Take time to observe the stone faces from different angles and explore the bas-relief galleries with a knowledgeable local guide."
        }
    },

    // ===================================
    // 3. TA PROHM TEMPLE
    // ===================================

    {
        name: "Ta Prohm Temple",
        country: "Cambodia",
        category: "Historical",
        image: "images/Ta Prohm Temple.jpg",
        budget: 65,

        description: "Ta Prohm Temple is a famous ancient temple in the Angkor Archaeological Park in Siem Reap, Cambodia. It is well known for its massive tree roots growing over ancient stone walls and structures.",

        location: "Angkor Archaeological Park, Siem Reap Province, Cambodia",

        history: "Ta Prohm was built in the late 12th century during the reign of King Jayavarman VII. It was originally established as a Buddhist monastery and university dedicated to his mother.",

        attractions: [
            {
                name: "Giant Tree Roots",
                description: "Admire enormous tree roots growing over the temple walls and stone structures."
            },
            {
                name: "Ancient Stone Galleries",
                description: "Explore the temple's corridors decorated with detailed Khmer carvings."
            },
            {
                name: "Hall of Dancers",
                description: "Discover the historic area associated with traditional Apsara dancers."
            },
            {
                name: "Central Sanctuary",
                description: "Explore the heart of the ancient temple complex."
            },
            {
                name: "Jungle Ruins",
                description: "Experience the atmosphere of an ancient temple surrounded by nature."
            }
        ],

        reasons: [
            "See the spectacular giant tree roots covering ancient structures.",
            "Discover the history of King Jayavarman VII.",
            "Explore beautiful Khmer architecture and stone carvings.",
            "Experience the unique atmosphere of a temple surrounded by nature.",
            "Photograph one of Cambodia's most recognizable ancient temples."
        ],

        bestTime: {
            season: "November to February",
            weather: "The cooler and drier months are generally more comfortable for exploring the temple.",
            recommendation: "Visit early in the morning to enjoy cooler temperatures and fewer crowds."
        },

        specialExperience: {
            title: "Explore the Temple Embraced by Nature",

            experience: "Discover how enormous tree roots grow over ancient stone walls, towers and corridors. The combination of nature and architecture makes Ta Prohm one of the most distinctive temples in the Angkor complex.",

            culturalSignificance: "Ta Prohm reflects the religious, cultural and architectural achievements of the Khmer Empire during the reign of King Jayavarman VII. Its ruins also demonstrate the relationship between the ancient structures and the surrounding natural environment.",

            recommendation: "Walk through the temple's ancient corridors, observe the giant tree roots and respect the protected structures while taking photographs."
        },

        budgetDetails: [
            { item: "One-day Angkor Pass", cost: "$37" },
            { item: "Local transportation", cost: "$15–20" },
            { item: "Food and drinks", cost: "$8–12" },
            { item: "Other expenses", cost: "$5–10" }
        ],

        budgetNote: "Estimated one-day visit budget: approximately $65–79 per person. The Angkor Pass also covers other included temples in the archaeological park.",

        transportation: [
            "Travel to Siem Reap by bus, car or plane.",
            "Use a tuk-tuk or private car to reach Ta Prohm.",
            "Consider hiring a local guide to learn more about the temple's history."
        ],
        accommodation: [
            "Budget guesthouses in Siem Reap.",
            "Mid-range hotels near the town center.",
            "Luxury hotels and resorts for a more comfortable stay."
        ],
        itinerary: [
            {
                time: "7:00 AM",
                activity: "Arrive at Ta Prohm",
                description: "Enter the temple early to enjoy cooler temperatures."
            },
            {
                time: "7:30 AM",
                activity: "Explore the Giant Tree Roots",
                description: "Admire the enormous roots growing over the ancient structures."
            },
            {
                time: "9:00 AM",
                activity: "Explore the Ancient Galleries",
                description: "Discover the temple's stone corridors and detailed carvings."
            },
            {
                time: "10:30 AM",
                activity: "Visit the Central Sanctuary",
                description: "Explore the central area of the temple complex."
            },
            {
                time: "12:00 PM",
                activity: "Lunch Break",
                description: "Enjoy Cambodian food at a nearby restaurant."
            },
            {
                time: "1:00 PM",
                activity: "Return to Siem Reap",
                description: "Relax and explore the town."
            }
        ],

        tips: [
            "Wear clothing that covers your shoulders and knees.",
            "Bring drinking water and sunscreen.",
            "Wear comfortable shoes for walking around the ruins.",
            "Be careful around tree roots and uneven stone surfaces.",
            "Do not climb on restricted or fragile structures.",
            "Keep your Angkor Pass with you during the visit."
        ]
    },

    // ===================================
    // 4. PREAH VIHEAR TEMPLE
    // ===================================

    {
        name: "Preah Vihear Temple",
        country: "Cambodia",
        category: "Historical",
        image: "images/Preah Vihear Temple.jpg",
        budget: 80,

        description: "Preah Vihear Temple is an ancient Khmer Hindu temple located on the edge of the Dangrek Mountains in northern Cambodia. It is famous for its remarkable architecture, long stone pathways and breathtaking mountain views.",

        location: "Dangrek Mountains, Preah Vihear Province, Cambodia",

        history: "Preah Vihear Temple was developed over several centuries, beginning in the 9th century and continuing through the reigns of several Khmer kings. It was dedicated to the Hindu god Shiva and is recognized for its important Khmer architectural heritage.",

        attractions: [
            {
                name: "Five Gopuras",
                description: "Explore the five monumental entrance structures arranged along the temple's long north-south axis."
            },
            {
                name: "Ancient Stone Stairways",
                description: "Discover the impressive stairways connecting the different levels of the temple."
            },
            {
                name: "Carved Stone Decorations",
                description: "Admire detailed carvings and traditional Khmer architectural designs."
            },
            {
                name: "Main Sanctuary",
                description: "Visit the central sanctuary dedicated to the Hindu god Shiva."
            },
            {
                name: "Mountain Viewpoint",
                description: "Enjoy panoramic views of the surrounding Cambodian landscape."
            }
        ],

        reasons: [
            "Discover an important masterpiece of ancient Khmer architecture.",
            "Explore a temple built along a dramatic mountain ridge.",
            "Learn about the religious history of the Khmer Empire.",
            "Admire beautiful stone carvings and ancient structures.",
            "Enjoy spectacular views of the surrounding landscape."
        ],
        bestTime: {
            season: "November to February",
            weather: "The cooler and drier season is generally more comfortable for exploring the mountain temple.",
            recommendation: "Visit in the morning for cooler weather and clearer views."
        },

        specialExperience: {
            title: "Discover the Temple Above the Mountains",

            experience: "Walk along the ancient temple complex built on the Dangrek Mountain ridge. Explore its monumental gateways, stone stairways and breathtaking viewpoints.",

            culturalSignificance: "Preah Vihear Temple reflects the religious beliefs and architectural achievements of the Khmer civilization. Dedicated to Shiva, it represents the historical importance of Hinduism in the ancient Khmer Empire.",

            recommendation: "Take your time exploring each gateway and enjoy the mountain scenery while respecting the temple's protected historical structures."
        },

        budgetDetails: [
            { item: "Temple entrance fee", cost: "Check current rates" },
            { item: "Transportation", cost: "$30–45" },
            { item: "Food and drinks", cost: "$8–12" },
            { item: "Other expenses", cost: "$5–10" }
        ],

        budgetNote: "Estimated travel budget: approximately $45–80 per person, depending on transportation, entrance fees and personal expenses. Confirm current access and fees before travelling.",

        transportation: [
            "Travel to Preah Vihear Province by private car or organized tour.",
            "Continue to the temple access area near the mountain.",
            "Follow current local transportation and visitor-access arrangements to reach the temple."
        ],

        accommodation: [
            "Guesthouses in Sra Em town.",
            "Hotels and guesthouses in Preah Vihear Province.",
        ],
        itinerary: [
            {
                time: "7:00 AM",
                activity: "Depart for Preah Vihear",
                description: "Begin the journey toward the mountain temple."
            },
            {
                time: "9:00 AM",
                activity: "Arrive at the Temple",
                description: "Follow visitor access arrangements."
            },
            {
                time: "9:30 AM",
                activity: "Explore the Five Gopuras",
                description: "Discover the monumental gateways."
            },
            {
                time: "11:00 AM",
                activity: "Visit the Main Sanctuary",
                description: "Explore the historic religious center."
            },
            {
                time: "12:00 PM",
                activity: "Lunch Break",
                description: "Enjoy a meal and take a short rest."
            },
            {
                time: "1:00 PM",
                activity: "Enjoy the Mountain Views",
                description: "Admire the surrounding landscape."
            }
        ],
        tips: [
            "Wear comfortable clothing and walking shoes.",
            "Bring drinking water, sunscreen and a hat.",
            "Check current visitor access and security conditions before travelling.",
            "Follow local instructions and designated visitor routes.",
            "Respect the ancient structures and avoid climbing restricted areas.",
            "Prepare for a long journey and mountainous terrain."
        ]
    },
    // ===================================
    // 5. KOH KER TEMPLE
    // ===================================

    {
        name: "Koh Ker Temple",
        country: "Cambodia",
        category: "Historical",
        image: "images/Koh Ker.jpg",
        budget: 75,

        description: "Koh Ker is an ancient archaeological site in Preah Vihear Province, Cambodia. It is famous for its impressive seven-tiered pyramid temple, Prasat Thom, and its remarkable Khmer architecture.",

        location: "Koh Ker, Preah Vihear Province, Cambodia",

        history: "Koh Ker served as the capital of the Khmer Empire during the reign of King Jayavarman IV in the 10th century. The site contains numerous temples, sculptures and monuments that reflect the artistic and architectural achievements of the period.",

        attractions: [
            {
                name: "Prasat Thom",
                description: "Explore the impressive seven-tiered pyramid that is the most famous monument at Koh Ker."
            },
            {
                name: "Prasat Pram",
                description: "Discover ancient brick towers partly covered by tree roots and vegetation."
            },
            {
                name: "Prasat Krahom",
                description: "Visit a red sandstone temple known for its distinctive color."
            },
            {
                name: "Ancient Temple Complex",
                description: "Explore the remains of numerous temples spread throughout the archaeological site."
            },
            {
                name: "Stone Sculptures",
                description: "Admire the artistic details of ancient Khmer stone carvings and sculptures."
            }
        ],

        reasons: [
            "See the unique seven-tiered pyramid of Prasat Thom.",
            "Discover the former capital of the Khmer Empire.",
            "Explore remarkable 10th-century Khmer architecture.",
            "Enjoy the peaceful atmosphere of an archaeological site surrounded by nature.",
            "Learn about an important period in Cambodian history."
        ],

        bestTime: {
            season: "November to February",
            weather: "The cooler and drier season is generally more comfortable for exploring the archaeological site.",
            recommendation: "Visit in the morning to avoid the strongest afternoon heat."
        },

        specialExperience: {
            title: "Climb Through the History of Koh Ker",

            experience: "Discover Prasat Thom, the remarkable seven-tiered pyramid that rises above the surrounding forest. Explore the ancient temple grounds and admire the distinctive architecture of this former Khmer capital.",

            culturalSignificance: "Koh Ker reflects the political, religious and artistic achievements of the Khmer Empire during the 10th century. Its monuments reveal the architectural ambition of King Jayavarman IV and the historical importance of the site.",

            recommendation: "Explore the pyramid and surrounding temples while following designated visitor paths. Respect restricted areas and enjoy the archaeological landscape."
        },

        budgetDetails: [
            { item: "Temple entrance fee", cost: "Check current rates" },
            { item: "Transportation", cost: "$35–45" },
            { item: "Food and drinks", cost: "$8–12" },
            { item: "Other expenses", cost: "$5–10" }
        ],

        budgetNote: "Estimated travel budget: approximately $50–75 per person, depending on transportation, current entrance fees and personal expenses. Confirm current rates before travelling.",

        transportation: [
            "Travel to Koh Ker from Siem Reap or other nearby destinations by private car or organized tour.",
            "Private transportation is a convenient option because the archaeological site is in a rural area.",
            "Follow local visitor instructions when travelling between the temples."
        ],
        accommodation: [
            "Guesthouses in nearby local communities.",
            "Hotels and guesthouses in Siem Reap.",
            "Accommodation in Preah Vihear Province for a longer regional trip."
        ],

        itinerary: [
            {
                time: "7:00 AM",
                activity: "Depart for Koh Ker",
                description: "Begin the journey to the ancient archaeological site."
            },
            {
                time: "9:00 AM",
                activity: "Arrive at Koh Ker",
                description: "Enter the archaeological area and prepare to explore."
            },
            {
                time: "9:30 AM",
                activity: "Explore Prasat Thom",
                description: "Discover the famous seven-tiered pyramid."
            },
            {
                time: "10:30 AM",
                activity: "Visit Prasat Pram",
                description: "Admire the ancient brick towers surrounded by vegetation."
            },
            {
                time: "11:30 AM",
                activity: "Explore Other Temples",
                description: "Discover more monuments and historical structures."
            },
            {
                time: "12:30 PM",
                activity: "Lunch Break",
                description: "Enjoy a meal and rest before returning."
            }
        ],

        tips: [
            "Wear comfortable clothing and walking shoes.",
            "Bring enough drinking water and sunscreen.",
            "Wear a hat to protect yourself from the sun.",
            "Follow designated visitor paths around the pyramid.",
            "Do not climb restricted or fragile structures.",
            "Check current entrance fees and opening arrangements before visiting."
        ]
    },
    // ===================================
    // 6. ROYAL PALACE
    // ===================================

    {
        name: "Royal Palace",
        country: "Cambodia",
        category: "Historical & Cultural",
        image: "images/Royal Palace.jpg",
        budget: 45,

        description: "The Royal Palace is a famous landmark in Phnom Penh, Cambodia. It serves as the official residence of the Cambodian King and is admired for its beautiful Khmer architecture, golden roofs and royal gardens.",

        location: "Samdach Sothearos Boulevard, Phnom Penh, Cambodia",

        history: "The Royal Palace was constructed in 1866 during the reign of King Norodom, after the capital was moved from Oudong to Phnom Penh. It has served as the residence of Cambodian monarchs and an important center of royal ceremonies.",

        attractions: [
            {
                name: "Throne Hall",
                description: "Admire the impressive royal building used for important ceremonies and official occasions."
            },
            {
                name: "Silver Pagoda",
                description: "Discover the famous pagoda known for its silver-tiled floor and sacred Buddha statues."
            },
            {
                name: "Moonlight Pavilion",
                description: "See the elegant pavilion used for royal performances and traditional celebrations."
            },
            {
                name: "Royal Gardens",
                description: "Enjoy the peaceful gardens and beautiful surroundings within the palace grounds."
            },
            {
                name: "Royal Architecture",
                description: "Observe the traditional Khmer roofs, decorative details and golden structures."
            }
        ],

        reasons: [
            "Discover Cambodia's royal history and traditions.",
            "Admire beautiful Khmer architecture and royal buildings.",
            "Visit the famous Silver Pagoda.",
            "Learn about Cambodian royal ceremonies and culture.",
            "Explore one of Phnom Penh's most iconic landmarks."
        ],

        bestTime: {
            season: "November to February",
            weather: "The cooler and drier season is generally more comfortable for exploring Phnom Penh.",
            recommendation: "Visit in the morning to enjoy cooler temperatures and allow enough time to explore the palace grounds."
        },

        specialExperience: {
            title: "Discover Cambodia's Royal Heritage",

            experience: "Explore the Royal Palace grounds and admire the traditional architecture, golden roofs and beautifully decorated royal buildings.",

            culturalSignificance: "The Royal Palace represents Cambodia's monarchy, national identity and royal traditions. It remains an important place for official ceremonies and cultural events.",

            recommendation: "Take time to appreciate the architectural details and learn about Cambodia's royal heritage while respecting palace rules and restricted areas."
        },

        budgetDetails: [
            { item: "Palace entrance fee", cost: "Check current rates" },
            { item: "Local transportation", cost: "$5–10" },
            { item: "Food and drinks", cost: "$8–12" },
            { item: "Other expenses", cost: "$5–10" }
        ],

        budgetNote: "Estimated visit budget: approximately $18–45 per person, depending on entrance fees, transportation and personal expenses. Confirm current visitor access and ticket prices before visiting.",

        transportation: [
            "Travel to Phnom Penh by bus, car or plane.",
            "Use a tuk-tuk, taxi or local transportation to reach the Royal Palace.",
            "The palace is located near the Mekong and Tonle Sap rivers in central Phnom Penh."
        ],

        accommodation: [
            "Budget guesthouses near the city center.",
            "Mid-range hotels around Riverside and BKK1.",
            "Luxury hotels in central Phnom Penh."
        ],
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Arrive at the Royal Palace",
                description: "Arrive early and check visitor access and ticket arrangements."
            },
            {
                time: "8:30 AM",
                activity: "Explore the Throne Hall",
                description: "Admire the royal architecture and ceremonial building."
            },
            {
                time: "9:30 AM",
                activity: "Visit the Silver Pagoda",
                description: "Discover the sacred statues and beautiful interior decorations."
            },
            {
                time: "10:30 AM",
                activity: "Explore the Royal Gardens",
                description: "Enjoy the peaceful gardens and palace surroundings."
            },
            {
                time: "11:30 AM",
                activity: "Discover the Moonlight Pavilion",
                description: "Learn about its role in royal celebrations and performances."
            },
            {
                time: "12:00 PM",
                activity: "Lunch Break",
                description: "Enjoy Cambodian food at a nearby restaurant."
            }
        ],

        tips: [
            "Wear clothing that covers your shoulders and knees.",
            "Bring drinking water and sunscreen.",
            "Check opening hours and visitor access before travelling.",
            "Respect royal buildings and restricted areas.",
            "Follow photography rules inside the palace grounds.",
            "Allow enough time to explore the different attractions."
        ]
    },
    {
    name: "Kep",
    country: "Cambodia",
    category: "Coastal & Nature",
    image: "images/Kep.jpg",
    budget: 60,

    description: "Kep is a peaceful coastal destination in southern Cambodia, famous for its beautiful beaches, fresh seafood, scenic coastline and relaxed atmosphere. It is a popular place for visitors who want to enjoy nature and seaside activities.",

    location: "Kep Province, southern Cambodia",

    history: "Kep developed as a seaside resort during the French colonial period in the early 20th century. It later became known for its coastal villas and peaceful atmosphere. Today, visitors can discover its history, beaches and local fishing culture.",

    attractions: [
        {
            name: "Kep Beach",
            description: "Relax beside the sea and enjoy the peaceful coastal atmosphere."
        },
        {
            name: "Kep Crab Market",
            description: "Explore the famous seafood market and try freshly prepared local crab."
        },
        {
            name: "Kep National Park",
            description: "Discover forest trails, tropical plants and beautiful viewpoints."
        },
        {
            name: "Rabbit Island (Koh Tonsay)",
            description: "Take a boat trip to enjoy beaches, swimming and island scenery."
        },
        {
            name: "Kep's Coastal Viewpoints",
            description: "Enjoy scenic views of the coastline and nearby islands."
        }
    ],

    reasons: [
        "Enjoy beautiful beaches and coastal scenery.",
        "Taste Kep's famous fresh crab and seafood.",
        "Explore nature trails and tropical forests.",
        "Visit nearby islands and enjoy water activities.",
        "Experience a peaceful seaside atmosphere."
    ],

    bestTime: {
        season: "November to April",
        weather: "The dry season generally offers sunnier weather and more comfortable conditions for beach activities.",
        recommendation: "Visit during the morning or late afternoon to enjoy the coastline while avoiding the strongest midday heat."
    },

    specialExperience: {
        title: "Experience Kep's Coastal Lifestyle",
        experience: "Enjoy freshly cooked Kep crab, explore the seaside market, relax at the beach and take a boat trip to Rabbit Island.",
        culturalSignificance: "Kep is known for its coastal fishing traditions and seafood culture. Its famous crab market reflects the importance of fishing and local livelihoods in the community.",
        recommendation: "Try local seafood, respect the marine environment and avoid leaving rubbish on beaches or islands."
    },

    budgetDetails: [
        { item: "Local transportation", cost: "$5–15" },
        { item: "Food and seafood", cost: "$8–15" },
        { item: "Boat trip", cost: "$5–10" },
        { item: "Other expenses", cost: "$5–10" }
    ],

    budgetNote: "Estimated visit budget: approximately $25–60 per person, depending on transportation, activities, accommodation and personal expenses.",

    transportation: [
        "Travel to Kep from Phnom Penh by bus, minivan or private car.",
        "Use a tuk-tuk, taxi or motorbike to explore the town.",
        "Take a local boat to visit Rabbit Island (Koh Tonsay)."
    ],

    accommodation: [
        "Budget guesthouses near Kep Beach.",
        "Mid-range hotels and resorts around the coastline.",
        "Seaside bungalows and boutique resorts."
    ],

    itinerary: [
        {
            time: "8:00 AM",
            activity: "Visit Kep Beach",
            description: "Enjoy the morning sea breeze and peaceful beach atmosphere."
        },
        {
            time: "9:30 AM",
            activity: "Explore Kep Crab Market",
            description: "Discover local seafood and try Kep's famous crab."
        },
        {
            time: "11:00 AM",
            activity: "Visit Kep National Park",
            description: "Explore nature trails and enjoy scenic viewpoints."
        },
        {
            time: "1:00 PM",
            activity: "Lunch Break",
            description: "Enjoy fresh seafood or traditional Cambodian dishes."
        },
        {
            time: "2:30 PM",
            activity: "Explore Rabbit Island",
            description: "Take a boat trip if weather and boat schedules allow."
        },
        {
            time: "5:00 PM",
            activity: "Enjoy the Coastal Sunset",
            description: "Relax and admire the beautiful seaside scenery."
        }
    ],

    tips: [
        "Bring sunscreen, drinking water and comfortable clothing.",
        "Bring cash for local markets and boat services.",
        "Check boat schedules and sea conditions before visiting Rabbit Island.",
        "Wear comfortable shoes when exploring Kep National Park.",
        "Keep beaches and natural areas clean.",
        "Try Kep's famous fresh crab and local seafood."
    ]
},
// ===================================
// 8. KAMPOT
// ===================================

{
    name: "Kampot",
    country: "Cambodia",
    category: "Nature & Cultural",
    image: "images/Kampot.jpg",
    budget: 65,

    description: "Kampot is a charming riverside town in southern Cambodia, known for its peaceful atmosphere, French colonial architecture, famous Kampot pepper and beautiful natural landscapes. It offers visitors a combination of cultural experiences, countryside adventures and relaxing riverside activities.",

    location: "Kampot Province, southern Cambodia",

    history: "Kampot developed as an important trading port during the French colonial period. Its historical buildings and riverside setting reflect its past as a center of commerce and cultural exchange. The region is also internationally recognized for its high-quality Kampot pepper.",

    attractions: [
        {
            name: "Kampot Riverside",
            description: "Enjoy beautiful river views, relaxing boat trips and the peaceful atmosphere of the town."
        },
        {
            name: "Bokor Mountain",
            description: "Explore mountain scenery, cool weather and historical buildings in Bokor National Park."
        },
        {
            name: "Kampot Pepper Plantations",
            description: "Discover how the famous Kampot pepper is grown and learn about local farming traditions."
        },
        {
            name: "Teuk Chhou Rapids",
            description: "Enjoy the natural freshwater rapids and surrounding green landscapes."
        },
        {
            name: "Phnom Chhngok Cave Temple",
            description: "Visit a limestone cave containing an ancient brick temple and fascinating natural formations."
        }
    ],

    reasons: [
        "Experience the peaceful atmosphere of a riverside town.",
        "Discover the famous Kampot pepper and local agriculture.",
        "Explore mountains, caves and natural attractions.",
        "Enjoy boat trips and beautiful countryside scenery.",
        "Learn about local culture and historical architecture."
    ],

    bestTime: {
        season: "November to April",
        weather: "The dry season generally provides more comfortable conditions for sightseeing and outdoor activities.",
        recommendation: "Visit during the cooler months and explore the countryside in the morning. Late afternoons are ideal for enjoying the riverside scenery."
    },

    specialExperience: {
        title: "Discover the Flavors and Beauty of Kampot",
        experience: "Visit a Kampot pepper plantation, learn about traditional pepper farming, taste local products and enjoy a relaxing sunset boat trip along the Kampot River.",
        culturalSignificance: "Kampot pepper is an important part of the region's agricultural heritage and is recognized for its distinctive flavor. The town's riverside history and colonial-era architecture also reflect its cultural development.",
        recommendation: "Try authentic Kampot pepper dishes and purchase locally produced pepper from reputable farms. Respect local communities and agricultural areas during your visit."
    },

    budgetDetails: [
        { item: "Local transportation", cost: "$5–15" },
        { item: "Food and drinks", cost: "$8–15" },
        { item: "Activities and entrance fees", cost: "$5–15" },
        { item: "Other expenses", cost: "$5–10" }
    ],

    budgetNote: "Estimated visit budget: approximately $25–65 per person, depending on transportation, activities, accommodation and personal expenses.",

    transportation: [
        "Travel to Kampot from Phnom Penh by bus, minivan or private car.",
        "Use a tuk-tuk, taxi or rented motorbike to explore nearby attractions.",
        "Take a local boat for sightseeing along the Kampot River."
    ],

    accommodation: [
        "Budget guesthouses near Kampot town.",
        "Mid-range hotels and riverside resorts.",
        "Boutique hotels and peaceful countryside accommodations."
    ],
    itinerary: [
        {
            time: "8:00 AM",
            activity: "Explore Kampot Town",
            description: "Walk around the town and admire its historical architecture."
        },
        {
            time: "9:30 AM",
            activity: "Visit a Pepper Plantation",
            description: "Learn about Kampot pepper farming and discover local agricultural products."
        },
        {
            time: "11:30 AM",
            activity: "Visit Phnom Chhngok Cave Temple",
            description: "Explore the limestone cave and its ancient temple."
        },
        {
            time: "1:00 PM",
            activity: "Lunch Break",
            description: "Enjoy Cambodian food prepared with locally grown Kampot pepper."
        },
        {
            time: "2:30 PM",
            activity: "Explore Teuk Chhou Rapids",
            description: "Enjoy the natural surroundings and relax beside the freshwater rapids."
        },
        {
            time: "5:00 PM",
            activity: "Kampot River Sunset",
            description: "Take a relaxing riverside walk or enjoy a sunset boat trip."
        }
    ],

    tips: [
        "Bring sunscreen, drinking water and comfortable walking shoes.",
        "Try dishes prepared with authentic Kampot pepper.",
        "Check weather conditions before visiting mountain and cave attractions.",
        "Bring cash for local markets and small businesses.",
        "Respect local communities and agricultural plantations.",
        "Allow enough time to explore attractions outside the town center."
    ]
},

// ===================================
// 9. TONLE SAP LAKE
// ===================================

{
    name: "Tonlé Sap Lake",
    country: "Cambodia",
    category: "Nature & Cultural",
    image: "images/Tonle Sap Lake.jpg",
    budget: 60,

    description: "Tonlé Sap Lake is the largest freshwater lake in Southeast Asia and one of Cambodia's most important natural resources. It is famous for its floating villages, rich biodiversity, fishing communities and unique seasonal changes in water levels.",

    location: "Central Cambodia, connected to the Mekong River",

    history: "Tonlé Sap has supported Cambodian communities for centuries through fishing, transportation and agriculture. Its seasonal connection with the Mekong River creates an unusual natural water-flow system that has played an important role in Cambodia's history and livelihoods.",

    attractions: [
        {
            name: "Kampong Phluk Floating Village",
            description: "Discover traditional stilt houses and experience daily life in a community near the lake."
        },
        {
            name: "Chong Khneas Floating Village",
            description: "Explore a well-known floating village with houses, boats and local businesses."
        },
        {
            name: "Kampong Khleang",
            description: "Visit a traditional lakeside community known for its tall stilt houses and fishing lifestyle."
        },
        {
            name: "Flooded Forest",
            description: "Observe the unique flooded forest ecosystem that provides shelter for wildlife and aquatic species."
        },
        {
            name: "Tonlé Sap Biosphere Reserve",
            description: "Learn about the lake's biodiversity and importance for environmental conservation."
        }
    ],

    reasons: [
        "Discover one of Southeast Asia's largest freshwater lakes.",
        "Experience traditional floating village communities.",
        "Learn about Cambodian fishing traditions and local lifestyles.",
        "Observe unique wildlife and natural ecosystems.",
        "Understand the importance of Tonlé Sap to Cambodia's environment and economy."
    ],

    bestTime: {
        season: "November to February",
        weather: "The cooler dry season is generally comfortable for sightseeing, while water levels and scenery change throughout the year.",
        recommendation: "Visit during the wet season if you want to see higher water levels and flooded forests, or during the dry season for a different view of the lake and its communities. Check local boat conditions before travelling."
    },

    specialExperience: {
        title: "Explore the Floating Villages of Tonlé Sap",
        experience: "Take a guided boat trip through a floating or stilt-house village, observe local fishing activities and discover how communities adapt to the lake's changing water levels.",
        culturalSignificance: "Tonlé Sap supports the livelihoods of many Cambodian communities. Fishing traditions, floating homes and seasonal lifestyles reflect the close relationship between people and the lake.",
        recommendation: "Choose responsible local tour operators, respect residents' privacy and avoid disturbing wildlife or damaging the natural environment."
    },

    budgetDetails: [
        { item: "Local transportation", cost: "$5–15" },
        { item: "Boat tour", cost: "$10–25" },
        { item: "Food and drinks", cost: "$5–10" },
        { item: "Other expenses", cost: "$5–10" }
    ],

    budgetNote: "Estimated visit budget: approximately $25–60 per person, depending on the village visited, boat arrangements, transportation and personal expenses.",

    transportation: [
        "Travel to Siem Reap by bus, minivan, car or plane.",
        "Use a tuk-tuk, taxi or local transportation to reach the selected lakeside village.",
        "Arrange a local boat tour to explore the lake and floating communities."
    ],

    accommodation: [
        "Budget guesthouses in Siem Reap town.",
        "Mid-range hotels near the city center.",
        "Luxury hotels and resorts around Siem Reap."
    ],

    itinerary: [
        {
            time: "8:00 AM",
            activity: "Travel to the Lakeside Village",
            description: "Travel from Siem Reap to your selected Tonlé Sap village."
        },
        {
            time: "9:00 AM",
            activity: "Explore the Floating Village",
            description: "Discover traditional houses, boats and community activities."
        },
        {
            time: "10:00 AM",
            activity: "Take a Boat Tour",
            description: "Enjoy a guided journey through the village and surrounding waterways."
        },
        {
            time: "11:00 AM",
            activity: "Discover the Local Lifestyle",
            description: "Learn about fishing traditions and how residents adapt to seasonal water changes."
        },
        {
            time: "12:00 PM",
            activity: "Lunch Break",
            description: "Enjoy a meal at a local restaurant or return toward Siem Reap."
        },
        {
            time: "1:30 PM",
            activity: "Return to Siem Reap",
            description: "Travel back and enjoy the remaining afternoon at your own pace."
        }
    ],

    tips: [
        "Bring sunscreen, drinking water and a hat.",
        "Wear comfortable clothing suitable for warm weather.",
        "Check water levels and boat availability before visiting.",
        "Respect local residents and ask permission before taking photographs.",
        "Choose responsible boat operators and local guides.",
        "Avoid leaving rubbish in the lake or surrounding waterways."
    ]
},

// ===================================
// 10. BOKOR NATIONAL PARK
// ===================================

    {
    name: "Bokor National Park",
    country: "Cambodia",
    category: "Nature & Historical",
    image: "images/Bokor National Park.jpg",
    budget: 65,

    description: "Bokor National Park is a beautiful mountain destination in Kampot Province, Cambodia. It is known for its cool climate, green forests, scenic viewpoints, waterfalls and historical French colonial buildings. The park offers visitors a combination of natural beauty and cultural history.",

    location: "Kampot Province, southern Cambodia",

    history: "Bokor became a mountain resort during the French colonial period in the early 20th century. Historical structures, including the old Bokor Palace Hotel and Catholic Church, remain important reminders of its past. Today, the area is part of a protected national park.",

    attractions: [
        {
            name: "Bokor Palace",
            description: "Discover the historic hilltop hotel building associated with Bokor's colonial-era resort history."
        },
        {
            name: "Old Catholic Church",
            description: "Visit a historic church surrounded by mountain scenery and misty landscapes."
        },
        {
            name: "Popokvil Waterfall",
            description: "Enjoy a scenic waterfall surrounded by forest, especially during the rainy season."
        },
        {
            name: "Bokor Mountain Viewpoints",
            description: "Admire panoramic views of the surrounding countryside and coastline."
        },
        {
            name: "Lok Yeay Mao Monument",
            description: "See the large monument dedicated to a respected figure in Cambodian folklore."
        }
    ],

    reasons: [
        "Enjoy cooler mountain weather and fresh air.",
        "Explore beautiful forests and natural landscapes.",
        "Discover historical buildings from the colonial period.",
        "Visit waterfalls and scenic viewpoints.",
        "Experience one of southern Cambodia's well-known nature destinations."
    ],

    bestTime: {
        season: "November to April",
        weather: "The dry season generally offers more convenient conditions for travelling around the mountain, although Bokor can be cool, cloudy or misty.",
        recommendation: "Visit in the morning for better sightseeing opportunities. During the rainy season, waterfalls may be more impressive, but check road and weather conditions."
    },

    specialExperience: {
        title: "Discover the Misty Mountains of Bokor",
        experience: "Travel through the mountain roads, explore historical buildings, visit Popokvil Waterfall and enjoy panoramic views across the surrounding landscape.",
        culturalSignificance: "Bokor's historical buildings reflect its development as a colonial-era mountain resort, while its protected forests and natural habitats contribute to Cambodia's environmental heritage.",
        recommendation: "Bring a light jacket, respect protected areas and avoid entering abandoned or restricted buildings."
    },

    budgetDetails: [
        { item: "Local transportation", cost: "$15–30" },
        { item: "Food and drinks", cost: "$8–12" },
        { item: "Activities and entrance fees", cost: "Check current rates" },
        { item: "Other expenses", cost: "$5–10" }
    ],

    budgetNote: "Estimated visit budget: approximately $35–65 per person, depending on transportation, activities and personal expenses. Confirm current access arrangements and fees before travelling.",

    transportation: [
        "Travel to Kampot from Phnom Penh by bus, minivan or private car.",
        "Continue from Kampot to Bokor Mountain by private car, motorbike or organized tour.",
        "Use suitable transportation and check road conditions before travelling through the mountain."
    ],

    accommodation: [
        "Budget guesthouses in Kampot town.",
        "Mid-range hotels and resorts around Kampot.",
        "Comfortable hotels and boutique accommodations in the surrounding countryside."
    ],

    itinerary: [
        {
            time: "7:00 AM",
            activity: "Travel to Bokor Mountain",
            description: "Begin the journey from Kampot and enjoy the mountain scenery."
        },
        {
            time: "8:30 AM",
            activity: "Visit Bokor Palace",
            description: "Discover the historical building and learn about Bokor's past."
        },
        {
            time: "9:30 AM",
            activity: "Explore the Old Catholic Church",
            description: "Admire the historic structure and surrounding mountain views."
        },
        {
            time: "10:30 AM",
            activity: "Visit Popokvil Waterfall",
            description: "Enjoy the natural surroundings and take photographs."
        },
        {
            time: "12:00 PM",
            activity: "Lunch Break",
            description: "Enjoy a meal and relax during your mountain trip."
        },
        {
            time: "1:30 PM",
            activity: "Explore Mountain Viewpoints",
            description: "Admire the scenery and visit accessible viewpoints before returning."
        }
    ],

    tips: [
        "Bring a light jacket because mountain temperatures can be cooler.",
        "Wear comfortable shoes for walking around natural attractions.",
        "Check weather and road conditions before travelling.",
        "Bring drinking water and sunscreen.",
        "Respect historical structures and protected natural areas.",
        "Avoid entering abandoned or restricted buildings."
    ]
},

// ===================================
// 11. PHNOM KULEN NATIONAL PARK
// ===================================

{
    name: "Phnom Kulen National Park",
    country: "Cambodia",
    category: "Nature & Historical",
    image: "images/Phnom Kulen National Park.jpg",
    budget: 70,

    description: "Phnom Kulen National Park is a sacred mountain destination in Siem Reap Province, Cambodia. It is famous for its beautiful waterfalls, ancient Khmer religious sites, carved riverbed and lush tropical forests. The mountain is also closely connected to the history of the Khmer Empire.",

    location: "Phnom Kulen, Siem Reap Province, Cambodia",

    history: "Phnom Kulen holds an important place in Khmer history. In 802 CE, King Jayavarman II is traditionally associated with the declaration of independence from Java and the beginning of the Angkorian period at Mahendraparvata on Phnom Kulen. The mountain later became an important religious and cultural center.",

    attractions: [
        {
            name: "Phnom Kulen Waterfall",
            description: "Enjoy the beautiful natural waterfall surrounded by tropical forest. Visitors can relax and swim in permitted areas."
        },
        {
            name: "River of a Thousand Lingas",
            description: "Discover ancient Hindu carvings of lingas and religious symbols on the riverbed."
        },
        {
            name: "Preah Ang Thom",
            description: "Visit the sacred site featuring a large reclining Buddha carved into a sandstone rock."
        },
        {
            name: "Mahendraparvata Archaeological Site",
            description: "Learn about the ancient settlement associated with the early history of the Khmer Empire."
        },
        {
            name: "Phnom Kulen Forest",
            description: "Explore the mountain's natural surroundings and appreciate its tropical forest environment."
        }
    ],

    reasons: [
        "Discover an important location in the history of the Khmer Empire.",
        "Enjoy beautiful waterfalls and natural swimming areas.",
        "Explore ancient religious carvings and historical sites.",
        "Visit sacred places that remain important to Cambodian culture.",
        "Experience the peaceful atmosphere of a mountain forest."
    ],

    bestTime: {
        season: "November to April",
        weather: "The dry season generally offers more convenient road and sightseeing conditions. Waterfalls are often fuller during and after the rainy season.",
        recommendation: "Visit early in the morning to explore the mountain comfortably and allow enough time for the waterfalls and historical attractions."
    },

    specialExperience: {
        title: "Discover the Sacred Mountain of the Khmer Empire",
        experience: "Explore the River of a Thousand Lingas, admire the reclining Buddha at Preah Ang Thom and enjoy the refreshing waterfalls surrounded by tropical forest.",
        culturalSignificance: "Phnom Kulen is associated with the early Angkorian period and the reign of King Jayavarman II. Its ancient religious carvings and sacred sites reflect the spiritual and cultural heritage of the Khmer people.",
        recommendation: "Dress respectfully when visiting religious sites, follow local guidance and help protect the ancient carvings and natural surroundings."
    },

    budgetDetails: [
        { item: "Transportation", cost: "$20–35" },
        { item: "Food and drinks", cost: "$8–12" },
        { item: "Activities and entrance fees", cost: "Check current rates" },
        { item: "Other expenses", cost: "$5–10" }
    ],

    budgetNote: "Estimated visit budget: approximately $35–70 per person, depending on transportation, current entrance fees, activities and personal expenses. Confirm visitor access and ticket arrangements before travelling.",

    transportation: [
        "Travel to Siem Reap by bus, minivan, car or plane.",
        "Continue to Phnom Kulen National Park by private car or organized tour.",
        "A suitable vehicle is recommended because the mountain roads can be steep and winding.",
        "Check road access and local travel arrangements before departure."
    ],

    accommodation: [
        "Budget guesthouses in Siem Reap town.",
        "Mid-range hotels near the city center.",
        "Luxury hotels and resorts around Siem Reap."
    ],

    itinerary: [
        {
            time: "7:00 AM",
            activity: "Travel to Phnom Kulen",
            description: "Begin the journey from Siem Reap and enjoy the mountain scenery."
        },
        {
            time: "8:30 AM",
            activity: "Visit the River of a Thousand Lingas",
            description: "Discover the ancient carvings and learn about their religious significance."
        },
        {
            time: "10:00 AM",
            activity: "Explore Preah Ang Thom",
            description: "Visit the sacred reclining Buddha and observe local religious traditions."
        },
        {
            time: "11:30 AM",
            activity: "Enjoy Phnom Kulen Waterfall",
            description: "Relax near the waterfall and swim only in permitted areas."
        },
        {
            time: "1:00 PM",
            activity: "Lunch Break",
            description: "Enjoy a meal and take a break before continuing the visit."
        },
        {
            time: "2:00 PM",
            activity: "Explore the Natural Surroundings",
            description: "Appreciate the forest scenery and prepare for the return journey."
        }
    ],

    tips: [
        "Wear comfortable walking shoes because some paths can be uneven or slippery.",
        "Bring swimwear and a towel if you plan to swim in permitted waterfall areas.",
        "Bring drinking water, sunscreen and insect repellent.",
        "Wear clothing that covers your shoulders and knees when visiting sacred places.",
        "Check current entrance fees, road conditions and visitor access before travelling.",
        "Be careful around wet rocks and strong water currents.",
        "Do not touch, damage or remove ancient carvings and historical objects.",
        "Keep the mountain clean and take all rubbish with you."
    ]
},

// ===================================
// 12. TOUL SLENG GENOCIDE MUSEUM
// ===================================

{
    name: "Tuol Sleng Genocide Museum",
    country: "Cambodia",
    category: "Historical & Educational",
    image: "images/Tuol Sleng Genocide Museum.jpg",
    budget: 25,

    description: "Tuol Sleng Genocide Museum is one of Cambodia's most important historical memorial sites, located in Phnom Penh. Formerly known as Security Prison 21 (S-21), it was used by the Khmer Rouge regime as a detention, interrogation and torture center between 1975 and 1979. Today, the museum preserves historical evidence, photographs, documents and personal stories of the victims. It serves as a place of remembrance, education and reflection, reminding visitors of the importance of peace, humanity and human rights.",

    location: "Street 113, Boeung Keng Kang III, Phnom Penh, Cambodia",

    history: "Before becoming S-21, the site was a school complex consisting of Tuol Sleng Primary School and Tuol Svay Prey High School, built in 1962. After the Khmer Rouge took control of Phnom Penh on April 17, 1975, the school buildings were transformed into a secret security prison known as S-21. Between 1975 and 1979, approximately 15,000 to 20,000 people were imprisoned there, including men, women and children. They were accused of being enemies of the regime, detained, interrogated and subjected to torture. Many prisoners were forced to provide false confessions before being transferred to execution sites, including Choeung Ek. When Phnom Penh was liberated on January 7, 1979, only 12 surviving prisoners were found at S-21, including four children. The prison was subsequently preserved as a memorial and became the Tuol Sleng Genocide Museum, allowing future generations to learn about this tragic period of Cambodian history.",

    attractions: [
        {
            name: "Building A - Former Prison Rooms",
            description: "Explore preserved rooms that reveal how former classrooms were transformed into detention and interrogation spaces during the Khmer Rouge regime."
        },
        {
            name: "Building B - Historical Photographs",
            description: "Discover photographs and records of prisoners that document the identities and experiences of people detained at S-21."
        },
        {
            name: "Building C - Preserved Prison Cells",
            description: "Observe the small prison cells and historical structures preserved to show the conditions in which prisoners were held."
        },
        {
            name: "Building D - Historical Evidence and Artworks",
            description: "Explore historical materials, torture-related evidence and paintings by Vann Nath, a survivor who documented prison life through art."
        },
        {
            name: "Memorial Courtyard",
            description: "Visit the memorial area dedicated to the victims and reflect on the human cost of the Khmer Rouge period."
        },
        {
            name: "Museum Archives and Documents",
            description: "Learn about the preserved photographs, records and documents that provide evidence of the crimes committed at S-21."
        },
        {
            name: "Educational Exhibitions",
            description: "Discover permanent and temporary exhibitions that explain the Khmer Rouge period, the experiences of victims and the importance of remembrance."
        }
    ],

    reasons: [
        "Learn about an important and painful chapter of Cambodian history.",
        "Understand the experiences of victims during the Khmer Rouge regime.",
        "See preserved historical evidence, photographs and documents.",
        "Honor the memory of innocent people who lost their lives.",
        "Understand the importance of peace, human rights and justice.",
        "Help younger generations learn from history and prevent similar tragedies."
    ],

    bestTime: {
        season: "Open throughout the year",
        weather: "The museum is an indoor and outdoor historical site, so it can be visited in both the dry and rainy seasons.",
        recommendation: "Visit in the morning when you have enough time to explore the exhibitions carefully. Allow approximately two to three hours or longer if you want to listen to the audio guide and study the historical materials."
    },

    specialExperience: {
        title: "Remember the Past, Protect the Future",
        experience: "Walk through the preserved school buildings, observe historical photographs and documents, learn about the experiences of former prisoners and visit the memorial area. The museum offers visitors an opportunity to understand Cambodia's past through historical evidence and survivor stories.",
        culturalSignificance: "Tuol Sleng represents an important part of Cambodia's modern history. It preserves the memory of victims of the Khmer Rouge regime and provides historical evidence for education, remembrance and justice. The museum encourages visitors to reflect on human dignity, peace and the responsibility to prevent violence and genocide.",
        recommendation: "Approach the museum with respect and sensitivity. Take time to understand the historical information, remember the victims and reflect on the importance of protecting future generations from similar tragedies."
    },

    budgetDetails: [
        {
            item: "Museum admission",
            cost: "Free for Cambodian citizens; international adult admission currently $5"
        },
        {
            item: "Audio guide",
            cost: "Cambodian visitors $1; non-Cambodian visitors $5"
        },
        {
            item: "Local transportation",
            cost: "$3–10"
        },
        {
            item: "Food and drinks",
            cost: "$5–10"
        },
        {
            item: "Other expenses",
            cost: "$2–5"
        }
    ],

    budgetNote: "Estimated visit budget: approximately $10–25 for Cambodian visitors and $15–30 for international adult visitors, depending on transportation, audio guide use and personal expenses. Confirm current admission and audio guide rates before visiting.",

    transportation: [
        "Travel to Phnom Penh by bus, minivan, private car or plane.",
        "Use a tuk-tuk, taxi or local transportation to reach the museum.",
        "The museum is located on Street 113 in Boeung Keng Kang III, Phnom Penh.",
        "Consider visiting Choeung Ek Genocidal Center separately to learn about another important memorial site connected to Cambodia's history."
    ],

    accommodation: [
        "Budget guesthouses around central Phnom Penh.",
        "Mid-range hotels near BKK1 and the city center.",
        "Hotels and boutique accommodations around Riverside and central Phnom Penh.",
        "Luxury hotels in Phnom Penh for visitors seeking premium accommodation."
    ],

    itinerary: [
        {
            time: "8:30 AM",
            activity: "Arrive at Tuol Sleng Genocide Museum",
            description: "Arrive early, purchase your entry pass and prepare for a respectful visit."
        },
        {
            time: "9:00 AM",
            activity: "Explore the Former Prison Buildings",
            description: "Learn how the former school buildings were transformed into S-21 and observe the preserved rooms."
        },
        {
            time: "9:45 AM",
            activity: "Discover Historical Photographs and Records",
            description: "Explore the photographs and documents that preserve the identities and stories of former prisoners."
        },
        {
            time: "10:30 AM",
            activity: "Learn About the Prison Conditions",
            description: "Observe the preserved cells, historical evidence and survivor artworks while learning about life inside S-21."
        },
        {
            time: "11:15 AM",
            activity: "Visit the Memorial Courtyard",
            description: "Pay respect to the victims and take time for quiet reflection."
        },
        {
            time: "11:45 AM",
            activity: "Educational Reflection",
            description: "Review the historical information and reflect on the importance of peace, justice and human rights."
        },
        {
            time: "12:00 PM",
            activity: "End of Museum Visit",
            description: "Leave respectfully or continue to another historical destination in Phnom Penh."
        }
    ],

    tips: [
        "Approach the museum with respect because it is a memorial site dedicated to victims of the Khmer Rouge regime.",
        "Wear clothing that covers your shoulders and knees.",
        "Allow enough time to read the historical information and understand the exhibitions.",
        "Consider using the audio guide for additional historical explanations.",
        "Be emotionally prepared because some photographs and exhibits contain disturbing historical material.",
        "Speak quietly and behave respectfully throughout the museum.",
        "Follow museum photography rules and avoid taking inappropriate photographs.",
        "Do not touch, remove or damage historical objects and preserved structures.",
        "Respect the privacy and feelings of other visitors.",
        "Consider visiting Choeung Ek Genocidal Center separately for a broader understanding of Cambodia's history.",
        "Bring drinking water and take a break if you feel emotionally overwhelmed.",
        "Remember that this is a place of remembrance and education, not entertainment."
    ]
},

// ===================================
// 13. BOU SRA WATERFALL
// ===================================
{
    name: "Bou Sra Waterfall",
    country: "Cambodia",
    category: "Natural & Cultural",
    image: "images/Bou Sra Waterfall.jpg",
    budget: 55,

    // Overview
    description:
        "Bou Sra Waterfall is one of Cambodia's most famous natural attractions, located in Mondulkiri Province. Surrounded by lush forests and beautiful highland scenery, the waterfall is known for its impressive two-level cascade and peaceful natural environment.",

    location:
        "Pech Chreada District, Mondulkiri Province, Cambodia.",

    history:
        "Bou Sra Waterfall is an important natural landmark of Mondulkiri, a northeastern Cambodian province known for its forests, highlands, and Indigenous communities. The waterfall is closely associated with the Bunong people, one of Cambodia's Indigenous ethnic communities, whose traditional knowledge, customs, and connection to the surrounding natural environment form an important part of the region's cultural identity. Over time, Bou Sra has become a popular destination for visitors interested in Cambodia's natural beauty and cultural heritage.",

    // Main Attractions
    attractions: [
        {
            name: "Upper Waterfall",
            description:
                "Discover the upper section of Bou Sra, where water flows over rocky formations and creates a beautiful natural landscape."
        },
        {
            name: "Lower Waterfall",
            description:
                "Admire the impressive lower cascade, which is known for its powerful flow and scenic surroundings."
        },
        {
            name: "Surrounding Forest",
            description:
                "Explore the green natural environment surrounding the waterfall and enjoy the peaceful atmosphere of Mondulkiri."
        },
        {
            name: "Mondulkiri Highland Scenery",
            description:
                "Experience the cool highland atmosphere, rolling landscapes, and natural beauty that make the province distinctive."
        },
        {
            name: "Local Indigenous Culture",
            description:
                "Learn about the traditions and cultural heritage of the Bunong community while respecting local customs and communities."
        }
    ],

    // Why Should You Visit?
    reasons: [
        "See one of Cambodia's most impressive waterfalls.",
        "Experience the beautiful forests and highland scenery of Mondulkiri.",
        "Enjoy photography and nature exploration.",
        "Learn about the cultural heritage of the Bunong Indigenous community.",
        "Take a relaxing break away from busy city life.",
        "Discover a different side of Cambodia beyond its ancient temples."
    ],

    // Best Time to Visit
    bestTime: {
        season:
            "The rainy season, generally from June to October, offers stronger waterfall flows and greener surroundings. The dry season, generally from November to May, can provide easier travel conditions, although the waterfall may have less water.",

        weather:
            "Mondulkiri generally has a cooler highland climate than many lowland areas of Cambodia. Rainfall can make paths slippery, especially during the wet season.",

        recommendation:
            "Visit during the rainy season if you want to see the waterfall at its most powerful, but check road and weather conditions before travelling. For easier sightseeing, consider visiting during the drier months."
    },

    // Special Experience
    specialExperience: {
        title: "Experience the Power of Cambodia's Highland Nature",

        experience:
            "Stand near the magnificent two-level waterfall, listen to the rushing water, and enjoy the refreshing atmosphere of the surrounding forest. The natural scenery offers visitors an opportunity to appreciate the beauty of Mondulkiri.",

        culturalSignificance:
        "Bou Sra is located in a region closely connected with Bunong Indigenous heritage. The surrounding landscape is part of a wider cultural environment shaped by generations of local knowledge and traditions.",

        recommendation:
            "Take time to appreciate both the upper and lower waterfall areas, follow local safety guidance, and treat the surrounding natural and cultural environment with respect."
    },

    // Estimated Travel Budget
    budgetDetails: [
        {
            item: "Transportation within Mondulkiri",
            cost: "$5–15"
        },
        {
            item: "Food and Drinks",
            cost: "$5–10"
        },
        {
            item: "Entrance and Local Fees",
            cost: "$0–5 (subject to current fees)"
        },
        {
            item: "Other Expenses",
            cost: "$3–5"
        }
    ],

    budgetNote:
        "Estimated spending is approximately $15–35 per person for a simple day visit, excluding long-distance transportation to Mondulkiri and accommodation. Actual costs depend on travel arrangements and current local fees.",

    // Transportation
    transportation: [
        "Private car: A convenient option for travelling from Phnom Penh or Sen Monorom to the waterfall.",
        "Motorbike: Suitable for experienced riders familiar with local roads and changing weather conditions.",
        "Local transportation: Visitors can arrange local transport from Sen Monorom, the provincial capital of Mondulkiri.",
        "Guided tours: Local guides and tour operators may help visitors explore the waterfall and nearby attractions."
    ],

    // Accommodation
    accommodation: [
        "Sen Monorom: A convenient base with guesthouses, hotels, restaurants, and access to other Mondulkiri attractions.",
        "Local Guesthouses: Budget-friendly accommodation for travellers exploring the province.",
        "Nature Lodges: Some accommodation options offer peaceful surroundings and opportunities to experience the highland environment."
    ],

    // Suggested Itinerary
    itinerary: [
        {
            time: "8:00 AM",
            activity: "Depart from Sen Monorom",
            description:
                "Begin the journey toward Bou Sra Waterfall and enjoy the highland scenery along the way."
        },
        {
            time: "9:00 AM",
            activity: "Explore the Upper Waterfall",
            description:
                "Discover the upper cascade, enjoy the natural surroundings, and take photographs from safe viewing areas."
        },
        {
            time: "10:00 AM",
            activity: "Visit the Lower Waterfall",
            description:
                "Continue exploring the lower section and appreciate the powerful flow of water."
        },
        {
            time: "11:30 AM",
            activity: "Enjoy the Natural Environment",
            description:
                "Relax, observe the surrounding forest, and learn about the area's natural and cultural heritage."
        },
        {
            time: "12:30 PM",
            activity: "Lunch and Return Journey",
            description:
                "Enjoy a local meal and prepare for the return journey to Sen Monorom."
        }
    ],

    // Travel Tips
    tips: [
        "Wear comfortable shoes with good grip because paths and rocks can become slippery.",
        "Bring drinking water, sunscreen, and insect repellent.",
        "During the rainy season, check road conditions before travelling.",
        "Stay behind safety barriers and avoid swimming in dangerous or fast-moving water.",
        "Bring a camera to capture the beautiful waterfall and surrounding forest.",
        "Respect Bunong Indigenous culture and local community traditions.",
        "Ask permission before photographing local people.",
        "Avoid leaving rubbish and help protect the natural environment.",
        "Consider spending additional time exploring other attractions in Mondulkiri.",
        "Follow local instructions and respect restricted or environmentally sensitive areas."
    ]
},

// ===================================
// 14. KOH RONG
// ===================================

{
    name: "Koh Rong",
    country: "Cambodia",
    category: "Island & Natural",
    image: "images/Koh Rong.jpg",
    budget: 85,

    // 1. Overview
    description:
        "Koh Rong is one of Cambodia's most famous tropical island destinations, located off the coast of Sihanoukville. Known for its white sandy beaches, turquoise waters, tropical forests, and peaceful coastal scenery, the island offers visitors opportunities for relaxation, adventure, and marine exploration. It is an ideal destination for travelers who want to experience Cambodia's beautiful island environment.",

    location:
        "Koh Rong, Preah Sihanouk Province, southwestern Cambodia.",

    history:
        "Koh Rong is part of Cambodia's southwestern island region in the Gulf of Thailand. Historically, local communities have depended on fishing and other coastal activities for their livelihoods. Over time, the island became increasingly popular among travelers because of its beaches, natural scenery, and marine environment. Tourism has brought new opportunities to the island, while also creating the importance of protecting its natural resources, local communities, and traditional way of life.",

    // 2. Main Attractions
    attractions: [
        {
            name: "Long Set Beach (4K Beach)",
            description:
                "Discover a beautiful stretch of white sand and clear water surrounded by tropical greenery. It is a popular place for swimming, relaxing, and enjoying the island atmosphere."
        },
        {
            name: "Sok San Beach",
            description:
                "Explore a scenic beach on the western side of the island, known for its long shoreline, peaceful atmosphere, and beautiful coastal views."
        },
        {
            name: "Koh Touch",
            description:
                "Visit one of the island's main tourist areas, with restaurants, guesthouses, beach activities, and boat connections."
        },
        {
            name: "Coconut Beach",
            description:
                "Enjoy a quieter coastal setting with beautiful natural scenery, sandy shores, and opportunities to relax by the sea."
        },
        {
            name: "Tropical Forests",
            description:
                "Discover the island's green landscapes and forested areas, which contribute to its natural beauty and biodiversity."
        },
        {
            name: "Marine Life and Coral Areas",
            description:
                "Explore the surrounding marine environment through snorkeling or diving activities, where visitors may encounter colorful fish and coral habitats."
        }
    ],

    // 3. Why Should You Visit?
    reasons: [
        "Experience some of Cambodia's most beautiful tropical beaches.",
        "Enjoy swimming and relaxing in clear coastal waters.",
        "Discover marine life through snorkeling and diving.",
        "Explore tropical forests and scenic island landscapes.",
        "Experience local seafood and island communities.",
        "Enjoy boat trips and other outdoor adventures.",
        "Have the opportunity to observe bioluminescent plankton under suitable conditions.",
        "Experience a peaceful escape from busy city life."
    ],

    // 4. Best Time to Visit
    bestTime: {
        season:
            "The dry season, generally from November to April, is often preferred for island visits because it usually brings sunnier weather and calmer sea conditions. The rainy season, generally from May to October, can bring heavier rainfall and rougher seas.",

        weather:
            "Koh Rong has a tropical coastal climate with warm temperatures throughout the year. Weather and sea conditions can change, especially during the rainy season.",

        recommendation:
        "November to April is generally a good period for beach activities, boat trips, snorkeling, and diving. Check the marine forecast and ferry conditions before travelling."
    },

    // 5. Special Experience
    specialExperience: {
        title: "Discover the Magical Glow of Bioluminescent Plankton",

        experience:
            "One of the fascinating natural experiences around Koh Rong is the possibility of seeing bioluminescent plankton. These tiny marine organisms can produce a beautiful blue glow when disturbed by movement in the water. Under suitable nighttime conditions, visitors may see sparkling blue lights near the shoreline or in darker areas away from artificial lighting.",

        culturalSignificance:
            "Koh Rong represents an important part of Cambodia's coastal and island heritage. Its fishing communities, marine environment, and local way of life contribute to the identity of the southwestern coastal region.",

        recommendation:
            "Consider joining a responsible local boat tour on a dark, clear night when conditions are suitable. Bioluminescence is a natural phenomenon and cannot be guaranteed. Avoid disturbing marine life or using harmful substances."
    },

    // 6. Estimated Travel Budget
    budgetDetails: [
        {
            item: "Ferry Transportation",
            cost: "$15–25"
        },
        {
            item: "Accommodation",
            cost: "$15–30"
        },
        {
            item: "Food and Drinks",
            cost: "$10–15"
        },
        {
            item: "Island Activities",
            cost: "$10–20"
        },
        {
            item: "Other Expenses",
            cost: "$5–10"
        }
    ],

    budgetNote:
        "An estimated budget is approximately $55–100 per person for a simple island trip, depending on ferry prices, accommodation, food, and activities. The estimate does not include transportation from Phnom Penh to Sihanoukville. Actual prices vary by season and service provider.",

    // 7. Transportation
    transportation: [
        "Ferry: Speed ferries connect Sihanoukville with Koh Rong. Departure points and arrival piers depend on the ferry operator and selected destination.",
        "Private Boat: Private boat arrangements may be available for visitors who want more flexible travel.",
        "Walking: Some beaches and nearby accommodation areas can be explored on foot.",
        "Motorbike: Local motorbike transport may be available in certain areas, but road conditions can vary. Ride carefully and follow local guidance.",
        "Boat Transfers: Long-tail boats and local boat services can help visitors reach beaches and areas that are not easily accessible by road."
    ],

    // 8. Accommodation
    accommodation: [
        "Beachfront Resorts: Suitable for visitors who want comfortable accommodation with beautiful coastal views.",
        "Island Bungalows: A popular choice for travelers who enjoy a relaxed tropical atmosphere.",
        "Guesthouses: Budget-friendly options are available around the main tourist areas.",
        "Hostels: Suitable for backpackers and travelers who want to meet other visitors.",
        "Eco-Friendly Stays: Some accommodations emphasize a closer connection with nature and responsible tourism."
    ],

    // 9. Suggested Itinerary
    itinerary: [
        {
            time: "8:00 AM",
            activity: "Ferry Departure",
            description:
                "Depart from Sihanoukville by ferry and enjoy the sea journey toward Koh Rong."
        },
        {
            time: "9:30 AM",
            activity: "Arrive at Koh Rong",
            description:
                "Arrive at the island, check in or leave your luggage at your accommodation, and prepare for the day's activities."
        },
        {
            time: "10:30 AM",
            activity: "Explore Long Set Beach",
            description:
                "Enjoy the beautiful white sand, swim where conditions are safe, and take photographs of the tropical scenery."
        },
        {
            time: "12:00 PM",
            activity: "Lunch by the Beach",
            description:
                "Enjoy fresh seafood or local meals at a restaurant near the beach."
        },
        {
            time: "1:30 PM",
            activity: "Snorkeling and Island Activities",
            description:
                "Join a suitable local activity to discover the surrounding marine environment or enjoy a relaxing afternoon by the sea."
        },
        {
            time: "4:00 PM",
            activity: "Discover Sok San Beach",
            description:
                "Explore another beautiful beach and enjoy the peaceful coastal atmosphere."
        },
        {
            time: "6:00 PM",
            activity: "Enjoy the Sunset",
            description:
                "Find a suitable coastal viewpoint and watch the sunset over the Gulf of Thailand."
        },
        {
            time: "8:00 PM",
            activity: "Optional Nighttime Experience",
            description:
                "Consider a responsible nighttime boat tour to look for bioluminescent plankton when natural conditions are suitable."
        }
    ],

    // 10. Travel Tips
    tips: [
        "Book ferry tickets in advance, especially during weekends and holiday periods.",
        "Check the ferry schedule and departure pier before travelling.",
        "Bring sunscreen, sunglasses, a hat, and enough drinking water.",
        "Pack lightweight clothing, swimwear, and comfortable footwear.",
        "Bring cash because not every local business may accept digital payments or bank cards.",
        "Check weather and sea conditions before joining boat trips or water activities.",
        "Use appropriate safety equipment when snorkeling, swimming, or diving.",
        "Avoid touching coral reefs and disturbing marine animals.",
        "Keep beaches clean and take your rubbish with you.",
        "Respect local fishing communities and ask permission before photographing people.",
        "Be careful when walking on unfamiliar paths, especially after rainfall.",
        "Do not expect bioluminescent plankton to appear every night because visibility depends on natural conditions.",
        "Choose responsible tour operators that care about marine conservation.",
        "Keep important belongings secure and protect electronic devices from water and sand."
    ]
},

// ===================================
// 15. KOH RONG SANLOEM
// ===================================

{
    name: "Koh Rong Sanloem",
    country: "Cambodia",
    category: "Island & Natural",
    image: "images/Koh Rong Sanloem.jpg",
    budget: 80,

    // 1. Overview
    description:
        "Koh Rong Sanloem is a beautiful tropical island located off the coast of Sihanoukville in southwestern Cambodia. Known for its peaceful beaches, clear turquoise waters, tropical forests, and relaxing atmosphere, the island is an ideal destination for visitors seeking a quieter coastal escape. Its natural scenery and laid-back environment make it one of Cambodia's most attractive island destinations.",

    location:
        "Koh Rong Sanloem, Preah Sihanouk Province, southwestern Cambodia.",

    history:
        "Koh Rong Sanloem is part of Cambodia's island region in the Gulf of Thailand. The island has traditionally been connected with coastal fishing communities and the marine environment. As tourism developed along Cambodia's southwestern coast, Koh Rong Sanloem became increasingly popular for its beaches and natural surroundings. Today, the island welcomes visitors while remaining an important example of Cambodia's coastal landscapes and the need to protect marine and forest ecosystems.",

    // 2. Main Attractions
    attractions: [
        {
            name: "Saracen Bay",
            description:
                "Explore the island's best-known beach area, featuring a long sandy shoreline, calm coastal scenery, and accommodation along the bay."
        },
        {
            name: "Lazy Beach",
            description:
                "Discover a scenic beach known for its relaxed atmosphere, natural surroundings, and beautiful sunset views."
        },
        {
            name: "Sunset Beach",
            description:
                "Visit a western-facing coastal area where visitors can enjoy sunset views over the Gulf of Thailand."
        },
        {
            name: "M'Pai Bay",
            description:
                "Experience a local coastal village atmosphere with guesthouses, small restaurants, and access to nearby marine activities."
        },
        {
            name: "Tropical Forest Trails",
            description:
                "Explore the island's forested environment through suitable walking routes while enjoying its natural scenery."
        },
        {
            name: "Marine Environment",
            description:
                "Discover the surrounding sea through responsible snorkeling and diving activities, with opportunities to observe marine life."
        }
    ],

    // 3. Why Should You Visit?
    reasons: [
        "Enjoy peaceful tropical beaches away from busy urban areas.",
        "Experience beautiful turquoise waters and natural coastal scenery.",
        "Relax in a quiet island environment.",
        "Explore beaches and forest trails.",
        "Discover marine life through snorkeling and diving.",
        "Enjoy beautiful sunset views along the western coastline.",
        "Experience local island communities and seafood.",
        "Discover another side of Cambodia's natural heritage."
    ],

    // 4. Best Time to Visit
    bestTime: {
        season:
            "The dry season, generally from November to April, is often preferred for visiting because it usually offers sunnier weather and calmer sea conditions. The rainy season, generally from May to October, may bring heavier rainfall and rougher seas.",

        weather:
            "Koh Rong Sanloem has a warm tropical coastal climate throughout the year. Sea conditions and rainfall can vary depending on the season.",

        recommendation:
            "November to April is generally suitable for beach activities, snorkeling, boat trips, and exploring the island. Always check weather conditions and ferry schedules before travelling."
    },

    // 5. Special Experience
    specialExperience: {
        title: "Find Peace in Cambodia's Tropical Island Paradise",

        experience:
        "Enjoy a peaceful day along the island's beautiful beaches, listen to the sound of the waves, explore the tropical surroundings, and watch the sun set over the sea. Visitors can also join responsible nighttime boat trips for a chance to observe bioluminescent plankton when natural conditions are suitable.",

        culturalSignificance:
            "Koh Rong Sanloem is part of Cambodia's southwestern coastal heritage. Its fishing communities, island environment, and marine ecosystems contribute to the cultural and natural identity of the region.",

        recommendation:
            "Spend time exploring different beaches, respect local communities, and choose environmentally responsible activities to help protect the island's natural beauty."
    },

    // 6. Estimated Travel Budget
    budgetDetails: [
        {
            item: "Ferry Transportation",
            cost: "$15–25"
        },
        {
            item: "Accommodation",
            cost: "$15–30"
        },
        {
            item: "Food and Drinks",
            cost: "$10–15"
        },
        {
            item: "Island Activities",
            cost: "$10–20"
        },
        {
            item: "Other Expenses",
            cost: "$5–10"
        }
    ],

    budgetNote:
        "An estimated budget is approximately $55–100 per person for a simple island trip, depending on ferry tickets, accommodation, food, and activities. This estimate excludes transportation from Phnom Penh to Sihanoukville. Actual prices vary by season and service provider.",

    // 7. Transportation
    transportation: [
        "Ferry: Speed ferries connect Sihanoukville with Koh Rong Sanloem. Check the destination pier and schedule before booking.",
        "Private Boat: Private boat arrangements may be available for visitors seeking flexible travel.",
        "Walking: Several beach areas and nearby accommodations can be explored on foot.",
        "Boat Transfers: Local boats can provide access between certain beaches and coastal areas.",
        "Local Transport: Ask accommodation providers or local operators about available transport options for reaching more distant areas."
    ],

    // 8. Accommodation
    accommodation: [
        "Beachfront Resorts: Suitable for visitors seeking comfortable stays near the beach.",
        "Island Bungalows: Offer a relaxed atmosphere surrounded by tropical scenery.",
        "Guesthouses: Budget-friendly accommodation can be found around M'Pai Bay and other visitor areas.",
        "Eco-Friendly Stays: Some accommodations focus on nature, sustainability, and a quieter island experience.",
        "Small Island Lodges: Suitable for visitors who prefer a peaceful environment and a closer connection with nature."
    ],

    // 9. Suggested Itinerary
    itinerary: [
        {
            time: "8:00 AM",
            activity: "Ferry Departure",
            description:
                "Depart from Sihanoukville and enjoy the sea journey toward Koh Rong Sanloem."
        },
        {
            time: "9:30 AM",
            activity: "Arrive at Saracen Bay",
            description:
                "Arrive at the island, check in or leave your luggage at your accommodation, and prepare to explore."
        },
        {
            time: "10:30 AM",
            activity: "Explore Saracen Bay",
            description:
                "Walk along the sandy beach, enjoy the coastal views, and relax by the water."
        },
        {
            time: "12:00 PM",
            activity: "Lunch by the Sea",
            description:
                "Enjoy fresh seafood or local meals at a restaurant near the beach."
        },
        {
            time: "1:30 PM",
            activity: "Visit Lazy Beach",
            description:
                "Explore the peaceful beach and enjoy the natural surroundings."
        },
        {
            time: "3:30 PM",
            activity: "Discover the Island",
            description:
            "Enjoy a suitable walking route or relax at your chosen beach while appreciating the tropical scenery."
        },
        {
            time: "5:30 PM",
            activity: "Watch the Sunset",
            description:
                "Visit a western-facing beach and enjoy the beautiful sunset over the Gulf of Thailand."
        },
        {
            time: "7:30 PM",
            activity: "Evening Relaxation",
            description:
                "Enjoy dinner and a peaceful evening on the island. Optional nighttime activities depend on local conditions and available tours."
        }
    ],

    // 10. Travel Tips
    tips: [
        "Book ferry tickets in advance, especially during weekends and holidays.",
        "Confirm the correct arrival pier because different services may stop at different parts of the island.",
        "Bring sunscreen, sunglasses, a hat, and drinking water.",
        "Pack lightweight clothing, swimwear, and comfortable walking shoes.",
        "Bring enough cash because payment options may be limited in some areas.",
        "Check the weather and sea conditions before joining boat trips.",
        "Use suitable safety equipment during snorkeling and other water activities.",
        "Avoid touching coral reefs or disturbing marine animals.",
        "Respect local fishing communities and ask permission before taking photographs.",
        "Keep the beaches clean and avoid leaving plastic waste behind.",
        "Use a flashlight when walking along darker paths at night.",
        "Check return ferry schedules before planning your final day.",
        "Choose responsible accommodation and tour operators that care about the environment.",
        "Remember that bioluminescent plankton sightings depend on natural conditions and cannot be guaranteed."
    ]
},

// ===================================
// 16. CENTRAL MARKET (PHSAR THMEY)
// ===================================

{
    name: "Central Market (Phsar Thmey)",
    country: "Cambodia",
    category: "Cultural & Historical",
    image: "images/Central Market.jpg",
    budget: 35,

    // 1. Overview
    description:
        "Central Market, locally known as Phsar Thmey, is one of Phnom Penh's most famous landmarks. Recognized for its impressive yellow Art Deco architecture and large central dome, the market offers visitors a glimpse into Cambodian shopping culture, local products, and everyday life.",

    location:
        "Located in the heart of Phnom Penh, Cambodia, near the city's main commercial and business areas.",

    history:
        "Central Market was completed in 1937 during the French colonial period. Its distinctive Art Deco design and impressive central dome made it one of the most recognizable buildings in Phnom Penh. Over the decades, it has remained an important commercial and cultural landmark, serving both local residents and international visitors.",

    // 2. Main Attractions
    attractions: [
        {
            name: "The Central Dome",
            description:
                "Admire the market's impressive central dome, which forms the architectural centerpiece of the building and connects its surrounding wings."
        },
        {
            name: "Four Market Wings",
            description:
                "Explore the four wings extending from the central structure, filled with shops selling clothing, accessories, souvenirs, and everyday products."
        },
        {
            name: "Jewelry and Gemstone Section",
            description:
                "Discover shops offering gold jewelry, silver accessories, watches, and various decorative items."
        },
        {
            name: "Cambodian Handicrafts and Souvenirs",
            description:
                "Find locally inspired handicrafts, traditional products, handmade accessories, and souvenirs to remember your visit."
        },
        {
            name: "Local Food and Snack Stalls",
            description:
                "Experience Cambodian market food, including local snacks, fresh fruit, drinks, and traditional treats."
        },
        {
            name: "Art Deco Architecture",
            description:
                "Appreciate the market's historic architecture, distinctive geometric details, spacious interior, and recognizable yellow exterior."
        }
    ],

    // 3. Why Should You Visit?
    reasons: [
        "Discover one of Phnom Penh's most recognizable historical landmarks.",
        "Appreciate the unique Art Deco architecture and impressive central dome.",
        "Experience the everyday shopping culture of Cambodia.",
        "Explore local products, handicrafts, jewelry, and traditional souvenirs.",
        "Taste Cambodian snacks and experience local food culture.",
        "Learn how a historic marketplace continues to serve the modern city."
    ],

    // 4. Best Time to Visit
    bestTime: {
        season:
            "November to February is generally a comfortable period to explore Phnom Penh because the weather is usually cooler and drier.",

        weather:
            "Phnom Penh has a tropical climate. The market is indoors, but the surrounding streets can become hot, especially during midday.",

        recommendation:
            "Visit in the morning, around 8:00 AM to 10:00 AM, when you can explore the market more comfortably and experience its daily activities."
    },

    // 5. Special Experience
    specialExperience: {
        title:
            "Discover the Heart of Phnom Penh Through Its Historic Market",

        experience:
            "Walk beneath the magnificent central dome, explore the market's four wings, discover local products, and experience the lively atmosphere of one of Cambodia's most famous marketplaces.",

        culturalSignificance:
        "Central Market represents an important part of Phnom Penh's commercial and social history. It connects Cambodia's architectural heritage with the everyday lives of local people.",

        recommendation:
            "Take time to appreciate the architecture, interact respectfully with local sellers, explore Cambodian products, and try some traditional snacks during your visit."
    },

    // 6. Estimated Travel Budget
    budgetDetails: [
        {
            item: "Transportation",
            cost: "$3–8"
        },
        {
            item: "Food and Drinks",
            cost: "$5–10"
        },
        {
            item: "Shopping and Souvenirs",
            cost: "$5–15"
        },
        {
            item: "Additional Expenses",
            cost: "$2–5"
        }
    ],

    budgetNote:
        "An estimated budget of $15–38 per person for a casual visit. Actual spending depends on transportation, food choices, and shopping preferences. Shopping expenses are optional.",

    // 7. Transportation & Accommodation
    transportation: [
        "Tuk-tuk: A convenient way to reach Central Market from different areas of Phnom Penh.",
        "Ride-hailing services: Visitors can use services such as Grab or PassApp.",
        "Motorbike: A common transportation option for local visitors.",
        "Walking: Visitors staying nearby can explore the surrounding city streets on foot."
    ],

    accommodation: [
        "Luxury Hotels: Several high-end hotels are available in central Phnom Penh.",
        "Mid-Range Hotels: Comfortable accommodation options can be found around the city center.",
        "Budget Guesthouses: Affordable guesthouses and hostels are available for travelers."
    ],

    // 8. Suggested Itinerary
    itinerary: [
        {
            time: "8:00 AM",
            activity: "Arrive at Central Market",
            description:
                "Begin your visit by admiring the famous yellow exterior and historic architecture."
        },
        {
            time: "8:30 AM",
            activity: "Explore the Central Dome",
            description:
                "Walk through the central area and appreciate the impressive dome and architectural design."
        },
        {
            time: "9:00 AM",
            activity: "Explore the Four Market Wings",
            description:
                "Discover clothing, jewelry, accessories, handicrafts, and other local products."
        },
        {
            time: "10:00 AM",
            activity: "Enjoy Cambodian Snacks",
            description:
                "Take a break and try some local food, fresh fruit, or traditional refreshments."
        },
        {
            time: "10:30 AM",
            activity: "Shopping and Souvenir Hunting",
            description:
                "Browse the shops, find memorable souvenirs, and enjoy the lively atmosphere."
        },
        {
            time: "11:00 AM",
            activity: "End Your Visit",
            description:
                "Finish your exploration and continue discovering other attractions around Phnom Penh."
        }
    ],

    // 9. Travel Tips
    tips: [
        "Visit in the morning to enjoy a more comfortable shopping experience.",
        "Bring cash because many small market sellers may not accept cards.",
        "Compare prices between different shops before purchasing items.",
        "Bargaining politely is common in many market stalls.",
        "Keep your phone, wallet, and personal belongings secure in crowded areas.",
        "Ask for permission before taking photographs of sellers or their stalls.",
        "Check the quality of jewelry, gemstones, and other valuable products before buying.",
        "Wear comfortable shoes because you may spend a long time walking around the market.",
        "Stay hydrated, especially when exploring the surrounding streets in hot weather.",
        "Respect local sellers and keep the market clean during your visit."
    ],

    // 10. Additional Information
    additionalInfo:
    "Central Market is more than a shopping destination. It is a historic landmark that reflects Phnom Penh's architectural heritage, commercial development, and local culture. Visitors can experience both the history of the building and the everyday life of the Cambodian community."
}
]