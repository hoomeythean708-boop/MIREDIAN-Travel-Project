/* ===================================
    MIREDIAN MAIN WEBSITE JAVASCRIPT
=================================== */

// ===================================
// 1. FAVORITE DESTINATIONS
// ===================================

function getFavoriteDestinations() {

    return JSON.parse(
        localStorage.getItem("miredianFavorites") || "[]"
    );

}


// ===================================
// 2. DESTINATION CARD GENERATOR
// ===================================

function createDestinationCard(destination) {

    const card = document.createElement("div");

    card.className = "destination-slide";

    const favorites = getFavoriteDestinations();

    const isFavorite = favorites.some(function(place) {

        return place.name === destination.name &&
                place.country === destination.country;

    });

    card.innerHTML =
        '<div class="card h-100 shadow-sm">' +

            '<img src="' + destination.image +
            '" class="card-img-top" alt="' +
            destination.name +
            '" style="height: 220px; object-fit: cover;">' +

            '<div class="card-body d-flex flex-column">' +

                '<div class="d-flex justify-content-between align-items-start">' +

                    '<h5 class="card-title">' +
                    destination.name +
                    '</h5>' +

                    '<button type="button" class="favorite-btn" aria-label="Toggle favorite">' +
                    (isFavorite ? '❤️' : '♡') +
                    '</button>' +

                '</div>' +

                '<p class="text-muted">' +
                destination.country +
                '</p>' +

                '<p class="card-text">' +
                destination.description +
                '</p>' +

                '<p><strong>Category:</strong> ' +
                destination.category +
                '</p>' +

                '<p><strong>Estimated Budget:</strong> $' +
                destination.budget +
                '</p>' +

                '<button class="btn btn-primary view-details-btn mt-auto">' +
                'View Details' +
                '</button>' +

            '</div>' +
        '</div>';

    // Favorite Button
    const favoriteButton = card.querySelector(".favorite-btn");

    favoriteButton.addEventListener("click", function() {

        let savedFavorites = getFavoriteDestinations();

        const existingIndex = savedFavorites.findIndex(function(place) {

            return place.name === destination.name &&
                    place.country === destination.country;

        });

        if (existingIndex !== -1) {

            savedFavorites.splice(existingIndex, 1);

            favoriteButton.textContent = "♡";

        } else {

            savedFavorites.push(destination);

            favoriteButton.textContent = "❤️";

        }

        localStorage.setItem(
            "miredianFavorites",
            JSON.stringify(savedFavorites)
        );

    });


    // View Details Button
    const detailsButton = card.querySelector(".view-details-btn");

    detailsButton.addEventListener("click", function() {

        window.location.href =
            "destination-detail.html?name=" +
            encodeURIComponent(destination.name);

    });

    return card;

}


// ===================================
// 3. DISPLAY DESTINATIONS
// ===================================

function displayDestinations(destinationArray, containerId) {

    const container = document.getElementById(containerId);

    if (!container) {
        console.error(containerId + " container not found!");
        return;
    }

    container.innerHTML = "";

    if (!destinationArray || destinationArray.length === 0) {

        container.innerHTML =
            "<p>No destinations available yet.</p>";

        return;
    }

    destinationArray.forEach(function(destination) {

        const card = createDestinationCard(destination);

        container.appendChild(card);

    });
}


// ===================================
// 4. POPULAR DESTINATIONS 2026
// ===================================

// Only destinations marked popular: true
// will appear in this section.

const popularDestinations = allDestinations.filter(function(destination) {

    return destination.popular === true;

});

displayDestinations(
    popularDestinations,
    "popular-destination-list"
);


// ===================================
// 5. CAMBODIA
// ===================================

displayDestinations(
    destinations.slice(0,10),
    "cambodia-destination-list"
);


// ===================================
// 6. SOUTHEAST ASIA
// ===================================

displayDestinations(
    southeastAsiaDestinations.slice(0,10),
    "southeast-asia-destination-list"
);


// ===================================
// 7. EAST ASIA
// ===================================

displayDestinations(
    eastAsiaDestinations.slice(0,10),
    "east-asia-destination-list"
);


// ===================================
// 8. SOUTH-WEST ASIA
// ===================================

displayDestinations(
    southWestAsiaDestinations.slice(0,10),
    "south-west-asia-destination-list"
);


// ===================================
// 9. EUROPE
// ===================================

displayDestinations(
    europeDestinations.slice(0,10),
    "europe-destination-list"
);


// ===================================
// 10. AFRICA
// ===================================

displayDestinations(
    africaDestinations.slice(0,10),
    "africa-destination-list"
);


// ===================================
// 11. NORTH AMERICA
// ===================================

displayDestinations(
    northAmericaDestinations.slice(0,10),
    "north-america-destination-list"
);


// ===================================
// 12. SOUTH AMERICA
// ===================================

displayDestinations(
    southAmericaDestinations.slice(0,10),
    "south-america-destination-list"
);


// ===================================
// 13. OCEANIA
// ===================================

displayDestinations(
    oceaniaDestinations.slice(0,10),
    "oceania-destination-list"
);

// ===================================
// 14. DESTINATION CAROUSEL ARROWS
// ===================================

document.querySelectorAll(".carousel-control").forEach(function(button) {

    button.addEventListener("click", function() {

        const targetId = button.getAttribute("data-target");
        const track = document.getElementById(targetId);

        if (!track) return;

        const firstCard = track.querySelector(".destination-slide");

        if (!firstCard) return;

        const cardWidth = firstCard.offsetWidth;
        const gap = 24;

        const direction = button.classList.contains("next") ? 1 : -1;

        track.scrollBy({
            left: direction * (cardWidth + gap),
            behavior: "smooth"
        });

    });

});