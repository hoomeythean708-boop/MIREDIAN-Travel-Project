/* ===================================
    DESTINATION DETAIL JAVASCRIPT
=================================== */

// Get destination name from URL
const params = new URLSearchParams(window.location.search);
const destinationName = params.get("name");

// Find selected destination
const destination = allDestinations.find(function(place) {
    return place.name === destinationName;
});
// Display destination information
function displayDestinationDetails() {

    if (!destination) {
        document.getElementById("destination-header").innerHTML =
            "<h1>Destination Not Found</h1>";
        return;
    }

    // Destination header
    document.getElementById("destination-name").textContent =
        destination.name;

    document.getElementById("destination-country").textContent =
        destination.location + " | " + destination.country;

    // Destination image
    document.getElementById("destination-image").src =
        destination.image;

    document.getElementById("destination-image").alt =
        destination.name;

    // 1. Overview
    document.getElementById("destination-overview").innerHTML =
        "<p>" + destination.description + "</p>" +
        "<p>" + destination.history + "</p>";

    // 2. Main Attractions
    document.getElementById("destination-attractions").innerHTML =
        destination.attractions.map(function(place) {
            return (
                "<div class='mb-3'>" +
                    "<h5>" + place.name + "</h5>" +
                    "<p>" + place.description + "</p>" +
                "</div>"
            );
        }).join("");

    // 3. Why Visit?
    document.getElementById("destination-reasons").innerHTML =
        "<ul>" +
        destination.reasons.map(function(reason) {
            return "<li>" + reason + "</li>";
        }).join("") +
        "</ul>";

    // 4. Best Time to Visit
    document.getElementById("destination-best-time").innerHTML =
        "<p><strong>Recommended season:</strong> " +
        destination.bestTime.season + "</p>" +
        "<p><strong>Weather:</strong> " +
        destination.bestTime.weather + "</p>" +
        "<p><strong>Recommendation:</strong> " +
        destination.bestTime.recommendation + "</p>";

    // Special Experience
    if (destination.specialExperience) {

        const special = destination.specialExperience;

        if (special.dates && special.time) {
            document.getElementById("destination-special").innerHTML =
                "<h4>" + special.title + "</h4>" +
                "<p><strong>Dates:</strong> " + special.dates + "</p>" +
                "<p><strong>Time:</strong> " + special.time + "</p>" +
                "<p>" + special.description + "</p>" +
                "<p><strong>Recommendation:</strong> " +
                special.recommendation + "</p>";

        } else {
            document.getElementById("destination-special").innerHTML =
                "<h4>" + special.title + "</h4>" +
                "<p>" + special.experience + "</p>" +
                "<p><strong>Cultural Significance:</strong> " +
                special.culturalSignificance + "</p>" +
                "<p><strong>Recommendation:</strong> " +
                special.recommendation + "</p>";
        }

    } else {
        document.getElementById("special-experience-section").style.display = "none";
    }
    // 5. Estimated Budget
    document.getElementById("destination-budget").innerHTML =
        "<ul>" +
        destination.budgetDetails.map(function(item) {
            return (
                "<li><strong>" + item.item +
                ":</strong> " + item.cost + "</li>"
            );
        }).join("") +
        "</ul>" +
        "<p><strong>" + destination.budgetNote + "</strong></p>";

    // 6. Transportation and Accommodation
    document.getElementById("destination-stay").innerHTML =
        "<h5>Transportation</h5>" +
        "<ul>" +
        destination.transportation.map(function(item) {
            return "<li>" + item + "</li>";
        }).join("") +
        "</ul>" +
        "<h5>Accommodation</h5>" +
        "<ul>" +
        destination.accommodation.map(function(item) {
            return "<li>" + item + "</li>";
        }).join("") +
        "</ul>";

    // 7. Suggested Itinerary
    document.getElementById("destination-itinerary").innerHTML =
        destination.itinerary.map(function(item) {
            return (
                "<div class='mb-3'>" +
                    "<h5>" + item.time + " - " +
                    item.activity + "</h5>" +
                    "<p>" + item.description + "</p>" +
                "</div>"
            );
        }).join("");

    // 8. Travel Tips
    document.getElementById("destination-tips").innerHTML =
        "<ul>" +
        destination.tips.map(function(tip) {
            return "<li>" + tip + "</li>";
        }).join("") +
        "</ul>";
}

// Run function
displayDestinationDetails();