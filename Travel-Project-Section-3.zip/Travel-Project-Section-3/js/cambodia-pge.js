// ===================================
// CAMBODIA DESTINATION PAGE
// ===================================

const cambodiaContainer = document.getElementById(
    "cambodia-destination-list"
);

if (cambodiaContainer) {

    destinations.forEach(function(destination) {

        const card = document.createElement("div");

        card.className = "col-lg-6 col-md-6 mb-4";

        card.innerHTML = `
            <div class="card h-100 shadow-sm">
                <img src="${destination.image}"
                    class="card-img-top"
                    alt="${destination.name} in ${destination.country}"
                    style="height: 220px; object-fit: cover;">

                <div class="card-body d-flex flex-column">
                    <h5 class="card-title">${destination.name}</h5>

                    <p class="text-muted">${destination.country}</p>

                    <p class="card-text">${destination.description}</p>

                    <p><strong>Category:</strong> ${destination.category}</p>

                    <p><strong>Estimated Budget:</strong> $${destination.budget}</p>

                    <button class="btn btn-primary mt-auto"
                            onclick="window.location.href='destination-detail.html?name=${encodeURIComponent(destination.name)}'">
                        View Details
                    </button>
                </div>
            </div>
        `;

        cambodiaContainer.appendChild(card);

    });

}