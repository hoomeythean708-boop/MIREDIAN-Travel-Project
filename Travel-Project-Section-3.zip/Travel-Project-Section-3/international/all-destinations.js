// ===================================
// ALL MIREDIAN DESTINATIONS
// ===================================

const allDestinations = [
    ...destinations,

    ...southeastAsiaDestinations,
    ...eastAsiaDestinations,
    ...southWestAsiaDestinations,
    ...europeDestinations,
    ...africaDestinations,
    ...northAmericaDestinations,
    ...southAmericaDestinations,
    ...oceaniaDestinations
];