// ===================================
// SOUTH-WEST ASIA
// ===================================

const southWestAsiaDestinations = [

    // ===================================
    // I. UNITED ARAB EMIRATES
    // ===================================

    // ===================================
    // 1. BURJ KHALIFA
    // ===================================


    {
        name: "Burj Khalifa",
        country: "United Arab Emirates",
        category: "Architecture & Modern Landmark",
        image: "images/Burj Khalifa.jpg",
        budget: 120,
        featured: true,

        // 1. Overview
        description: "Burj Khalifa is the tallest building in the world and one of Dubai's most famous landmarks. Rising above the city's skyline, this extraordinary skyscraper offers luxury experiences, observation decks, restaurants, and breathtaking views of Dubai.",

        // 2. Location
        location: "Downtown Dubai, Dubai, United Arab Emirates",

        // 3. History
        history: "Construction of Burj Khalifa began in 2004, and the building officially opened in January 2010. Designed by architect Adrian Smith, it was developed as part of Dubai's vision to become a leading international destination for tourism, business, and innovation.",

        // 4. Attractions
        attractions: [
            {
                name: "At the Top",
                description: "Visit the observation decks on levels 124 and 125 for spectacular views of Dubai."
            },
            {
                name: "At the Top SKY",
                description: "Experience a premium observation area on level 148 with impressive panoramic scenery."
            },
            {
                name: "The Dubai Fountain",
                description: "Watch spectacular choreographed fountain performances near the base of the tower."
            },
            {
                name: "Burj Khalifa Park",
                description: "Relax in the landscaped outdoor area surrounding the famous skyscraper."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "See the tallest building in the world.",
            "Enjoy incredible panoramic views of Dubai.",
            "Experience modern architecture and engineering.",
            "Watch the famous Dubai Fountain performances.",
            "Explore one of the city's most popular shopping and entertainment districts."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "November to March",
            weather: "Cooler and more comfortable weather for sightseeing and outdoor activities.",
            recommendation: "Visit in the late afternoon to enjoy daylight views and the beautiful city skyline after sunset."
        },

        // 7. Special Experience
        specialExperience: {
            title: "The World's Tallest Building Experience",
            experience: "Ride high-speed elevators to the observation decks and admire Dubai from extraordinary heights.",
            culturalSignificance: "Burj Khalifa represents Dubai's ambition, innovation, and transformation into a global city.",
            recommendation: "Book observation deck tickets in advance and consider visiting around sunset."
        },

        // 8. Budget Details
        budgetDetails: [
            {
                item: "Observation Deck Ticket",
                cost: "$45–60"
            },
            {
                item: "Food and Drinks",
                cost: "$20–25"
            },
            {
                item: "Transportation",
                cost: "$10–15"
            },
            {
                item: "Shopping and Extras",
                cost: "$15–20"
            }
        ],

        budgetNote: "Estimated budget is approximately $120 per person, depending on ticket selection, dining, and shopping choices.",

        // 9. Transportation
        transportation: [
            "Take the Dubai Metro Red Line to Burj Khalifa/Dubai Mall Station.",
            "Use connecting walkways to reach Dubai Mall and Burj Khalifa.",
            "Take taxis or ride-hailing services for convenient transportation around Downtown Dubai."
        ],

        // 10. Accommodation
        accommodation: [
            "Luxury hotels in Downtown Dubai with views of Burj Khalifa.",
            "Mid-range hotels near Business Bay and Dubai Mall.",
            "Budget hotels near Dubai Metro stations for convenient access."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "9:00 AM",
                activity: "Arrive at Burj Khalifa",
                description: "Explore the surrounding area and admire the impressive skyscraper."
            },
            {
                time: "10:00 AM",
                activity: "Visit the Observation Deck",
                description: "Enjoy panoramic views of Dubai from above."
            },
            {
                time: "12:00 PM",
                activity: "Lunch at Dubai Mall",
                description: "Enjoy a meal and explore the nearby shopping complex."
            },
            {
                time: "2:00 PM",
                activity: "Explore Downtown Dubai",
                description: "Discover the surrounding attractions and beautiful architecture."
            },
            {
                time: "4:30 PM",
                activity: "Enjoy the Sunset View",
                description: "Return to the observation area to admire the changing skyline."
            },
            {
                time: "6:30 PM",
                activity: "Watch Dubai Fountain",
                description: "Enjoy the spectacular fountain show near the tower."
            },
            {
                time: "8:00 PM",
                activity: "Evening Sightseeing",
                description: "Take photographs of Burj Khalifa illuminated against the night sky."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Book observation deck tickets in advance.",
            "Visit during sunset for beautiful city views.",
            "Arrive early to allow time for security and ticket checks.",
            "Use the Dubai Metro to avoid busy road traffic.",
            "Wear comfortable shoes when exploring Downtown Dubai.",
            "Check observation deck opening hours before visiting.",
            "Bring a camera for photographs of the skyline.",
            "Allow extra time to explore Dubai Mall and nearby attractions."
        ]
    },

    // ===================================
    // 2. SHEIKH ZAYED GRAND MOSQUE
    // ===================================

    {
        name: "Sheikh Zayed Grand Mosque",
        country: "United Arab Emirates",
        category: "Culture & Religious Architecture",
        image: "images/Sheikh Zayed Grand Mosque.jpg",
        budget: 65,
        featured: false,

        // 1. Overview
        description: "Sheikh Zayed Grand Mosque is one of the largest and most beautiful mosques in the world, located in Abu Dhabi. Famous for its white marble architecture, elegant domes, reflective pools, and magnificent interior decorations, it is an important symbol of Islamic culture and the UAE's heritage.",

        // 2. Location
        location: "Abu Dhabi, United Arab Emirates",

        // 3. History
        history: "The mosque was commissioned by Sheikh Zayed bin Sultan Al Nahyan, the founding father of the United Arab Emirates. Construction began in 1996, and the mosque officially opened in 2007. It was designed to reflect Islamic architectural traditions while welcoming visitors from different backgrounds.",

        // 4. Attractions
        attractions: [
            {
                name: "Grand Courtyard",
                description: "Admire the enormous marble courtyard decorated with beautiful floral designs."
            },
            {
                name: "Main Prayer Hall",
                description: "Discover the magnificent interior featuring an enormous chandelier and intricate decorations."
            },
            {
                name: "Reflective Pools",
                description: "Enjoy peaceful views of the mosque reflected beautifully in the surrounding pools."
            },
            {
                name: "Marble Architecture",
                description: "Explore elegant domes, columns, and detailed Islamic artistic designs."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Admire one of the world's most impressive mosques.",
            "Experience beautiful Islamic architecture and artistic details.",
            "Learn about the cultural and religious heritage of the UAE.",
            "Capture stunning photographs of the white marble buildings.",
            "Enjoy a peaceful and meaningful cultural experience."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "November to March",
            weather: "Cooler temperatures make sightseeing more comfortable.",
            recommendation: "Visit in the late afternoon to admire the architecture during daylight and enjoy its beautiful evening illumination."
        },

        // 7. Special Experience
        specialExperience: {
            title: "A Journey Through Islamic Architecture",
            experience: "Walk through the magnificent courtyard and prayer hall while discovering the mosque's artistic decorations and peaceful atmosphere.",
            culturalSignificance: "The mosque represents Islamic values, cultural understanding, and the vision of Sheikh Zayed for a welcoming and inclusive UAE.",
            recommendation: "Join a guided cultural tour to learn more about the mosque's history, architecture, and traditions."
        },

        // 8. Budget Details
        budgetDetails: [
            {
                item: "General Admission",
                cost: "Free"
            },
            {
                item: "Food and Drinks",
                cost: "$10–15"
            },
            {
                item: "Transportation",
                cost: "$15–25"
            },
            {
                item: "Optional Tour and Extras",
                cost: "$10–20"
            }
        ],

        budgetNote: "Estimated budget is approximately $65 per person for transportation, food, and optional activities. General visitor admission is free, subject to entry arrangements.",

        // 9. Transportation
        transportation: [
            "Take a taxi or ride-hailing service from central Abu Dhabi.",
            "Use public buses serving the mosque area and nearby attractions.",
            "Travel by car from Dubai to Abu Dhabi using the main highway."
        ],

        // 10. Accommodation
        accommodation: [
            "Luxury hotels in central Abu Dhabi for convenient sightseeing.",
            "Mid-range hotels near the Corniche and city center.",
            "Budget hotels and guesthouses in accessible areas of Abu Dhabi."
        ],
        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "9:00 AM",
                activity: "Arrive at the Mosque",
                description: "Begin your visit and admire the impressive exterior architecture."
            },
            {
                time: "10:00 AM",
                activity: "Explore the Grand Courtyard",
                description: "Discover the beautiful marble courtyard and decorative designs."
            },
            {
                time: "11:00 AM",
                activity: "Visit the Main Prayer Hall",
                description: "Admire the chandeliers, carpets, and detailed interior decorations."
            },
            {
                time: "12:30 PM",
                activity: "Lunch Break",
                description: "Enjoy a meal at a nearby restaurant."
            },
            {
                time: "2:00 PM",
                activity: "Learn About the Mosque",
                description: "Discover its history and cultural significance through a guided visit."
            },
            {
                time: "4:30 PM",
                activity: "Photography and Sightseeing",
                description: "Capture beautiful photographs of the architecture and reflective pools."
            },
            {
                time: "6:00 PM",
                activity: "Enjoy the Evening View",
                description: "Admire the mosque's elegant appearance as the evening lights illuminate it."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Check visitor opening hours before your visit.",
            "Dress modestly and follow the mosque's clothing requirements.",
            "Women should bring suitable clothing and a head covering.",
            "Remove shoes when required before entering prayer areas.",
            "Respect worshippers and maintain a quiet atmosphere.",
            "Book a guided tour if you want to learn more about its history.",
            "Avoid visiting during restricted prayer times.",
            "Follow photography rules and staff instructions."
        ]
    },

    // ===================================
    // 3. PALM JUMEIRAH
    // ===================================

    {
        name: "Palm Jumeirah",
        country: "United Arab Emirates",
        category: "Architecture & Island Destination",
        image: "images/Palm Jumeirah.jpg",
        budget: 110,
        featured: false,

        // 1. Overview
        description: "Palm Jumeirah is a world-famous artificial island in Dubai, designed in the shape of a palm tree. Known for its luxurious resorts, beautiful beaches, waterfront restaurants, and impressive architecture, it is one of the city's most recognizable destinations.",

        // 2. Location
        location: "Dubai, United Arab Emirates",

        // 3. History
        history: "Palm Jumeirah was developed by Nakheel as part of Dubai's major coastal development projects. Construction began in 2001, creating an artificial island that expanded the city's coastline and became an internationally recognized tourism destination.",

        // 4. Main Attractions
        attractions: [
            {
                name: "Atlantis The Palm",
                description: "Visit the iconic resort known for its impressive architecture, restaurants, entertainment, and water attractions."
            },
            {
                name: "The View at The Palm",
                description: "Enjoy panoramic views of Palm Jumeirah and the surrounding Dubai skyline from an observation deck."
            },
            {
                name: "Palm West Beach",
                description: "Relax along a beautiful waterfront area featuring beach activities, restaurants, and stunning sea views."
            },
            {
                name: "Palm Jumeirah Boardwalk",
                description: "Take a relaxing walk along the waterfront and enjoy views of the Arabian Gulf and Dubai's coastline."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "See one of the world's most famous artificial islands.",
            "Enjoy beautiful beaches and waterfront scenery.",
            "Experience luxury resorts and exciting entertainment.",
            "Discover impressive engineering and modern architecture.",
            "Capture memorable photographs of Dubai's coastline."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "November to March",
            weather: "The cooler winter months offer comfortable temperatures for outdoor activities and beach visits.",
            recommendation: "Visit in the afternoon and stay until sunset to enjoy beautiful coastal views."
        },

        // 7. Special Experience
        specialExperience: {
            title: "Enjoy the Palm Island Experience",
            experience: "Explore the island, enjoy waterfront dining, relax at the beach, and admire the impressive view of Palm Jumeirah from above.",
            culturalSignificance: "Palm Jumeirah represents Dubai's ambition, modern engineering, and development as an international tourism destination.",
            recommendation: "Visit The View at The Palm for a memorable panoramic experience."
        },

        // 8. Estimated Budget
        budgetDetails: [
            {
                item: "Food and Drinks",
                cost: "$25"
            },
            {
                item: "Transportation",
                cost: "$20"
            },
            {
                item: "Attraction Tickets",
                cost: "$45"
            },
            {
                item: "Shopping and Extra Activities",
                cost: "$20"
            }
        ],

        budgetNote: "The estimated daily budget is around $110 per person, depending on transportation, dining choices, and selected attractions.",

        // 9. Transportation
        transportation: [
            "Use the Dubai Tram to reach areas connected to Palm Jumeirah.",
            "Take the Palm Monorail to travel between selected island attractions.",
            "Use taxis or ride-hailing services for convenient transportation around the island."
        ],

        // 10. Accommodation
        accommodation: [
            "Luxury beachfront resorts on Palm Jumeirah.",
            "Mid-range hotels around Dubai Marina and Jumeirah Beach Residence.",
            "Budget hotels in other parts of Dubai with transportation connections to the island."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "9:00 AM",
                activity: "Arrive at Palm Jumeirah",
                description: "Begin your visit by exploring the island and enjoying its impressive surroundings."
            },
            {
                time: "10:00 AM",
                activity: "Visit The View at The Palm",
                description: "Admire panoramic views of the island and Dubai's skyline."
            },
            {
                time: "11:30 AM",
                activity: "Explore Atlantis The Palm",
                description: "Discover the famous resort and its surrounding attractions."
            },
            {
                time: "12:30 PM",
                activity: "Lunch by the Waterfront",
                description: "Enjoy a relaxing meal at one of the island's restaurants."
            },
            {
                time: "2:00 PM",
                activity: "Relax at Palm West Beach",
                description: "Enjoy the beach atmosphere and beautiful coastal views."
            },
            {
                time: "4:30 PM",
                activity: "Walk Along the Boardwalk",
                description: "Take photographs and enjoy the peaceful waterfront scenery."
            },
            {
                time: "6:00 PM",
                activity: "Enjoy Sunset",
                description: "Finish the day with a beautiful sunset and dinner near the water."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Visit between November and March for more comfortable weather.",
            "Check attraction ticket prices before your visit.",
            "Use the Palm Monorail to explore selected areas of the island.",
            "Bring sunscreen, sunglasses, and drinking water.",
            "Wear comfortable shoes for walking.",
            "Respect beach rules and local customs.",
            "Book popular attractions in advance when possible.",
            "Visit during sunset for beautiful photographs."
        ]
    },

    // ===================================
    // 4. LOUVRE ABU DHABI
    // ===================================

    {
        name: "Louvre Abu Dhabi",
        country: "United Arab Emirates",
        category: "Art, Culture & Museum",
        image: "images/Louvre Abu Dhabi.jpg",
        budget: 85,
        featured: false,

        // 1. Overview
        description: "Louvre Abu Dhabi is a remarkable art and civilization museum located on Saadiyat Island. Known for its impressive architecture and beautiful floating dome, the museum brings together artworks and historical objects from different cultures and civilizations around the world.",

        // 2. Location
        location: "Saadiyat Island, Abu Dhabi, United Arab Emirates",

        // 3. History
        history: "Louvre Abu Dhabi opened in 2017 as a cultural project between the United Arab Emirates and France. Designed by architect Jean Nouvel, the museum was created to connect different cultures through art, history, and shared human experiences.",

        // 4. Main Attractions
        attractions: [
            {
                name: "The Floating Dome",
                description: "Admire the museum's enormous geometric dome, which creates a beautiful rain of light known as the Rain of Light."
            },
            {
                name: "Museum Galleries",
                description: "Explore artworks and historical collections that represent different civilizations and periods throughout human history."
            },
            {
                name: "Outdoor Waterfront Area",
                description: "Enjoy peaceful views of the Arabian Gulf while walking around the museum's beautiful waterfront spaces."
            },
            {
                name: "Children's Museum",
                description: "Discover interactive exhibitions and creative activities designed especially for younger visitors."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Experience one of the most impressive cultural museums in the Middle East.",
            "Admire unique architecture designed by Jean Nouvel.",
            "Discover artworks and objects from different civilizations.",
            "Enjoy beautiful photography opportunities under the famous dome.",
            "Learn about the connections between cultures and human history."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "November to March",
            weather: "Cooler temperatures make exploring Abu Dhabi more comfortable.",
            recommendation: "Visit in the morning or afternoon to explore the galleries and enjoy the natural light beneath the dome."
        },

        // 7. Special Experience
        specialExperience: {
            title: "Discover the Rain of Light",
            experience: "Walk beneath the museum's spectacular dome and watch sunlight pass through its geometric patterns, creating beautiful light effects.",
            culturalSignificance: "The museum connects different civilizations through art, history, and shared human experiences.",
            recommendation: "Take time to explore both the indoor galleries and outdoor waterfront areas."
        },

        // 8. Estimated Budget
        budgetDetails: [
            {
                item: "Museum Admission",
                cost: "$17"
            },
            {
                item: "Food and Drinks",
                cost: "$20"
            },
            {
                item: "Transportation",
                cost: "$30"
            },
            {
                item: "Shopping and Extra Activities",
                cost: "$18"
            }
        ],

        budgetNote: "The estimated total budget is around $85 per person, depending on transportation, food choices, and additional activities.",

        // 9. Transportation
        transportation: [
            "Take a taxi or ride-hailing service from central Abu Dhabi.",
            "Use public buses serving the Saadiyat Island area and check the latest routes.",
            "Rent a car for a more flexible journey around Abu Dhabi."
        ],

        // 10. Accommodation
        accommodation: [
            "Luxury hotels near Saadiyat Island for a comfortable cultural getaway.",
            "Mid-range hotels in central Abu Dhabi with convenient city access.",
            "Budget hotels and apartments in other parts of Abu Dhabi."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "9:00 AM",
                activity: "Arrive at Louvre Abu Dhabi",
                description: "Begin your visit by admiring the museum's impressive exterior and architecture."
            },
            {
                time: "9:30 AM",
                activity: "Explore the Galleries",
                description: "Discover historical objects and artworks from different civilizations."
            },
            {
                time: "11:00 AM",
                activity: "Experience the Rain of Light",
                description: "Walk beneath the dome and enjoy its beautiful sunlight patterns."
            },
            {
                time: "12:00 PM",
                activity: "Lunch Break",
                description: "Enjoy a relaxing meal at the museum's dining facilities or nearby restaurants."
            },
            {
                time: "1:00 PM",
                activity: "Visit the Children's Museum",
                description: "Explore creative and interactive exhibitions when available."
            },
            {
                time: "2:00 PM",
                activity: "Waterfront Walk",
                description: "Enjoy the peaceful surroundings and take photographs near the Arabian Gulf."
            },
            {
                time: "3:00 PM",
                activity: "Finish Your Visit",
                description: "Visit the museum shop before leaving Saadiyat Island."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Check museum opening hours and admission prices before visiting.",
            "Book tickets online in advance when possible.",
            "Wear comfortable shoes for walking through the galleries.",
            "Dress respectfully when visiting cultural spaces.",
            "Allow several hours to explore the museum properly.",
            "Photography is permitted in many areas, but follow exhibition rules.",
            "Bring a camera to capture the beautiful dome and waterfront views.",
            "Respect artworks and avoid touching museum displays."
        ]
    },
    
    // ===================================
    // 5. DUBAI
    // ===================================

    {
        name: "Dubai",
        country: "United Arab Emirates",
        category: "City, Culture & Modern Attractions",
        image: "images/Dubai City.jpg",
        budget: 130,
        featured: false,

        // 1. Overview
        description: "Dubai is a vibrant city in the United Arab Emirates known for its impressive skyline, luxury shopping, beautiful beaches, traditional markets, and exciting attractions. It combines modern architecture with rich Emirati culture, offering visitors a unique city experience.",

        // 2. Location
        location: "Dubai, United Arab Emirates",

        // 3. History
        history: "Dubai developed from a small fishing and pearl-diving settlement into one of the world's most recognized modern cities. Its growth accelerated after the discovery of oil in the 1960s, followed by major investments in trade, tourism, transportation, and business.",

        // 4. Main Attractions
        attractions: [
            {
                name: "Dubai Mall",
                description: "Explore one of the world's largest shopping and entertainment destinations, with shops, restaurants, and indoor attractions."
            },
            {
                name: "Dubai Marina",
                description: "Enjoy waterfront views, modern skyscrapers, restaurants, and relaxing walks along the marina."
            },
            {
                name: "Al Fahidi Historical Neighbourhood",
                description: "Discover traditional wind-tower architecture, cultural spaces, museums, and the city's historic atmosphere."
            },
            {
                name: "Dubai Creek",
                description: "Experience an important historic waterway and enjoy traditional abra boat rides between the old districts."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Experience a city filled with modern architecture and exciting attractions.",
            "Explore traditional Emirati culture and historic neighbourhoods.",
            "Enjoy shopping, dining, and entertainment experiences.",
            "Discover beautiful beaches and waterfront destinations.",
            "Experience the contrast between historic Dubai and its modern skyline."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "November to March",
            weather: "The cooler winter season offers more comfortable temperatures for sightseeing and outdoor activities.",
            recommendation: "Visit during the cooler months and explore outdoor attractions in the morning or evening."
        },

        // 7. Special Experience
        specialExperience: {
            title: "Explore Old and Modern Dubai",
            experience: "Spend the day discovering historic neighbourhoods and traditional markets before enjoying the modern city skyline and waterfront attractions.",
            culturalSignificance: "Dubai reflects the transformation of the UAE while preserving important elements of Emirati heritage and traditions.",
            recommendation: "Take a traditional abra ride across Dubai Creek and explore the nearby souks for a memorable cultural experience."
        },

        // 8. Estimated Budget
        budgetDetails: [
            {
                item: "Food and Drinks",
                cost: "$30"
            },
            {
                item: "Transportation",
                cost: "$25"
            },
            {
                item: "Attraction Tickets",
                cost: "$45"
            },
            {
                item: "Shopping and Extra Activities",
                cost: "$30"
            }
        ],

        budgetNote: "The estimated daily budget is around $130 per person, depending on accommodation, transportation, dining choices, and selected attractions.",

        // 9. Transportation
        transportation: [
            "Use the Dubai Metro to travel between major areas of the city.",
            "Take public buses, taxis, or ride-hailing services for convenient transportation.",
            "Rent a car if you plan to explore destinations outside the main city areas."
        ],

        // 10. Accommodation
        accommodation: [
            "Luxury hotels in Downtown Dubai with access to major attractions.",
            "Mid-range hotels around Business Bay or Dubai Marina.",
            "Budget hotels and guesthouses in areas such as Deira and Bur Dubai."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Explore Al Fahidi",
                description: "Begin your day in Dubai's historic neighbourhood and discover traditional architecture."
            },
            {
                time: "9:30 AM",
                activity: "Visit Dubai Creek",
                description: "Enjoy the waterfront atmosphere and experience a traditional abra ride."
            },
            {
                time: "11:00 AM",
                activity: "Explore Traditional Souks",
                description: "Browse local markets and discover traditional goods, spices, and souvenirs."
            },
            {
                time: "12:30 PM",
                activity: "Lunch Break",
                description: "Enjoy Emirati or international cuisine at a local restaurant."
            },
            {
                time: "2:00 PM",
                activity: "Visit Dubai Mall",
                description: "Explore shopping, entertainment, and dining options in the city."
            },
            {
                time: "4:30 PM",
                activity: "Discover Dubai Marina",
                description: "Enjoy a relaxing walk along the waterfront and admire the modern skyline."
            },
            {
                time: "6:30 PM",
                activity: "Evening City Views",
                description: "Finish the day with beautiful evening views and dinner in Dubai."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Visit between November and March for more comfortable outdoor weather.",
            "Use the Metro to save money and avoid traffic.",
            "Dress respectfully when visiting cultural and religious places.",
            "Stay hydrated, especially during warmer months.",
            "Check attraction opening hours and ticket prices in advance.",
            "Use sunscreen and comfortable shoes when exploring the city.",
            "Respect local customs and public behaviour guidelines.",
            "Keep some cash available for traditional markets and smaller shops."
        ]
    },

    // ===================================
    // 6. DUBAI MIRACLE GARDEN
    // ===================================

    {
        name: "Dubai Miracle Garden",
        country: "United Arab Emirates",
        category: "Nature & Flower Garden",
        image: "images/Dubai Miracle Garden.jpg",
        budget: 55,
        featured: false,

        // 1. Overview
        description: "Dubai Miracle Garden is a spectacular flower garden featuring millions of colorful flowers arranged into creative displays, beautiful pathways, and impressive floral structures. It is one of Dubai's most popular seasonal outdoor attractions.",

        // 2. Location
        location: "Dubailand, Dubai, United Arab Emirates",

        // 3. History
        history: "Dubai Miracle Garden opened in 2013 and became a unique attraction in the desert city. It was developed to create a large outdoor floral destination using creative landscaping and carefully maintained flower displays.",

        // 4. Main Attractions
        attractions: [
            {
                name: "Floral Castle",
                description: "Admire a colorful castle decorated with beautiful flowers and creative garden designs."
            },
            {
                name: "Heart-Shaped Flower Passage",
                description: "Walk through romantic heart-shaped floral structures surrounded by colorful blooms."
            },
            {
                name: "Emirates A380 Floral Display",
                description: "See the famous floral installation shaped like an Emirates aircraft, covered in beautiful flowers."
            },
            {
                name: "Flower-Themed Sculptures",
                description: "Discover creative sculptures and large decorative displays made with thousands of flowers."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Enjoy millions of colorful flowers in one beautiful garden.",
            "Discover creative floral sculptures and themed displays.",
            "Take memorable photographs in unique garden settings.",
            "Experience a peaceful outdoor attraction away from the busy city.",
            "Enjoy a special seasonal attraction in Dubai."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "November to April",
            weather: "The garden generally operates during the cooler months because of Dubai's hot summer climate.",
            recommendation: "Visit in the morning or late afternoon for more comfortable weather and beautiful natural lighting."
        },

        // 7. Special Experience
        specialExperience: {
            title: "Walk Through a World of Flowers",
            experience: "Explore colorful flower tunnels, creative sculptures, and beautifully arranged gardens while enjoying the fresh outdoor atmosphere.",
            culturalSignificance: "The garden represents creativity, environmental landscaping, and the ability to create extraordinary green spaces in a desert environment.",
            recommendation: "Take your time exploring the themed displays and bring a camera for memorable photographs."
        },

        // 8. Estimated Budget
        budgetDetails: [
            {
                item: "Garden Admission",
                cost: "$25"
            },
            {
                item: "Food and Drinks",
                cost: "$12"
            },
            {
                item: "Transportation",
                cost: "$13"
            },
            {
                item: "Souvenirs and Extras",
                cost: "$5"
            }
        ],

        budgetNote: "The estimated budget is around $55 per person, depending on transportation, food choices, and additional purchases. Check current ticket prices before visiting.",

        // 9. Transportation
        transportation: [
            "Take a taxi or ride-hailing service directly to the garden.",
            "Use public transportation connections and check the latest bus routes to reach the attraction.",
            "Rent a car for a convenient trip to nearby attractions in Dubailand."
        ],

        // 10. Accommodation
        accommodation: [
            "Hotels in central Dubai with convenient access to major attractions.",
            "Mid-range hotels around Al Barsha for easier access to the garden.",
            "Budget hotels in other parts of Dubai with public transportation connections."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "9:00 AM",
                activity: "Arrive at Dubai Miracle Garden",
                description: "Begin your visit early and enjoy the beautiful entrance displays."
            },
            {
                time: "9:30 AM",
                activity: "Explore the Flower Tunnels",
                description: "Walk through colorful floral passages and enjoy the garden scenery."
            },
            {
                time: "10:30 AM",
                activity: "Visit the Floral Sculptures",
                description: "Discover creative flower arrangements and impressive themed displays."
            },
            {
                time: "11:30 AM",
                activity: "Photography Time",
                description: "Capture beautiful photographs surrounded by colorful flowers."
            },
            {
                time: "12:30 PM",
                activity: "Lunch Break",
                description: "Enjoy refreshments or a meal at available food outlets."
            },
            {
                time: "1:30 PM",
                activity: "Explore More Garden Areas",
                description: "Visit the remaining displays and enjoy a relaxing walk."
            },
            {
                time: "2:30 PM",
                activity: "Finish Your Visit",
                description: "Purchase souvenirs and prepare for your next destination."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Check the seasonal opening dates before planning your visit.",
            "Visit during cooler months when the garden is open.",
            "Arrive early to avoid larger crowds.",
            "Wear comfortable walking shoes.",
            "Bring sunscreen, sunglasses, and drinking water.",
            "Follow garden rules and avoid damaging flowers or displays.",
            "Check photography guidelines before using professional equipment.",
            "Bring a camera to capture the colorful floral attractions."
        ]
    },

    // ===================================
    // II. TURKEY
    // ===================================

    // ===================================
    // 7. HAGIA SOPHIA
    // ===================================

    {
        name: "Hagia Sophia",
        country: "Turkey",
        category: "History & Religious Architecture",
        image: "images/Hagia Sophia.jpg",
        budget: 75,
        featured: true,

        // 1. Overview
        description: "Hagia Sophia is one of Istanbul's most famous historical landmarks, admired for its enormous dome, beautiful architecture, and rich cultural history. It has served as a Byzantine cathedral, an Ottoman mosque, a museum, and a mosque again, representing the meeting of different civilizations.",

        // 2. Location
        location: "Sultanahmet, Istanbul, Turkey",

        // 3. History
        history: "Originally completed in 537 CE under Byzantine Emperor Justinian I, Hagia Sophia served as the cathedral of Constantinople for nearly a thousand years. Following the Ottoman conquest of Constantinople in 1453, it became a mosque. It was converted into a museum in 1935 and returned to mosque status in 2020.",

        // 4. Main Attractions
        attractions: [
            {
                name: "The Great Dome",
                description: "Admire the enormous central dome, one of the most remarkable achievements of Byzantine architecture."
            },
            {
                name: "Historic Mosaics",
                description: "Discover beautiful Byzantine mosaics that reflect the building's long religious and artistic history."
            },
            {
                name: "Marble Columns and Interior",
                description: "Explore the impressive interior featuring marble surfaces, decorative details, and historic architectural elements."
            },
            {
                name: "Sultanahmet Square",
                description: "Enjoy the historic surroundings and visit other famous landmarks located near Hagia Sophia."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Discover more than 1,400 years of history.",
            "Admire one of the world's most recognizable architectural landmarks.",
            "Explore the artistic influence of Byzantine and Ottoman civilizations.",
            "Experience the historic atmosphere of Istanbul's old city.",
            "Learn about the cultural connections between Europe and Asia."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "April to June and September to October",
            weather: "Spring and autumn generally offer pleasant temperatures for exploring Istanbul.",
            recommendation: "Visit early in the day to enjoy the surrounding historic district with fewer crowds."
        },

        // 7. Special Experience
        specialExperience: {
            title: "Discover Byzantine and Ottoman Heritage",
            experience: "Admire the enormous dome, historic mosaics, and architectural details while learning about the building's transformation across different periods.",
            culturalSignificance: "Hagia Sophia reflects the historical influence of Byzantine and Ottoman civilizations and remains an important religious and cultural landmark.",
            recommendation: "Take time to explore the surrounding Sultanahmet district and respect the current mosque's visitor rules."
        },

        // 8. Estimated Budget
        budgetDetails: [
            {
                item: "Visitor Admission",
                cost: "$30"
            },
            {
                item: "Food and Drinks",
                cost: "$15"
            },
            {
                item: "Transportation",
                cost: "$10"
            },
            {
                item: "Extra Activities and Souvenirs",
                cost: "$20"
            }
        ],

        budgetNote: "The estimated daily budget is around $75 per person. Visitor access rules, admission arrangements, and prices may change, so check official information before visiting.",
        // 9. Transportation
        transportation: [
            "Take the T1 tram to Sultanahmet station, which is within walking distance.",
            "Use public buses or taxis to reach Istanbul's historic district.",
            "Walk from nearby attractions such as the Blue Mosque and Basilica Cistern."
        ],

        // 10. Accommodation
        accommodation: [
            "Boutique hotels in Sultanahmet near the historic landmarks.",
            "Mid-range hotels around Sirkeci with convenient tram connections.",
            "Budget hostels and guesthouses in central Istanbul."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "8:30 AM",
                activity: "Arrive at Sultanahmet",
                description: "Begin your day in Istanbul's historic district."
            },
            {
                time: "9:00 AM",
                activity: "Visit Hagia Sophia",
                description: "Explore the landmark and admire its remarkable architecture."
            },
            {
                time: "10:30 AM",
                activity: "Discover the Historic Interior",
                description: "Learn about the building's Byzantine and Ottoman heritage."
            },
            {
                time: "11:30 AM",
                activity: "Explore Sultanahmet Square",
                description: "Enjoy the surrounding historic atmosphere and take photographs."
            },
            {
                time: "12:30 PM",
                activity: "Lunch Break",
                description: "Try traditional Turkish food at a nearby restaurant."
            },
            {
                time: "2:00 PM",
                activity: "Visit Nearby Landmarks",
                description: "Explore other historic attractions in the Sultanahmet area."
            },
            {
                time: "4:00 PM",
                activity: "Enjoy the Old City",
                description: "Walk through the surrounding streets and discover local shops."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Check current visitor access rules and opening hours before visiting.",
            "Dress modestly because Hagia Sophia currently functions as a mosque.",
            "Women visitors may need to cover their hair in designated prayer areas.",
            "Remove your shoes when required in designated areas.",
            "Avoid visiting during prayer times if tourist access is restricted.",
            "Respect worshippers and maintain a quiet atmosphere.",
            "Wear comfortable shoes for exploring the historic district.",
            "Check photography rules before taking pictures inside."
        ]
    },

    // ===================================
    // 8. CAPPADOCIA
    // ===================================

    {
        name: "Cappadocia",
        country: "Turkey",
        category: "Nature & Cultural Landscape",
        image: "images/Cappadocia.jpg",
        budget: 180,
        featured: false,

        // 1. Overview
        description: "Cappadocia is a breathtaking region in central Turkey famous for its fairy chimneys, unusual rock formations, ancient cave dwellings, and unforgettable hot-air balloon experiences. Its unique landscapes and historical heritage make it one of Turkey's most popular travel destinations.",

        // 2. Location
        location: "Nevşehir Province, Central Anatolia, Turkey",

        // 3. History
        history: "Cappadocia has been inhabited since ancient times. Its soft volcanic rock allowed communities to create underground cities, churches, monasteries, and cave homes. The region became an important center of early Christianity and preserves remarkable historical settlements.",

        // 4. Main Attractions
        attractions: [
            {
                name: "Göreme Open-Air Museum",
                description: "Explore historic rock-cut churches and monasteries decorated with beautiful Byzantine frescoes."
            },
            {
                name: "Love Valley",
                description: "Discover unusual fairy chimneys and impressive rock formations surrounded by scenic walking trails."
            },
            {
                name: "Derinkuyu Underground City",
                description: "Explore an extraordinary underground settlement with tunnels, rooms, and historic communal spaces."
            },
            {
                name: "Uçhisar Castle",
                description: "Enjoy panoramic views of Cappadocia from a historic rock-carved fortress."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Experience the famous hot-air balloon flights at sunrise.",
            "Explore extraordinary fairy chimneys and volcanic landscapes.",
            "Discover ancient underground cities and cave churches.",
            "Enjoy scenic hiking routes and beautiful photography locations.",
            "Experience traditional cave hotels and local Turkish culture."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "April to June and September to October",
            weather: "Spring and autumn generally provide comfortable temperatures for outdoor exploration.",
            recommendation: "Stay for at least two mornings if you hope to take a hot-air balloon flight, as weather conditions can affect departures."
        },

        // 7. Special Experience
        specialExperience: {
            title: "Hot-Air Balloon Sunrise",
            experience: "Float above Cappadocia's extraordinary valleys and fairy chimneys while watching the sunrise over the landscape.",
            culturalSignificance: "Cappadocia preserves centuries of human settlement, including underground cities, cave churches, and traditional rock-carved homes.",
            recommendation: "Book a balloon flight with a licensed operator and remember that flights depend on weather and aviation safety approvals."
        },

        // 8. Estimated Budget
        budgetDetails: [
            {
                item: "Accommodation",
                cost: "$45"
            },
            {
                item: "Food and Drinks",
                cost: "$30"
            },
            {
                item: "Transportation",
                cost: "$20"
            },
            {
                item: "Activities and Entrance Fees",
                cost: "$85"
            }
        ],

        // 9. Transportation
        transportation: [
            "Fly to Nevşehir or Kayseri Airport and arrange an airport transfer.",
            "Use local shuttle services, taxis, or rental cars to explore nearby towns.",
            "Join guided tours to visit valleys, underground cities, and historical sites."
        ],

        // 10. Accommodation
        accommodation: [
            "Traditional cave hotels in Göreme for a memorable stay.",
            "Boutique hotels in Ürgüp with beautiful regional architecture.",
            "Budget guesthouses and hostels around Göreme town center."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "5:30 AM",
                activity: "Hot-Air Balloon Experience",
                description: "Enjoy a sunrise balloon flight if weather conditions and flight approvals allow."
            },
            {
                time: "8:00 AM",
                activity: "Traditional Breakfast",
                description: "Enjoy a Turkish breakfast after your morning adventure."
            },
            {
                time: "9:30 AM",
                activity: "Visit Göreme Open-Air Museum",
                description: "Discover ancient rock-cut churches and historical frescoes."
            },
            {
                time: "11:30 AM",
                activity: "Explore Love Valley",
                description: "Walk through the beautiful landscape and admire the fairy chimneys."
            },
            {
                time: "1:00 PM",
                activity: "Lunch Break",
                description: "Taste traditional Cappadocian and Turkish dishes."
            },
            {
                time: "2:30 PM",
                activity: "Discover an Underground City",
                description: "Explore the fascinating underground spaces used by ancient communities."
            },
            {
                time: "5:00 PM",
                activity: "Sunset at Uçhisar",
                description: "Enjoy panoramic views of Cappadocia before ending the day."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Book hot-air balloon flights with licensed operators.",
            "Remember that balloon flights may be cancelled because of weather conditions.",
            "Bring a jacket because early mornings can be cold.",
            "Wear comfortable shoes for walking on rocky paths.",
            "Book cave accommodation in advance during busy seasons.",
            "Carry drinking water when exploring valleys.",
            "Respect historical sites and avoid damaging rock formations.",
            "Allow extra time in your itinerary in case weather changes your plans."
        ]
    },

    // ===================================
    // 9. PAMUKKALE
    // ===================================

    {
        name: "Pamukkale",
        country: "Turkey",
        category: "Nature & Historical Heritage",
        image: "images/Pamukkale.jpg",
        budget: 90,
        featured: false,

        // 1. Overview
        description: "Pamukkale is a spectacular natural destination in southwestern Turkey, famous for its bright white travertine terraces and warm mineral-rich thermal waters. Located beside the ancient city of Hierapolis, it offers a unique combination of natural beauty and historical heritage.",

        // 2. Location
        location: "Denizli Province, Southwestern Turkey",

        // 3. History
        history: "Pamukkale's thermal springs have attracted visitors for thousands of years. The nearby ancient city of Hierapolis developed around these waters during the Hellenistic and Roman periods and became an important center for healing and relaxation. The area is now recognized as a UNESCO World Heritage Site.",

        // 4. Main Attractions
        attractions: [
            {
                name: "White Travertine Terraces",
                description: "Admire the beautiful white limestone terraces formed by mineral-rich thermal water flowing down the hillside."
            },
            {
                name: "Hierapolis Ancient City",
                description: "Explore the remains of an ancient Roman city featuring historic streets, temples, and impressive architecture."
            },
            {
                name: "Pamukkale Antique Pool",
                description: "Discover the famous thermal pool surrounded by ancient columns, with swimming access subject to current operating rules."
            },
            {
                name: "Hierapolis Theatre",
                description: "Visit a remarkably preserved ancient Roman theatre known for its impressive structure and historical details."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "See one of Turkey's most extraordinary natural landscapes.",
            "Experience the beautiful white travertine terraces.",
            "Discover the ancient history of Hierapolis.",
            "Enjoy the region's famous thermal water heritage.",
            "Capture unforgettable photographs of the natural scenery."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "April to June and September to October",
            weather: "Spring and autumn generally offer comfortable temperatures for walking and sightseeing.",
            recommendation: "Visit in the morning or late afternoon to enjoy the scenery in more comfortable weather."
        },

        // 7. Special Experience
        specialExperience: {
            title: "Walk Along the White Terraces",
            experience: "Walk barefoot along designated travertine areas and admire the mineral formations and beautiful thermal pools.",
            culturalSignificance: "Pamukkale and Hierapolis demonstrate the historical relationship between natural thermal springs, ancient healing traditions, and human settlement.",
            recommendation: "Follow all visitor instructions and avoid walking on restricted or protected terraces."
        },

        // 8. Estimated Budget
        budgetDetails: [
            {
                item: "Entrance and Site Admission",
                cost: "$30"
            },
            {
                item: "Food and Drinks",
                cost: "$20"
            },
            {
                item: "Transportation",
                cost: "$25"
            },
            {
                item: "Extra Activities",
                cost: "$15"
            }
        ],

        budgetNote: "The estimated daily budget is around $90 per person. Admission arrangements, optional activities, and transportation costs may change, so check current prices before visiting.",
        // 9. Transportation
        transportation: [
            "Travel by bus or train to Denizli and continue to Pamukkale by local minibus.",
            "Take a taxi or private transfer from Denizli to the attraction.",
            "Join an organized day tour from nearby destinations."
        ],

        // 10. Accommodation
        accommodation: [
            "Thermal hotels near Pamukkale for a relaxing stay.",
            "Mid-range hotels and guesthouses in Pamukkale village.",
            "Budget accommodation in Denizli with convenient transport connections."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "8:30 AM",
                activity: "Arrive at Pamukkale",
                description: "Begin your visit early and enjoy the peaceful surroundings."
            },
            {
                time: "9:00 AM",
                activity: "Explore the Travertine Terraces",
                description: "Admire the white mineral formations and thermal pools."
            },
            {
                time: "10:30 AM",
                activity: "Discover Hierapolis",
                description: "Walk through the archaeological site and learn about its ancient history."
            },
            {
                time: "11:30 AM",
                activity: "Visit the Ancient Theatre",
                description: "Explore the impressive Roman theatre and its historic surroundings."
            },
            {
                time: "12:30 PM",
                activity: "Lunch Break",
                description: "Enjoy a traditional Turkish meal at a nearby restaurant."
            },
            {
                time: "2:00 PM",
                activity: "Explore the Antique Pool Area",
                description: "Visit the historic thermal pool area and check current swimming availability."
            },
            {
                time: "4:00 PM",
                activity: "Enjoy the Scenery",
                description: "Take photographs and relax while enjoying the beautiful landscape."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Check current entrance fees and opening hours before visiting.",
            "Bring comfortable footwear for walking around the archaeological site.",
            "Shoes must be removed when walking on designated travertine areas.",
            "Follow signs and stay away from restricted terraces.",
            "Bring sunscreen, sunglasses, and drinking water.",
            "Visit early to avoid larger crowds.",
            "Check swimming rules and availability before planning a thermal pool visit.",
            "Respect the natural formations and historical ruins."
        ]
    },

    // ===================================
    // 10. BLUE MOSQUE
    // ===================================

    {
        name: "Blue Mosque",
        country: "Turkey",
        category: "Religious Architecture & History",
        image: "images/Blue Mosque.jpg",
        budget: 65,
        featured: false,

        // 1. Overview
        description: "The Blue Mosque, officially known as the Sultan Ahmed Mosque, is one of Istanbul's most famous religious and architectural landmarks. Recognized for its elegant domes, six minarets, and beautiful blue Iznik tiles, it attracts visitors from around the world.",

        // 2. Location
        location: "Sultanahmet, Istanbul, Turkey",

        // 3. History
        history: "The Blue Mosque was commissioned by Ottoman Sultan Ahmed I and constructed between 1609 and 1616. Designed by architect Sedefkâr Mehmed Ağa, it became an important example of classical Ottoman architecture and remains an active place of worship.",

        // 4. Main Attractions
        attractions: [
            {
                name: "Blue Iznik Tiles",
                description: "Admire the thousands of decorative blue and white tiles that give the mosque its famous nickname."
            },
            {
                name: "Central Dome",
                description: "Look up at the impressive central dome and its surrounding smaller domes and decorative details."
            },
            {
                name: "Six Minarets",
                description: "See the mosque's distinctive six minarets, which create one of Istanbul's most recognizable skylines."
            },
            {
                name: "Sultanahmet Square",
                description: "Explore the historic square surrounding the mosque and enjoy views of nearby landmarks."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Experience one of the finest examples of Ottoman architecture.",
            "Admire beautiful traditional Iznik tile decorations.",
            "Discover the history of the Ottoman Empire.",
            "Enjoy the peaceful atmosphere of a historic place of worship.",
            "Explore Istanbul's famous Sultanahmet district."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "April to June and September to October",
            weather: "Spring and autumn generally provide pleasant weather for exploring Istanbul.",
            recommendation: "Visit in the morning between prayer periods and check visitor access arrangements before arriving."
        },

        // 7. Special Experience
        specialExperience: {
            title: "Admire Ottoman Architecture",
            experience: "Step inside the mosque to appreciate its elegant interior, beautiful tilework, decorative calligraphy, and impressive domes.",
            culturalSignificance: "The Blue Mosque represents the artistic, religious, and architectural achievements of the Ottoman Empire.",
            recommendation: "Take time to admire the exterior from Sultanahmet Square and respect the mosque's active worship activities."
        },

        // 8. Estimated Budget
        budgetDetails: [
            {
                item: "Mosque Admission",
                cost: "Free"
            },
            {
                item: "Food and Drinks",
                cost: "$20"
            },
            {
                item: "Transportation",
                cost: "$10"
            },
            {
                item: "Shopping and Extra Activities",
                cost: "$35"
            }
        ],

        budgetNote: "The estimated daily budget is around $65 per person. General visitor admission to the mosque is free, while food, transportation, and optional activities may add to the cost.",

        // 9. Transportation
        transportation: [
            "Take the T1 tram to Sultanahmet station and walk to the mosque.",
            "Use public buses or taxis to reach the historic district.",
            "Walk from nearby attractions such as Hagia Sophia and the Basilica Cistern."
        ],

        // 10. Accommodation
        accommodation: [
            "Boutique hotels in Sultanahmet near the mosque and other historic landmarks.",
            "Mid-range hotels in Sirkeci with convenient public transportation.",
            "Budget hostels and guesthouses in central Istanbul."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "8:30 AM",
                activity: "Arrive at Sultanahmet Square",
                description: "Enjoy the historic surroundings and admire the mosque's exterior."
            },
            {
                time: "9:00 AM",
                activity: "Visit the Blue Mosque",
                description: "Explore the mosque when visitor access is available outside prayer periods."
            },
            {
                time: "10:00 AM",
                activity: "Admire the Interior",
                description: "Discover the blue tiles, impressive domes, and traditional decorations."
            },
            {
                time: "11:00 AM",
                activity: "Explore the Historic Square",
                description: "Enjoy the atmosphere and photograph the surrounding landmarks."
            },
            {
                time: "12:30 PM",
                activity: "Lunch Break",
                description: "Try traditional Turkish food at a nearby restaurant."
            },
            {
                time: "2:00 PM",
                activity: "Discover Nearby Attractions",
                description: "Visit other historic sites in the Sultanahmet district."
            },
            {
                time: "4:00 PM",
                activity: "Enjoy the Old City",
                description: "Walk through nearby streets and explore local shops."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Check prayer times and visitor access arrangements before visiting.",
            "Dress modestly when entering the mosque.",
            "Women visitors should bring a headscarf to cover their hair.",
            "Remove your shoes when required before entering prayer areas.",
            "Avoid disturbing people who are praying.",
            "Photography should be respectful and follow posted rules.",
            "Wear comfortable shoes for exploring the historic district.",
            "Visit early to enjoy a more peaceful atmosphere."
        ]
    },

    // ===================================
    // 11. EPHESUS
    // ===================================

    {
        name: "Ephesus",
        country: "Turkey",
        category: "Ancient History & Archaeology",
        image: "images/Ephesus.jpg",
        budget: 95,
        featured: false,

        // 1. Overview
        description: "Ephesus is one of the best-preserved ancient cities in the Mediterranean region. Located in western Turkey, it is famous for its impressive Roman ruins, the Library of Celsus, the Great Theatre, and its importance in ancient Greek and Roman history.",

        // 2. Location
        location: "Near Selçuk, İzmir Province, Western Turkey",

        // 3. History
        history: "Ephesus was an important ancient Greek city that later became a major Roman center. It developed into a significant commercial, cultural, and religious destination. The city was also home to the Temple of Artemis, one of the Seven Wonders of the Ancient World, although only limited remains survive today.",

        // 4. Main Attractions
        attractions: [
            {
                name: "Library of Celsus",
                description: "Admire the famous two-story Roman library façade, one of the most recognizable structures in Ephesus."
            },
            {
                name: "Great Theatre",
                description: "Explore the enormous ancient theatre that once hosted performances and public gatherings."
            },
            {
                name: "Temple of Hadrian",
                description: "Discover the remains of a Roman temple decorated with impressive architectural details."
            },
            {
                name: "Terrace Houses",
                description: "Explore the remains of luxurious Roman homes featuring mosaics, frescoes, and historic living spaces."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Explore one of the Mediterranean's most important ancient cities.",
            "Discover impressive Roman architecture and archaeological remains.",
            "See the famous Library of Celsus.",
            "Learn about ancient Greek and Roman civilization.",
            "Experience an important historical destination in Turkey."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "April to June and September to October",
            weather: "Spring and autumn generally provide comfortable temperatures for exploring the extensive archaeological site.",
            recommendation: "Arrive early in the morning to avoid the strongest afternoon heat and larger tour groups."
        },

        // 7. Special Experience
        specialExperience: {
            title: "Walk Through an Ancient Roman City",
            experience: "Walk along ancient marble streets, admire the Library of Celsus, and imagine everyday life in one of the Roman world's important cities.",
            culturalSignificance: "Ephesus preserves evidence of Greek, Roman, and early Christian history and demonstrates the region's importance in ancient Mediterranean civilization.",
            recommendation: "Consider joining a licensed guided tour to understand the history behind the ruins."
        },

        // 8. Estimated Budget
        budgetDetails: [
            {
                item: "Archaeological Site Admission",
                cost: "$35"
            },
            {
                item: "Food and Drinks",
                cost: "$20"
            },
            {
                item: "Transportation",
                cost: "$25"
            },
            {
                item: "Guide and Extra Activities",
                cost: "$15"
            }
        ],

        budgetNote: "The estimated daily budget is around $95 per person. Admission prices and optional site access may change, so check current official ticket information before visiting.",

        // 9. Transportation
        transportation: [
            "Travel by train or bus to Selçuk from İzmir.",
            "Take a local taxi or minibus from Selçuk to the archaeological site.",
            "Join an organized day tour from İzmir or nearby coastal destinations."
        ],

        // 10. Accommodation
        accommodation: [
            "Boutique hotels in Selçuk near the archaeological site.",
            "Mid-range hotels in Kuşadası for a combination of history and coastal relaxation.",
            "Budget guesthouses and hostels in Selçuk town center."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "8:30 AM",
                activity: "Arrive at Ephesus",
                description: "Begin your visit early and prepare to explore the ancient city."
            },
            {
                time: "9:00 AM",
                activity: "Visit the Library of Celsus",
                description: "Admire the famous façade and learn about its historical importance."
            },
            {
                time: "10:00 AM",
                activity: "Explore the Great Theatre",
                description: "Discover the enormous Roman theatre and its impressive structure."
            },
            {
                time: "11:00 AM",
                activity: "Walk Along Marble Street",
                description: "Explore the ancient streets and surrounding archaeological remains."
            },
            {
                time: "12:30 PM",
                activity: "Lunch Break",
                description: "Enjoy traditional Turkish food in nearby Selçuk."
            },
            {
                time: "2:00 PM",
                activity: "Discover the Terrace Houses",
                description: "Explore the preserved Roman homes and their decorative details, subject to separate admission."
            },
            {
                time: "3:30 PM",
                activity: "Explore Nearby Historical Sites",
                description: "Discover more of the region's ancient heritage before ending your visit."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Visit early in the morning to avoid the midday heat.",
            "Wear comfortable walking shoes because the site has uneven stone paths.",
            "Bring sunscreen, a hat, and drinking water.",
            "Check current ticket prices and opening hours before visiting.",
            "Consider hiring a licensed guide for historical explanations.",
            "Respect archaeological remains and do not climb restricted structures.",
            "Allow several hours to explore the extensive site.",
            "Bring a camera to capture the impressive ancient architecture."
        ]
    },

    // ===================================
    // III. JORDAN
    // ===================================

    // ===================================
    // 12. PETRA
    // ===================================

    {
        name: "Petra",
        country: "Jordan",
        category: "Ancient History & Archaeological Heritage",
        image: "images/Petra.jpg",
        budget: 95,
        featured: true,

        // 1. Overview
        description: "Petra is an ancient archaeological city in southern Jordan, famous for its magnificent buildings carved directly into rose-colored sandstone cliffs. Known as the Rose City, it is one of the world's most remarkable historical destinations.",

        // 2. Location
        location: "Ma'an Governorate, southern Jordan, approximately 240 kilometers south of Amman.",

        // 3. History
        history: "Petra was established by the Nabataeans around the 4th century BCE and became an important center for trade. Its location connected major trade routes between Arabia, Egypt, and the Mediterranean. The city later became part of the Roman Empire and is now recognized as a UNESCO World Heritage Site.",

        // 4. Main Attractions
        attractions: [
            {
                name: "Al-Khazneh (The Treasury)",
                description: "Petra's most famous monument, featuring an impressive facade carved into a sandstone cliff."
            },
            {
                name: "The Monastery (Ad Deir)",
                description: "A massive rock-carved monument located high in the mountains, offering spectacular views."
            },
            {
                name: "The Siq",
                description: "A narrow natural canyon that creates a dramatic entrance to the ancient city."
            },
            {
                name: "Royal Tombs",
                description: "A collection of impressive ancient tombs carved into the colorful sandstone mountains."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Explore one of the world's most extraordinary ancient cities.",
            "Discover remarkable Nabataean architecture and history.",
            "Enjoy breathtaking sandstone mountains and desert scenery.",
            "Experience the famous walk through the Siq.",
            "Visit a UNESCO World Heritage Site and one of the New Seven Wonders of the World."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "Spring and Autumn",
            weather: "Mild temperatures and comfortable conditions for walking and exploring.",
            recommendation: "March to May and September to November are ideal for visiting Petra."
        },

        // 7. Special Experience
        specialExperience: {
            title: "Petra by Night",
            experience: "Walk through the candlelit Siq toward the Treasury and enjoy a magical atmosphere under the night sky.",
            culturalSignificance: "The experience highlights the beauty and historical importance of Petra's ancient architecture.",
            recommendation: "Check the official schedule before planning your visit, as this experience operates on selected evenings."
        },

        // 8. Budget Details
        budgetDetails: [
            {
                item: "Entrance Ticket",
                cost: "$50 - $75"
            },
            {
                item: "Food and Drinks",
                cost: "$10 - $20"
            },
            {
                item: "Local Transportation",
                cost: "$10 - $25"
            },
            {
                item: "Additional Activities",
                cost: "$10 - $25"
            }
        ],

        budgetNote: "Estimated daily budget: $95 per person, excluding international flights and accommodation.",

        // 9. Transportation
        transportation: [
            "Travel from Amman to Petra by bus, taxi, or private car.",
            "Walk through the archaeological site to explore its main attractions.",
            "Local guides are available for visitors who want to learn more about Petra's history."
        ],
        // 10. Accommodation
        accommodation: [
            "Hotels and guesthouses in Wadi Musa near the Petra entrance.",
            "Luxury resorts offering comfortable facilities and mountain views.",
            "Budget-friendly hostels and local guesthouses for backpackers."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "7:00 AM",
                activity: "Enter Petra",
                description: "Begin your journey early to enjoy cooler temperatures and fewer crowds."
            },
            {
                time: "8:00 AM",
                activity: "Walk Through the Siq",
                description: "Explore the beautiful narrow canyon leading toward the ancient city."
            },
            {
                time: "9:00 AM",
                activity: "Visit the Treasury",
                description: "Admire Petra's most famous rock-carved monument and take photographs."
            },
            {
                time: "11:00 AM",
                activity: "Explore the Royal Tombs",
                description: "Discover impressive burial monuments and ancient Nabataean architecture."
            },
            {
                time: "1:00 PM",
                activity: "Lunch Break",
                description: "Enjoy a meal and take a short rest before continuing your exploration."
            },
            {
                time: "2:00 PM",
                activity: "Visit the Monastery",
                description: "Explore the magnificent mountain monument and enjoy the surrounding scenery."
            },
            {
                time: "4:00 PM",
                activity: "Return and Relax",
                description: "Walk back through the ancient city and enjoy the beautiful landscape."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Wear comfortable walking shoes because the archaeological site is very large.",
            "Bring enough drinking water, especially during warmer months.",
            "Start your visit early to avoid the midday heat.",
            "Wear sunscreen, sunglasses, and a hat.",
            "Respect historical structures and avoid touching or climbing protected monuments.",
            "Consider hiring a licensed local guide to learn about Petra's history.",
            "Carry some cash for small purchases and local services.",
            "Check entrance fees and opening hours before your visit."
        ]
    },

    // ===================================
    // 13. WADI RUM
    // ===================================

    {
        name: "Wadi Rum",
        country: "Jordan",
        category: "Desert Nature & Adventure",
        image: "images/Wadi Rum.jpg",
        budget: 110,
        featured: false,

        // 1. Overview
        description: "Wadi Rum is a spectacular desert valley in southern Jordan, famous for its red sand dunes, towering sandstone mountains, and breathtaking natural landscapes. Often called the Valley of the Moon, it offers unforgettable desert adventures and peaceful nights beneath the stars.",

        // 2. Location
        location: "Aqaba Governorate, southern Jordan, approximately 60 kilometers east of Aqaba.",

        // 3. History
        history: "Wadi Rum has been inhabited by human communities for thousands of years. Ancient inscriptions and rock drawings reveal the lives of earlier civilizations and the Nabataean people. Today, it is recognized as a UNESCO World Heritage Site for its natural and cultural significance.",

        // 4. Main Attractions
        attractions: [
            {
                name: "Seven Pillars of Wisdom",
                description: "A dramatic group of sandstone formations named after the famous book by T. E. Lawrence."
            },
            {
                name: "Lawrence's Spring",
                description: "A natural spring surrounded by desert mountains and ancient inscriptions."
            },
            {
                name: "Khazali Canyon",
                description: "A narrow canyon featuring ancient petroglyphs and impressive rock formations."
            },
            {
                name: "Um Fruth Rock Bridge",
                description: "A beautiful natural sandstone bridge offering panoramic desert views."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Experience the beauty of Jordan's famous red desert.",
            "Explore extraordinary sandstone mountains and rock formations.",
            "Enjoy exciting jeep tours and desert adventures.",
            "Discover ancient inscriptions and Bedouin culture.",
            "Experience unforgettable sunsets and star-filled night skies."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "Spring and Autumn",
            weather: "Comfortable daytime temperatures and cooler evenings.",
            recommendation: "March to May and September to November are ideal for desert exploration."
        },

        // 7. Special Experience
        specialExperience: {
            title: "Bedouin Desert Camp Experience",
            experience: "Stay in a traditional-style desert camp, enjoy local Bedouin food, and watch the stars in the peaceful desert night.",
            culturalSignificance: "Experience the hospitality, traditions, and lifestyle of the Bedouin communities who have lived in the region for generations.",
            recommendation: "Choose a responsible local camp and enjoy the desert while respecting its environment and culture."
        },

        // 8. Budget Details
        budgetDetails: [
            {
                item: "Desert Tour",
                cost: "$35 - $50"
            },
            {
                item: "Food and Drinks",
                cost: "$15 - $25"
            },
            {
                item: "Local Transportation",
                cost: "$10 - $20"
            },
            {
                item: "Accommodation",
                cost: "$30 - $45"
            }
        ],

        budgetNote: "Estimated daily budget: $110 per person, depending on tours and accommodation.",

        // 9. Transportation
        transportation: [
            "Travel from Amman or Aqaba to Wadi Rum by bus, taxi, or private car.",
            "Join a local 4x4 jeep tour to explore the desert attractions.",
            "Walking and camel experiences are available with local guides."
        ],
        // 10. Accommodation
        accommodation: [
            "Traditional Bedouin-style desert camps.",
            "Luxury desert bubble tents with mountain views.",
            "Simple guesthouses and camps near Wadi Rum Village."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Arrive at Wadi Rum",
                description: "Begin your desert adventure and enjoy the impressive surrounding landscape."
            },
            {
                time: "9:00 AM",
                activity: "Explore the Seven Pillars of Wisdom",
                description: "Admire the enormous sandstone formations and take photographs."
            },
            {
                time: "10:30 AM",
                activity: "Visit Lawrence's Spring",
                description: "Discover the natural spring and learn about its historical connection."
            },
            {
                time: "12:00 PM",
                activity: "Enjoy a Bedouin Lunch",
                description: "Taste traditional local food and experience Bedouin hospitality."
            },
            {
                time: "1:30 PM",
                activity: "Explore Khazali Canyon",
                description: "Walk through the narrow canyon and discover ancient rock inscriptions."
            },
            {
                time: "3:00 PM",
                activity: "Visit Um Fruth Rock Bridge",
                description: "Enjoy the dramatic desert views and explore the natural sandstone bridge."
            },
            {
                time: "5:00 PM",
                activity: "Watch the Desert Sunset",
                description: "Relax at a scenic viewpoint before enjoying the peaceful desert evening."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Bring enough water to stay hydrated during desert activities.",
            "Wear comfortable shoes suitable for walking on sand and rocks.",
            "Bring sunscreen, sunglasses, and a hat.",
            "Pack warm clothing because desert temperatures can drop at night.",
            "Book jeep tours with trusted local operators.",
            "Carry some cash for local services and small purchases.",
            "Respect Bedouin traditions and ask permission before photographing people.",
            "Avoid littering and help protect the desert environment."
        ]
    },

    // ===================================
    // 14. DEAD SEA
    // ===================================

    {
        name: "Dead Sea",
        country: "Jordan",
        category: "Nature & Wellness Destination",
        image: "images/Dead Sea.jpg",
        budget: 100,
        featured: false,

        // 1. Overview
        description: "The Dead Sea is a remarkable salt lake located between Jordan and the West Bank. Famous for its extremely salty water, mineral-rich mud, and unique floating experience, it is one of the most extraordinary natural destinations in the world.",

        // 2. Location
        location: "Western Jordan, along the eastern shore of the Dead Sea, approximately 55 kilometers southwest of Amman.",

        // 3. History
        history: "The Dead Sea has been known since ancient times for its unusual natural properties and mineral resources. It lies in the Jordan Rift Valley and is one of the lowest exposed land areas on Earth. Its surrounding region is also associated with important historical and religious traditions.",

        // 4. Main Attractions
        attractions: [
            {
                name: "Dead Sea Shoreline",
                description: "Enjoy the extraordinary salty water and experience floating naturally on the lake's surface."
            },
            {
                name: "Salt Formations",
                description: "Discover beautiful white salt crystals and formations along the shoreline."
            },
            {
                name: "Dead Sea Mineral Mud",
                description: "Experience the famous mineral-rich mud used in traditional spa treatments."
            },
            {
                name: "Dead Sea Panorama Complex",
                description: "Visit a scenic viewpoint overlooking the spectacular lake and surrounding landscape."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Experience the unusual feeling of floating in extremely salty water.",
            "Discover one of the lowest places on Earth.",
            "Enjoy beautiful desert and lake landscapes.",
            "Try mineral mud experiences and relaxing spa treatments.",
            "Explore the natural and historical significance of the region."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "Spring and Autumn",
            weather: "Warm and generally comfortable conditions for enjoying the lakeside.",
            recommendation: "March to May and September to November are popular periods for visiting."
        },

        // 7. Special Experience
        specialExperience: {
            title: "The Floating Experience",
            experience: "Float effortlessly on the salty water of the Dead Sea and enjoy the unique natural sensation.",
            culturalSignificance: "The Dead Sea has been valued for its minerals and natural resources throughout history.",
            recommendation: "Avoid getting water in your eyes or mouth, do not shave immediately before swimming, and follow local swimming safety guidance."
        },

        // 8. Budget Details
        budgetDetails: [
            {
                item: "Beach Entrance",
                cost: "$20 - $35"
            },
            {
                item: "Food and Drinks",
                cost: "$15 - $25"
            },
            {
                item: "Local Transportation",
                cost: "$20 - $25"
            },
            {
                item: "Spa or Mud Experience",
                cost: "$15 - $25"
            }
        ],

        budgetNote: "Estimated daily budget: $100 per person, depending on beach facilities and activities.",

        // 9. Transportation
        transportation: [
            "Travel from Amman to the Dead Sea by taxi, rental car, or organized tour.",
            "Use resort shuttle services when available.",
            "Explore nearby viewpoints and attractions with local transportation."
        ],
        // 10. Accommodation
        accommodation: [
            "Luxury resorts with private beach access and spa facilities.",
            "Mid-range hotels offering comfortable rooms and lake views.",
            "Budget-friendly accommodation in nearby towns and villages."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Arrive at the Dead Sea",
                description: "Enjoy the beautiful landscape and prepare for a relaxing day."
            },
            {
                time: "9:00 AM",
                activity: "Experience Floating",
                description: "Carefully enjoy the unique floating experience in the salty water."
            },
            {
                time: "10:30 AM",
                activity: "Explore Salt Formations",
                description: "Admire the white salt crystals and take photographs along the shoreline."
            },
            {
                time: "12:00 PM",
                activity: "Enjoy Lunch",
                description: "Relax and enjoy a meal at a nearby restaurant or resort."
            },
            {
                time: "1:30 PM",
                activity: "Try a Mineral Mud Experience",
                description: "Enjoy a traditional Dead Sea mud experience while following facility guidance."
            },
            {
                time: "3:00 PM",
                activity: "Visit Dead Sea Panorama",
                description: "Take in the impressive views of the lake from a scenic viewpoint."
            },
            {
                time: "5:00 PM",
                activity: "Relax and Enjoy the Sunset",
                description: "End the day with beautiful views over the Dead Sea."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Never drink Dead Sea water because its salt concentration is extremely high.",
            "Avoid swimming if you have open cuts or wounds.",
            "Keep your face above the water and avoid splashing.",
            "Rinse your body with fresh water after leaving the lake.",
            "Wear water shoes to protect your feet from sharp salt formations.",
            "Bring sunscreen, sunglasses, and drinking water.",
            "Follow beach staff instructions and swim only in designated areas.",
            "Avoid staying in the water longer than recommended."
        ]
    },

// ===================================
    // 15. JERASH
    // ===================================

    {
        name: "Jerash",
        country: "Jordan",
        category: "Ancient History & Roman Heritage",
        image: "images/Jerash.jpg",
        budget: 70,
        featured: false,

        // 1. Overview
        description: "Jerash is one of the best-preserved ancient Roman cities in the Middle East. Known for its impressive temples, theaters, stone streets, and monumental arches, it offers visitors an unforgettable journey into the history of the Roman Empire.",

        // 2. Location
        location: "Jerash Governorate, northern Jordan, approximately 50 kilometers north of Amman.",

        // 3. History
        history: "Jerash developed into an important city during the Hellenistic and Roman periods. It became part of the Decapolis, a group of influential ancient cities in the region. Its impressive ruins reveal the city's former importance as a center of trade, culture, and urban life.",

        // 4. Main Attractions
        attractions: [
            {
                name: "Hadrian's Arch",
                description: "A monumental entrance built to honor the visit of Roman Emperor Hadrian in the 2nd century CE."
            },
            {
                name: "Oval Plaza",
                description: "A remarkable open space surrounded by elegant columns and connected to the city's main streets."
            },
            {
                name: "Temple of Artemis",
                description: "An impressive ancient temple dedicated to Artemis, the city's patron goddess."
            },
            {
                name: "South Theater",
                description: "A large Roman theater known for its impressive stone seating and historical performances."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Explore one of the Middle East's best-preserved Roman cities.",
            "Discover remarkable ancient architecture and engineering.",
            "Learn about Roman, Greek, and regional history.",
            "Walk along original stone streets and impressive colonnades.",
            "Enjoy an unforgettable cultural and archaeological experience."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "Spring and Autumn",
            weather: "Pleasant temperatures and comfortable conditions for outdoor sightseeing.",
            recommendation: "March to May and September to November are ideal for exploring the archaeological site."
        },

        // 7. Special Experience
        specialExperience: {
            title: "Roman Army and Chariot Experience",
            experience: "Enjoy historical performances at the ancient Hippodrome, featuring demonstrations inspired by Roman military life and chariot racing.",
            culturalSignificance: "The performances introduce visitors to aspects of ancient Roman entertainment and military traditions.",
            recommendation: "Check the performance schedule before visiting because shows may not operate every day."
        },

        // 8. Budget Details
        budgetDetails: [
            {
                item: "Entrance Ticket",
                cost: "$10 - $15"
            },
            {
                item: "Food and Drinks",
                cost: "$10 - $20"
            },
            {
                item: "Local Transportation",
                cost: "$25 - $30"
            },
            {
                item: "Guide or Additional Activities",
                cost: "$10 - $15"
            }
        ],

        budgetNote: "Estimated daily budget: $70 per person, depending on transportation and activities.",

        // 9. Transportation
        transportation: [
            "Travel from Amman to Jerash by public bus, taxi, or private car.",
            "Walk through the archaeological site to explore its historical monuments.",
            "Hire a local guide for a deeper understanding of the city's history."
        ],
        // 10. Accommodation
        accommodation: [
            "Hotels and guesthouses in Jerash and nearby towns.",
            "Comfortable hotels in Amman for visitors planning a day trip.",
            "Budget-friendly accommodation options in northern Jordan."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Arrive at Jerash",
                description: "Begin exploring the ancient city before the afternoon heat."
            },
            {
                time: "9:00 AM",
                activity: "Visit Hadrian's Arch",
                description: "Admire the monumental entrance and learn about its Roman history."
            },
            {
                time: "10:00 AM",
                activity: "Explore the Oval Plaza",
                description: "Walk through the impressive open plaza surrounded by ancient columns."
            },
            {
                time: "11:00 AM",
                activity: "Visit the Temple of Artemis",
                description: "Discover the architecture and religious significance of this ancient temple."
            },
            {
                time: "12:30 PM",
                activity: "Enjoy Lunch",
                description: "Take a break and enjoy traditional Jordanian food nearby."
            },
            {
                time: "1:30 PM",
                activity: "Explore the South Theater",
                description: "Experience the impressive Roman theater and its historic surroundings."
            },
            {
                time: "3:00 PM",
                activity: "Visit the Hippodrome",
                description: "Discover the ancient arena and learn about Roman entertainment."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Wear comfortable walking shoes because the site has uneven ancient stone paths.",
            "Bring drinking water and sun protection.",
            "Start your visit early to enjoy cooler temperatures.",
            "Consider hiring a local guide to understand the historical details.",
            "Respect archaeological structures and avoid climbing protected ruins.",
            "Bring a camera to capture the impressive ancient architecture.",
            "Check opening hours and performance schedules before visiting.",
            "Allow several hours to explore the large archaeological site."
        ]
    },

    // ===================================
    // 16. WADI MUJIB
    // ===================================

    {
        name: "Wadi Mujib",
        country: "Jordan",
        category: "Nature & Adventure Tourism",
        image: "images/Wadi Mujib.jpg",
        budget: 85,
        featured: false,

        // 1. Overview
        description: "Wadi Mujib is a spectacular nature reserve in Jordan, famous for its deep sandstone canyons, flowing water, waterfalls, and dramatic landscapes. Located near the Dead Sea, it offers exciting outdoor adventures and unforgettable natural scenery.",

        // 2. Location
        location: "Along the eastern shore of the Dead Sea in central-western Jordan, approximately 90 kilometers south of Amman.",

        // 3. History
        history: "Wadi Mujib is part of the Mujib Biosphere Reserve, established in 1987 to protect its unique ecosystems and biodiversity. The reserve contains dramatic landscapes, rare wildlife, and diverse plant species. It is recognized as one of the world's lowest nature reserves.",

        // 4. Main Attractions
        attractions: [
            {
                name: "Siq Trail",
                description: "A famous canyon adventure where visitors walk and swim through flowing water between towering sandstone cliffs."
            },
            {
                name: "Mujib Biosphere Reserve",
                description: "A protected natural area featuring remarkable biodiversity and spectacular mountain landscapes."
            },
            {
                name: "Wadi Mujib Waterfalls",
                description: "Beautiful waterfalls and flowing streams surrounded by impressive canyon walls."
            },
            {
                name: "Dead Sea Viewpoints",
                description: "Enjoy scenic views of the Dead Sea and the surrounding rugged landscape."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Experience an exciting water adventure through a natural canyon.",
            "Discover beautiful waterfalls and dramatic sandstone landscapes.",
            "Explore one of Jordan's most important protected natural areas.",
            "Enjoy hiking, swimming, and outdoor activities.",
            "Experience a different side of Jordan beyond its famous historical attractions."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "Spring and Summer",
            weather: "Warmer conditions make water-based canyon adventures enjoyable, depending on trail availability and weather.",
            recommendation: "The Siq Trail generally operates seasonally, often from April to October, but visitors should check official opening information before traveling."
        },

        // 7. Special Experience
        specialExperience: {
            title: "Siq Trail Canyon Adventure",
            experience: "Walk, wade, and swim through a spectacular water-filled canyon surrounded by towering sandstone cliffs, with a waterfall along the route.",
            culturalSignificance: "The reserve highlights Jordan's natural heritage and the importance of protecting its unique landscapes and wildlife.",
            recommendation: "Follow official safety instructions and visit with authorized guides where required. Trail access depends on weather and water conditions."
        },

        // 8. Budget Details
        budgetDetails: [
            {
                item: "Trail Entrance",
                cost: "$20 - $30"
            },
            {
                item: "Food and Drinks",
                cost: "$10 - $15"
            },
            {
                item: "Local Transportation",
                cost: "$30 - $35"
            },
            {
                item: "Equipment and Additional Activities",
                cost: "$10 - $15"
            }
        ],

        budgetNote: "Estimated daily budget: $85 per person, depending on transportation, trail fees, and activities.",
        // 9. Transportation
        transportation: [
            "Travel from Amman or the Dead Sea area by taxi, rental car, or organized tour.",
            "Reach the reserve entrance and follow the designated visitor routes.",
            "Use authorized guides and transportation services when required."
        ],

        // 10. Accommodation
        accommodation: [
            "Hotels and resorts near the Dead Sea.",
            "Guesthouses and hotels in nearby towns.",
            "Comfortable accommodation in Amman for visitors planning a day trip."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Arrive at Wadi Mujib",
                description: "Reach the reserve entrance and prepare for your outdoor adventure."
            },
            {
                time: "8:30 AM",
                activity: "Safety Briefing",
                description: "Listen to the staff instructions and check the trail conditions and required equipment."
            },
            {
                time: "9:00 AM",
                activity: "Begin the Siq Trail",
                description: "Enter the beautiful canyon and enjoy the flowing water between the sandstone cliffs."
            },
            {
                time: "10:30 AM",
                activity: "Explore the Waterfall Area",
                description: "Enjoy the natural scenery and take a break at the designated stopping points."
            },
            {
                time: "12:00 PM",
                activity: "Return from the Trail",
                description: "Follow the designated route back while respecting safety instructions."
            },
            {
                time: "1:00 PM",
                activity: "Enjoy Lunch",
                description: "Relax and enjoy a meal at a nearby restaurant or visitor area."
            },
            {
                time: "2:30 PM",
                activity: "Enjoy the Surrounding Views",
                description: "Take photographs and appreciate the beautiful landscape near the Dead Sea."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Check trail opening dates and weather conditions before visiting.",
            "Wear suitable water shoes with a good grip.",
            "Bring a waterproof bag for personal belongings.",
            "Follow all safety instructions from reserve staff and guides.",
            "Do not enter the canyon during unsafe weather or flash-flood warnings.",
            "Bring drinking water and sun protection.",
            "Choose activities suitable for your swimming ability and physical fitness.",
            "Respect wildlife and avoid leaving rubbish inside the reserve."
        ]
    },
    
];