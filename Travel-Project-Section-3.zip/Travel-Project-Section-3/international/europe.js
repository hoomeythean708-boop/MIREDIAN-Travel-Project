// ===================================
// MIREDIAN - EUROPE
// ===================================

const europeDestinations = [

    // ===================================
    // I. FRANCE
    // ===================================

    // ===================================
    // 1. EIFFEL TOWER
    // ===================================

    {
        name: "Eiffel Tower",
        country: "France",
        category: "Architecture & Historic Landmark",
        image: "images/Eiffel Tower.jpg",
        budget: 85,
        featured: true,

        // 1. Overview
        description: "The Eiffel Tower is one of the world's most recognizable landmarks and a symbol of Paris, France. Famous for its impressive iron structure and breathtaking city views, it attracts millions of visitors from around the world every year.",

        // 2. Location
        location: "Champ de Mars, 5 Avenue Anatole France, Paris, France.",

        // 3. History
        history: "The Eiffel Tower was designed by engineer Gustave Eiffel's company and completed in 1889 for the Exposition Universelle, celebrating the 100th anniversary of the French Revolution. Originally intended as a temporary structure, it became one of the most famous symbols of France.",

        // 4. Main Attractions
        attractions: [
            {
                name: "First Floor",
                description: "Explore exhibitions, restaurants, and a transparent glass floor offering a unique view beneath the tower."
            },
            {
                name: "Second Floor",
                description: "Enjoy spectacular panoramic views of Paris and admire the city's famous landmarks."
            },
            {
                name: "Summit",
                description: "Reach the highest visitor level and experience breathtaking views across the French capital."
            },
            {
                name: "Champ de Mars",
                description: "Relax in the beautiful public gardens surrounding the Eiffel Tower and enjoy wonderful photo opportunities."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "See one of the most famous landmarks in the world.",
            "Enjoy breathtaking panoramic views of Paris.",
            "Discover an important achievement in engineering and architecture.",
            "Experience the romantic atmosphere of the French capital.",
            "Take unforgettable photographs during the day and at night."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "Spring and Autumn",
            weather: "Mild temperatures and comfortable conditions for sightseeing.",
            recommendation: "April to June and September to October are excellent periods to visit."
        },

        // 7. Special Experience
        specialExperience: {
            title: "Eiffel Tower at Night",
            experience: "Watch the tower illuminate the Paris skyline and enjoy its sparkling light display after sunset.",
            culturalSignificance: "The Eiffel Tower represents French creativity, engineering, and cultural identity.",
            recommendation: "Visit in the evening to enjoy the illuminated tower and beautiful nighttime atmosphere."
        },

        // 8. Budget Details
        budgetDetails: [
            {
                item: "Entrance Ticket",
                cost: "$20 - $35"
            },
            {
                item: "Food and Drinks",
                cost: "$15 - $25"
            },
            {
                item: "Local Transportation",
                cost: "$10 - $15"
            },
            {
                item: "Additional Activities",
                cost: "$10 - $20"
            }
        ],

        budgetNote: "Estimated daily budget: $85 per person, excluding international flights and accommodation.",

        // 9. Transportation
        transportation: [
            "Take Metro Line 6 to Bir-Hakeim or Line 9 to Trocadéro.",
            "Use local buses and taxis to reach the Eiffel Tower area.",
            "Walk along the Seine River and nearby gardens to explore the surrounding attractions."
        ],

        // 10. Accommodation
        accommodation: [
            "Luxury hotels near the Eiffel Tower offering beautiful city views.",
            "Mid-range hotels in the 7th and 15th arrondissements.",
            "Budget-friendly hostels and guesthouses throughout Paris."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Arrive at the Eiffel Tower",
                description: "Begin your visit early and enjoy the beautiful surroundings."
            },
            {
                time: "9:00 AM",
                activity: "Explore the First Floor",
                description: "Discover the tower's history, exhibitions, and glass floor."
            },
            {
                time: "10:00 AM",
                activity: "Visit the Second Floor",
                description: "Enjoy impressive views of Paris and its famous architecture."
            },
            {
                time: "11:00 AM",
                activity: "Experience the Summit",
                description: "Admire the spectacular skyline from the tower's highest visitor level."
            },
            {
                time: "12:30 PM",
                activity: "Enjoy Lunch",
                description: "Relax and enjoy French food at a nearby restaurant or café."
            },
            {
                time: "2:00 PM",
                activity: "Explore Champ de Mars",
                description: "Walk through the gardens and take memorable photographs."
            },
            {
                time: "7:00 PM",
                activity: "Enjoy the Night View",
                description: "Return to admire the illuminated Eiffel Tower and its sparkling lights."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Book entrance tickets in advance to avoid long queues.",
            "Visit early in the morning for a more comfortable experience.",
            "Bring a camera to capture the beautiful Paris skyline.",
            "Wear comfortable shoes for walking around the tower.",
            "Check the weather before visiting the summit.",
            "Keep personal belongings secure in crowded areas.",
            "Use public transportation to avoid traffic and parking difficulties.",
            "Stay after sunset to enjoy the tower's sparkling light display."
        ]
    },

    // ===================================
    // 2. LOUVRE MUSEUM
    // ===================================

    {
        name: "Louvre Museum",
        country: "France",
        category: "Art, Culture & History Museum",
        image: "images/Louvre Museum.jpg",
        budget: 90,
        featured: false,

        // 1. Overview
        description: "The Louvre Museum is one of the largest and most famous art museums in the world, located in the heart of Paris. Home to thousands of remarkable artworks and historical treasures, it is especially famous for the Mona Lisa and its iconic glass pyramid.",

        // 2. Location
        location: "Rue de Rivoli, 75001 Paris, France.",

        // 3. History
        history: "The Louvre originally began as a fortress in the late 12th century before becoming a royal palace. It officially opened as a public museum in 1793 during the French Revolution. Over time, it developed into one of the world's most important cultural institutions.",

        // 4. Main Attractions
        attractions: [
            {
                name: "Mona Lisa",
                description: "Leonardo da Vinci's world-famous portrait, admired for its mysterious expression and artistic significance."
            },
            {
                name: "Venus de Milo",
                description: "An ancient Greek marble sculpture representing Aphrodite, the goddess of love and beauty."
            },
            {
                name: "Winged Victory of Samothrace",
                description: "A magnificent ancient Greek sculpture depicting the goddess Nike."
            },
            {
                name: "Louvre Glass Pyramid",
                description: "The museum's iconic modern glass entrance, designed by architect I. M. Pei."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Explore one of the world's greatest art collections.",
            "Discover famous masterpieces from different civilizations.",
            "See the Mona Lisa and other internationally recognized artworks.",
            "Admire the beautiful architecture of the historic palace.",
            "Learn about art, culture, and history through extraordinary exhibitions."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "Spring and Autumn",
            weather: "Comfortable temperatures for exploring Paris and its cultural attractions.",
            recommendation: "April to June and September to October are excellent periods to visit."
        },

        // 7. Special Experience
        specialExperience: {
            title: "Discover the Mona Lisa",
            experience: "Visit the famous Mona Lisa gallery and admire Leonardo da Vinci's celebrated masterpiece in person.",
            culturalSignificance: "The painting represents an important achievement in Renaissance art and remains one of the most recognized portraits in history.",
            recommendation: "Arrive early and check the museum map to plan your visit to popular galleries."
        },

        // 8. Budget Details
        budgetDetails: [
            {
                item: "Museum Entrance",
                cost: "$25 - $35"
            },
            {
                item: "Food and Drinks",
                cost: "$15 - $25"
            },
            {
                item: "Local Transportation",
                cost: "$10 - $15"
            },
            {
                item: "Additional Activities",
                cost: "$10 - $15"
            }
        ],

        budgetNote: "Estimated daily budget: $90 per person, excluding international flights and accommodation.",

        // 9. Transportation
        transportation: [
            "Take Metro Line 1 or Line 7 to Palais Royal - Musée du Louvre station.",
            "Use local buses and taxis to reach the museum.",
            "Walk along the Seine River to explore nearby attractions and gardens."
        ],
        // 10. Accommodation
        accommodation: [
            "Luxury hotels near the Louvre and central Paris.",
            "Mid-range hotels in the 1st and 2nd arrondissements.",
            "Budget-friendly hostels and guesthouses throughout Paris."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "9:00 AM",
                activity: "Arrive at the Louvre",
                description: "Begin your museum visit early and explore the beautiful entrance courtyard."
            },
            {
                time: "9:30 AM",
                activity: "Visit the Mona Lisa",
                description: "Discover Leonardo da Vinci's famous masterpiece."
            },
            {
                time: "10:30 AM",
                activity: "Explore Ancient Sculptures",
                description: "Admire the Venus de Milo and Winged Victory of Samothrace."
            },
            {
                time: "12:00 PM",
                activity: "Enjoy Lunch",
                description: "Take a break at a nearby café or restaurant."
            },
            {
                time: "1:00 PM",
                activity: "Discover the Art Collections",
                description: "Explore galleries featuring European paintings and historical artworks."
            },
            {
                time: "3:00 PM",
                activity: "Visit the Glass Pyramid",
                description: "Admire the museum's iconic modern architectural landmark."
            },
            {
                time: "4:00 PM",
                activity: "Explore the Tuileries Garden",
                description: "Relax in the beautiful garden located beside the Louvre."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Book your museum ticket in advance.",
            "Check opening days and hours before visiting.",
            "Arrive early to avoid the busiest periods.",
            "Download the museum map to plan your route.",
            "Wear comfortable shoes because the museum is very large.",
            "Allow several hours to explore the main collections.",
            "Follow museum photography and visitor guidelines.",
            "Keep personal belongings secure in crowded galleries."
        ]
    },

    // ===================================
    // 3. PALACE OF VERSAILLES
    // ===================================

    {
        name: "Palace of Versailles",
        country: "France",
        category: "Royal History & Architecture",
        image: "images/Palace Of Versailles.jpg",
        budget: 100,
        featured: false,

        // 1. Overview
        description: "The Palace of Versailles is a magnificent royal residence located near Paris, France. Famous for its luxurious architecture, beautiful gardens, and rich royal history, it represents the grandeur of the French monarchy and is one of Europe's most celebrated historical landmarks.",

        // 2. Location
        location: "Place d'Armes, 78000 Versailles, France.",

        // 3. History
        history: "The Palace of Versailles was originally a hunting lodge built for King Louis XIII. It was transformed into a magnificent royal palace under King Louis XIV, who moved the royal court there in 1682. The palace later became an important symbol of French royal power and witnessed major historical events, including the signing of the Treaty of Versailles in 1919.",

        // 4. Main Attractions
        attractions: [
            {
                name: "Hall of Mirrors",
                description: "A spectacular gallery decorated with mirrors, chandeliers, and beautiful ceiling paintings."
            },
            {
                name: "Royal Apartments",
                description: "Luxurious rooms that reveal the lifestyle and artistic taste of French kings and queens."
            },
            {
                name: "Gardens of Versailles",
                description: "Magnificent formal gardens featuring fountains, sculptures, and carefully designed landscapes."
            },
            {
                name: "Grand Trianon",
                description: "An elegant marble palace built as a private retreat for the French royal family."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Explore one of Europe's most magnificent royal palaces.",
            "Discover the history of French kings and queens.",
            "Admire extraordinary architecture and luxurious interior design.",
            "Walk through beautiful gardens and impressive fountains.",
            "Experience an important landmark in French and European history."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "Spring and Summer",
            weather: "Mild to warm temperatures with beautiful garden scenery and seasonal fountain displays.",
            recommendation: "April to June and September are excellent periods for visiting the palace and gardens."
        },

        // 7. Special Experience
        specialExperience: {
            title: "The Hall of Mirrors Experience",
            experience: "Walk through the magnificent Hall of Mirrors and admire its sparkling chandeliers, grand windows, and historic decorations.",
            culturalSignificance: "The hall represents the power and artistic ambition of the French monarchy and hosted important historical events.",
            recommendation: "Consider visiting on a day when the gardens and musical fountain shows are operating."
        },

        // 8. Budget Details
        budgetDetails: [
            {
                item: "Palace Entrance",
                cost: "$25 - $35"
            },
            {
                item: "Food and Drinks",
                cost: "$15 - $25"
            },
            {
                item: "Local Transportation",
                cost: "$15 - $20"
            },
            {
                item: "Additional Activities",
                cost: "$15 - $20"
            }
        ],

        budgetNote: "Estimated daily budget: $100 per person, excluding international flights and accommodation.",

        // 9. Transportation
        transportation: [
            "Take an RER C train from central Paris to Versailles Château - Rive Gauche station.",
            "Use local buses or taxis to reach the palace entrance.",
            "Explore the palace grounds and gardens on foot or use available transport services."
        ],

        // 10. Accommodation
        accommodation: [
            "Luxury hotels near the Palace of Versailles.",
            "Mid-range hotels and guesthouses in Versailles town.",
            "Budget-friendly accommodation in Paris with convenient train connections."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "9:00 AM",
                activity: "Arrive at the Palace",
                description: "Begin your visit and admire the magnificent palace exterior."
            },
            {
                time: "10:00 AM",
                activity: "Explore the Royal Apartments",
                description: "Discover the luxurious rooms and historical decorations."
            },
            {
                time: "11:00 AM",
                activity: "Visit the Hall of Mirrors",
                description: "Admire the spectacular mirrors, chandeliers, and royal architecture."
            },
            {
                time: "12:30 PM",
                activity: "Enjoy Lunch",
                description: "Take a break at a restaurant or café near the palace."
            },
            {
                time: "1:30 PM",
                activity: "Explore the Gardens",
                description: "Walk through the beautiful gardens and admire their fountains and sculptures."
            },
            {
                time: "3:00 PM",
                activity: "Visit the Grand Trianon",
                description: "Discover the elegant royal retreat and its surrounding gardens."
            },
            {
                time: "4:30 PM",
                activity: "Enjoy the Palace Grounds",
                description: "Take photographs and appreciate the beautiful historic surroundings."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Purchase tickets in advance, especially during busy seasons.",
            "Check which areas are included in your selected ticket.",
            "Wear comfortable walking shoes because the grounds are extensive.",
            "Arrive early to enjoy the palace before the busiest hours.",
            "Check the seasonal fountain show schedule before visiting.",
            "Bring water and sun protection when exploring the gardens.",
            "Allow several hours to experience the palace and its grounds.",
            "Respect the historical interiors and follow visitor instructions."
        ]
    },

    // ===================================
    // 4. MONT SAINT-MICHEL
    // ===================================

    {
        name: "Mont Saint-Michel",
        country: "France",
        category: "Medieval Heritage & Architecture",
        image: "images/Mont Saint-Michel.jpg",
        budget: 75,
        featured: false,

        // 1. Overview
        description: "Mont Saint-Michel is a remarkable medieval island village in Normandy, famous for its magnificent abbey, narrow cobblestone streets, and dramatic tidal surroundings.",

        // 2. Location
        location: "Normandy, northwestern France, near the coast of the English Channel.",

        // 3. History
        history: "Mont Saint-Michel developed as a major religious destination after a sanctuary was established in the 8th century. Its abbey grew throughout the Middle Ages and became an important pilgrimage site and defensive stronghold.",

        // 4. Top Attractions
        attractions: [
            {
                name: "Mont Saint-Michel Abbey",
                description: "Explore the impressive medieval abbey built high above the island."
            },
            {
                name: "Grand Rue",
                description: "Walk along the narrow historic street filled with traditional buildings, shops, and restaurants."
            },
            {
                name: "Ramparts",
                description: "Discover the ancient defensive walls and enjoy beautiful views of the surrounding bay."
            },
            {
                name: "Mont Saint-Michel Bay",
                description: "Experience the spectacular coastal landscape and dramatic changes caused by the tides."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Discover one of France's most extraordinary medieval landmarks.",
            "Explore the beautiful historic abbey and village.",
            "Enjoy breathtaking coastal scenery and tidal landscapes.",
            "Experience centuries of French religious and cultural history.",
            "Capture unforgettable photographs of the island."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "Spring and Autumn",
            weather: "Mild temperatures with occasional rain and coastal winds.",
            recommendation: "April to June and September to October are excellent periods for comfortable sightseeing and fewer crowds."
        },

        // 7. Special Experiences
        specialExperience: {
            title: "Exploring the Medieval Island",
            experience: "Walk through the historic village, visit the abbey, explore the ancient ramparts, and admire the changing tides around the island.",
            culturalSignificance: "Mont Saint-Michel represents an important part of French medieval religious heritage and architectural history.",
            recommendation: "Visit the abbey and check the local tide schedule before exploring the bay."
        },

        // 8. Budget Details
        budgetDetails: [
            {
                item: "Accommodation",
                cost: "$35–$100 per night"
            },
            {
                item: "Food",
                cost: "$15–$35 per day"
            },
            {
                item: "Transportation",
                cost: "$15–$50"
            },
            {
                item: "Attractions",
                cost: "$10–$25"
            }
        ],

        budgetNote: "An estimated budget of $75 per person, excluding international flights. Actual expenses depend on travel style and season.",

        // 9. Transportation
        transportation: [
            "Take a train from Paris to Pontorson or nearby Rennes.",
            "Use the shuttle bus from the mainland visitor area to reach the island.",
            "Walk across the island to explore its historic attractions."
        ],

        // 10. Accommodation
        accommodation: [
            "Stay in traditional hotels on Mont Saint-Michel for a unique historic atmosphere.",
            "Choose guesthouses in nearby Beauvoir for more affordable accommodation.",
            "Consider hotels in Pontorson for convenient transportation access."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Arrival at Mont Saint-Michel",
                description: "Arrive early and enjoy the beautiful views of the island."
            },
            {
                time: "9:00 AM",
                activity: "Visit Mont Saint-Michel Abbey",
                description: "Explore the historic abbey and admire its impressive architecture."
            },
            {
                time: "11:00 AM",
                activity: "Explore Grand Rue",
                description: "Walk through the medieval streets and discover local shops."
            },
            {
                time: "12:30 PM",
                activity: "Lunch",
                description: "Enjoy traditional Norman food at a local restaurant."
            },
            {
                time: "2:00 PM",
                activity: "Walk Along the Ramparts",
                description: "Discover the historic defensive walls and panoramic views."
            },
            {
                time: "4:00 PM",
                activity: "Enjoy the Bay Scenery",
                description: "Admire the surrounding tidal landscape and take memorable photographs."
            },
            {
                time: "5:30 PM",
                activity: "Departure",
                description: "Return to the mainland after a memorable day of exploration."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Check the tide schedule before visiting the island.",
            "Wear comfortable walking shoes for the steep and uneven streets.",
            "Arrive early to avoid large tourist crowds.",
            "Bring a light jacket because coastal weather can change quickly.",
            "Book accommodation in advance during busy seasons.",
            "Respect the historic buildings and religious spaces.",
            "Carry some cash for small shops and local purchases.",
            "Check abbey opening hours before planning your visit."
        ]
    },

    // ===================================
    // 5. FRENCH RIVIERA
    // ===================================

    {
        name: "French Riviera",
        country: "France",
        category: "Coastal Tourism & Luxury Travel",
        image: "images/French Riviera.jpg",
        budget: 120,
        featured: false,

        // 1. Overview
        description: "The French Riviera, also known as the Côte d'Azur, is a beautiful Mediterranean coastline famous for its sunny beaches, charming seaside towns, luxury resorts, and vibrant cultural atmosphere.",

        // 2. Location
        location: "Southeastern France along the Mediterranean Sea, including popular destinations such as Nice, Cannes, Monaco's neighboring coast, and Saint-Tropez.",

        // 3. History
        history: "The French Riviera became a popular holiday destination during the 18th and 19th centuries, attracting European aristocrats and wealthy visitors. Over time, it developed into an internationally recognized center for tourism, art, and luxury coastal living.",

        // 4. Top Attractions
        attractions: [
            {
                name: "Promenade des Anglais",
                description: "Enjoy a scenic seaside walk along Nice's famous waterfront boulevard."
            },
            {
                name: "Cannes",
                description: "Discover the glamorous city known for its international film festival and beautiful beaches."
            },
            {
                name: "Saint-Tropez",
                description: "Explore a charming coastal town famous for its harbor, beaches, and Mediterranean atmosphere."
            },
            {
                name: "Èze Village",
                description: "Visit a picturesque medieval hilltop village with breathtaking views of the Mediterranean Sea."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Enjoy beautiful Mediterranean beaches and coastal scenery.",
            "Explore charming seaside towns and historic villages.",
            "Experience French food, art, and local culture.",
            "Discover famous destinations such as Nice and Cannes.",
            "Relax in one of Europe's most attractive coastal regions."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "Late Spring and Early Autumn",
            weather: "Warm, sunny Mediterranean weather with pleasant coastal breezes.",
            recommendation: "May to June and September to October offer comfortable temperatures and fewer crowds than the peak summer season."
        },

        // 7. Special Experiences
        specialExperience: {
            title: "Mediterranean Coastal Escape",
            experience: "Spend time on beautiful beaches, explore colorful seaside towns, enjoy coastal walks, and taste traditional French Mediterranean cuisine.",
            culturalSignificance: "The French Riviera represents an important part of French coastal culture and has inspired artists, writers, and travelers for generations.",
            recommendation: "Explore Nice's waterfront, visit a traditional hilltop village, and enjoy a relaxing sunset beside the Mediterranean Sea."
        },

        // 8. Budget Details
        budgetDetails: [
            {
                item: "Accommodation",
                cost: "$50–$150 per night"
            },
            {
                item: "Food",
                cost: "$20–$45 per day"
            },
            {
                item: "Transportation",
                cost: "$10–$35"
            },
            {
                item: "Attractions",
                cost: "$10–$40"
            }
        ],

        budgetNote: "An estimated budget of $120 per person, excluding international flights. Actual expenses vary depending on the town, season, and travel style.",

        // 9. Transportation
        transportation: [
            "Fly into Nice Côte d'Azur Airport for convenient access to the region.",
            "Use regional trains to travel between Nice, Cannes, and other coastal towns.",
            "Rent a car or use local buses to explore smaller villages and scenic coastal areas."
        ],

        // 10. Accommodation
        accommodation: [
            "Choose seaside hotels in Nice for convenient beach and city access.",
            "Stay in boutique hotels in Cannes for a stylish coastal experience.",
        "Consider guesthouses in nearby towns for more affordable accommodation."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Explore Nice",
                description: "Start the day by discovering Nice's beautiful streets and Mediterranean atmosphere."
            },
            {
                time: "9:30 AM",
                activity: "Promenade des Anglais",
                description: "Enjoy a relaxing walk along the famous waterfront boulevard."
            },
            {
                time: "11:00 AM",
                activity: "Visit Èze Village",
                description: "Explore the medieval village and admire its spectacular coastal views."
            },
            {
                time: "1:00 PM",
                activity: "Lunch",
                description: "Enjoy traditional French Mediterranean dishes at a local restaurant."
            },
            {
                time: "2:30 PM",
                activity: "Discover Cannes",
                description: "Explore the famous seaside city, its harbor, and its beaches."
            },
            {
                time: "4:30 PM",
                activity: "Relax by the Mediterranean",
                description: "Spend time enjoying the beach and beautiful coastal scenery."
            },
            {
                time: "6:00 PM",
                activity: "Sunset by the Coast",
                description: "Enjoy the evening atmosphere and take memorable photographs before departure."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Visit during spring or early autumn for pleasant weather.",
            "Book accommodation early during the summer season.",
            "Use regional trains to travel between major coastal towns.",
            "Bring sunscreen, sunglasses, and comfortable walking shoes.",
            "Carry swimwear if you plan to enjoy the beaches.",
            "Try local specialties such as salade niçoise and socca.",
            "Check public transportation schedules before traveling.",
            "Respect local beaches and keep the coastal environment clean."
        ]
    },

    // ===================================
    // II. ITALY
    // ===================================

    // ===================================
    // 1. COLOSSEUM
    // ===================================

    {
        name: "Colosseum",
        country: "Italy",
        category: "Ancient History & Architecture",
        image: "images/Colosseum.jpg",
        budget: 90,
        featured: true,

        // 1. Overview
        description: "The Colosseum is one of the world's most famous ancient landmarks, located in Rome, Italy. This enormous Roman amphitheater once hosted gladiator battles, public spectacles, and entertainment for thousands of spectators.",

        // 2. Location
        location: "Rome, Lazio, central Italy.",

        // 3. History
        history: "The Colosseum was constructed under Emperor Vespasian around AD 70–72 and officially opened by Emperor Titus in AD 80. It became a major center for public entertainment during the Roman Empire and remains an extraordinary symbol of ancient Roman engineering and civilization.",

        // 4. Top Attractions
        attractions: [
            {
                name: "Colosseum Arena",
                description: "Discover the central arena where gladiators and performers once entertained Roman audiences."
            },
            {
                name: "Underground Chambers",
                description: "Explore the underground areas where gladiators and animals were prepared for events."
            },
            {
                name: "Upper Levels",
                description: "Enjoy impressive views of the amphitheater and surrounding ancient city."
            },
            {
                name: "Roman Forum",
                description: "Visit the nearby archaeological site that was once the center of political and public life in ancient Rome."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Explore one of the most recognizable historical landmarks in the world.",
            "Discover the fascinating history of the Roman Empire.",
            "Admire remarkable ancient Roman engineering.",
            "Experience the atmosphere of an ancient amphitheater.",
            "Visit nearby archaeological sites and historic attractions."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "Spring and Autumn",
            weather: "Generally mild and comfortable, with warm sunshine and occasional rain.",
            recommendation: "April to June and September to October are ideal for exploring Rome with more comfortable sightseeing temperatures."
        },

        // 7. Special Experiences
        specialExperience: {
            title: "Journey Through Ancient Rome",
            experience: "Walk through the historic amphitheater, discover its underground structures, and imagine the spectacular public events that took place centuries ago.",
            culturalSignificance: "The Colosseum represents the power, architectural achievements, and entertainment culture of the ancient Roman Empire.",
            recommendation: "Book an official guided tour to learn more about the arena, underground chambers, and ancient Roman history."
        },

        // 8. Budget Details
        budgetDetails: [
            {
                item: "Accommodation",
                cost: "$35–$100 per night"
            },
            {
                item: "Food",
                cost: "$15–$35 per day"
            },
            {
                item: "Transportation",
                cost: "$5–$20"
            },
            {
                item: "Attractions",
                cost: "$20–$35"
            }
        ],

        budgetNote: "An estimated budget of $90 per person, excluding international flights. Actual expenses depend on accommodation, transportation, and travel style.",

        // 9. Transportation
        transportation: [
            "Fly into Rome Fiumicino Airport or Rome Ciampino Airport.",
            "Use Rome's Metro Line B and exit at the Colosseo station.",
            "Walk from nearby attractions such as the Roman Forum and Palatine Hill."
        ],

        // 10. Accommodation
        accommodation: [
            "Stay near the Colosseum for convenient access to ancient landmarks.",
            "Choose hotels around Monti for charming streets, restaurants, and cafés.",
            "Consider guesthouses near Termini Station for more affordable accommodation."
        ],
        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "8:30 AM",
                activity: "Arrival at the Colosseum",
                description: "Arrive early and admire the impressive exterior of the ancient amphitheater."
            },
            {
                time: "9:00 AM",
                activity: "Explore the Colosseum",
                description: "Discover the arena, seating areas, and fascinating architectural details."
            },
            {
                time: "11:00 AM",
                activity: "Visit the Underground Chambers",
                description: "Learn how gladiators and animals were prepared for ancient events."
            },
            {
                time: "12:30 PM",
                activity: "Lunch",
                description: "Enjoy traditional Italian pasta or pizza at a nearby restaurant."
            },
            {
                time: "2:00 PM",
                activity: "Explore the Roman Forum",
                description: "Walk among the ruins of ancient temples, public buildings, and historic streets."
            },
            {
                time: "4:00 PM",
                activity: "Visit Palatine Hill",
                description: "Discover the ancient ruins and enjoy beautiful views over Rome."
            },
            {
                time: "5:30 PM",
                activity: "Evening Walk",
                description: "Enjoy the historic surroundings and capture memorable photographs."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Book Colosseum tickets in advance, especially during busy seasons.",
            "Arrive early to avoid long queues and large crowds.",
            "Wear comfortable walking shoes for the archaeological areas.",
            "Bring water and sunscreen during warmer months.",
            "Check official ticket information before visiting.",
            "Consider a guided tour to understand the site's history.",
            "Keep personal belongings secure in crowded tourist areas.",
            "Respect the ancient structures and follow visitor regulations."
        ]
    },

    // ===================================
    // 2. GRAND CANAL
    // ===================================

    {
        name: "Grand Canal",
        country: "Italy",
        category: "Historic Waterway & Cultural Heritage",
        image: "images/Grand Canal.jpg",
        budget: 85,
        featured: false,

        // 1. Overview
        description: "The Grand Canal is Venice's most famous waterway, winding through the heart of the city. Lined with historic palaces, beautiful bridges, and colorful buildings, it offers visitors an unforgettable view of Venetian life and architecture.",

        // 2. Location
        location: "Venice, Veneto, northeastern Italy.",

        // 3. History
        history: "The Grand Canal developed as Venice grew into an important maritime trading city during the Middle Ages. Wealthy Venetian families built magnificent palaces along its banks, reflecting the city's prosperity and architectural traditions.",

        // 4. Top Attractions
        attractions: [
            {
                name: "Rialto Bridge",
                description: "Visit Venice's most famous historic bridge, featuring beautiful architecture and lively shops."
            },
            {
                name: "St. Mark's Basilica",
                description: "Admire the magnificent basilica known for its golden mosaics and Byzantine architecture."
            },
            {
                name: "Ca' d'Oro",
                description: "Discover a beautiful Gothic palace overlooking the Grand Canal."
            },
            {
                name: "Santa Maria della Salute",
                description: "Explore the impressive Baroque church located near the entrance of the Grand Canal."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Experience the romantic atmosphere of Venice's famous waterways.",
            "Admire beautiful historic palaces and Venetian architecture.",
            "Enjoy traditional gondola and waterbus rides.",
            "Discover the history of Venice as a maritime trading city.",
            "Capture unforgettable photographs of the canals and bridges."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "Spring and Early Autumn",
            weather: "Generally mild temperatures with comfortable conditions for walking and boat trips.",
            recommendation: "April to June and September to October are excellent periods for sightseeing and enjoying the waterways."
        },

        // 7. Special Experiences
        specialExperience: {
            title: "Gondola Ride Through Venice",
            experience: "Enjoy a traditional gondola ride along the Grand Canal and smaller waterways while admiring historic buildings and charming bridges.",
            culturalSignificance: "The Grand Canal represents the historic importance of Venice's waterways, which shaped its transportation, trade, architecture, and daily life.",
            recommendation: "Take a gondola ride for a traditional experience or use a vaporetto waterbus for an affordable scenic journey."
        },

        // 8. Budget Details
        budgetDetails: [
            {
                item: "Accommodation",
                cost: "$40–$120 per night"
            },
            {
                item: "Food",
                cost: "$15–$35 per day"
            },
            {
                item: "Transportation",
                cost: "$10–$30"
            },
            {
                item: "Attractions",
                cost: "$10–$35"
            }
        ],

        budgetNote: "An estimated budget of $85 per person, excluding international flights. Actual expenses depend on accommodation, transportation, and activities.",

        // 9. Transportation
        transportation: [
            "Fly into Venice Marco Polo Airport or arrive by train at Venezia Santa Lucia Station.",
            "Use vaporetto waterbuses to travel along the Grand Canal.",
            "Explore nearby streets and bridges on foot to discover hidden corners of Venice."
        ],

        // 10. Accommodation
        accommodation: [
            "Stay near Rialto Bridge for convenient access to historic attractions.",
            "Choose hotels in San Marco for a central location and beautiful surroundings.",
            "Consider guesthouses in Cannaregio for a quieter and more affordable stay."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Explore Venice",
                description: "Start the day with a peaceful walk through the charming streets of Venice."
            },
            {
                time: "9:00 AM",
                activity: "Visit Rialto Bridge",
                description: "Admire the historic bridge and enjoy views of the Grand Canal."
            },
            {
                time: "10:30 AM",
                activity: "Take a Vaporetto Ride",
                description: "Travel along the Grand Canal and admire the historic waterfront buildings."
            },
            {
                time: "12:00 PM",
                activity: "Lunch",
                description: "Enjoy traditional Venetian dishes at a local restaurant."
            },
            {
                time: "1:30 PM",
                activity: "Visit St. Mark's Basilica",
                description: "Explore the famous basilica and admire its impressive architecture."
            },
            {
                time: "3:30 PM",
                activity: "Enjoy a Gondola Ride",
                description: "Experience Venice from the water while passing historic bridges and beautiful buildings."
            },
            {
                time: "5:30 PM",
                activity: "Sunset by the Canal",
                description: "Relax beside the water and enjoy the beautiful evening atmosphere."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Visit popular attractions early to avoid large crowds.",
            "Wear comfortable shoes for walking along narrow streets and bridges.",
            "Use vaporetto waterbuses for affordable transportation.",
            "Book gondola rides in advance during busy travel periods.",
            "Carry some cash for small shops and local purchases.",
            "Be careful around slippery steps and canal edges.",
            "Check waterbus schedules before planning your journey.",
            "Respect local residents and keep the waterways clean."
        ]
    },

    // ===================================
    // 3. FLORENCE CATHEDRAL
    // ===================================

    {
        name: "Florence Cathedral",
        country: "Italy",
        category: "Religious Heritage & Renaissance Architecture",
        image: "images/Florence Cathedral.jpg",
        budget: 85,
        featured: false,

        // 1. Overview
        description: "Florence Cathedral, officially known as the Cathedral of Santa Maria del Fiore, is one of Italy's most magnificent architectural landmarks. Famous for its enormous dome, colorful marble exterior, and impressive Renaissance design, it stands at the heart of Florence.",

        // 2. Location
        location: "Piazza del Duomo, Florence, Tuscany, central Italy.",

        // 3. History
        history: "Construction of Florence Cathedral began in 1296 under architect Arnolfo di Cambio. Its famous dome was designed by Filippo Brunelleschi and completed in 1436, becoming one of the greatest engineering achievements of the Renaissance.",

        // 4. Top Attractions
        attractions: [
            {
                name: "Brunelleschi's Dome",
                description: "Admire the enormous Renaissance dome and enjoy panoramic views of Florence from its top."
            },
            {
                name: "Giotto's Bell Tower",
                description: "Discover the beautiful Gothic bell tower decorated with colorful marble and detailed sculptures."
            },
            {
                name: "Baptistery of St. John",
                description: "Explore the historic octagonal building famous for its magnificent bronze doors and mosaics."
            },
            {
                name: "Cathedral Interior",
                description: "Discover impressive religious artwork, beautiful architecture, and historic decorations inside the cathedral."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Admire one of the most famous Renaissance architectural masterpieces.",
            "Discover the remarkable engineering behind Brunelleschi's dome.",
            "Explore the artistic and religious heritage of Florence.",
            "Enjoy breathtaking views of the historic city.",
            "Experience one of Italy's most important cultural landmarks."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "Spring and Autumn",
            weather: "Mild temperatures with comfortable conditions for walking and sightseeing.",
            recommendation: "April to June and September to October are ideal for exploring Florence and its historic attractions."
        },

        // 7. Special Experiences
        specialExperience: {
            title: "Climbing Brunelleschi's Dome",
            experience: "Climb the historic dome's interior staircase to admire its impressive structure, beautiful artwork, and panoramic views across Florence.",
            culturalSignificance: "Florence Cathedral represents the artistic, religious, and architectural achievements of the Italian Renaissance.",
            recommendation: "Reserve a dome-climbing ticket in advance and enjoy the surrounding Piazza del Duomo."
        },

        // 8. Budget Details
        budgetDetails: [
            {
                item: "Accommodation",
                cost: "$40–$110 per night"
            },
            {
                item: "Food",
                cost: "$15–$35 per day"
            },
            {
                item: "Transportation",
                cost: "$5–$20"
            },
            {
                item: "Attractions",
                cost: "$15–$35"
            }
        ],

        budgetNote: "An estimated budget of $85 per person, excluding international flights. Actual expenses depend on accommodation, ticket choices, and travel style.",

        // 9. Transportation
        transportation: [
            "Fly into Florence Airport or arrive by train at Firenze Santa Maria Novella Station.",
            "Walk from the central train station to Piazza del Duomo.",
            "Explore nearby historic attractions on foot because many are located within walking distance."
        ],

        // 10. Accommodation
        accommodation: [
            "Stay near Piazza del Duomo for convenient access to the cathedral.",
            "Choose hotels around Santa Maria Novella for easy train station access.",
            "Consider guesthouses in Oltrarno for a quieter atmosphere and traditional neighborhood experience."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Arrival at Piazza del Duomo",
                description: "Begin the day by admiring the magnificent cathedral and its colorful marble exterior."
            },
            {
                time: "9:00 AM",
                activity: "Explore the Cathedral",
                description: "Discover the impressive interior and learn about its religious and artistic history."
            },
            {
                time: "10:30 AM",
                activity: "Climb Brunelleschi's Dome",
                description: "Experience the famous dome and enjoy spectacular views of Florence."
            },
            {
                time: "12:30 PM",
                activity: "Lunch",
                description: "Enjoy traditional Tuscan food at a nearby Italian restaurant."
            },
            {
                time: "2:00 PM",
                activity: "Visit Giotto's Bell Tower",
                description: "Admire the historic tower and its beautiful Gothic architecture."
            },
            {
                time: "3:30 PM",
                activity: "Explore the Baptistery",
                description: "Discover the historic building and its famous bronze doors."
            },
            {
                time: "5:00 PM",
                activity: "Evening Walk",
                description: "Explore the surrounding historic streets and enjoy the atmosphere of Florence."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Book dome-climbing tickets in advance.",
            "Dress respectfully when entering religious buildings.",
            "Wear comfortable shoes for climbing stairs and walking.",
            "Arrive early to avoid long queues.",
            "Check opening hours and ticket combinations before visiting.",
            "Bring water during warmer months.",
            "Keep personal belongings secure in crowded areas.",
            "Allow enough time to explore the entire Piazza del Duomo complex."
        ]
    },

        // ===================================
    // 4. LEANING TOWER OF PISA
    // ===================================

    {
        name: "Leaning Tower of Pisa",
        country: "Italy",
        category: "Historic Architecture & Cultural Heritage",
        image: "images/Leaning Tower of Pisa.jpg",
        budget: 80,
        featured: false,

        // 1. Overview
        description: "The Leaning Tower of Pisa is one of the world's most recognizable architectural landmarks. Famous for its unintended tilt, this historic bell tower attracts visitors who come to admire its unique design and take playful photographs.",

        // 2. Location
        location: "Piazza del Duomo, Pisa, Tuscany, central Italy.",

        // 3. History
        history: "Construction of the Leaning Tower began in 1173 as the bell tower of Pisa Cathedral. Its tilt developed because of unstable, soft ground beneath the foundations. Construction continued over several centuries, and the tower became a famous symbol of medieval Italian architecture.",

        // 4. Top Attractions
        attractions: [
            {
                name: "Leaning Tower of Pisa",
                description: "Admire the famous tilted marble bell tower and climb its historic staircase for views of the city."
            },
            {
                name: "Pisa Cathedral",
                description: "Explore the magnificent Romanesque cathedral located beside the tower."
            },
            {
                name: "Pisa Baptistery",
                description: "Discover the impressive circular religious building known for its architectural beauty and acoustics."
            },
            {
                name: "Camposanto Monumentale",
                description: "Visit the historic monumental cemetery featuring beautiful courtyards, artwork, and medieval architecture."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "See one of the most famous leaning structures in the world.",
            "Discover the fascinating engineering history behind the tower.",
            "Explore the beautiful Piazza del Duomo complex.",
            "Admire remarkable medieval Italian architecture.",
            "Capture creative and memorable photographs."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "Spring and Autumn",
            weather: "Mild temperatures and generally comfortable conditions for outdoor sightseeing.",
            recommendation: "April to June and September to October are excellent periods for visiting Pisa and exploring its historic attractions."
        },

        // 7. Special Experiences
        specialExperience: {
            title: "Climbing the Leaning Tower",
            experience: "Climb the historic spiral staircase and enjoy views of Pisa from the upper levels of the famous leaning bell tower.",
            culturalSignificance: "The tower represents an extraordinary example of medieval architecture and an important part of Pisa's historic cathedral complex.",
            recommendation: "Reserve an entry time in advance and take the classic photograph appearing to hold up the leaning tower."
        },

        // 8. Budget Details
        budgetDetails: [
            {
                item: "Accommodation",
                cost: "$35–$90 per night"
            },
            {
                item: "Food",
                cost: "$15–$30 per day"
            },
            {
                item: "Transportation",
                cost: "$5–$20"
            },
            {
                item: "Attractions",
                cost: "$15–$30"
            }
        ],

        budgetNote: "An estimated budget of $80 per person, excluding international flights. Actual expenses depend on accommodation, transportation, and selected attraction tickets.",

        // 9. Transportation
        transportation: [
            "Fly into Pisa International Airport for convenient access to the city.",
            "Take a local bus or walk from Pisa Centrale railway station to Piazza del Duomo.",
            "Use regional trains to travel between Pisa and other Tuscan cities such as Florence."
        ],

        // 10. Accommodation
        accommodation: [
            "Stay near Piazza del Duomo for convenient access to the main attractions.",
            "Choose hotels around Pisa Centrale for easy train and airport connections.",
            "Consider guesthouses in the historic city center for a charming local experience."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Arrival at Piazza del Duomo",
                description: "Begin the day by admiring the famous tower and its surrounding historic buildings."
            },
            {
                time: "9:00 AM",
                activity: "Climb the Leaning Tower",
                description: "Explore the tower's interior staircase and enjoy views from the upper levels."
            },
            {
                time: "10:30 AM",
                activity: "Visit Pisa Cathedral",
                description: "Discover the cathedral's beautiful architecture and religious artwork."
            },
            {
                time: "12:00 PM",
                activity: "Lunch",
                description: "Enjoy traditional Italian food at a nearby restaurant."
            },
            {
                time: "1:30 PM",
                activity: "Explore the Baptistery",
                description: "Admire the impressive circular structure and learn about its history."
            },
            {
                time: "3:00 PM",
                activity: "Visit Camposanto Monumentale",
                description: "Discover the historic cemetery and its remarkable artistic heritage."
            },
            {
                time: "4:30 PM",
                activity: "Photography and City Walk",
                description: "Capture memorable photographs and enjoy a relaxing walk around Pisa."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Book tower climbing tickets in advance because entry is limited.",
            "Arrive early to enjoy the attractions before the largest crowds.",
            "Wear comfortable shoes for climbing the spiral staircase.",
            "Follow all safety instructions when visiting the tower.",
            "Store large bags in the designated luggage area before climbing.",
            "Bring water and sunscreen during warmer months.",
            "Allow time to explore the entire Piazza del Duomo complex.",
            "Respect the historic buildings and visitor regulations."
        ]
    },

    // ===================================
    // 5. AMALFI COAST
    // ===================================

    {
        name: "Amalfi Coast",
        country: "Italy",
        category: "Coastal Tourism & Cultural Heritage",
        image: "images/Amalfi Coast.jpg",
        budget: 130,
        featured: false,

        // 1. Overview
        description: "The Amalfi Coast is a breathtaking coastal region in southern Italy, famous for its colorful villages, dramatic cliffs, turquoise waters, and beautiful Mediterranean scenery. Its charming seaside towns and winding coastal roads make it one of Italy's most unforgettable destinations.",

        // 2. Location
        location: "Salerno Province, Campania, southwestern Italy, along the southern edge of the Sorrentine Peninsula.",

        // 3. History
        history: "The Amalfi Coast developed as an important maritime region during the Middle Ages. The historic Republic of Amalfi became a powerful trading center, connecting different Mediterranean cultures. Today, the region is celebrated for its traditional villages, historic architecture, and coastal heritage.",

        // 4. Top Attractions
        attractions: [
            {
                name: "Positano",
                description: "Explore the famous hillside village with colorful houses, narrow streets, and beautiful beaches."
            },
            {
                name: "Amalfi Cathedral",
                description: "Visit the magnificent cathedral in Amalfi, known for its impressive staircase and historic architecture."
            },
            {
                name: "Ravello",
                description: "Discover a peaceful hilltop town famous for its elegant gardens and panoramic sea views."
            },
            {
                name: "Path of the Gods",
                description: "Enjoy a spectacular hiking trail with breathtaking views of the coastline and surrounding mountains."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Admire spectacular Mediterranean coastal scenery.",
            "Explore charming villages built along dramatic cliffs.",
            "Enjoy beautiful beaches and clear blue waters.",
            "Experience traditional Italian food and local culture.",
            "Discover historic towns, gardens, and scenic hiking trails."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "Late Spring and Early Autumn",
            weather: "Warm Mediterranean sunshine with pleasant temperatures and coastal breezes.",
            recommendation: "May to June and September to October are ideal for comfortable sightseeing, beach visits, and exploring the villages."
        },

        // 7. Special Experiences
        specialExperience: {
            title: "Scenic Coastal Boat Tour",
            experience: "Take a boat trip along the coastline, admire colorful cliffside villages, swim in beautiful waters, and enjoy unforgettable views of the Mediterranean Sea.",
            culturalSignificance: "The Amalfi Coast reflects Italy's maritime history, traditional coastal communities, and distinctive Mediterranean lifestyle.",
            recommendation: "Enjoy a boat excursion between Amalfi and Positano and try traditional local specialties such as limoncello and fresh seafood."
        },

        // 8. Budget Details
        budgetDetails: [
            {
                item: "Accommodation",
                cost: "$60–$180 per night"
            },
            {
                item: "Food",
                cost: "$20–$45 per day"
            },
            {
                item: "Transportation",
                cost: "$15–$40"
            },
            {
                item: "Attractions",
                cost: "$10–$35"
            }
        ],

        budgetNote: "An estimated budget of $130 per person, excluding international flights. Actual expenses depend on the season, accommodation, and activities.",

        // 9. Transportation
        transportation: [
            "Fly into Naples International Airport and travel toward the Amalfi Coast.",
            "Use regional buses and ferries to travel between coastal towns.",
            "Take a boat tour for scenic transportation between destinations such as Amalfi and Positano."
        ],
        // 10. Accommodation
        accommodation: [
            "Stay in Positano for beautiful coastal scenery and a lively seaside atmosphere.",
            "Choose hotels in Amalfi for convenient access to historic attractions and ferry services.",
            "Consider guesthouses in smaller nearby towns for more affordable accommodation."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Arrival in Positano",
                description: "Begin the day by exploring the colorful hillside village and its charming streets."
            },
            {
                time: "9:30 AM",
                activity: "Enjoy the Beach",
                description: "Relax beside the Mediterranean Sea and admire the beautiful coastal scenery."
            },
            {
                time: "11:00 AM",
                activity: "Boat Ride Along the Coast",
                description: "Enjoy a scenic boat journey and admire the dramatic cliffs and seaside villages."
            },
            {
                time: "12:30 PM",
                activity: "Lunch in Amalfi",
                description: "Taste traditional Italian seafood dishes and local specialties."
            },
            {
                time: "2:00 PM",
                activity: "Visit Amalfi Cathedral",
                description: "Explore the historic cathedral and discover the town's maritime heritage."
            },
            {
                time: "3:30 PM",
                activity: "Explore Ravello",
                description: "Visit the hilltop town and enjoy its peaceful atmosphere and panoramic views."
            },
            {
                time: "5:30 PM",
                activity: "Coastal Sunset",
                description: "Relax and admire the beautiful Mediterranean coastline before departure."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Visit during late spring or early autumn for pleasant weather.",
            "Book accommodation early, especially during summer.",
            "Wear comfortable shoes because many streets and paths are steep.",
            "Use ferries when available to avoid busy coastal roads.",
            "Bring sunscreen, sunglasses, and swimwear.",
            "Carry some cash for small shops and local purchases.",
            "Check ferry and bus schedules before planning your journey.",
            "Respect the beaches and help keep the coastline clean."
        ]
    },

    // ===================================
    // III. SWITZERLAND
    // ===================================

    // ===================================
    // 1. MATTERHORN
    // ===================================

    {
        name: "Matterhorn",
        country: "Switzerland",
        category: "Mountain Tourism & Alpine Adventure",
        image: "images/Matterhorn.jpg",
        budget: 150,
        featured: true,

        // 1. Overview
        description: "The Matterhorn is one of the most iconic mountains in the Swiss Alps, famous for its distinctive pyramid-shaped peak and breathtaking alpine scenery. It attracts visitors from around the world for mountain adventures, skiing, hiking, and spectacular photography.",

        // 2. Location
        location: "Near Zermatt, Valais, southwestern Switzerland.",

        // 3. History
        history: "The Matterhorn became internationally famous after its first successful ascent in 1865 by a team led by British climber Edward Whymper. Today, it is a symbol of Switzerland and an important destination for mountaineering and alpine tourism.",

        // 4. Top Attractions
        attractions: [
            {
                name: "Gornergrat",
                description: "Enjoy spectacular panoramic views of the Matterhorn and surrounding snow-covered Alpine peaks from this famous mountain viewpoint."
            },
            {
                name: "Matterhorn Glacier Paradise",
                description: "Visit Europe's highest mountain cable car station and discover impressive glacier scenery."
            },
            {
                name: "Riffelsee Lake",
                description: "Admire the famous reflection of the Matterhorn in this beautiful alpine lake."
            },
            {
                name: "Zermatt Village",
                description: "Explore the charming mountain village filled with traditional wooden buildings, restaurants, and alpine shops."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Admire one of the world's most recognizable mountain peaks.",
            "Experience spectacular Swiss Alpine landscapes.",
            "Enjoy hiking, skiing, and mountain adventures.",
            "Discover beautiful alpine lakes and mountain viewpoints.",
            "Experience the peaceful atmosphere of Zermatt village."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "Summer and Winter",
            weather: "Summer offers mild mountain temperatures, while winter brings cold conditions and excellent snow for winter sports.",
            recommendation: "June to September is ideal for hiking and sightseeing, while December to March is popular for skiing and snow activities."
        },

        // 7. Special Experiences
        specialExperience: {
            title: "Scenic Alpine Mountain Adventure",
            experience: "Take a mountain railway or cable car to enjoy breathtaking views of the Matterhorn, explore alpine trails, and photograph the mountain reflected in Riffelsee Lake.",
            culturalSignificance: "The Matterhorn represents Switzerland's alpine heritage and has become a worldwide symbol of mountain exploration and natural beauty.",
            recommendation: "Visit Gornergrat for incredible panoramic views and arrive early for the best photography conditions."
        },

        // 8. Budget Details
        budgetDetails: [
            {
                item: "Accommodation",
                cost: "$80–$200 per night"
            },
            {
                item: "Food",
                cost: "$25–$50 per day"
            },
            {
                item: "Transportation",
                cost: "$20–$60"
            },
            {
                item: "Attractions",
                cost: "$30–$80"
            }
        ],

        budgetNote: "An estimated budget of $150 per person, excluding international flights. Actual expenses depend on accommodation, mountain transport, activities, and season.",

        // 9. Transportation
        transportation: [
            "Fly into Geneva or Zurich Airport and travel by train toward Zermatt.",
            "Take a scenic Swiss train journey from Visp or Brig to Zermatt.",
            "Use mountain railways and cable cars to reach viewpoints around the Matterhorn."
        ],
        // 10. Accommodation
        accommodation: [
            "Stay in Zermatt village for convenient access to mountain transportation and attractions.",
            "Choose alpine hotels with beautiful mountain views for a memorable experience.",
            "Consider guesthouses and hostels for more affordable accommodation."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "7:30 AM",
                activity: "Explore Zermatt Village",
                description: "Begin the day with a peaceful walk through the charming alpine village."
            },
            {
                time: "8:30 AM",
                activity: "Travel to Gornergrat",
                description: "Take the mountain railway and enjoy beautiful views along the journey."
            },
            {
                time: "10:00 AM",
                activity: "Admire the Matterhorn",
                description: "Enjoy spectacular panoramic views of the famous mountain peak."
            },
            {
                time: "11:30 AM",
                activity: "Visit Riffelsee Lake",
                description: "Discover the beautiful alpine lake and photograph the Matterhorn's reflection when conditions allow."
            },
            {
                time: "1:00 PM",
                activity: "Lunch",
                description: "Enjoy traditional Swiss food at a mountain restaurant."
            },
            {
                time: "2:30 PM",
                activity: "Explore Zermatt",
                description: "Return to the village and discover its traditional buildings and local shops."
            },
            {
                time: "5:00 PM",
                activity: "Alpine Evening Views",
                description: "Relax and admire the beautiful mountain scenery before ending the day."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Check mountain weather conditions before traveling.",
            "Bring warm clothing because mountain temperatures can change quickly.",
            "Wear comfortable hiking shoes for alpine trails.",
            "Book accommodation early during popular travel seasons.",
            "Carry sunscreen and sunglasses because sunlight can be strong at high altitudes.",
            "Check mountain railway and cable car operating schedules.",
            "Stay on marked trails and follow mountain safety instructions.",
            "Respect the natural environment and keep the mountain area clean."
        ]
    },

    // ===================================
    // 2. LAKE GENEVA
    // ===================================

    {
        name: "Lake Geneva",
        country: "Switzerland",
        category: "Lake Tourism & Scenic Landscapes",
        image: "images/Lake Geneva.jpg",
        budget: 120,
        featured: false,

        // 1. Overview
        description: "Lake Geneva, also known as Lac Léman, is one of Europe's largest lakes, surrounded by beautiful Alpine scenery, charming lakeside towns, vineyards, and historic landmarks. Its peaceful waterfront atmosphere makes it a popular destination for sightseeing, boat trips, and outdoor activities.",

        // 2. Location
        location: "Western Switzerland, bordering France, with popular lakeside destinations including Geneva, Lausanne, Montreux, and Vevey.",

        // 3. History
        history: "Lake Geneva has played an important role in the region's trade, transportation, and settlement for centuries. Its shores developed into cultural and tourism centers, attracting artists, writers, and visitors from around the world.",

        // 4. Top Attractions
        attractions: [
            {
                name: "Jet d'Eau",
                description: "Admire Geneva's famous water fountain, which rises dramatically above the lake."
            },
            {
                name: "Chillon Castle",
                description: "Explore the beautiful medieval castle located beside the lake near Montreux."
            },
            {
                name: "Lavaux Vineyards",
                description: "Discover terraced vineyards overlooking the lake, famous for their spectacular scenery."
            },
            {
                name: "Montreux Lakeside Promenade",
                description: "Enjoy a relaxing waterfront walk surrounded by flowers, mountain views, and beautiful landscapes."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Enjoy breathtaking views of the Swiss Alps and clear blue waters.",
            "Explore historic castles and charming lakeside towns.",
            "Experience scenic boat cruises across the lake.",
            "Discover beautiful vineyards and peaceful walking paths.",
            "Enjoy Swiss culture, food, and relaxing waterfront activities."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "Late Spring and Summer",
            weather: "Generally mild to warm weather with pleasant conditions for outdoor sightseeing and lake activities.",
            recommendation: "May to September is ideal for boat trips, lakeside walks, and exploring the surrounding towns."
        },

        // 7. Special Experiences
        specialExperience: {
            title: "Scenic Cruise Across Lake Geneva",
            experience: "Take a boat cruise across the lake while admiring the surrounding mountains, historic waterfront towns, and beautiful lakeside scenery.",
            culturalSignificance: "Lake Geneva has shaped the history, culture, trade, and tourism of communities along its shores for generations.",
            recommendation: "Enjoy a scenic cruise between Geneva, Lausanne, and Montreux, and visit Chillon Castle for a memorable cultural experience."
        },

        // 8. Budget Details
        budgetDetails: [
            {
                item: "Accommodation",
                cost: "$70–$160 per night"
            },
            {
                item: "Food",
                cost: "$25–$50 per day"
            },
            {
                item: "Transportation",
                cost: "$10–$35"
            },
            {
                item: "Attractions",
                cost: "$15–$45"
            }
        ],

        budgetNote: "An estimated budget of $120 per person, excluding international flights. Actual expenses depend on the town, accommodation, transportation, and activities.",

        // 9. Transportation
        transportation: [
            "Fly into Geneva Airport for convenient access to the western side of the lake.",
            "Use Switzerland's railway network to travel between Geneva, Lausanne, Vevey, and Montreux.",
            "Take passenger boats to explore different lakeside destinations."
        ],
        // 10. Accommodation
        accommodation: [
            "Stay in Geneva for convenient access to international transport and city attractions.",
            "Choose lakeside hotels in Montreux for beautiful mountain and waterfront views.",
            "Consider guesthouses in Lausanne or Vevey for a comfortable stay near the lake."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Explore Geneva",
                description: "Begin the day with a walk along the waterfront and enjoy the beautiful lake scenery."
            },
            {
                time: "9:00 AM",
                activity: "Visit Jet d'Eau",
                description: "Admire the famous fountain and take photographs beside the lake."
            },
            {
                time: "10:30 AM",
                activity: "Lake Geneva Boat Cruise",
                description: "Enjoy a scenic boat journey while admiring the surrounding mountains and towns."
            },
            {
                time: "12:30 PM",
                activity: "Lunch in Lausanne",
                description: "Enjoy traditional Swiss food at a local restaurant overlooking the lake."
            },
            {
                time: "2:00 PM",
                activity: "Explore Lavaux Vineyards",
                description: "Discover the beautiful terraced vineyards and panoramic lake views."
            },
            {
                time: "3:30 PM",
                activity: "Visit Chillon Castle",
                description: "Explore the historic medieval castle near Montreux."
            },
            {
                time: "5:30 PM",
                activity: "Evening Lakeside Walk",
                description: "Relax along the waterfront and enjoy the peaceful Alpine scenery."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Visit between May and September for pleasant outdoor activities.",
            "Check boat cruise schedules before planning your trip.",
            "Bring a light jacket because lakeside weather can change.",
            "Wear comfortable shoes for walking along the waterfront.",
            "Book accommodation early during summer festivals and holidays.",
            "Carry sunscreen and sunglasses for sunny days.",
            "Try traditional Swiss cheese dishes and local chocolate.",
            "Respect the lake environment and keep public areas clean."
        ]
    },

    // ===================================
    // 3. JUNGFRAUJOCH
    // ===================================

    {
        name: "Jungfraujoch",
        country: "Switzerland",
        category: "Mountain Tourism & Alpine Adventure",
        image: "images/Jungfraujoch.jpg",
        budget: 180,
        featured: false,

        // 1. Overview
        description: "Jungfraujoch, famously known as the Top of Europe, is a spectacular mountain destination in the Swiss Alps. Located between the Jungfrau and Mönch mountains, it offers breathtaking snowy landscapes, glaciers, panoramic viewpoints, and unforgettable high-altitude experiences.",

        // 2. Location
        location: "Bernese Alps, Switzerland, accessible by mountain railway from the Jungfrau Region.",

        // 3. History
        history: "Jungfraujoch became a remarkable tourism destination after the Jungfrau Railway project began in 1896. The railway officially opened in 1912, making it possible for visitors to reach one of Europe's highest railway stations and experience the spectacular Alpine environment.",

        // 4. Top Attractions
        attractions: [
            {
                name: "Sphinx Observatory",
                description: "Enjoy incredible panoramic views of the surrounding mountains and Aletsch Glacier from this famous high-altitude observatory."
            },
            {
                name: "Aletsch Glacier",
                description: "Admire the largest glacier in the Alps, surrounded by impressive snow-covered mountain scenery."
            },
            {
                name: "Ice Palace",
                description: "Explore fascinating ice tunnels and beautifully carved ice sculptures inside a glacier."
            },
            {
                name: "Jungfrau Panorama",
                description: "Experience immersive panoramic views of the dramatic Alpine landscape through a spectacular viewing attraction."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Experience the breathtaking beauty of the Swiss Alps.",
            "Visit one of Europe's highest railway stations.",
            "Discover impressive glaciers and year-round snowy landscapes.",
            "Explore fascinating ice sculptures and mountain attractions.",
            "Enjoy unforgettable panoramic views from high above the Alps."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "Summer and Winter",
            weather: "Cold mountain conditions throughout the year, with snow and rapidly changing weather possible even during summer.",
            recommendation: "June to September is popular for clearer sightseeing conditions, while December to March offers a beautiful winter atmosphere. Always check mountain weather before visiting."
        },

        // 7. Special Experiences
        specialExperience: {
            title: "Journey to the Top of Europe",
            experience: "Ride the famous Jungfrau Railway through the mountains and discover snowy viewpoints, the Ice Palace, and spectacular glacier scenery.",
            culturalSignificance: "The Jungfrau Railway represents an extraordinary achievement in Swiss engineering and helped make the high Alpine region accessible to international visitors.",
            recommendation: "Take the railway journey early in the day and spend time enjoying the Sphinx Observatory and surrounding mountain views."
        },

        // 8. Budget Details
        budgetDetails: [
            {
                item: "Accommodation",
                cost: "$80–$180 per night"
            },
            {
                item: "Food",
                cost: "$25–$50 per day"
            },
            {
                item: "Transportation",
                cost: "$100–$160"
            },
            {
                item: "Attractions",
                cost: "$20–$40"
            }
        ],

        budgetNote: "An estimated budget of $180 per person, excluding international flights. The Jungfrau Railway ticket is a major expense, and actual costs depend on the departure point, season, and travel discounts.",

        // 9. Transportation
        transportation: [
            "Fly into Zurich or Geneva Airport and travel by train to the Jungfrau Region.",
            "Take a regional train to Grindelwald or Lauterbrunnen before connecting to the mountain railway.",
            "Use the Jungfrau Railway to reach Jungfraujoch and enjoy the scenic mountain journey."
        ],

        // 10. Accommodation
        accommodation: [
            "Stay in Grindelwald for convenient access to mountain transport and outdoor activities.",
            "Choose Lauterbrunnen for a peaceful village atmosphere surrounded by waterfalls and mountains.",
            "Consider Interlaken for a wider selection of hotels, restaurants, and transport connections."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "7:00 AM",
                activity: "Depart for Jungfraujoch",
                description: "Begin the journey from Grindelwald or Lauterbrunnen toward the mountain railway."
            },
            {
                time: "8:30 AM",
                activity: "Jungfrau Railway Journey",
                description: "Enjoy the spectacular train ride through the Swiss Alps."
            },
            {
                time: "10:00 AM",
                activity: "Visit Sphinx Observatory",
                description: "Admire the breathtaking views of the surrounding mountains and glaciers."
            },
            {
                time: "11:00 AM",
                activity: "Explore the Ice Palace",
                description: "Walk through beautiful ice tunnels and discover impressive ice sculptures."
            },
            {
                time: "12:30 PM",
                activity: "Mountain Lunch",
                description: "Enjoy a meal while taking in the unforgettable Alpine scenery."
            },
            {
                time: "2:00 PM",
                activity: "Discover Jungfrau Panorama",
                description: "Experience immersive mountain views and capture memorable photographs."
            },
            {
                time: "3:30 PM",
                activity: "Return to the Jungfrau Region",
                description: "Take the railway back down and enjoy the beautiful mountain landscapes along the way."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Check mountain weather and visibility before starting your journey.",
            "Book railway tickets in advance, especially during busy seasons.",
            "Wear warm clothing even when visiting during summer.",
            "Bring sunglasses because sunlight reflects strongly off the snow.",
            "Walk slowly and allow your body time to adjust to the high altitude.",
            "Drink enough water and avoid strenuous activity if you feel unwell.",
            "Keep your camera or phone ready for spectacular mountain views.",
            "Follow safety instructions and stay within designated visitor areas."
        ]
    },

    // ===================================
    // 4. CHAPEL BRIDGE
    // ===================================

    {
        name: "Chapel Bridge",
        country: "Switzerland",
        category: "Historic Landmarks & Cultural Tourism",
        image: "images/Chapel Bridge.jpg",
        budget: 100,
        featured: false,

        // 1. Overview
        description: "Chapel Bridge, known as Kapellbrücke, is one of Switzerland's most famous historic landmarks. Located in the charming city of Lucerne, this beautiful covered wooden bridge crosses the Reuss River and features a distinctive stone water tower. Its historic architecture and picturesque surroundings make it a must-visit destination.",

        // 2. Location
        location: "Lucerne, central Switzerland, crossing the Reuss River near the Old Town.",

        // 3. History
        history: "Chapel Bridge was originally constructed in the 14th century as part of Lucerne's medieval fortifications. The bridge is famous for its historic painted interior panels, many of which depict important events from Swiss history. A major fire damaged the bridge in 1993, but it was carefully restored and remains a beloved symbol of Lucerne.",

        // 4. Top Attractions
        attractions: [
            {
                name: "Chapel Bridge",
                description: "Walk across the historic covered wooden bridge and admire its traditional architecture."
            },
            {
                name: "Water Tower",
                description: "Discover the iconic octagonal stone tower that stands beside the bridge and has served various purposes throughout history."
            },
            {
                name: "Jesuit Church",
                description: "Visit the beautiful Baroque church along the Reuss River, known for its elegant interior and twin towers."
            },
            {
                name: "Lucerne Old Town",
                description: "Explore charming streets, historic buildings, colorful painted facades, and traditional Swiss shops."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Discover one of Switzerland's most recognizable historic landmarks.",
            "Admire beautiful medieval wooden architecture.",
            "Learn about Lucerne's history through the bridge's painted panels.",
            "Enjoy picturesque views of the Reuss River and surrounding mountains.",
            "Explore the charming streets and cultural attractions of Lucerne."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "Spring and Summer",
            weather: "Generally mild and pleasant, making it comfortable to explore the bridge and surrounding city on foot.",
            recommendation: "April to September is ideal for walking, sightseeing, photography, and enjoying the lakeside atmosphere."
        },

        // 7. Special Experiences
        specialExperience: {
            title: "Walk Through Medieval Lucerne",
            experience: "Take a peaceful walk across Chapel Bridge, admire its historic paintings, photograph the Water Tower, and explore the beautiful Old Town.",
            culturalSignificance: "Chapel Bridge represents Lucerne's medieval heritage and is an important symbol of Swiss history, craftsmanship, and cultural identity.",
            recommendation: "Visit early in the morning or around sunset to enjoy the bridge's beautiful atmosphere and capture memorable photographs."
        },

        // 8. Budget Details
        budgetDetails: [
            {
                item: "Accommodation",
                cost: "$60–$130 per night"
            },
            {
                item: "Food",
                cost: "$20–$45 per day"
            },
            {
                item: "Transportation",
                cost: "$10–$25"
            },
            {
                item: "Attractions",
                cost: "$10–$30"
            }
        ],

        budgetNote: "An estimated budget of $100 per person, excluding international flights. Walking across Chapel Bridge is free, while other expenses depend on accommodation, dining, and optional activities.",

        // 9. Transportation
        transportation: [
            "Fly into Zurich Airport and take a train to Lucerne.",
            "Walk from Lucerne railway station to Chapel Bridge in just a few minutes.",
            "Use local buses, trains, or boats to explore other attractions around the city and Lake Lucerne."
        ],

        // 10. Accommodation
        accommodation: [
            "Stay near Lucerne Old Town for easy access to Chapel Bridge and historic attractions.",
            "Choose a lakeside hotel for beautiful views of Lake Lucerne and the surrounding mountains.",
            "Consider guesthouses outside the city center for more affordable accommodation."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Visit Chapel Bridge",
                description: "Begin the day with a peaceful walk across the historic wooden bridge."
            },
            {
                time: "9:00 AM",
                activity: "Explore the Water Tower",
                description: "Admire the famous stone tower and take photographs beside the river."
            },
            {
                time: "10:00 AM",
                activity: "Discover Lucerne Old Town",
                description: "Walk through charming streets and admire colorful historic buildings."
            },
            {
                time: "11:30 AM",
                activity: "Visit Jesuit Church",
                description: "Explore the beautiful Baroque architecture and peaceful interior."
            },
            {
                time: "12:30 PM",
                activity: "Swiss Lunch",
                description: "Enjoy traditional Swiss food at a local restaurant in the Old Town."
            },
            {
                time: "2:00 PM",
                activity: "Lake Lucerne Waterfront",
                description: "Relax beside the lake and enjoy views of the surrounding mountains."
            },
            {
                time: "4:00 PM",
                activity: "Evening Photography",
                description: "Return to Chapel Bridge to capture beautiful photographs as the city becomes quieter."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Visit early in the morning to avoid large crowds.",
            "Walk carefully and respect the historic wooden structure.",
            "Take time to admire the painted panels inside the bridge.",
            "Bring a camera to capture the beautiful river and mountain scenery.",
            "Wear comfortable shoes for exploring Lucerne Old Town.",
            "Check the weather before planning outdoor activities.",
            "Try traditional Swiss dishes at nearby restaurants.",
            "Keep the historic site clean and respect local visitors."
        ]
    },

    // ===================================
    // 5. LAUTERBRUNNEN VALLEY
    // ===================================

    {
        name: "Lauterbrunnen Valley",
        country: "Switzerland",
        category: "Nature Tourism & Alpine Landscapes",
        image: "images/Lauterbrunnen Valley.jpg",
        budget: 140,
        featured: false,

        // 1. Overview
        description: "Lauterbrunnen Valley is one of Switzerland's most breathtaking natural destinations, famous for its dramatic cliffs, green meadows, traditional mountain villages, and spectacular waterfalls. Surrounded by the Swiss Alps, this peaceful valley offers unforgettable scenery and outdoor adventures.",

        // 2. Location
        location: "Bernese Oberland, Canton of Bern, Switzerland, near the famous mountain villages of Wengen and Mürren.",

        // 3. History
        history: "Lauterbrunnen has a long history as an Alpine farming and mountain settlement. Its name is commonly associated with the many springs and waterfalls found throughout the valley. Over time, its remarkable landscapes attracted travelers, nature lovers, and mountaineers from around the world.",

        // 4. Top Attractions
        attractions: [
            {
                name: "Staubbach Falls",
                description: "Admire one of Switzerland's highest free-falling waterfalls, cascading dramatically down a steep mountain cliff."
            },
            {
                name: "Trümmelbach Falls",
                description: "Discover impressive waterfalls flowing through narrow rock formations inside the mountain."
            },
            {
                name: "Wengen Village",
                description: "Explore a charming car-free Alpine village with beautiful mountain views and traditional Swiss scenery."
            },
            {
                name: "Mürren Village",
                description: "Visit a picturesque mountain village overlooking the Lauterbrunnen Valley and surrounding peaks."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Experience spectacular waterfalls and dramatic Alpine cliffs.",
            "Enjoy peaceful mountain scenery and traditional Swiss villages.",
            "Explore beautiful hiking trails and outdoor activities.",
            "Capture unforgettable photographs of the Swiss countryside.",
            "Discover the natural beauty and traditional lifestyle of the Alps."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "Late Spring and Summer",
            weather: "Generally mild weather with green landscapes, flowing waterfalls, and comfortable conditions for outdoor exploration.",
            recommendation: "May to September is ideal for hiking, sightseeing, and enjoying the valley's waterfalls and mountain villages."
        },

        // 7. Special Experiences
        specialExperience: {
            title: "Discover Switzerland's Waterfall Valley",
            experience: "Walk through the beautiful valley, admire Staubbach Falls, explore traditional Alpine villages, and enjoy spectacular mountain views.",
            culturalSignificance: "Lauterbrunnen reflects the traditional Alpine way of life, where mountain communities developed around farming, nature, and close connections with the surrounding landscape.",
            recommendation: "Take a scenic walk through the valley and visit Wengen or Mürren to experience the peaceful atmosphere of traditional Swiss mountain villages."
        },

        // 8. Budget Details
        budgetDetails: [
            {
                item: "Accommodation",
                cost: "$70–$150 per night"
            },
            {
                item: "Food",
                cost: "$25–$45 per day"
            },
            {
                item: "Transportation",
                cost: "$15–$45"
            },
            {
                item: "Attractions",
                cost: "$10–$35"
            }
        ],

        budgetNote: "An estimated budget of $140 per person, excluding international flights. Actual expenses depend on accommodation, mountain transport, seasonal activities, and dining choices.",

        // 9. Transportation
        transportation: [
            "Fly into Zurich or Geneva Airport and travel by train to Interlaken.",
            "Take a regional train from Interlaken to Lauterbrunnen village.",
            "Use mountain trains, cable cars, and local transport to reach nearby villages and viewpoints."
        ],

        // 10. Accommodation
        accommodation: [
            "Stay in Lauterbrunnen village for convenient access to waterfalls and valley walking trails.",
            "Choose Wengen for a peaceful mountain village experience with beautiful Alpine views.",
            "Consider Mürren for spectacular scenery and a relaxing stay above the valley."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Explore Lauterbrunnen Village",
                description: "Start the day with a peaceful walk through the village and enjoy the surrounding mountain scenery."
            },
            {
                time: "9:00 AM",
                activity: "Visit Staubbach Falls",
                description: "Admire the famous waterfall and take photographs of its dramatic mountain setting."
            },
            {
                time: "10:30 AM",
                activity: "Discover Trümmelbach Falls",
                description: "Explore the impressive waterfalls hidden inside the mountain."
            },
            {
                time: "12:00 PM",
                activity: "Traditional Swiss Lunch",
                description: "Enjoy a relaxing meal at a local restaurant in the valley."
            },
            {
                time: "1:30 PM",
                activity: "Visit Wengen Village",
                description: "Take a scenic mountain train and explore this charming Alpine village."
            },
            {
                time: "3:30 PM",
                activity: "Explore Mürren",
                description: "Enjoy breathtaking views of the surrounding mountains and traditional village scenery."
            },
            {
                time: "5:30 PM",
                activity: "Relax in Lauterbrunnen",
                description: "Return to the valley and enjoy its peaceful atmosphere before the end of the day."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Visit between May and September for pleasant hiking conditions.",
            "Wear comfortable walking shoes for mountain trails.",
            "Bring a waterproof jacket because waterfall areas can be misty.",
            "Check mountain train and cable car schedules before traveling.",
            "Bring a camera to capture the beautiful waterfalls and landscapes.",
            "Carry drinking water and snacks during longer walks.",
            "Check the opening conditions of Trümmelbach Falls before visiting.",
            "Respect nature, follow marked trails, and keep the valley clean."
        ]
    },
];