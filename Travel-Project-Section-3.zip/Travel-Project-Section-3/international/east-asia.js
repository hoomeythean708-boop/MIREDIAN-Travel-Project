// ===================================
// MIREDIAN - EAST ASIA
// ===================================

const eastAsiaDestinations = [

    // ===================================
    // I. CHINA 
    // ===================================

    // ===================================
    // 1. GREAT WALL OF CHINA
    // ===================================

    {
        name: "Great Wall of China",
        country: "China",
        category: "Historical & Cultural",
        image: "images/Great Wall of China.jpg",
        budget: 80,
        featured: true,

        // 1. Overview
        description: "The Great Wall of China is one of the world's most famous historical landmarks and a remarkable symbol of Chinese civilization. Stretching across mountains, valleys, and landscapes, this ancient defensive structure represents China's long history, architectural achievements, and cultural heritage. Visitors can explore restored sections, enjoy breathtaking scenery, and discover the stories behind one of humanity's greatest engineering accomplishments.",

        location: "Northern China, extending across several provinces and regions.",

        history: "Construction of early defensive walls began during ancient Chinese kingdoms, with different sections later connected and expanded by successive dynasties. The Ming Dynasty (1368–1644) built many of the stone and brick sections that visitors see today. The Great Wall served primarily as a defensive system protecting territories and communities from invasions and raids.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Mutianyu Section",
                description: "Explore one of the best-restored sections of the Great Wall, surrounded by beautiful mountains and green forests."
            },
            {
                name: "Badaling Section",
                description: "Visit one of the most famous and accessible sections of the Great Wall, featuring impressive towers and historic architecture."
            },
            {
                name: "Ancient Watchtowers",
                description: "Discover the stone watchtowers that were historically used for observation, communication, and military defense."
            },
            {
                name: "Mountain Scenery",
                description: "Enjoy panoramic views of the Great Wall stretching across the surrounding mountains and valleys."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Experience one of the most recognizable historical landmarks in the world.",
            "Learn about China's ancient history and military architecture.",
            "Enjoy spectacular mountain scenery and panoramic views.",
            "Explore historic watchtowers and restored sections of the wall.",
            "Capture memorable photographs of this UNESCO World Heritage Site."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "April to May and September to October.",
            weather: "Spring and autumn generally offer comfortable temperatures and beautiful natural scenery for exploring the Great Wall.",
            recommendation: "Visit early in the morning to avoid larger crowds and allow enough time to walk along the historic sections."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Walking Along the Great Wall of China",
            experience: "Walk along the ancient stone pathways, climb historic watchtowers, and enjoy breathtaking views of the surrounding mountains and landscapes.",
            culturalSignificance: "The Great Wall represents China's historical defense systems, architectural achievements, and the determination of generations who contributed to its construction.",
            recommendation: "Choose a suitable section based on your fitness level and wear comfortable walking shoes for the journey."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Entrance Ticket", cost: "$6 - $10" },
            { item: "Transportation", cost: "$15 - $30" },
            { item: "Food and Drinks", cost: "$10 - $15" },
            { item: "Cable Car or Other Activities", cost: "$15 - $25" }
        ],
        budgetNote: "Estimated budget is approximately $45 - $80 per person, depending on the section visited, transportation, ticket options, and additional activities.",

        // 7. Transportation and Accommodation
        transportation: [
            "Travel from Beijing by tourist bus, private car, or organized tour.",
            "Use public transportation and connecting buses to reach selected sections.",
            "Cable cars are available at certain sections to help visitors reach higher areas of the wall."
        ],

        accommodation: [
            "Stay in central Beijing for convenient access to transportation and other attractions.",
            "Choose hotels near popular Great Wall sections for an early morning visit.",
            "Budget hostels, guesthouses, and luxury hotels are available in Beijing."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "7:00 AM",
                activity: "Depart from Beijing",
                description: "Begin the journey toward your selected section of the Great Wall."
            },
            {
                time: "9:00 AM",
                activity: "Arrive at the Great Wall",
                description: "Reach the entrance, purchase tickets if necessary, and prepare for the visit."
            },
            {
                time: "9:30 AM",
                activity: "Explore Ancient Watchtowers",
                description: "Walk along the historic wall and discover its defensive architecture."
            },
            {
                time: "11:00 AM",
                activity: "Enjoy Mountain Views",
                description: "Take photographs and admire the breathtaking landscapes surrounding the wall."
            },
            {
                time: "12:30 PM",
                activity: "Enjoy Lunch",
                description: "Take a break and enjoy a meal at a nearby restaurant."
            },
            {
                time: "2:00 PM",
                activity: "Return to Beijing",
                description: "Travel back to the city and continue exploring other attractions if time allows."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Wear comfortable walking shoes because some sections have steep stairs.",
            "Bring drinking water and snacks for the journey.",
            "Visit early in the morning to avoid large crowds.",
            "Check weather conditions before traveling.",
            "Bring sunscreen, a hat, and suitable clothing.",
            "Choose a section that matches your physical fitness.",
            "Keep personal belongings secure while exploring.",
            "Respect the historical site and avoid damaging its structures."
        ]
    },

    // ===================================
    // 2. FORBIDDEN CITY
    // ===================================

    {
        name: "Forbidden City",
        country: "China",
        category: "Historical & Cultural",
        image: "images/Forbidden City.jpg",
        budget: 70,
        featured: false,

        // 1. Overview
        description: "The Forbidden City is a magnificent imperial palace complex located in the heart of Beijing, China. Known for its traditional Chinese architecture, golden roofs, red walls, and beautiful courtyards, it served as the home of Chinese emperors for nearly 500 years. Today, it is one of China's most important cultural attractions and houses the Palace Museum, where visitors can explore the country's imperial history and artistic treasures.",

        location: "Dongcheng District, central Beijing, China.",

        history: "The Forbidden City was constructed between 1406 and 1420 during the Ming Dynasty under the Yongle Emperor. It served as the imperial residence and political center for 24 emperors from the Ming and Qing dynasties. After the last emperor left in 1924, the palace complex became a museum in 1925. It was later recognized as a UNESCO World Heritage Site in 1987.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Hall of Supreme Harmony",
                description: "Discover the largest and most important ceremonial hall in the Forbidden City, where major imperial ceremonies were held."
            },
            {
                name: "Meridian Gate",
                description: "Explore the magnificent southern entrance of the palace, featuring impressive traditional architecture."
            },
            {
                name: "Imperial Garden",
                description: "Enjoy a peaceful garden filled with ancient trees, decorative rocks, traditional pavilions, and beautiful landscaping."
            },
            {
                name: "Palace Museum Collections",
                description: "Discover valuable Chinese paintings, ceramics, jade objects, imperial treasures, and historical artifacts."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Explore one of the world's largest and best-preserved ancient palace complexes.",
            "Learn about the history of China's Ming and Qing dynasties.",
            "Admire traditional Chinese architecture and imperial decorations.",
            "Discover valuable historical artifacts and royal collections.",
            "Experience the cultural heritage of ancient Chinese imperial life."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "April to May and September to October.",
            weather: "Spring and autumn generally provide mild temperatures and comfortable conditions for exploring the palace grounds.",
            recommendation: "Visit early in the morning to enjoy the main courtyards before they become crowded. Book admission in advance and check the museum's opening schedule."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Exploring China's Imperial Palace",
            experience: "Walk through grand palace halls, admire golden rooftops, explore peaceful courtyards, and discover the fascinating stories of China's emperors.",
            culturalSignificance: "The Forbidden City represents the political power, artistic achievements, and traditional architectural values of China's imperial dynasties.",
            recommendation: "Take time to explore the Palace Museum exhibitions and learn about the meaning behind the palace's traditional colors, symbols, and architectural designs."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Entrance Ticket", cost: "$8 - $12" },
            { item: "Transportation", cost: "$5 - $15" },
            { item: "Food and Drinks", cost: "$10 - $15" },
            { item: "Souvenirs and Other Expenses", cost: "$5 - $15" }
        ],
        budgetNote: "Estimated budget is approximately $30 - $55 per person, depending on transportation, food choices, souvenirs, and ticket arrangements.",

        // 7. Transportation and Accommodation
        transportation: [
            "Take the Beijing Subway to Tiananmen East or Tiananmen West Station and follow the official visitor entrance directions.",
            "Use taxis or ride-hailing services to reach the surrounding area.",
            "Walking is convenient when exploring nearby attractions such as Tiananmen Square and Jingshan Park."
        ],

        accommodation: [
            "Stay in central Beijing for convenient access to the Forbidden City and other historical attractions.",
            "Choose accommodation near Wangfujing or Dongcheng for shopping, restaurants, and transportation.",
            "Budget hostels, comfortable hotels, and luxury accommodation are available throughout Beijing."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Arrive Near the Palace",
                description: "Reach the entrance area early and prepare your admission arrangements."
            },
            {
                time: "8:30 AM",
                activity: "Enter Through Meridian Gate",
                description: "Begin exploring the magnificent entrance and its impressive architecture."
            },
            {
                time: "9:30 AM",
                activity: "Visit the Main Palace Halls",
                description: "Discover the Hall of Supreme Harmony and other important imperial buildings."
            },
            {
                time: "11:00 AM",
                activity: "Explore the Palace Museum",
                description: "View historical collections and learn about China's imperial heritage."
            },
            {
                time: "12:30 PM",
                activity: "Enjoy Lunch",
                description: "Take a break and enjoy a meal at a nearby restaurant."
            },
            {
                time: "2:00 PM",
                activity: "Discover the Imperial Garden",
                description: "Relax among traditional pavilions, ancient trees, and beautiful garden scenery."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Reserve your admission ticket in advance and check the official visitor requirements.",
            "Bring your passport or required identification for entry.",
            "Wear comfortable shoes because the palace complex is very large.",
            "Arrive early to avoid the busiest visiting hours.",
            "Bring drinking water and sun protection.",
            "Allow several hours to explore the palace properly.",
            "Follow museum rules when taking photographs.",
            "Respect historical buildings and displayed cultural artifacts."
        ]
    },

    // ===================================
    // 3. ZHANGJIAJIE NATIONAL FOREST PARK
    // ===================================

    {
        name: "Zhangjiajie National Forest Park",
        country: "China",
        category: "Nature & Adventure",
        image: "images/Zhangjiajie National Forest Park.jpg",
        budget: 80,
        featured: false,

        // 1. Overview
        description: "Zhangjiajie National Forest Park is a spectacular natural destination in Hunan Province, China, famous for its towering sandstone pillars, misty mountains, and lush forests. Its extraordinary landscapes inspired the floating mountains in the movie Avatar. Visitors can explore scenic walking trails, ride mountain cable cars, and enjoy breathtaking views of one of China's most beautiful natural environments.",

        location: "Wulingyuan District, Zhangjiajie City, Hunan Province, China.",

        history: "Zhangjiajie National Forest Park was established in 1982 as China's first national forest park. It forms part of the larger Wulingyuan Scenic Area, which was recognized as a UNESCO World Heritage Site in 1992. The area is famous for its unusual quartz-sandstone formations, shaped by millions of years of geological processes and erosion.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Avatar Hallelujah Mountain",
                description: "Admire the famous towering sandstone pillar that became internationally recognized for its resemblance to the floating mountains in Avatar."
            },
            {
                name: "Yuanjiajie Scenic Area",
                description: "Explore a spectacular mountain area filled with dramatic stone pillars, viewing platforms, and beautiful natural scenery."
            },
            {
                name: "Golden Whip Stream",
                description: "Walk along a peaceful stream surrounded by forests, cliffs, and impressive sandstone formations."
            },
            {
                name: "Bailong Elevator",
                description: "Experience a remarkable outdoor glass elevator built against a cliff, offering impressive views of the surrounding mountains."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Discover one of China's most extraordinary natural landscapes.",
            "See the famous sandstone pillars that inspired the floating mountains in Avatar.",
            "Enjoy scenic hiking trails and beautiful forest environments.",
            "Experience panoramic mountain views from observation platforms.",
            "Explore a UNESCO World Heritage landscape filled with unique geological formations."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "April to May and September to October.",
            weather: "Spring and autumn generally offer pleasant temperatures, green landscapes, and beautiful mountain scenery. Misty conditions can also create dramatic views.",
            recommendation: "Visit on weekdays when possible and check weather conditions before hiking, as heavy rain or fog may affect visibility and some attractions."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Discovering the Floating Mountains of Zhangjiajie",
            experience: "Explore the towering sandstone pillars, walk through peaceful forest trails, and enjoy unforgettable views from mountain observation platforms.",
            culturalSignificance: "Zhangjiajie represents the natural beauty and geological diversity of China. Its distinctive landscape has become an internationally recognized symbol of the country's remarkable natural heritage.",
            recommendation: "Visit Yuanjiajie for its famous mountain formations and take time to explore the scenic walking routes."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Park Entrance Ticket", cost: "$25 - $35" },
            { item: "Transportation and Shuttle Bus", cost: "$10 - $15" },
            { item: "Food and Drinks", cost: "$10 - $15" },
            { item: "Cable Car or Elevator Activities", cost: "$10 - $15" }
        ],

        budgetNote: "Estimated budget is approximately $55 - $80 per person, depending on ticket options, transportation, meals, and additional activities.",

        // 7. Transportation and Accommodation
        transportation: [
            "Travel to Zhangjiajie by train or flight from major Chinese cities.",
            "Use local buses, taxis, or shuttle services to reach the Wulingyuan scenic area.",
            "Use the park's shuttle buses, cable cars, and sightseeing elevators to explore different mountain sections."
        ],

        accommodation: [
            "Stay in Wulingyuan District for convenient access to the national park entrances.",
            "Choose a hotel near Zhangjiajie National Forest Park for an early start.",
            "Guesthouses, budget hotels, and comfortable resorts are available around the scenic area."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "7:30 AM",
                activity: "Arrive at the Park",
                description: "Reach the entrance early and prepare your admission ticket for a full day of exploration."
            },
            {
                time: "8:30 AM",
                activity: "Explore Yuanjiajie",
                description: "Discover the famous sandstone pillars and enjoy panoramic views of the mountain landscape."
            },
            {
                time: "10:30 AM",
                activity: "Visit Avatar Hallelujah Mountain",
                description: "Admire the iconic natural formation and take photographs of the surrounding scenery."
            },
            {
                time: "12:00 PM",
                activity: "Enjoy Lunch",
                description: "Take a break and enjoy a meal at an available restaurant or food area."
            },
            {
                time: "1:00 PM",
                activity: "Experience the Bailong Elevator",
                description: "Enjoy an exciting ride along the cliffside while viewing the surrounding mountain formations."
            },
            {
                time: "2:30 PM",
                activity: "Walk Along Golden Whip Stream",
                description: "Relax with a scenic walk through the forest and along the peaceful stream."
            },
            {
                time: "4:30 PM",
                activity: "Return to the Entrance",
                description: "Finish the visit and travel back to your accommodation."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Wear comfortable hiking shoes with good grip.",
            "Bring drinking water and snacks for the journey.",
            "Check the weather forecast before visiting.",
            "Prepare for steep stairs and long walking distances.",
            "Carry a light jacket because mountain weather can change quickly.",
            "Keep your ticket and identification available.",
            "Follow park safety instructions and stay on marked trails.",
            "Allow enough time to explore the main scenic areas."
        ]
    },

    // ===================================
    // 4. LI RIVER
    // ===================================

    {
        name: "Li River",
        country: "China",
        category: "Nature & Scenic Landscapes",
        image: "images/Li River.jpg",
        budget: 70,
        featured: false,

        // 1. Overview
        description: "The Li River is one of China's most beautiful natural attractions, famous for its peaceful waters, dramatic limestone mountains, and picturesque countryside. Flowing through Guilin and Yangshuo in Guangxi Province, the river offers unforgettable scenery that has inspired Chinese paintings, poetry, and photography for centuries. Visitors can enjoy river cruises, bamboo rafting, and charming riverside villages.",

        location: "Guilin and Yangshuo, Guangxi Zhuang Autonomous Region, southern China.",

        history: "The Li River has played an important role in the history, transportation, agriculture, and culture of the Guilin region for centuries. Its spectacular karst mountain scenery has long appeared in traditional Chinese paintings and literature. Today, the river is one of China's most celebrated scenic destinations and an important part of the Guilin and Lijiang River Scenic Area.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Nine Horse Fresco Hill",
                description: "Admire a famous limestone cliff along the river that is associated with a traditional story about discovering horse-shaped patterns in the rock."
            },
            {
                name: "Xingping Ancient Town",
                description: "Explore a historic riverside town known for traditional streets, peaceful scenery, and beautiful views of the surrounding mountains."
            },
            {
                name: "Yellow Cloth Shoal",
                description: "Enjoy one of the Li River's most recognizable scenic areas, featuring reflections of limestone peaks on the clear water."
            },
            {
                name: "Yangshuo Countryside",
                description: "Discover peaceful villages, green fields, traditional farms, and beautiful mountain scenery near the river."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Experience one of China's most beautiful river landscapes.",
            "Enjoy spectacular limestone mountains and peaceful countryside.",
            "Take a scenic cruise or traditional bamboo raft journey.",
            "Discover charming ancient towns and local village culture.",
            "Capture beautiful photographs of China's famous karst scenery."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "April to October.",
            weather: "Spring and autumn generally offer comfortable temperatures and beautiful scenery. Summer brings greener landscapes but may also have heavy rainfall.",
            recommendation: "Visit in the morning for peaceful river views and softer natural light. Check river conditions before booking boat activities."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Cruising Along the Beautiful Li River",
            experience: "Enjoy a scenic journey along the river, passing towering limestone mountains, traditional villages, green fields, and peaceful waterways.",
            culturalSignificance: "The Li River is deeply connected to the cultural identity and artistic heritage of the Guilin region. Its distinctive landscapes have inspired traditional Chinese paintings, poetry, and local stories.",
            recommendation: "Choose a river cruise from Guilin toward Yangshuo to experience some of the region's most famous natural scenery."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "River Cruise or Bamboo Raft", cost: "$20 - $35" },
            { item: "Local Transportation", cost: "$10 - $15" },
            { item: "Food and Drinks", cost: "$10 - $15" },
            { item: "Other Activities", cost: "$5 - $10" }
        ],

        budgetNote: "Estimated budget is approximately $45 - $70 per person, depending on the type of river experience, transportation, and additional activities.",

        // 7. Transportation and Accommodation
        transportation: [
            "Travel to Guilin by train or flight from major Chinese cities.",
            "Use local buses, taxis, or private transportation to reach the river cruise terminals.",
            "Travel between Guilin and Yangshuo by bus, boat, or other local transportation services."
        ],

        accommodation: [
            "Stay in central Guilin for convenient access to restaurants, transportation, and river cruise services.",
            "Choose accommodation in Yangshuo for a peaceful countryside atmosphere and easy access to outdoor activities.",
            "Guesthouses, budget hotels, and riverside resorts are available throughout the region."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Arrive at the River Cruise Terminal",
                description: "Prepare for your scenic journey and check your cruise arrangements."
            },
            {
                time: "9:00 AM",
                activity: "Begin the Li River Cruise",
                description: "Enjoy beautiful views of limestone mountains and peaceful waterways."
            },
            {
                time: "10:30 AM",
                activity: "Discover Famous River Scenery",
                description: "Admire the dramatic mountain formations and take photographs along the journey."
            },
            {
                time: "12:00 PM",
                activity: "Enjoy Lunch",
                description: "Have a meal during your journey or after arriving at a nearby riverside area."
            },
            {
                time: "1:30 PM",
                activity: "Explore Xingping Ancient Town",
                description: "Walk through traditional streets and discover the town's historic atmosphere."
            },
            {
                time: "3:00 PM",
                activity: "Enjoy Yangshuo Countryside",
                description: "Explore the beautiful surroundings and relax among green fields and mountain scenery."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Check river cruise schedules and weather conditions before traveling.",
            "Bring sunscreen, sunglasses, and a hat.",
            "Carry drinking water during outdoor activities.",
            "Wear comfortable shoes for exploring riverside towns.",
            "Bring a camera to capture the beautiful mountain scenery.",
            "Book popular cruises in advance during busy travel seasons.",
            "Follow safety instructions when using bamboo rafts.",
            "Keep personal belongings secure during boat activities."
        ]
    },

    // ===================================
    // 5. THE BUND
    // ===================================

    {
        name: "The Bund",
        country: "China",
        category: "Urban & Historical Landmark",
        image: "images/The Bund.jpg",
        budget: 60,
        featured: false,

        // 1. Overview
        description: "The Bund is one of Shanghai's most famous waterfront attractions, offering beautiful views of historic European-style buildings and the modern skyline across the Huangpu River. This iconic riverside promenade combines Shanghai's architectural heritage with its modern city atmosphere. Visitors can enjoy scenic walks, admire impressive landmarks, explore nearby shopping streets, and experience the city's vibrant lifestyle.",

        location: "Huangpu District, central Shanghai, China.",

        history: "The Bund developed as an important international trading and financial area during the 19th and early 20th centuries. Many impressive buildings were constructed along the waterfront, reflecting different architectural styles. Today, these historic structures stand alongside Shanghai's modern skyline and represent the city's development into one of China's major global cities.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Historic Waterfront Buildings",
                description: "Admire the impressive collection of historic buildings featuring European architectural styles along the famous promenade."
            },
            {
                name: "Huangpu River",
                description: "Enjoy beautiful riverside views and watch boats travel along one of Shanghai's most important waterways."
            },
            {
                name: "Oriental Pearl Tower View",
                description: "See the famous tower across the river as part of Shanghai's spectacular modern skyline."
            },
            {
                name: "Nanjing Road",
                description: "Explore one of Shanghai's most famous shopping streets, filled with shops, restaurants, and lively city attractions."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Experience one of Shanghai's most iconic waterfront destinations.",
            "Admire the contrast between historic architecture and modern skyscrapers.",
            "Enjoy beautiful views of the Huangpu River and city skyline.",
            "Explore nearby shopping streets, restaurants, and cultural attractions.",
            "Experience Shanghai's lively atmosphere during both daytime and nighttime."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "March to May and September to November.",
            weather: "Spring and autumn generally offer comfortable temperatures for walking along the waterfront and exploring the surrounding city.",
            recommendation: "Visit in the late afternoon and stay into the evening to enjoy the city skyline as the buildings light up after sunset."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Enjoying Shanghai's Famous Night Skyline",
            experience: "Walk along the waterfront promenade, admire the illuminated skyscrapers across the Huangpu River, and enjoy the beautiful atmosphere of Shanghai after sunset.",
            culturalSignificance: "The Bund represents Shanghai's historical development as an international trading center and reflects the city's combination of cultural heritage and modern urban growth.",
            recommendation: "Take an evening walk along the promenade and consider a Huangpu River cruise for another perspective of the city's skyline."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Waterfront Promenade Visit", cost: "Free" },
            { item: "Local Transportation", cost: "$5 - $10" },
            { item: "Food and Drinks", cost: "$15 - $25" },
            { item: "River Cruise or Other Activities", cost: "$10 - $25" }
        ],
        budgetNote: "Estimated budget is approximately $30 - $60 per person, depending on food choices, transportation, and optional river cruise activities.",

        // 7. Transportation and Accommodation
        transportation: [
            "Take the Shanghai Metro to East Nanjing Road Station and walk toward the waterfront.",
            "Use taxis or local buses to reach the Bund area.",
            "Walking is a convenient way to explore the promenade and nearby attractions."
        ],

        accommodation: [
            "Stay in central Shanghai for convenient access to the Bund and major city attractions.",
            "Choose accommodation near Nanjing Road or People's Square for shopping and transportation.",
            "Budget hotels, modern city hotels, and luxury riverside accommodation are available throughout Shanghai."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "3:00 PM",
                activity: "Arrive at The Bund",
                description: "Begin exploring the famous waterfront promenade and historic buildings."
            },
            {
                time: "3:30 PM",
                activity: "Discover Historic Architecture",
                description: "Admire the impressive buildings and learn about the area's history."
            },
            {
                time: "4:30 PM",
                activity: "Enjoy Huangpu River Views",
                description: "Take photographs of the river, passing boats, and modern skyline."
            },
            {
                time: "5:30 PM",
                activity: "Explore Nanjing Road",
                description: "Walk through the nearby shopping district and discover local stores."
            },
            {
                time: "6:30 PM",
                activity: "Enjoy Dinner",
                description: "Try local Shanghai dishes at a nearby restaurant."
            },
            {
                time: "7:30 PM",
                activity: "Admire the Night Skyline",
                description: "Return to the waterfront and enjoy the illuminated city views."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Visit in the evening for beautiful illuminated skyline views.",
            "Bring a camera or phone for waterfront photography.",
            "Wear comfortable shoes for walking along the promenade.",
            "Check weather conditions before planning your visit.",
            "Expect larger crowds during weekends and public holidays.",
            "Keep personal belongings secure in crowded areas.",
            "Use the metro for convenient transportation.",
            "Respect local rules and pedestrian areas along the waterfront."
        ]
    },

    // ===================================
    // II. SOUTH KOREA
    // ===================================

    // ===================================
    // 6. GYEONGBOKGUNG PALACE
    // ===================================

    {
        name: "Gyeongbokgung Palace",
        country: "South Korea",
        category: "Historical & Cultural",
        image: "images/Gyeongbokgung Palace.jpg",
        budget: 55,
        featured: true,

        // 1. Overview
        description: "Gyeongbokgung Palace is one of South Korea's most famous historical landmarks, located in the heart of Seoul. Built during the Joseon Dynasty, the palace features traditional Korean architecture, beautiful courtyards, impressive gates, and peaceful gardens. Visitors can explore the royal residence, learn about Korean history, and experience the country's traditional cultural heritage.",

        location: "Jongno District, central Seoul, South Korea.",

        history: "Gyeongbokgung Palace was originally constructed in 1395 as the main royal palace of the Joseon Dynasty. It served as the residence of kings and the center of government for much of the dynasty. Although it was damaged during historical conflicts and later restored, the palace remains an important symbol of Korean royal history and cultural identity.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Gwanghwamun Gate",
                description: "Admire the grand main entrance of the palace, known for its traditional Korean architectural design and royal significance."
            },
            {
                name: "Geunjeongjeon Hall",
                description: "Explore the main throne hall where important royal ceremonies and official events were held."
            },
            {
                name: "Gyeonghoeru Pavilion",
                description: "Discover the beautiful royal pavilion surrounded by a peaceful pond and traditional scenery."
            },
            {
                name: "Changing of the Royal Guard",
                description: "Watch the traditional guard-changing ceremony performed near the palace entrance."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Discover the royal history of the Joseon Dynasty.",
            "Admire beautiful traditional Korean palace architecture.",
            "Experience Korean royal traditions and cultural ceremonies.",
            "Explore historic halls, gates, and peaceful palace gardens.",
            "Take memorable photographs in one of Seoul's most iconic landmarks."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "April to May and September to October.",
            weather: "Spring and autumn generally offer comfortable temperatures and beautiful scenery for exploring the palace grounds.",
            recommendation: "Visit in the morning to enjoy the palace before larger crowds arrive. Check the guard-changing ceremony schedule before your visit."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Experiencing Traditional Korean Royal Culture",
            experience: "Explore the historic palace buildings, watch the royal guard-changing ceremony, and enjoy the traditional atmosphere of Korea's royal heritage.",
            culturalSignificance: "Gyeongbokgung Palace represents the political power, cultural traditions, and architectural achievements of the Joseon Dynasty.",
            recommendation: "Consider wearing a traditional Korean hanbok during your visit. Visitors wearing eligible hanbok may receive free palace admission under the palace's admission policy."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Entrance Ticket", cost: "$2 - $3" },
            { item: "Hanbok Rental", cost: "$10 - $20" },
            { item: "Food and Drinks", cost: "$10 - $15" },
            { item: "Local Transportation", cost: "$5 - $10" }
        ],

        budgetNote: "Estimated budget is approximately $25 - $55 per person, depending on clothing rental, transportation, food, and other activities.",
        // 7. Transportation and Accommodation
        transportation: [
            "Take Seoul Subway Line 3 to Gyeongbokgung Station and walk toward the palace.",
            "Use local buses or taxis to reach the palace entrance.",
            "Walking is convenient for exploring nearby attractions such as Bukchon Hanok Village and Gwanghwamun Square."
        ],

        accommodation: [
            "Stay in central Seoul for convenient access to the palace and other major attractions.",
            "Choose accommodation near Jongno or Insadong for traditional streets, restaurants, and cultural experiences.",
            "Budget hostels, modern hotels, and luxury accommodation are available throughout Seoul."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "9:00 AM",
                activity: "Arrive at Gyeongbokgung Palace",
                description: "Begin your visit at the main entrance and admire the impressive palace gates."
            },
            {
                time: "9:30 AM",
                activity: "Explore the Royal Palace Halls",
                description: "Discover the historic buildings and learn about the royal traditions of the Joseon Dynasty."
            },
            {
                time: "10:30 AM",
                activity: "Visit Gyeonghoeru Pavilion",
                description: "Enjoy the peaceful pond scenery and admire the traditional pavilion."
            },
            {
                time: "11:00 AM",
                activity: "Watch the Royal Guard Ceremony",
                description: "Experience the traditional changing-of-the-guard performance if it is scheduled."
            },
            {
                time: "12:00 PM",
                activity: "Enjoy Korean Food",
                description: "Take a break and try traditional Korean dishes at a nearby restaurant."
            },
            {
                time: "1:30 PM",
                activity: "Explore Nearby Cultural Areas",
                description: "Continue your journey through the surrounding historic streets and cultural attractions."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Check the palace's weekly closing day and opening hours before visiting.",
            "Arrive early to enjoy the palace with fewer crowds.",
            "Wear comfortable shoes for walking around the large palace grounds.",
            "Consider renting a hanbok for a traditional cultural experience.",
            "Check the royal guard ceremony schedule in advance.",
            "Bring a camera to capture the beautiful architecture.",
            "Respect the historic buildings and cultural displays.",
            "Prepare for changing weather conditions."
        ]
    },

    // ===================================
    // 7. N SEOUL TOWER
    // ===================================

    {
        name: "N Seoul Tower",
        country: "South Korea",
        category: "City Views & Entertainment",
        image: "images/N Seoul Tower.jpg",
        budget: 60,
        featured: false,

        // 1. Overview
        description: "N Seoul Tower is one of South Korea's most recognizable landmarks, standing on Namsan Mountain in the heart of Seoul. Famous for its panoramic city views, romantic atmosphere, and colorful nighttime lighting, the tower attracts visitors from around the world. Visitors can enjoy observation decks, restaurants, cultural attractions, and beautiful views of Seoul's skyline.",

        location: "Namsan Mountain, Yongsan District, Seoul, South Korea.",

        history: "Originally constructed in 1969 as a broadcasting tower, N Seoul Tower opened to the public as an observation and cultural attraction in 1980. It later became one of Seoul's most popular landmarks. The tower is especially famous for its panoramic views and love locks, which have become a popular symbol of romance among visitors.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Observation Deck",
                description: "Enjoy panoramic views of Seoul and its surrounding mountains from the tower's observation areas."
            },
            {
                name: "Love Locks",
                description: "Discover the famous love-lock displays where couples attach colorful locks as symbols of affection and lasting memories."
            },
            {
                name: "Namsan Park",
                description: "Explore the beautiful green park surrounding the tower, featuring walking paths and seasonal scenery."
            },
            {
                name: "Tower Restaurants",
                description: "Enjoy meals and refreshments while experiencing impressive views of Seoul from the tower."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Enjoy breathtaking panoramic views of Seoul.",
            "Experience one of South Korea's most famous city landmarks.",
            "Explore the romantic atmosphere of the famous love-lock areas.",
            "Discover beautiful walking paths around Namsan Mountain.",
            "Enjoy spectacular nighttime views of the illuminated city."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "April to May and September to November.",
            weather: "Spring and autumn generally offer comfortable temperatures and clear views of the city.",
            recommendation: "Visit in the late afternoon to enjoy daylight scenery, sunset, and the beautiful illuminated skyline after dark."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Enjoying Seoul from Above",
            experience: "Take in the breathtaking city views from the observation deck, explore the famous love-lock displays, and enjoy the atmosphere of Namsan Mountain.",
            culturalSignificance: "N Seoul Tower has become an important symbol of modern Seoul, representing the city's development, entertainment culture, and romantic attractions.",
            recommendation: "Visit around sunset for a memorable experience and bring a camera to capture the city from different viewpoints."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Observation Deck Ticket", cost: "$15 - $20" },
            { item: "Transportation", cost: "$5 - $10" },
            { item: "Food and Drinks", cost: "$15 - $20" },
            { item: "Other Activities", cost: "$5 - $10" }
        ],

        budgetNote: "Estimated budget is approximately $40 - $60 per person, depending on admission options, transportation, meals, and additional activities.",
        // 7. Transportation and Accommodation
        transportation: [
            "Take the subway to Myeongdong Station or Chungmuro Station and continue toward Namsan.",
            "Use the Namsan cable car for a scenic ride toward the tower.",
            "Take the Namsan circular bus to reach the tower area.",
            "Walking trails are also available for visitors who enjoy hiking."
        ],

        accommodation: [
            "Stay in central Seoul for convenient access to Namsan Mountain and other attractions.",
            "Choose accommodation near Myeongdong for shopping, restaurants, and transportation.",
            "Budget hostels, comfortable hotels, and luxury accommodation are available throughout Seoul."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "3:00 PM",
                activity: "Arrive at Namsan Mountain",
                description: "Travel toward the tower area and enjoy the surrounding park scenery."
            },
            {
                time: "3:30 PM",
                activity: "Explore Namsan Park",
                description: "Walk along the scenic paths and enjoy views of the surrounding city."
            },
            {
                time: "4:30 PM",
                activity: "Visit N Seoul Tower",
                description: "Explore the tower and enjoy panoramic views from the observation areas."
            },
            {
                time: "5:30 PM",
                activity: "Discover the Love Locks",
                description: "Visit the famous love-lock displays and take memorable photographs."
            },
            {
                time: "6:30 PM",
                activity: "Enjoy Dinner",
                description: "Have a meal at one of the restaurants around the tower or nearby city areas."
            },
            {
                time: "7:30 PM",
                activity: "Admire Seoul at Night",
                description: "Enjoy the illuminated skyline before returning to the city."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Check tower opening hours and observation deck ticket availability.",
            "Visit near sunset for beautiful daytime and nighttime views.",
            "Bring a jacket because temperatures can be cooler on the mountain.",
            "Wear comfortable shoes if you plan to walk up Namsan.",
            "Check cable car and shuttle bus schedules before traveling.",
            "Bring a camera for panoramic city photography.",
            "Expect larger crowds during weekends and holidays.",
            "Keep personal belongings secure in crowded areas."
        ]
    },

    // ===================================
    // 8. JEJU ISLAND
    // ===================================

    {
        name: "Jeju Island",
        country: "South Korea",
        category: "Nature & Island Tourism",
        image: "images/Jeju Island.jpg",
        budget: 80,
        featured: false,

        // 1. Overview
        description: "Jeju Island is a beautiful volcanic island located off the southern coast of South Korea. Famous for its dramatic coastlines, waterfalls, volcanic landscapes, beaches, and peaceful countryside, Jeju offers a wonderful escape for nature lovers and adventure seekers. Visitors can explore scenic hiking trails, discover traditional villages, enjoy fresh seafood, and experience the island's unique natural beauty and local culture.",

        location: "Jeju Special Self-Governing Province, South Korea.",

        history: "Jeju Island was formed through volcanic activity and has developed a distinctive natural environment and cultural identity. Historically, it was an important center for fishing, farming, and local trade. The island is also known for its traditional stone houses, unique dialect, and haenyeo, the remarkable women divers who harvest seafood from the ocean. Its volcanic landscapes were recognized as part of a UNESCO World Heritage Site in 2007.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Seongsan Ilchulbong",
                description: "Explore the famous volcanic tuff cone, known for its dramatic crater and spectacular sunrise views over the ocean."
            },
            {
                name: "Hallasan Mountain",
                description: "Discover South Korea's highest mountain, featuring beautiful hiking trails, forests, and volcanic landscapes."
            },
            {
                name: "Jeongbang Waterfall",
                description: "Visit a beautiful coastal waterfall that flows directly into the ocean, creating a remarkable natural scene."
            },
            {
                name: "Jungmun Saekdal Beach",
                description: "Relax on a scenic beach famous for its colorful sand, ocean views, and opportunities for water activities."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Discover one of South Korea's most beautiful natural destinations.",
            "Explore volcanic landscapes, waterfalls, and spectacular coastlines.",
            "Enjoy outdoor activities such as hiking, sightseeing, and swimming.",
            "Experience Jeju's unique local culture and traditional seafood.",
            "Relax in a peaceful island atmosphere surrounded by beautiful scenery."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "April to June and September to October.",
            weather: "Spring and autumn generally offer pleasant temperatures and comfortable conditions for exploring the island. Summer is warmer and suitable for beaches, although rainfall and typhoons are possible.",
            recommendation: "Visit in spring for beautiful flowers and comfortable hiking conditions, or autumn for pleasant weather and clear coastal views."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Exploring Jeju's Volcanic Landscapes",
            experience: "Hike through beautiful natural scenery, admire volcanic craters, discover coastal waterfalls, and enjoy peaceful views of the surrounding ocean.",
            culturalSignificance: "Jeju Island represents a distinctive part of Korean natural and cultural heritage. Its volcanic landscape, traditional stone structures, and haenyeo diving traditions make it especially unique.",
            recommendation: "Explore Seongsan Ilchulbong and learn about the haenyeo tradition to experience both the island's natural beauty and local culture."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Attraction Entrance Fees", cost: "$5 - $15" },
            { item: "Local Transportation", cost: "$15 - $25" },
            { item: "Food and Drinks", cost: "$15 - $20" },
            { item: "Other Activities", cost: "$10 - $20" }
        ],

        budgetNote: "Estimated daily budget is approximately $45 - $80 per person, excluding flights and accommodation. Costs depend on transportation, meals, and activities selected.",

        // 7. Transportation and Accommodation
        transportation: [
            "Fly to Jeju International Airport from Seoul or other major cities.",
            "Use local buses to travel between popular attractions and towns.",
            "Rent a car for greater flexibility when exploring different parts of the island, with the required driving documents.",
            "Use taxis or organized tours to visit attractions that are difficult to reach by public transportation."
        ],

        accommodation: [
            "Stay in Jeju City for convenient access to the airport, restaurants, and transportation.",
            "Choose Seogwipo for access to waterfalls, coastal attractions, and southern island scenery.",
            "Guesthouses, budget hotels, resorts, and seaside accommodation are available throughout the island."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Explore Seongsan Ilchulbong",
                description: "Start the day by discovering the famous volcanic crater and enjoying ocean views."
            },
            {
                time: "10:00 AM",
                activity: "Discover Local Coastal Villages",
                description: "Explore traditional island communities and learn about Jeju's local culture."
            },
            {
                time: "11:30 AM",
                activity: "Enjoy Fresh Seafood",
                description: "Take a break and experience local seafood dishes at a nearby restaurant."
            },
            {
                time: "1:00 PM",
                activity: "Visit Jeongbang Waterfall",
                description: "Admire the beautiful waterfall and its unique location beside the ocean."
            },
            {
                time: "2:30 PM",
                activity: "Relax at the Beach",
                description: "Enjoy the coastal scenery and peaceful atmosphere of one of Jeju's beaches."
            },
            {
                time: "4:30 PM",
                activity: "Explore Seogwipo",
                description: "Walk around the town, discover local shops, and enjoy the island atmosphere."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Check weather conditions before planning outdoor activities.",
            "Bring comfortable walking shoes for hiking and sightseeing.",
            "Rent a car only if you have the appropriate driving documents.",
            "Use public transportation or organized tours when necessary.",
            "Bring sunscreen, sunglasses, and a hat.",
            "Carry drinking water during outdoor activities.",
            "Respect local traditions and the environment.",
            "Try Jeju's local specialties and support small businesses."
        ]
    },

    // ===================================
    // 9. HAEUNDAE BEACH
    // ===================================

    {
        name: "Haeundae Beach",
        country: "South Korea",
        category: "Beach & Coastal Tourism",
        image: "images/Haeundae Beach.jpg",
        budget: 60,
        featured: false,

        // 1. Overview
        description: "Haeundae Beach is one of South Korea's most famous coastal destinations, located in the lively city of Busan. Known for its wide sandy shoreline, clear ocean views, and modern city skyline, the beach attracts visitors throughout the year. Visitors can relax by the sea, enjoy water activities during the summer, explore nearby attractions, and experience Busan's vibrant coastal lifestyle.",

        location: "Haeundae District, Busan, South Korea.",

        history: "Haeundae Beach developed into a popular seaside destination during the 20th century and became one of Busan's most recognized tourist attractions. Its name is traditionally associated with the scholar Choe Chi-won, who admired the area's beautiful coastal scenery. Today, the beach is an important part of Busan's tourism and cultural identity.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Haeundae Sandy Beach",
                description: "Enjoy the beautiful sandy shoreline, ocean views, and relaxing atmosphere of one of Korea's most popular beaches."
            },
            {
                name: "Dongbaekseom Island",
                description: "Explore a scenic coastal walking area featuring natural landscapes, ocean views, and the Nurimaru APEC House."
            },
            {
                name: "The Bay 101",
                description: "Visit a popular waterfront complex known for its restaurants, cafes, and impressive views of Busan's modern skyline."
            },
            {
                name: "Haeundae Traditional Market",
                description: "Discover local street food, seafood restaurants, and traditional Korean snacks in a lively market environment."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Relax at one of South Korea's most famous beaches.",
            "Enjoy beautiful ocean scenery and a lively coastal atmosphere.",
            "Experience swimming and seasonal beach activities.",
            "Explore nearby parks, markets, restaurants, and cultural attractions.",
            "Capture beautiful photographs of Busan's coastline and modern skyline."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "June to September for beach activities, and April to May or September to October for comfortable sightseeing.",
            weather: "Summer offers warmer temperatures for enjoying the beach, while spring and autumn generally provide pleasant conditions for coastal walks.",
            recommendation: "Visit during summer for the liveliest beach atmosphere, or choose spring and autumn for a more relaxed coastal experience."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Enjoying Busan's Beautiful Beach Atmosphere",
            experience: "Spend time relaxing on the sandy beach, enjoy ocean activities during the swimming season, and explore the nearby waterfront attractions and local food areas.",
            culturalSignificance: "Haeundae Beach is an important part of Busan's coastal identity and represents the city's connection to the sea, tourism, and modern Korean beach culture.",
            recommendation: "Take an evening walk along the beach to enjoy the coastal atmosphere and beautiful city lights."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Beach Access", cost: "Free" },
            { item: "Food and Drinks", cost: "$15 - $20" },
            { item: "Local Transportation", cost: "$5 - $10" },
            { item: "Activities and Other Expenses", cost: "$10 - $30" }
        ],
        budgetNote: "Estimated budget is approximately $30 - $60 per person, depending on meals, transportation, seasonal activities, and personal spending.",

        // 7. Transportation and Accommodation
        transportation: [
            "Take Busan Metro Line 2 to Haeundae Station and walk toward the beach.",
            "Use local buses or taxis to reach nearby coastal attractions.",
            "Walking is convenient for exploring Haeundae Market, Dongbaekseom Island, and nearby waterfront areas."
        ],

        accommodation: [
            "Stay near Haeundae Beach for convenient access to the shoreline and nearby attractions.",
            "Choose accommodation near Haeundae Station for easy access to public transportation.",
            "Budget guesthouses, modern hotels, and luxury seaside resorts are available throughout the district."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "9:00 AM",
                activity: "Arrive at Haeundae Beach",
                description: "Begin your visit with a relaxing walk along the beautiful sandy shoreline."
            },
            {
                time: "10:00 AM",
                activity: "Enjoy the Coastal Scenery",
                description: "Take photographs and admire the ocean views and surrounding city landscape."
            },
            {
                time: "11:00 AM",
                activity: "Explore Dongbaekseom Island",
                description: "Walk along the scenic coastal paths and discover the beautiful natural surroundings."
            },
            {
                time: "12:30 PM",
                activity: "Enjoy Local Seafood",
                description: "Try fresh seafood or traditional Korean dishes at a nearby restaurant."
            },
            {
                time: "2:00 PM",
                activity: "Visit Haeundae Market",
                description: "Explore local food stalls and discover popular Korean street food."
            },
            {
                time: "4:00 PM",
                activity: "Relax by the Beach",
                description: "Spend the afternoon enjoying the coastal atmosphere before ending your visit."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Check seasonal swimming schedules and beach safety information.",
            "Bring sunscreen, sunglasses, and a hat during sunny weather.",
            "Wear comfortable footwear for walking along the coast.",
            "Bring swimwear and a towel if visiting during swimming season.",
            "Expect larger crowds during summer weekends and holidays.",
            "Keep the beach clean and dispose of rubbish properly.",
            "Check public transportation schedules before returning to your accommodation.",
            "Try local seafood and traditional Korean street food nearby."
        ]
    },

    // ===================================
    // 10. BUKCHON HANOK VILLAGE
    // ===================================

    {
        name: "Bukchon Hanok Village",
        country: "South Korea",
        category: "Traditional Culture & Heritage",
        image: "images/Bukchon Hanok Village.jpg",
        budget: 45,
        featured: false,

        // 1. Overview
        description: "Bukchon Hanok Village is a charming traditional neighborhood located in central Seoul, South Korea. Famous for its beautifully preserved Korean houses known as hanok, the village offers visitors a glimpse into traditional Korean architecture and everyday life. Surrounded by historic streets, cultural centers, and scenic viewpoints, it is a wonderful place to experience the country's heritage while exploring the modern city.",

        location: "Jongno District, Seoul, South Korea, between Gyeongbokgung Palace and Changdeokgung Palace.",

        history: "Bukchon has a history dating back to the Joseon Dynasty, when it was home to members of the royal family, government officials, and wealthy families. Its traditional hanok houses reflect the architectural styles and residential culture of that period. Today, the neighborhood remains an important cultural area where traditional Korean homes and modern city life exist side by side.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Traditional Hanok Houses",
                description: "Explore the beautiful traditional Korean houses featuring tiled roofs, wooden structures, and elegant architectural details."
            },
            {
                name: "Bukchon Traditional Culture Center",
                description: "Discover Korean traditional culture, architecture, and heritage through cultural activities and exhibitions."
            },
            {
                name: "Bukchon Eight Scenic Views",
                description: "Visit selected viewpoints around the neighborhood to enjoy beautiful views of traditional rooftops and surrounding city landscapes."
            },
            {
                name: "Traditional Tea Houses",
                description: "Relax in charming tea houses and experience traditional Korean tea and refreshments."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Experience traditional Korean architecture and residential culture.",
            "Discover the history of Seoul during the Joseon Dynasty.",
            "Explore beautiful hanok houses and peaceful traditional streets.",
            "Enjoy scenic viewpoints and cultural photography opportunities.",
            "Learn about Korean heritage through local cultural experiences."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "April to May and September to October.",
            weather: "Spring and autumn generally provide pleasant temperatures and beautiful scenery for walking through the traditional neighborhood.",
            recommendation: "Visit during weekday mornings for a quieter experience. Follow current visitor access hours and neighborhood guidelines."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Discovering Traditional Korean Hanok Culture",
            experience: "Walk through historic residential streets, admire traditional architecture, visit cultural centers, and enjoy Korean tea in a traditional-style tea house.",
            culturalSignificance: "Bukchon Hanok Village represents the traditional residential architecture and lifestyle of Korea during the Joseon Dynasty. Its hanok houses preserve important elements of Korean cultural heritage.",
            recommendation: "Take a guided cultural walk to learn about the history and architectural features of traditional Korean homes."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Village Walking Visit", cost: "Free" },
            { item: "Traditional Tea or Snacks", cost: "$5 - $10" },
            { item: "Local Transportation", cost: "$5 - $10" },
            { item: "Cultural Activities or Souvenirs", cost: "$10 - $20" }
        ],

        budgetNote: "Estimated budget is approximately $20 - $45 per person, depending on food, transportation, cultural activities, and souvenirs.",

        // 7. Transportation and Accommodation
        transportation: [
            "Take Seoul Subway Line 3 to Anguk Station and walk toward the village.",
            "Use local buses or taxis to reach the surrounding cultural district.",
            "Walking is the best way to explore the traditional streets and nearby attractions."
        ],

        accommodation: [
            "Stay in central Seoul for convenient access to Bukchon and other historic attractions.",
            "Choose accommodation near Insadong or Jongno for traditional shops, restaurants, and cultural experiences.",
            "Guesthouses, boutique hotels, and traditional hanok accommodation are available in nearby neighborhoods."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "9:00 AM",
                activity: "Arrive at Bukchon Hanok Village",
                description: "Begin exploring the traditional neighborhood and its beautiful hanok houses."
            },
            {
                time: "9:30 AM",
                activity: "Discover Traditional Streets",
                description: "Walk through historic lanes and admire the architectural details of traditional Korean homes."
            },
            {
                time: "10:30 AM",
                activity: "Visit Cultural Centers",
                description: "Learn about Korean traditions, architecture, and the history of the neighborhood."
            },
            {
                time: "11:30 AM",
                activity: "Enjoy Traditional Korean Tea",
                description: "Relax at a nearby tea house and experience traditional Korean refreshments."
            },
            {
                time: "12:30 PM",
                activity: "Enjoy Local Lunch",
                description: "Try traditional Korean food at a nearby restaurant."
            },
            {
                time: "2:00 PM",
                activity: "Explore Nearby Attractions",
                description: "Continue your visit around Insadong and other nearby cultural areas."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Remember that Bukchon is a living residential neighborhood.",
            "Respect residents' privacy and avoid making excessive noise.",
            "Follow posted visitor access hours and local regulations.",
            "Wear comfortable shoes for walking on narrow and sometimes steep streets.",
            "Visit during weekday mornings for a quieter experience.",
            "Ask permission before photographing residents or private properties.",
            "Keep the neighborhood clean and respect local traditions.",
            "Consider joining a guided cultural walking tour."
        ]
    },

    // ===================================
    // III. JAPAN
    // ===================================

    // ===================================
    // 11. MOUNT FUJI
    // ===================================

    {
        name: "Mount Fuji",
        country: "Japan",
        category: "Nature & Mountain Tourism",
        image: "images/Mount Fuji.jpg",
        budget: 80,
        featured: true,

        // 1. Overview
        description: "Mount Fuji is Japan's highest and most iconic mountain, famous for its nearly symmetrical volcanic shape and snow-covered summit. Located between Yamanashi and Shizuoka Prefectures, it is admired for its natural beauty, cultural significance, and breathtaking scenery. Visitors can enjoy mountain views, explore nearby lakes, experience traditional villages, and climb the mountain during the official climbing season.",

        location: "Between Yamanashi and Shizuoka Prefectures, Honshu, Japan.",

        history: "Mount Fuji is an active stratovolcano that last erupted in 1707 during the Edo period. It has been an important symbol in Japanese art, literature, religion, and traditional beliefs for centuries. Recognized as a UNESCO World Heritage Site in 2013 for its cultural significance, the mountain continues to attract visitors and climbers from around the world.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Lake Kawaguchiko",
                description: "Enjoy beautiful views of Mount Fuji reflected across the lake, especially during clear weather and the cherry blossom season."
            },
            {
                name: "Chureito Pagoda",
                description: "Visit the famous pagoda viewpoint offering a spectacular view of Mount Fuji surrounded by seasonal scenery."
            },
            {
                name: "Fuji Subaru Line 5th Station",
                description: "Discover a popular starting point for mountain climbers and enjoy impressive views from the mountain's upper slopes."
            },
            {
                name: "Oshino Hakkai",
                description: "Explore a traditional village famous for its clear spring-water ponds and beautiful views of Mount Fuji."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Experience Japan's most recognizable natural landmark.",
            "Enjoy breathtaking views of the mountain and surrounding landscapes.",
            "Discover the cultural and spiritual importance of Mount Fuji.",
            "Explore nearby lakes, traditional villages, and scenic viewpoints.",
            "Experience mountain climbing during the official climbing season."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "October to February for clear mountain views, and July to early September for the official climbing season.",
            weather: "Spring and autumn generally provide beautiful scenery and comfortable sightseeing conditions. Winter offers clear views on many days, while summer is the main climbing season.",
            recommendation: "Visit early in the morning for better chances of seeing Mount Fuji clearly. Always check official climbing information before planning a hike."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Enjoying the Beauty of Japan's Sacred Mountain",
            experience: "Admire Mount Fuji from nearby lakes and scenic viewpoints, explore traditional villages, and experience the mountain's remarkable natural surroundings.",
            culturalSignificance: "Mount Fuji has inspired Japanese art, poetry, religious traditions, and cultural identity for generations. It is considered a sacred mountain and an important symbol of Japan.",
            recommendation: "Visit Lake Kawaguchiko or Chureito Pagoda for memorable views and photographs of Mount Fuji."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Local Transportation", cost: "$20 - $30" },
            { item: "Food and Drinks", cost: "$10 - $15" },
            { item: "Attraction and Activity Fees", cost: "$10 - $20" },
            { item: "Other Expenses", cost: "$5 - $15" }
        ],

        budgetNote: "Estimated budget is approximately $45 - $80 per person for a sightseeing visit, excluding accommodation and long-distance travel. Mountain climbing may involve additional costs and required fees.",

        // 7. Transportation and Accommodation
        transportation: [
            "Travel from Tokyo by train or highway bus toward the Mount Fuji and Lake Kawaguchiko area.",
            "Use local sightseeing buses to reach popular viewpoints and nearby attractions.",
            "Renting a car can provide greater flexibility when exploring the surrounding region."
        ],

        accommodation: [
            "Stay near Lake Kawaguchiko for convenient access to scenic viewpoints and transportation.",
            "Choose a traditional Japanese ryokan for a cultural accommodation experience.",
            "Budget guesthouses, hotels, and hot spring resorts are available around the Mount Fuji area."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "7:00 AM",
                activity: "Depart Toward Mount Fuji",
                description: "Begin your journey from Tokyo or nearby accommodation toward the Mount Fuji region."
            },
            {
                time: "9:00 AM",
                activity: "Visit Lake Kawaguchiko",
                description: "Enjoy beautiful lake scenery and admire Mount Fuji from the waterfront."
            },
            {
                time: "10:30 AM",
                activity: "Explore Chureito Pagoda",
                description: "Visit the famous viewpoint and capture photographs of the mountain and pagoda."
            },
            {
                time: "12:00 PM",
                activity: "Enjoy Japanese Lunch",
                description: "Try local dishes at a restaurant around the Mount Fuji area."
            },
            {
                time: "1:30 PM",
                activity: "Discover Oshino Hakkai",
                description: "Explore the traditional village and its clear spring-water ponds."
            },
            {
                time: "3:30 PM",
                activity: "Enjoy the Mountain Scenery",
                description: "Spend time appreciating the beautiful surroundings before returning to your accommodation."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Check the weather forecast because clouds may hide the mountain.",
            "Visit early in the morning for better visibility.",
            "Bring warm clothing because mountain temperatures can be cold.",
            "Wear comfortable shoes for walking and sightseeing.",
            "Check official climbing dates and safety requirements before hiking.",
            "Bring drinking water and sun protection.",
            "Respect local customs and keep the natural environment clean.",
            "Allow enough travel time when visiting from Tokyo."
        ]
    },

    // ===================================
    // 12. FUSHIMI INARI SHRINE
    // ===================================

    {
        name: "Fushimi Inari Shrine",
        country: "Japan",
        category: "Culture & Religious Tourism",
        image: "images/Fushimi Inari Shrine.jpg",
        budget: 45,
        featured: false,

        // 1. Overview
        description: "Fushimi Inari Shrine is one of Japan's most famous Shinto shrines, located in Kyoto. It is especially known for thousands of bright red torii gates that form beautiful pathways through the forested mountain. Dedicated to Inari, the Shinto deity associated with rice, agriculture, and prosperity, the shrine offers visitors a memorable cultural and spiritual experience.",

        location: "Fushimi Ward, Kyoto, Japan.",

        history: "Fushimi Inari Shrine was established in 711 and has become one of the most important Inari shrines in Japan. Throughout history, people have visited to pray for good harvests, business success, and prosperity. The famous torii gates have been donated by individuals and businesses as expressions of gratitude and wishes for good fortune.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Senbon Torii",
                description: "Walk through thousands of iconic red torii gates arranged along beautiful mountain pathways."
            },
            {
                name: "Main Shrine",
                description: "Discover the traditional shrine buildings and learn about the religious importance of Inari."
            },
            {
                name: "Mount Inari Hiking Trail",
                description: "Explore the peaceful forest paths leading toward the mountain summit and enjoy scenic views."
            },
            {
                name: "Fox Statues",
                description: "See the many fox statues believed to be messengers of Inari, often holding symbolic objects."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Experience one of Japan's most recognizable cultural landmarks.",
            "Walk through thousands of beautiful red torii gates.",
            "Discover traditional Japanese Shinto beliefs and customs.",
            "Enjoy peaceful forest paths and mountain scenery.",
            "Capture memorable photographs of Kyoto's historic atmosphere."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "March to May and September to November.",
            weather: "Spring and autumn generally offer comfortable temperatures and beautiful seasonal scenery. Summer can be hot and humid, while winter is usually cooler.",
            recommendation: "Visit early in the morning to enjoy a quieter atmosphere and take photographs with fewer crowds."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Walking Through the Thousand Red Torii Gates",
            experience: "Follow the beautiful pathways beneath rows of red torii gates, explore traditional shrine areas, and enjoy the peaceful natural surroundings of Mount Inari.",
            culturalSignificance: "The shrine is dedicated to Inari, a deity associated with rice, agriculture, prosperity, and business success. Foxes are traditionally regarded as Inari's messengers.",
            recommendation: "Take time to explore beyond the main torii gate pathway to discover quieter sections of the mountain trail."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Local Transportation", cost: "$5 - $10" },
            { item: "Food and Drinks", cost: "$10 - $15" },
            { item: "Souvenirs", cost: "$5 - $10" },
            { item: "Other Expenses", cost: "$5 - $10" }
        ],

        budgetNote: "Estimated budget is approximately $25 - $45 per person, excluding accommodation and transportation from other cities. General shrine access is free.",
        // 7. Transportation and Accommodation
        transportation: [
            "Take the JR Nara Line to Inari Station, located directly beside the shrine.",
            "Use the Keihan Main Line and get off at Fushimi-Inari Station.",
            "Walk through the surrounding area to explore nearby shops and traditional streets."
        ],

        accommodation: [
            "Stay near Kyoto Station for convenient access to public transportation.",
            "Choose a traditional Japanese ryokan to experience local hospitality.",
            "Budget hotels, guesthouses, and hostels are available throughout Kyoto."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "7:00 AM",
                activity: "Arrive at Fushimi Inari Shrine",
                description: "Begin your visit early and enjoy the peaceful atmosphere around the shrine."
            },
            {
                time: "7:30 AM",
                activity: "Explore the Main Shrine",
                description: "Discover the traditional buildings and learn about the shrine's history."
            },
            {
                time: "8:30 AM",
                activity: "Walk Through Senbon Torii",
                description: "Experience the famous red torii gate pathways and take memorable photographs."
            },
            {
                time: "10:00 AM",
                activity: "Explore Mount Inari",
                description: "Continue along the mountain trails and discover smaller shrines along the route."
            },
            {
                time: "12:00 PM",
                activity: "Enjoy Local Japanese Food",
                description: "Try traditional Kyoto dishes and snacks at nearby restaurants."
            },
            {
                time: "1:30 PM",
                activity: "Explore Nearby Shops",
                description: "Browse local shops for souvenirs and enjoy the surrounding neighborhood."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Visit early in the morning to avoid large crowds.",
            "Wear comfortable walking shoes for the mountain trails.",
            "Bring drinking water, especially during warmer months.",
            "Respect shrine traditions and follow posted instructions.",
            "Avoid blocking pathways when taking photographs.",
            "Keep the shrine and surrounding environment clean.",
            "Allow enough time if you plan to hike toward the summit.",
            "Check train schedules when planning your return journey."
        ]
    },

    // ===================================
    // 13. SHIBUYA CROSSING
    // ===================================

    {
        name: "Shibuya Crossing",
        country: "Japan",
        category: "City & Urban Tourism",
        image: "images/Shibuya Crossing.jpg",
        budget: 60,
        featured: false,

        // 1. Overview
        description: "Shibuya Crossing is one of the world's most famous pedestrian intersections, located in the heart of Tokyo, Japan. Known for its busy streets, colorful digital screens, and energetic atmosphere, the crossing attracts visitors from around the world. It represents modern Japanese city life and offers an exciting experience surrounded by shopping centers, restaurants, entertainment, and fashionable streets.",

        location: "Shibuya, Tokyo, Japan.",

        history: "Shibuya developed from a small railway-side area into one of Tokyo's major commercial and entertainment districts. The famous pedestrian crossing became internationally recognized through its large crowds, surrounding advertising screens, and appearances in films, television, and popular media. Today, it is an important symbol of modern Tokyo.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Shibuya Scramble Crossing",
                description: "Experience the famous intersection where pedestrians cross from every direction when traffic lights change."
            },
            {
                name: "Hachiko Memorial Statue",
                description: "Visit the statue of Hachiko, the loyal Akita dog remembered for waiting for his owner at Shibuya Station."
            },
            {
                name: "Shibuya Sky",
                description: "Enjoy panoramic views of Tokyo from the observation deck above Shibuya Scramble Square."
            },
            {
                name: "Center-Gai Street",
                description: "Explore a lively shopping and entertainment street filled with restaurants, fashion stores, and colorful signs."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Experience one of Tokyo's most recognizable landmarks.",
            "Discover the exciting atmosphere of modern Japanese city life.",
            "Explore popular shopping, dining, and entertainment areas.",
            "Enjoy impressive city views from nearby observation spaces.",
            "Capture memorable photographs of Tokyo's famous streets."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "March to May and September to November.",
            weather: "Spring and autumn generally provide comfortable weather for walking around Tokyo. Summer can be hot and humid, while winter is cooler.",
            recommendation: "Visit in the evening to enjoy the illuminated buildings and lively atmosphere. Weekends are especially busy."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Experiencing Tokyo's Famous Scramble Crossing",
            experience: "Stand among hundreds of pedestrians crossing the intersection, explore the surrounding streets, and enjoy the bright lights and energetic atmosphere of Shibuya.",
            culturalSignificance: "Shibuya Crossing represents the energy, technology, fashion, and modern urban lifestyle that make Tokyo famous around the world.",
            recommendation: "Watch the crossing from a nearby elevated viewpoint before experiencing it on foot."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Local Transportation", cost: "$5 - $10" },
            { item: "Food and Drinks", cost: "$15 - $20" },
            { item: "Attraction Fees", cost: "$15 - $25" },
            { item: "Shopping and Other Expenses", cost: "$10 - $20" }
        ],

        budgetNote: "Estimated budget is approximately $45 - $60 per person for a sightseeing visit, excluding accommodation and major shopping expenses.",
        // 7. Transportation and Accommodation
        transportation: [
            "Take the JR Yamanote Line to Shibuya Station.",
            "Use Tokyo Metro or other railway lines to reach Shibuya from different parts of the city.",
            "Explore the surrounding district on foot because many attractions are close together."
        ],

        accommodation: [
            "Stay near Shibuya Station for convenient access to shopping and entertainment.",
            "Choose hotels around Shinjuku or Harajuku for additional sightseeing opportunities.",
            "Budget hostels, capsule hotels, and business hotels are available throughout Tokyo."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "10:00 AM",
                activity: "Arrive at Shibuya",
                description: "Explore the district and discover its famous shopping streets."
            },
            {
                time: "11:00 AM",
                activity: "Visit Hachiko Memorial Statue",
                description: "Learn about the touching story of Hachiko and take photographs near the statue."
            },
            {
                time: "12:00 PM",
                activity: "Enjoy Japanese Lunch",
                description: "Try popular Japanese meals at a local restaurant."
            },
            {
                time: "1:30 PM",
                activity: "Explore Center-Gai Street",
                description: "Discover fashion shops, entertainment areas, and colorful city streets."
            },
            {
                time: "4:00 PM",
                activity: "Visit Shibuya Sky",
                description: "Enjoy impressive panoramic views of Tokyo from the observation deck."
            },
            {
                time: "6:00 PM",
                activity: "Experience Shibuya Crossing",
                description: "Watch the famous intersection become illuminated and experience its lively evening atmosphere."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Use Shibuya Station as your main transportation point.",
            "Visit in the evening to enjoy the colorful city lights.",
            "Keep your belongings secure in crowded areas.",
            "Follow pedestrian traffic signals when crossing.",
            "Book observation deck tickets in advance when possible.",
            "Wear comfortable shoes for walking around the district.",
            "Respect local rules when taking photographs.",
            "Check train schedules before returning to your accommodation."
        ]
    },

    // ===================================
    // 14. OSAKA CASTLE
    // ===================================

    {
        name: "Osaka Castle",
        country: "Japan",
        category: "History & Cultural Tourism",
        image: "images/Osaka Castle.jpg",
        budget: 65,
        featured: false,

        // 1. Overview
        description: "Osaka Castle is one of Japan's most famous historical landmarks, located in Osaka. Surrounded by beautiful stone walls, moats, gardens, and seasonal flowers, the castle is admired for its traditional Japanese architecture and historical importance. Visitors can explore the castle museum, learn about Japan's samurai history, and enjoy beautiful views of the surrounding city.",

        location: "Chuo Ward, Osaka, Japan.",

        history: "Osaka Castle was originally built in 1583 by Toyotomi Hideyoshi, an important leader who helped unify Japan. The castle played a significant role during the late 16th century and the conflicts that followed. Although the original structure was destroyed and rebuilt several times, the present main tower was reconstructed in 1931 and later renovated.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Osaka Castle Main Tower",
                description: "Explore the famous castle tower, which contains historical exhibitions and offers views of Osaka."
            },
            {
                name: "Nishinomaru Garden",
                description: "Enjoy a peaceful garden with beautiful cherry blossoms and impressive views of the castle."
            },
            {
                name: "Osaka Castle Park",
                description: "Walk through the large park surrounding the castle, featuring green spaces, seasonal flowers, and historic structures."
            },
            {
                name: "Castle Moats and Stone Walls",
                description: "Discover the impressive defensive architecture and massive stone walls that once protected the castle."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Discover an important landmark in Japanese history.",
            "Learn about samurai culture and the unification of Japan.",
            "Admire traditional Japanese castle architecture.",
            "Enjoy beautiful gardens and seasonal cherry blossoms.",
            "Experience one of Osaka's most popular sightseeing destinations."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "March to May and October to November.",
            weather: "Spring offers beautiful cherry blossoms and comfortable temperatures, while autumn brings colorful leaves and pleasant sightseeing weather.",
            recommendation: "Visit during cherry blossom season for spectacular scenery, or explore in autumn for beautiful gardens and cooler weather."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Discovering Japan's Samurai History",
            experience: "Explore the castle museum, admire its traditional architecture, walk through the surrounding gardens, and enjoy panoramic views from the main tower.",
            culturalSignificance: "Osaka Castle represents an important period in Japanese history, especially the efforts of Toyotomi Hideyoshi to unify the country during the late 16th century.",
            recommendation: "Visit the main tower and Nishinomaru Garden to enjoy both historical exhibitions and beautiful castle scenery."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Local Transportation", cost: "$5 - $10" },
            { item: "Food and Drinks", cost: "$10 - $15" },
            { item: "Castle Museum Admission", cost: "$5 - $10" },
            { item: "Other Expenses", cost: "$5 - $15" }
        ],

        budgetNote: "Estimated budget is approximately $25 - $50 per person, excluding accommodation and long-distance transportation. Additional costs may apply for special exhibitions or activities.",
        // 7. Transportation and Accommodation
        transportation: [
            "Take the JR Osaka Loop Line to Osakajokoen Station or Morinomiya Station.",
            "Use the Osaka Metro Chuo Line or Tanimachi Line to reach nearby stations.",
            "Walk through Osaka Castle Park to access the main tower and surrounding attractions."
        ],

        accommodation: [
            "Stay around Osaka Station or Umeda for convenient transportation connections.",
            "Choose accommodation in Namba for shopping, restaurants, and nightlife.",
            "Budget hotels, hostels, and traditional Japanese accommodation are available throughout Osaka."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "9:00 AM",
                activity: "Arrive at Osaka Castle Park",
                description: "Begin your visit by exploring the beautiful park and its surrounding historical scenery."
            },
            {
                time: "10:00 AM",
                activity: "Explore Osaka Castle Main Tower",
                description: "Discover historical exhibitions and learn about the castle's important role in Japanese history."
            },
            {
                time: "11:30 AM",
                activity: "Enjoy Panoramic Views",
                description: "Admire the surrounding city and castle grounds from the observation area."
            },
            {
                time: "12:30 PM",
                activity: "Enjoy Japanese Lunch",
                description: "Try local Osaka dishes at a nearby restaurant or food area."
            },
            {
                time: "2:00 PM",
                activity: "Visit Nishinomaru Garden",
                description: "Walk through the peaceful garden and enjoy its seasonal flowers and castle views."
            },
            {
                time: "3:30 PM",
                activity: "Explore the Castle Grounds",
                description: "Discover the historic stone walls, moats, and other interesting areas before leaving."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Wear comfortable shoes because the castle grounds are large.",
            "Visit early to avoid the busiest hours.",
            "Check museum opening hours and admission information before visiting.",
            "Bring a camera to capture the castle and gardens.",
            "Visit during spring for beautiful cherry blossoms.",
            "Respect historical buildings and restricted areas.",
            "Bring water during warmer months.",
            "Allow enough time to explore the entire park."
        ]
    },

    // ===================================
    // 15. NARA PARK
    // ===================================

    {
        name: "Nara Park",
        country: "Japan",
        category: "Nature & Cultural Tourism",
        image: "images/Nara Park.jpg",
        budget: 55,
        featured: false,

        // 1. Overview
        description: "Nara Park is a famous public park in Nara, Japan, known for its beautiful natural surroundings, historic temples, and hundreds of freely roaming deer. Visitors can enjoy peaceful walking paths, interact with the friendly deer, and explore important cultural landmarks. The park offers a unique combination of Japanese history, wildlife, and traditional scenery.",

        location: "Nara City, Nara Prefecture, Japan.",

        history: "Nara Park was established in 1880 and is located in an area that was once the center of Japan's ancient capital. The surrounding temples and shrines reflect the importance of Nara during the Nara period (710–794). The deer have long been regarded as sacred messengers associated with Kasuga Taisha Shrine and remain an important symbol of the city.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Nara Deer Park",
                description: "Meet the famous freely roaming deer and observe them throughout the park's green spaces."
            },
            {
                name: "Todai-ji Temple",
                description: "Visit the historic Buddhist temple famous for its enormous Great Buddha statue and impressive wooden hall."
            },
            {
                name: "Kasuga Taisha Shrine",
                description: "Discover a beautiful Shinto shrine surrounded by forest and decorated with thousands of stone and bronze lanterns."
            },
            {
                name: "Nara National Museum",
                description: "Explore important collections of Buddhist art, sculptures, and historical cultural treasures."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Experience the unique opportunity to see freely roaming deer.",
            "Discover important historical temples and traditional Japanese shrines.",
            "Enjoy peaceful natural scenery and beautiful walking paths.",
            "Learn about Nara's ancient history and cultural traditions.",
            "Experience one of Japan's most memorable wildlife and cultural destinations."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "March to May and October to November.",
            weather: "Spring offers comfortable temperatures and beautiful cherry blossoms, while autumn brings colorful foliage and pleasant walking conditions.",
            recommendation: "Visit in spring or autumn for enjoyable outdoor activities and beautiful scenery. Arrive early to explore the park before it becomes crowded."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Meeting the Famous Deer of Nara",
            experience: "Walk through the park, observe the freely roaming deer, and purchase special deer crackers from authorized vendors to feed them safely.",
            culturalSignificance: "Deer have been traditionally considered sacred messengers of the gods associated with Kasuga Taisha Shrine. They are an important part of Nara's cultural identity and heritage.",
            recommendation: "Enjoy a peaceful walk through the park and visit Todai-ji Temple to experience both its wildlife and cultural attractions."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Local Transportation", cost: "$5 - $10" },
            { item: "Food and Drinks", cost: "$10 - $15" },
            { item: "Temple and Museum Admission", cost: "$5 - $15" },
            { item: "Deer Crackers and Other Expenses", cost: "$5 - $10" }
        ],
        budgetNote: "Estimated budget is approximately $25 - $50 per person, excluding accommodation and transportation from other cities. Some park areas are free to enter, while individual attractions may charge admission fees.",

        // 7. Transportation and Accommodation
        transportation: [
            "Take the JR Yamatoji Line to JR Nara Station.",
            "Use the Kintetsu Nara Line to reach Kintetsu-Nara Station, which is closer to the park.",
            "Walk or use local buses to explore the park and nearby temples."
        ],

        accommodation: [
            "Stay near Nara Park for convenient access to the main attractions.",
            "Choose accommodation near Kintetsu-Nara Station for easy transportation and shopping.",
            "Traditional Japanese inns, guesthouses, and budget hotels are available throughout Nara."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:30 AM",
                activity: "Arrive at Nara Park",
                description: "Begin your day with a peaceful walk through the park and enjoy the natural scenery."
            },
            {
                time: "9:00 AM",
                activity: "Meet the Nara Deer",
                description: "Observe the famous deer and enjoy feeding them with authorized deer crackers."
            },
            {
                time: "10:30 AM",
                activity: "Visit Todai-ji Temple",
                description: "Explore the historic temple and admire the enormous Great Buddha statue."
            },
            {
                time: "12:00 PM",
                activity: "Enjoy Japanese Lunch",
                description: "Try local dishes at a restaurant near the park."
            },
            {
                time: "1:30 PM",
                activity: "Explore Kasuga Taisha Shrine",
                description: "Discover the traditional shrine, beautiful forest surroundings, and historic lanterns."
            },
            {
                time: "3:00 PM",
                activity: "Visit Nara National Museum",
                description: "Explore Buddhist art and learn more about the region's cultural heritage."
            },
            {
                time: "4:30 PM",
                activity: "Enjoy the Park Scenery",
                description: "Take a final walk through the park and enjoy the peaceful atmosphere before leaving."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Keep a safe and respectful distance from the deer.",
            "Only feed deer with authorized deer crackers.",
            "Do not tease, chase, or feed the deer other food.",
            "Wear comfortable shoes for walking around the park.",
            "Visit early to enjoy a quieter atmosphere.",
            "Keep your belongings secure around curious deer.",
            "Respect the temples, shrines, and local traditions.",
            "Check attraction opening hours and admission fees before visiting."
        ]
    },

    // ===================================
    // IV. MONGOLIA
    // ===================================

    // ===================================
    // 16. GOBI DESERT
    // ===================================

    {
        name: "Gobi Desert",
        country: "Mongolia",
        category: "Nature & Adventure Tourism",
        image: "images/Gobi Desert.jpg",
        budget: 120,
        featured: true,

        // 1. Overview
        description: "The Gobi Desert is one of the largest deserts in Asia, stretching across southern Mongolia and northern China. Famous for its vast landscapes, dramatic sand dunes, rocky mountains, and unique wildlife, it offers visitors an unforgettable adventure. Travelers can explore traditional nomadic culture, ride camels, discover ancient fossils, and experience the peaceful beauty of the Mongolian wilderness.",

        location: "Southern Mongolia, extending into northern China.",

        history: "The Gobi Desert has played an important role in the history of Central Asia and the ancient Silk Road trade routes. It is also internationally famous for its dinosaur fossil discoveries, including important discoveries made during expeditions in the 1920s. For generations, Mongolian nomadic communities have lived in and traveled across this challenging landscape.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Khongoryn Els",
                description: "Discover the enormous sand dunes known as the Singing Dunes, famous for their impressive size and sounds produced by moving sand."
            },
            {
                name: "Bayanzag Flaming Cliffs",
                description: "Explore the dramatic red sandstone cliffs where important dinosaur fossils and eggs were discovered."
            },
            {
                name: "Yolyn Am",
                description: "Visit a beautiful mountain gorge in Gurvan Saikhan National Park, known for its impressive rock formations and seasonal ice."
            },
            {
                name: "Gobi Gurvansaikhan National Park",
                description: "Experience the desert's diverse landscapes, wildlife, mountains, and spectacular natural scenery."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Explore one of Asia's most remarkable desert landscapes.",
            "Experience traditional Mongolian nomadic culture.",
            "Enjoy camel riding and desert adventures.",
            "Discover famous dinosaur fossil sites and geological formations.",
            "Experience peaceful scenery and unforgettable star-filled night skies."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "May to September.",
            weather: "Late spring and early autumn generally offer more comfortable temperatures. Summer can be extremely hot during the day, while nights may become cold.",
            recommendation: "Visit in June or September for a more comfortable desert adventure. Prepare for changing temperatures and check local travel conditions."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Camel Riding Across the Mongolian Desert",
            experience: "Ride a Bactrian camel across the beautiful sand dunes, explore traditional nomadic settlements, and enjoy the spectacular desert sunset.",
            culturalSignificance: "The Gobi Desert is closely connected to Mongolia's nomadic heritage. Camels have traditionally supported transportation, trade, and daily life in the desert regions.",
            recommendation: "Spend a night in a traditional ger camp to experience Mongolian hospitality and admire the stars above the desert."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Transportation and Guided Tours", cost: "$50 - $70" },
            { item: "Food and Drinks", cost: "$15 - $20" },
            { item: "Accommodation", cost: "$25 - $35" },
            { item: "Activities and Other Expenses", cost: "$10 - $20" }
        ],
        budgetNote: "Estimated budget is approximately $100 - $145 per person for a guided desert experience. Actual costs depend on tour length, transportation, accommodation, and activities.",

        // 7. Transportation and Accommodation
        transportation: [
            "Travel from Ulaanbaatar toward Dalanzadgad, the main gateway to the South Gobi region.",
            "Use organized four-wheel-drive tours to reach remote desert attractions.",
            "Travel with experienced local guides because distances are long and some roads are unpaved."
        ],

        accommodation: [
            "Stay in traditional ger camps to experience Mongolian nomadic hospitality.",
            "Choose tourist camps around Khongoryn Els or other major attractions.",
            "Basic guesthouses and hotels are available in Dalanzadgad."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "7:00 AM",
                activity: "Begin the Desert Journey",
                description: "Start your guided journey toward the beautiful landscapes of the Gobi Desert."
            },
            {
                time: "9:30 AM",
                activity: "Explore Bayanzag Flaming Cliffs",
                description: "Discover the famous red sandstone formations and learn about the region's dinosaur fossil discoveries."
            },
            {
                time: "11:30 AM",
                activity: "Enjoy a Traditional Lunch",
                description: "Try local Mongolian dishes and experience traditional hospitality."
            },
            {
                time: "1:00 PM",
                activity: "Visit Khongoryn Els",
                description: "Explore the impressive sand dunes and enjoy the surrounding desert scenery."
            },
            {
                time: "3:30 PM",
                activity: "Experience Camel Riding",
                description: "Enjoy a memorable camel ride across the beautiful desert landscape."
            },
            {
                time: "6:00 PM",
                activity: "Watch the Desert Sunset",
                description: "Admire the changing colors of the sand dunes as the sun sets."
            },
            {
                time: "8:00 PM",
                activity: "Stay at a Ger Camp",
                description: "Enjoy a traditional Mongolian evening and relax beneath the beautiful night sky."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Bring warm clothing because desert temperatures can change quickly.",
            "Carry enough drinking water during outdoor activities.",
            "Use sunscreen, sunglasses, and a hat for sun protection.",
            "Wear comfortable shoes suitable for sandy and rocky terrain.",
            "Travel with an experienced local guide.",
            "Bring cash because payment options may be limited in remote areas.",
            "Respect local nomadic communities and their traditions.",
            "Avoid leaving rubbish behind and protect the natural environment."
        ]
    },

    // ===================================
    // 17. GENGHIS KHAN STATUE COMPLEX
    // ===================================

    {
        name: "Genghis Khan Statue Complex",
        country: "Mongolia",
        category: "History & Cultural Tourism",
        image: "images/Genghis Khan Statue Complex.jpg",
        budget: 70,
        featured: false,

        // 1. Overview
        description: "The Genghis Khan Statue Complex is a famous historical and cultural attraction located near Ulaanbaatar, Mongolia. It features an enormous stainless-steel equestrian statue of Genghis Khan, one of the most influential leaders in world history. Visitors can explore the complex, learn about the Mongol Empire, and enjoy panoramic views of the surrounding countryside.",

        location: "Tsonjin Boldog, near Ulaanbaatar, Mongolia.",

        history: "The complex was opened in 2008 to commemorate Genghis Khan and his historical legacy. The enormous statue represents the legendary Mongol leader on horseback and stands at a location associated with a story about his discovery of a golden whip. Genghis Khan founded the Mongol Empire in 1206, creating one of the largest connected land empires in history.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Genghis Khan Equestrian Statue",
                description: "Admire the enormous stainless-steel statue of Genghis Khan riding a horse, one of Mongolia's most recognizable landmarks."
            },
            {
                name: "Statue Observation Area",
                description: "Enjoy beautiful views of the surrounding grasslands and countryside from the upper viewing area."
            },
            {
                name: "Historical Exhibition Hall",
                description: "Discover displays about Mongolian history, traditional clothing, weapons, and the Mongol Empire."
            },
            {
                name: "Traditional Mongolian Cultural Displays",
                description: "Explore cultural exhibits that introduce visitors to Mongolia's nomadic traditions and historical heritage."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Discover the legacy of one of history's most influential leaders.",
            "Admire one of the world's largest equestrian statues.",
            "Learn about the history and expansion of the Mongol Empire.",
            "Enjoy impressive views of Mongolia's open countryside.",
            "Experience an important symbol of Mongolian national identity."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "May to September.",
            weather: "Summer generally offers warmer temperatures and greener landscapes. Spring and autumn can be cooler, while winter is extremely cold.",
            recommendation: "Visit during summer for comfortable sightseeing and clear countryside views. Check weather conditions before traveling."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Standing Before the Giant Statue of Genghis Khan",
            experience: "Explore the impressive monument, enter the statue complex, learn about Mongolian history, and admire the surrounding grasslands from the observation area.",
            culturalSignificance: "Genghis Khan is widely remembered in Mongolia as a major historical leader and an important symbol of national heritage and identity.",
            recommendation: "Take time to explore the historical exhibition and enjoy the panoramic views from the statue."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Transportation", cost: "$15 - $25" },
            { item: "Food and Drinks", cost: "$10 - $15" },
            { item: "Entrance and Exhibition Fees", cost: "$10 - $15" },
            { item: "Other Expenses", cost: "$5 - $15" }
        ],

        budgetNote: "Estimated budget is approximately $40 - $70 per person, depending on transportation, entrance fees, and personal spending.",
        // 7. Transportation and Accommodation
        transportation: [
            "Travel from Ulaanbaatar toward Tsonjin Boldog by car or organized tour.",
            "Join a guided day trip to explore the statue complex and nearby attractions.",
            "Use local tour operators for convenient transportation and historical explanations."
        ],

        accommodation: [
            "Stay in Ulaanbaatar for convenient access to the statue complex.",
            "Choose a traditional ger camp in the surrounding countryside for a cultural experience.",
            "Hotels, guesthouses, and budget accommodation are available in Ulaanbaatar."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Depart from Ulaanbaatar",
                description: "Begin your journey toward the Genghis Khan Statue Complex."
            },
            {
                time: "9:30 AM",
                activity: "Arrive at the Statue Complex",
                description: "Admire the impressive equestrian statue and take photographs."
            },
            {
                time: "10:00 AM",
                activity: "Explore the Historical Exhibition",
                description: "Learn about Genghis Khan, the Mongol Empire, and traditional Mongolian culture."
            },
            {
                time: "11:30 AM",
                activity: "Visit the Observation Area",
                description: "Enjoy panoramic views of the surrounding grasslands."
            },
            {
                time: "12:30 PM",
                activity: "Enjoy a Traditional Lunch",
                description: "Try Mongolian food and experience local hospitality."
            },
            {
                time: "2:00 PM",
                activity: "Explore the Surrounding Area",
                description: "Discover nearby countryside scenery and learn more about Mongolia's heritage."
            },
            {
                time: "4:00 PM",
                activity: "Return to Ulaanbaatar",
                description: "Complete your visit and travel back to the city."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Bring a camera to capture the enormous statue.",
            "Wear comfortable shoes for walking around the complex.",
            "Bring a jacket because the weather can change quickly.",
            "Check entrance fees and opening hours before visiting.",
            "Learn a little about Genghis Khan before your visit.",
            "Respect historical displays and cultural exhibits.",
            "Carry some cash for small purchases.",
            "Consider joining a guided tour for a deeper understanding of Mongolian history."
        ]
    },

    // ===================================
    // 18. TERELJ NATIONAL PARK
    // ===================================

    {
        name: "Terelj National Park",
        country: "Mongolia",
        category: "Nature & Adventure Tourism",
        image: "images/Terelj National Park.jpg",
        budget: 100,
        featured: false,

        // 1. Overview
        description: "Terelj National Park is one of Mongolia's most beautiful natural destinations, located northeast of Ulaanbaatar. Famous for its green valleys, dramatic granite rock formations, forests, and open grasslands, the park offers visitors opportunities for hiking, horseback riding, camping, and experiencing traditional Mongolian nomadic culture. Its peaceful landscapes make it a popular destination for nature lovers and adventure travelers.",

        location: "Tuv Province, northeast of Ulaanbaatar, Mongolia.",

        history: "Gorkhi-Terelj National Park was established as a protected natural area in 1993. The region is known for its distinctive granite formations, mountain scenery, and traditional nomadic communities. It has become an important destination for protecting Mongolia's natural environment while introducing visitors to its outdoor lifestyle and cultural heritage.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Turtle Rock",
                description: "Visit the park's famous granite formation that naturally resembles a giant turtle."
            },
            {
                name: "Aryabal Meditation Temple",
                description: "Explore a peaceful Buddhist meditation temple situated on a hillside with beautiful mountain views."
            },
            {
                name: "Terelj River",
                description: "Enjoy the scenic river surroundings and peaceful landscapes of the national park."
            },
            {
                name: "Gorkhi-Terelj Valley",
                description: "Discover beautiful green valleys, unusual rock formations, and open grasslands surrounded by mountains."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Enjoy some of Mongolia's most beautiful mountain landscapes.",
            "Explore unique granite rock formations and green valleys.",
            "Experience horseback riding and outdoor adventures.",
            "Discover traditional Mongolian nomadic culture.",
            "Relax in a peaceful natural environment away from city life."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "June to September.",
            weather: "Summer offers warmer temperatures, green landscapes, and suitable conditions for outdoor activities. Spring and autumn can be cooler, while winter brings snow and freezing temperatures.",
            recommendation: "Visit during summer for hiking, horseback riding, and enjoying the park's green scenery."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Experiencing Traditional Mongolian Nomadic Life",
            experience: "Stay in a traditional ger camp, enjoy horseback riding through the open valleys, and discover the peaceful lifestyle of Mongolia's countryside.",
            culturalSignificance: "Terelj is connected to Mongolia's nomadic traditions, where horses, livestock, and the natural environment have played important roles in everyday life for generations.",
            recommendation: "Spend a night in a ger camp and enjoy the beautiful mountain scenery and traditional Mongolian hospitality."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Transportation", cost: "$20 - $30" },
            { item: "Food and Drinks", cost: "$15 - $20" },
            { item: "Accommodation", cost: "$30 - $40" },
            { item: "Activities and Other Expenses", cost: "$10 - $20" }
        ],
        budgetNote: "Estimated budget is approximately $75 - $110 per person for a short visit, depending on transportation, accommodation, and activities.",

        // 7. Transportation and Accommodation
        transportation: [
            "Travel from Ulaanbaatar to Terelj National Park by car or organized tour.",
            "Use local four-wheel-drive transportation to reach more remote areas.",
            "Horseback riding and walking are popular ways to explore selected areas of the park."
        ],

        accommodation: [
            "Stay in traditional ger camps for an authentic Mongolian experience.",
            "Choose tourist resorts and lodges located around the park.",
            "Return to Ulaanbaatar for a wider selection of hotels and guesthouses."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Depart from Ulaanbaatar",
                description: "Begin your journey toward the beautiful landscapes of Terelj National Park."
            },
            {
                time: "9:30 AM",
                activity: "Visit Turtle Rock",
                description: "Explore the famous natural rock formation and enjoy the surrounding scenery."
            },
            {
                time: "11:00 AM",
                activity: "Explore Aryabal Meditation Temple",
                description: "Walk along the hillside trail and discover the peaceful Buddhist temple."
            },
            {
                time: "12:30 PM",
                activity: "Enjoy Traditional Mongolian Lunch",
                description: "Try local dishes and experience Mongolian hospitality."
            },
            {
                time: "2:00 PM",
                activity: "Experience Horseback Riding",
                description: "Enjoy a guided horseback ride through the park's open valleys."
            },
            {
                time: "4:00 PM",
                activity: "Explore the Terelj Valley",
                description: "Admire the mountain scenery, rivers, and beautiful natural surroundings."
            },
            {
                time: "6:00 PM",
                activity: "Relax at a Ger Camp",
                description: "Enjoy the peaceful countryside and traditional Mongolian accommodation."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Bring warm clothing because temperatures can change quickly.",
            "Wear comfortable shoes for walking and hiking.",
            "Use sunscreen and bring drinking water.",
            "Follow safety instructions during horseback riding.",
            "Respect local communities and nomadic traditions.",
            "Book accommodation in advance during busy seasons.",
            "Keep the national park clean and protect its natural environment.",
            "Consider joining a guided tour when exploring remote areas."
        ]
    },

    // ===================================
    // 19. KHUVSGUL LAKE
    // ===================================

    {
        name: "Khuvsgul Lake",
        country: "Mongolia",
        category: "Nature & Eco-Tourism",
        image: "images/Khuvsgul Lake.jpg",
        budget: 110,
        featured: false,

        // 1. Overview
        description: "Khuvsgul Lake is one of Mongolia's largest and most beautiful freshwater lakes, located in the northern part of the country near the Russian border. Surrounded by forests, mountains, and peaceful wilderness, the lake is famous for its clear blue water and breathtaking natural scenery. Visitors can enjoy boating, hiking, horseback riding, and discovering the traditional lifestyle of local communities.",

        location: "Khuvsgul Province, northern Mongolia.",

        history: "Khuvsgul Lake was formed through geological processes millions of years ago and is one of the world's ancient freshwater lakes. It contains a significant portion of Mongolia's freshwater resources and is an important part of the country's natural heritage. The surrounding region is also home to the Tsaatan people, known for their traditional reindeer-herding culture.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Khuvsgul Lake Shoreline",
                description: "Enjoy the crystal-clear blue water, beautiful beaches, and spectacular mountain views surrounding the lake."
            },
            {
                name: "Khuvsgul National Park",
                description: "Explore the protected natural area featuring forests, wildlife, mountains, and peaceful hiking routes."
            },
            {
                name: "Khatgal Village",
                description: "Discover a small lakeside settlement that serves as a popular starting point for exploring the lake."
            },
            {
                name: "Tsaatan Reindeer-Herding Communities",
                description: "Learn about the traditional lifestyle and cultural heritage of Mongolia's reindeer-herding communities through respectful guided visits."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Admire one of Mongolia's most beautiful freshwater lakes.",
            "Enjoy clear blue water and spectacular mountain scenery.",
            "Experience outdoor activities such as boating and hiking.",
            "Discover local traditions and unique cultural communities.",
            "Relax in one of northern Mongolia's most peaceful natural environments."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "June to September.",
            weather: "Summer offers warmer temperatures and suitable conditions for outdoor activities. Spring and autumn are cooler, while winter brings freezing temperatures and snowy landscapes.",
            recommendation: "Visit during July or August for comfortable sightseeing, lake activities, and opportunities to explore the surrounding countryside."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Exploring Mongolia's Beautiful Blue Pearl",
            experience: "Enjoy a boat trip across the clear lake, explore peaceful forest trails, and experience the traditional culture of northern Mongolia.",
            culturalSignificance: "Khuvsgul Lake is an important natural treasure for Mongolia. Its surrounding region also preserves the traditions of communities whose lives are closely connected to nature and livestock herding.",
            recommendation: "Spend a few days near the lake to enjoy its peaceful atmosphere, beautiful scenery, and outdoor activities."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Transportation", cost: "$35 - $50" },
            { item: "Food and Drinks", cost: "$15 - $20" },
            { item: "Accommodation", cost: "$30 - $40" },
            { item: "Activities and Other Expenses", cost: "$10 - $20" }
        ],
        budgetNote: "Estimated budget is approximately $90 - $130 per person for a short visit, depending on transportation, accommodation, and selected activities.",

        // 7. Transportation and Accommodation
        transportation: [
            "Travel from Ulaanbaatar to Murun by domestic flight or long-distance road transportation.",
            "Continue from Murun to Khatgal village by car or organized tour.",
            "Use local guides and suitable vehicles to explore remote areas around the lake."
        ],

        accommodation: [
            "Stay in lakeside ger camps for beautiful views and a traditional experience.",
            "Choose guesthouses and small lodges around Khatgal village.",
            "Camping is possible in designated areas when weather and local conditions allow."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Enjoy Breakfast by the Lake",
                description: "Begin the day with beautiful views of the surrounding mountains and clear blue water."
            },
            {
                time: "9:00 AM",
                activity: "Explore Khuvsgul Lake",
                description: "Walk along the shoreline and discover the lake's peaceful natural scenery."
            },
            {
                time: "10:30 AM",
                activity: "Enjoy a Boat Trip",
                description: "Experience the beauty of the lake from the water when weather and services permit."
            },
            {
                time: "12:00 PM",
                activity: "Enjoy a Local Lunch",
                description: "Try traditional Mongolian food at a nearby restaurant or ger camp."
            },
            {
                time: "1:30 PM",
                activity: "Explore the National Park",
                description: "Discover forest trails and enjoy the beautiful mountain surroundings."
            },
            {
                time: "3:30 PM",
                activity: "Discover Local Culture",
                description: "Learn about northern Mongolian traditions through a respectful local cultural experience."
            },
            {
                time: "5:30 PM",
                activity: "Relax by the Shoreline",
                description: "Enjoy the peaceful lake views and watch the changing colors of the evening sky."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Bring warm clothing even during summer.",
            "Wear comfortable shoes for outdoor activities.",
            "Carry drinking water and sun protection.",
            "Check transportation arrangements before traveling to the region.",
            "Respect wildlife and avoid disturbing natural habitats.",
            "Follow local guidance when visiting remote communities.",
            "Book accommodation in advance during the summer season.",
            "Keep the lake and surrounding environment clean."
        ]
    },

    // ===================================
    // 20. ERDENE ZUU MONASTERY
    // ===================================

    {
        name: "Erdene Zuu Monastery",
        country: "Mongolia",
        category: "History & Religious Tourism",
        image: "images/Erdene Zuu Monastery.jpg",
        budget: 65,
        featured: false,

        // 1. Overview
        description: "Erdene Zuu Monastery is one of Mongolia's oldest surviving Buddhist monasteries, located near the ancient city of Karakorum. Surrounded by impressive white stupas and traditional walls, the monastery is an important destination for understanding Mongolian Buddhism, architecture, and history. Visitors can explore its temples, discover religious artifacts, and experience the peaceful atmosphere of this historic site.",

        location: "Kharkhorin, Uvurkhangai Province, Mongolia.",

        history: "Erdene Zuu Monastery was established in 1586 by Abtai Sain Khan, one of the Mongolian leaders who helped introduce Tibetan Buddhism to Mongolia. It was constructed using materials from the nearby ruins of Karakorum, the former capital of the Mongol Empire. The monastery suffered serious damage during the religious purges of the 1930s, but parts of it survived and have since been restored as an important cultural heritage site.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Erdene Zuu Temple Complex",
                description: "Explore the historic monastery buildings and discover traditional Mongolian Buddhist architecture."
            },
            {
                name: "White Stupas",
                description: "Admire the impressive rows of white stupas surrounding the monastery walls."
            },
            {
                name: "Lavrin Temple",
                description: "Discover an important temple within the monastery complex and learn about its religious traditions."
            },
            {
                name: "Karakorum Historical Area",
                description: "Explore the nearby historical region associated with the ancient capital of the Mongol Empire."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Discover one of Mongolia's oldest surviving Buddhist monasteries.",
            "Learn about the history of Buddhism in Mongolia.",
            "Admire traditional Mongolian religious architecture.",
            "Explore a historic location connected to the Mongol Empire.",
            "Experience the peaceful atmosphere of an important cultural heritage site."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "May to September.",
            weather: "Summer generally provides warmer temperatures and comfortable conditions for exploring the monastery and surrounding historical sites. Spring and autumn can be cooler.",
            recommendation: "Visit during summer for pleasant sightseeing weather and opportunities to explore nearby historical attractions."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Discovering Mongolia's Buddhist Heritage",
            experience: "Walk through the historic monastery, admire its traditional temples and white stupas, and learn about the development of Buddhism in Mongolia.",
            culturalSignificance: "Erdene Zuu Monastery represents an important period in Mongolian religious history and reflects the influence of Tibetan Buddhism on Mongolian culture.",
            recommendation: "Combine your visit with the nearby Karakorum historical sites to better understand Mongolia's cultural and imperial past."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Transportation", cost: "$20 - $30" },
            { item: "Food and Drinks", cost: "$10 - $15" },
            { item: "Admission and Guided Tour", cost: "$10 - $15" },
            { item: "Other Expenses", cost: "$5 - $10" }
        ],
        budgetNote: "Estimated budget is approximately $45 - $70 per person, depending on transportation, entrance fees, and additional activities.",

        // 7. Transportation and Accommodation
        transportation: [
            "Travel from Ulaanbaatar to Kharkhorin by long-distance bus, private vehicle, or organized tour.",
            "Use local transportation or walk around the historical area to explore nearby attractions.",
            "Consider combining the monastery visit with a guided tour of the Orkhon Valley."
        ],

        accommodation: [
            "Stay in local guesthouses in Kharkhorin for convenient access to the monastery.",
            "Choose traditional ger camps for a cultural accommodation experience.",
            "Hotels and other accommodation options are available in nearby towns and along organized tour routes."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Arrive in Kharkhorin",
                description: "Begin your visit in the historic town near the former capital of the Mongol Empire."
            },
            {
                time: "9:00 AM",
                activity: "Explore Erdene Zuu Monastery",
                description: "Discover the historic temple complex and admire its traditional architecture."
            },
            {
                time: "10:30 AM",
                activity: "Visit the White Stupas",
                description: "Walk around the monastery walls and enjoy the beautiful rows of white stupas."
            },
            {
                time: "12:00 PM",
                activity: "Enjoy Traditional Mongolian Lunch",
                description: "Try local dishes and experience Mongolian hospitality."
            },
            {
                time: "1:30 PM",
                activity: "Discover the Historical Area",
                description: "Explore nearby historical landmarks connected to ancient Karakorum."
            },
            {
                time: "3:00 PM",
                activity: "Learn About Buddhist Heritage",
                description: "Discover more about Mongolia's religious traditions and the monastery's history."
            },
            {
                time: "4:30 PM",
                activity: "Enjoy the Surrounding Scenery",
                description: "Relax and appreciate the peaceful countryside before continuing your journey."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Dress respectfully when entering religious buildings.",
            "Check photography rules before taking pictures inside temples.",
            "Wear comfortable shoes for exploring the monastery grounds.",
            "Bring warm clothing because temperatures can change quickly.",
            "Respect monks, visitors, and religious ceremonies.",
            "Check opening hours and admission information before visiting.",
            "Consider hiring a local guide to learn more about the monastery's history.",
            "Keep the historical site clean and protect its cultural heritage."
        ]
    },

    // ===================================
    // V. TAIWAN
    // ===================================

    // ===================================
    // 21. TAIPEI 101
    // ===================================

    {
        name: "Taipei 101",
        country: "Taiwan",
        category: "Modern Architecture & City Landmark",
        image: "images/Taipei 101.jpg",
        budget: 75,
        featured: true,

        // 1. Overview
        description: "Taipei 101 is one of Taiwan's most famous landmarks and was once the tallest building in the world. Located in the heart of Taipei, this impressive skyscraper combines modern architecture, shopping, dining, and breathtaking city views.",

        // 2. Location
        location: "Xinyi District, Taipei, Taiwan",

        // 3. History
        history: "Taipei 101 was officially opened in 2004 and became an important symbol of Taiwan's economic growth and modern development. Its design was inspired by traditional Asian architecture and the shape of bamboo, representing strength, growth, and prosperity.",

        // 4. Attractions
        attractions: [
            {
                name: "Observation Deck",
                description: "Enjoy breathtaking panoramic views of Taipei from high above the city."
            },
            {
                name: "Outdoor Observatory",
                description: "Experience the open-air viewing area and admire the surrounding skyline."
            },
            {
                name: "Taipei 101 Mall",
                description: "Explore luxury shopping stores, restaurants, cafes, and entertainment."
            },
            {
                name: "Damper Baby",
                description: "Discover the famous tuned mass damper that helps stabilize the skyscraper during strong winds and earthquakes."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "See one of Taiwan's most recognizable architectural landmarks.",
            "Enjoy spectacular views of Taipei from the observation decks.",
            "Experience modern shopping and dining in a famous skyscraper.",
            "Learn about innovative engineering and earthquake protection.",
            "Capture beautiful photographs of the city skyline."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "October to April",
            weather: "Generally cooler and more comfortable for exploring Taipei.",
            recommendation: "Visit in the late afternoon to enjoy daylight views and watch the city lights appear after sunset."
        },

        // 7. Special Experience
        specialExperience: {
            title: "Skyline Experience at Taipei 101",
            experience: "Ride one of the world's fastest elevators to the observation deck and enjoy incredible views of Taipei.",
            culturalSignificance: "Taipei 101 represents Taiwan's modern identity, technological progress, and ambition.",
            recommendation: "Visit near sunset for a memorable view of the city during both day and night."
        },

        // 8. Budget Details
        budgetDetails: [
            {
                item: "Observation Deck Ticket",
                cost: "$20–25"
            },
            {
                item: "Food and Drinks",
                cost: "$15–20"
            },
            {
                item: "Transportation",
                cost: "$5–10"
            },
            {
                item: "Shopping and Extras",
                cost: "$15–20"
            }
        ],

        budgetNote: "Estimated budget is approximately $75 per person, depending on activities, shopping, and dining choices.",

        // 9. Transportation
        transportation: [
            "Take the Taipei Metro Red Line to Taipei 101/World Trade Center Station.",
            "Use local buses or taxis to reach the surrounding Xinyi District.",
            "Walk around the nearby shopping and entertainment areas."
        ],

        // 10. Accommodation
        accommodation: [
            "Luxury hotels in the Xinyi District for convenient access to Taipei 101.",
            "Mid-range hotels near Taipei City Hall and surrounding shopping areas.",
            "Budget hostels and guesthouses near metro stations throughout Taipei."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "9:00 AM",
                activity: "Arrive at Taipei 101",
                description: "Explore the impressive architecture and surrounding area."
            },
            {
                time: "10:00 AM",
                activity: "Visit the Observation Deck",
                description: "Enjoy panoramic views of Taipei from above."
            },
            {
                time: "11:30 AM",
                activity: "Explore Taipei 101 Mall",
                description: "Discover shopping stores and interesting attractions."
            },
            {
                time: "12:30 PM",
                activity: "Lunch",
                description: "Enjoy Taiwanese food at one of the nearby restaurants."
            },
            {
                time: "2:00 PM",
                activity: "Explore Xinyi District",
                description: "Visit nearby shopping streets and modern city attractions."
            },
            {
                time: "5:00 PM",
                activity: "Enjoy the Sunset",
                description: "Return to the observation area and admire the changing skyline."
            },
            {
                time: "7:00 PM",
                activity: "Evening City Views",
                description: "Take beautiful nighttime photographs of Taipei 101."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Book observation deck tickets in advance during busy seasons.",
            "Visit on a clear day for the best city views.",
            "Bring a camera or smartphone for photographs.",
            "Use the Taipei Metro for convenient transportation.",
            "Check the observation deck's opening hours before visiting.",
            "Wear comfortable shoes when exploring the surrounding district.",
            "Try local Taiwanese food at nearby restaurants.",
            "Allow extra time for shopping and sightseeing."
        ]
    },

    // ===================================
    // 22. JIUFEN OLD STREET
    // ===================================

    {
        name: "Jiufen Old Street",
        country: "Taiwan",
        category: "Culture & Traditional Streets",
        image: "images/Jiufen Old Street.jpg",
        budget: 55,
        featured: false,

        // 1. Overview
        description: "Jiufen Old Street is a charming mountain town in northern Taiwan, famous for its narrow alleyways, traditional teahouses, glowing red lanterns, and beautiful hillside scenery. Visitors can explore local shops, taste traditional Taiwanese snacks, and experience the town's unique atmosphere.",

        // 2. Location
        location: "Ruifang District, New Taipei City, Taiwan",

        // 3. History
        history: "Jiufen developed as a small settlement and later became an important gold-mining town during the late 19th and early 20th centuries. After the mining industry declined, its historic streets and traditional buildings became popular attractions, preserving the atmosphere of old Taiwan.",

        // 4. Attractions
        attractions: [
            {
                name: "Jiufen Old Street",
                description: "Walk through narrow traditional streets filled with local shops, snacks, and souvenirs."
            },
            {
                name: "A-Mei Teahouse",
                description: "Visit a famous traditional teahouse known for its beautiful architecture and lantern decorations."
            },
            {
                name: "Shengping Theater",
                description: "Discover a historic theater that reflects Jiufen's golden mining-era history."
            },
            {
                name: "Mountain and Ocean Viewpoints",
                description: "Enjoy scenic views of the surrounding mountains and the beautiful northern coastline."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Experience the charm of a traditional Taiwanese mountain town.",
            "Photograph beautiful red lanterns and historic alleyways.",
            "Taste famous Taiwanese street food and local desserts.",
            "Explore traditional teahouses and historic buildings.",
            "Enjoy peaceful mountain scenery and coastal views."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "October to April",
            weather: "Generally cooler weather, although Jiufen can be rainy and misty throughout the year.",
            recommendation: "Visit in the late afternoon and stay until evening to enjoy the glowing lanterns and atmospheric streets."
        },

        // 7. Special Experience
        specialExperience: {
            title: "Traditional Teahouse and Lantern Experience",
            experience: "Enjoy traditional Taiwanese tea inside a hillside teahouse while admiring the beautiful scenery and glowing red lanterns.",
            culturalSignificance: "Jiufen preserves the history of Taiwan's gold-mining communities and traditional mountain-town lifestyle.",
            recommendation: "Explore the old streets slowly, try local snacks, and enjoy the evening atmosphere."
        },

        // 8. Budget Details
        budgetDetails: [
            {
                item: "Food and Local Snacks",
                cost: "$10–15"
            },
            {
                item: "Tea and Drinks",
                cost: "$10–15"
            },
            {
                item: "Transportation",
                cost: "$10–15"
            },
            {
                item: "Shopping and Extras",
                cost: "$10–15"
            }
        ],

        budgetNote: "Estimated budget is approximately $55 per person, depending on transportation, food, and shopping choices.",

        // 9. Transportation
        transportation: [
            "Take a train from Taipei to Ruifang Station, then transfer to a local bus toward Jiufen.",
            "Use direct buses from Taipei to Jiufen for a convenient journey.",
            "Take a taxi or private car from nearby towns for a more flexible trip."
        ],

        // 10. Accommodation
        accommodation: [
            "Traditional guesthouses with mountain and ocean views in Jiufen.",
            "Small boutique hotels near Jiufen Old Street.",
            "Budget guesthouses and hotels in nearby Ruifang."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "9:00 AM",
                activity: "Travel to Jiufen",
                description: "Enjoy the scenic journey from Taipei to the mountain town."
            },
            {
                time: "10:30 AM",
                activity: "Explore Jiufen Old Street",
                description: "Walk through traditional alleyways and browse local shops."
            },
            {
                time: "12:00 PM",
                activity: "Taste Local Food",
                description: "Try Taiwanese snacks, taro balls, and traditional desserts."
            },
            {
                time: "1:30 PM",
                activity: "Visit A-Mei Teahouse",
                description: "Relax with traditional tea and admire the beautiful surroundings."
            },
            {
                time: "3:00 PM",
                activity: "Discover Historic Attractions",
                description: "Visit Shengping Theater and explore the town's history."
            },
            {
                time: "5:00 PM",
                activity: "Enjoy the Lantern Views",
                description: "Watch the streets glow as the red lanterns light up."
            },
            {
                time: "6:30 PM",
                activity: "Return to Taipei",
                description: "Travel back after enjoying a memorable day in Jiufen."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Bring an umbrella or raincoat because Jiufen often experiences rain.",
            "Wear comfortable shoes for walking on steep streets and stairs.",
            "Visit in the late afternoon to enjoy the lanterns after sunset.",
            "Carry some cash for small shops and street food.",
            "Try traditional taro balls and local Taiwanese snacks.",
            "Avoid weekends and public holidays if you prefer fewer crowds.",
            "Check the last bus schedule before returning to Taipei.",
            "Bring a camera to capture the beautiful mountain scenery."
        ]
    },

    // ===================================
    // 23. SUN MOON LAKE
    // ===================================

    {
        name: "Sun Moon Lake",
        country: "Taiwan",
        category: "Nature & Scenic Lake",
        image: "images/Sun Moon Lake.jpg",
        budget: 85,
        featured: false,

        // 1. Overview
        description: "Sun Moon Lake is one of Taiwan's most famous natural attractions, surrounded by green mountains, peaceful forests, and beautiful traditional villages. Visitors can enjoy boat rides, cycling, scenic viewpoints, and cultural experiences around this stunning freshwater lake.",

        // 2. Location
        location: "Yuchi Township, Nantou County, Taiwan",

        // 3. History
        history: "Sun Moon Lake has long been an important place for the Indigenous Thao people, who have lived in the surrounding region for generations. Its name comes from the lake's distinctive shape, with one side resembling the sun and the other resembling a crescent moon.",

        // 4. Attractions
        attractions: [
            {
                name: "Wenwu Temple",
                description: "Visit a beautiful temple overlooking the lake, known for its traditional Chinese architecture."
            },
            {
                name: "Ita Thao Village",
                description: "Explore a lakeside village famous for Indigenous Thao culture, local food, and traditional products."
            },
            {
                name: "Sun Moon Lake Ropeway",
                description: "Enjoy a cable car journey with spectacular aerial views of the lake and surrounding mountains."
            },
            {
                name: "Ci'en Pagoda",
                description: "Discover a historic pagoda on a hilltop offering panoramic views of the lake."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Admire one of Taiwan's most beautiful natural landscapes.",
            "Enjoy peaceful boat rides across the lake.",
            "Explore Indigenous Thao culture and local traditions.",
            "Experience scenic cycling routes along the lakeshore.",
            "Capture unforgettable photographs of mountains and water."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "October to April",
            weather: "Generally pleasant and comfortable, with cooler temperatures in the surrounding mountains.",
            recommendation: "Visit during the morning for peaceful lake views and clearer scenery."
        },

        // 7. Special Experience
        specialExperience: {
            title: "Sunrise and Lakeside Adventure",
            experience: "Watch the morning light reflect across the lake, enjoy a relaxing boat ride, or cycle along the scenic lakeside paths.",
            culturalSignificance: "Sun Moon Lake is closely connected to the history and cultural heritage of the Indigenous Thao people.",
            recommendation: "Combine a boat ride with a visit to Ita Thao Village to experience both nature and local culture."
        },

        // 8. Budget Details
        budgetDetails: [
            {
                item: "Boat Ride",
                cost: "$10–15"
            },
            {
                item: "Food and Drinks",
                cost: "$15–20"
            },
            {
                item: "Transportation",
                cost: "$25–30"
            },
            {
                item: "Activities and Extras",
                cost: "$15–20"
            }
        ],

        budgetNote: "Estimated budget is approximately $85 per person, depending on transportation, activities, and dining choices.",

        // 9. Transportation
        transportation: [
            "Take a bus from Taichung to Sun Moon Lake.",
            "Use local buses or boats to explore attractions around the lake.",
            "Rent a bicycle to enjoy the scenic cycling routes along the lakeshore."
        ],

        // 10. Accommodation
        accommodation: [
            "Lakeside resorts with beautiful water and mountain views.",
            "Mid-range hotels near Shuishe Visitor Center.",
            "Budget guesthouses and homestays in Ita Thao Village."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Arrive at Sun Moon Lake",
                description: "Enjoy the peaceful morning atmosphere and beautiful lake scenery."
            },
            {
                time: "9:00 AM",
                activity: "Visit Wenwu Temple",
                description: "Explore the traditional temple and admire its panoramic views."
            },
            {
                time: "10:30 AM",
                activity: "Enjoy a Boat Ride",
                description: "Travel across the lake and appreciate the surrounding mountains."
            },
            {
                time: "12:00 PM",
                activity: "Explore Ita Thao Village",
                description: "Taste local food and discover Indigenous Thao culture."
            },
            {
                time: "2:00 PM",
                activity: "Ride the Ropeway",
                description: "Enjoy spectacular views from above the lake."
            },
            {
                time: "4:00 PM",
                activity: "Cycling and Sightseeing",
                description: "Explore the lakeside paths and take beautiful photographs."
            },
            {
                time: "5:30 PM",
                activity: "Enjoy the Evening Scenery",
                description: "Relax beside the water and admire the peaceful mountain landscape."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Check the weather forecast before planning outdoor activities.",
            "Bring a light jacket because temperatures can be cooler near the lake.",
            "Book accommodation early during holidays and peak seasons.",
            "Try local food and traditional snacks in Ita Thao Village.",
            "Wear comfortable shoes for walking and cycling.",
            "Check boat and ropeway operating schedules before visiting.",
            "Bring a camera to capture the beautiful lake scenery.",
            "Allow enough time to explore the different areas around the lake."
        ]
    },

    // ===================================
    // 24. TAROKO NATIONAL PARK
    // ===================================

    {
        name: "Taroko National Park",
        country: "Taiwan",
        category: "Nature & Mountain Adventure",
        image: "images/Taroko National Park.jpg",
        budget: 90,
        featured: false,

        // 1. Overview
        description: "Taroko National Park is famous for its dramatic marble cliffs, deep river valleys, tunnels, waterfalls, and spectacular mountain scenery. Located in eastern Taiwan, it is known for the remarkable Taroko Gorge and its impressive natural landscapes.",

        // 2. Location
        location: "Hualien County, Eastern Taiwan",

        // 3. History
        history: "Taroko National Park was originally established in 1937 during Japanese rule and later re-established by Taiwan in 1986. The region is also closely connected to the Indigenous Truku people, whose culture and history are part of the area's heritage.",

        // 4. Attractions
        attractions: [
            {
                name: "Taroko Gorge",
                description: "Admire towering marble cliffs and the beautiful Liwu River flowing through the gorge."
            },
            {
                name: "Eternal Spring Shrine",
                description: "Discover a scenic shrine built into the mountainside near a cascading waterfall."
            },
            {
                name: "Swallow Grotto",
                description: "Explore dramatic rock formations and cliffside scenery along the gorge."
            },
            {
                name: "Qingshui Cliffs",
                description: "Enjoy breathtaking coastal views where steep mountains meet the Pacific Ocean."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Discover Taiwan's spectacular marble gorge landscapes.",
            "Enjoy impressive mountain, river, and waterfall scenery.",
            "Explore natural tunnels, cliffs, and scenic viewpoints.",
            "Learn about the cultural heritage of the Indigenous Truku people.",
            "Experience one of eastern Taiwan's most famous natural regions."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "October to April",
            weather: "Generally cooler and comfortable, although mountain weather can change quickly.",
            recommendation: "Check local weather and park access conditions before traveling, especially during periods of heavy rain or typhoons."
        },

        // 7. Special Experience
        specialExperience: {
            title: "Marble Gorge Adventure",
            experience: "Discover impressive marble cliffs, winding river valleys, and beautiful mountain scenery while exploring accessible park areas.",
            culturalSignificance: "The region reflects the natural heritage and Indigenous history of eastern Taiwan, particularly the Truku people.",
            recommendation: "Choose open and officially accessible trails, and follow all park safety notices."
        },

        // 8. Budget Details
        budgetDetails: [
            {
                item: "Transportation",
                cost: "$30–35"
            },
            {
                item: "Food and Drinks",
                cost: "$15–20"
            },
            {
                item: "Guided Activities",
                cost: "$20–25"
            },
            {
                item: "Other Expenses",
                cost: "$10–15"
            }
        ],

        budgetNote: "Estimated budget is approximately $90 per person, excluding accommodation and depending on transportation and activities.",

        // 9. Transportation
        transportation: [
            "Travel to Hualien by train from Taipei or other major Taiwanese cities.",
            "Use permitted local transportation or organized tours to reach accessible park areas.",
            "Check official park notices for road closures, shuttle services, and trail access before traveling."
        ],

        // 10. Accommodation
        accommodation: [
            "Hotels and guesthouses in Hualien City for convenient access to the region.",
            "Mid-range accommodation near scenic areas outside the park.",
            "Budget hostels and local guesthouses in Hualien."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Travel to Taroko Area",
                description: "Begin the journey from Hualien and check current park access conditions."
            },
            {
                time: "9:00 AM",
                activity: "Explore Taroko Gorge",
                description: "Admire the dramatic marble cliffs and river scenery from accessible viewpoints."
            },
            {
                time: "10:30 AM",
                activity: "Visit Eternal Spring Shrine Area",
                description: "Discover the famous shrine and surrounding mountain landscape if access is permitted."
            },
            {
                time: "12:00 PM",
                activity: "Lunch Break",
                description: "Enjoy a meal in an open and permitted dining area."
            },
            {
                time: "1:30 PM",
                activity: "Explore Accessible Scenic Areas",
                description: "Visit open viewpoints and trails according to current park safety notices."
            },
            {
                time: "3:30 PM",
                activity: "Enjoy Coastal Scenery",
                description: "If accessible, admire the spectacular Qingshui Cliffs and Pacific Ocean views."
            },
            {
                time: "5:00 PM",
                activity: "Return to Hualien",
                description: "Finish the sightseeing trip and return to the city."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Check official park announcements before your visit.",
            "Be aware that earthquakes, landslides, and heavy rain can affect access.",
            "Never enter closed trails, tunnels, or restricted areas.",
            "Wear comfortable walking shoes and suitable outdoor clothing.",
            "Bring drinking water and snacks for your journey.",
            "Check transportation schedules before leaving Hualien.",
            "Follow park safety instructions and warning signs.",
            "Allow extra travel time because mountain roads and access conditions can change."
        ]
    },

    // ===================================
    // 25. SHILIN NIGHT MARKET
    // ===================================

    {
        name: "Shilin Night Market",
        country: "Taiwan",
        category: "Food & Nightlife",
        image: "images/Shilin Night Market.jpg",
        budget: 40,
        featured: false,

        // 1. Overview
        description: "Shilin Night Market is one of Taipei's most famous and lively night markets, known for its delicious street food, shopping stalls, games, and exciting nighttime atmosphere. Visitors can experience Taiwanese food culture while exploring colorful streets filled with local vendors and entertainment.",

        // 2. Location
        location: "Shilin District, Taipei, Taiwan",

        // 3. History
        history: "Shilin Night Market developed around the traditional Shilin market area and became a popular gathering place for local residents and visitors. Over time, it grew into one of Taiwan's best-known night markets, representing the country's vibrant street-food and shopping culture.",

        // 4. Attractions
        attractions: [
            {
                name: "Street Food Stalls",
                description: "Discover a wide variety of Taiwanese snacks, grilled foods, desserts, and local specialties."
            },
            {
                name: "Traditional Shopping Stalls",
                description: "Browse clothing, accessories, souvenirs, and everyday products."
            },
            {
                name: "Entertainment Games",
                description: "Enjoy traditional night-market games and fun activities with friends and family."
            },
            {
                name: "Local Food Experiences",
                description: "Taste famous Taiwanese dishes such as oyster omelets, fried chicken, and bubble tea."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Experience Taiwan's famous night-market culture.",
            "Taste a wide variety of delicious Taiwanese street food.",
            "Explore colorful shops and local shopping stalls.",
            "Enjoy fun games and lively nighttime entertainment.",
            "Discover local traditions and everyday Taiwanese life."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "October to April",
            weather: "Generally cooler and more comfortable for walking around the outdoor market.",
            recommendation: "Visit after 6:00 PM when the market becomes lively with food stalls, shoppers, and evening entertainment."
        },

        // 7. Special Experience
        specialExperience: {
            title: "Taiwanese Night Market Food Adventure",
            experience: "Walk through the lively market, sample traditional Taiwanese snacks, enjoy bubble tea, and explore colorful shopping streets.",
            culturalSignificance: "Night markets are an important part of Taiwanese social life, bringing together food, shopping, entertainment, and local communities.",
            recommendation: "Bring friends or family and try several small dishes instead of choosing only one meal."
        },

        // 8. Budget Details
        budgetDetails: [
            {
                item: "Street Food",
                cost: "$15–20"
            },
            {
                item: "Drinks and Desserts",
                cost: "$5–10"
            },
            {
                item: "Transportation",
                cost: "$5"
            },
            {
                item: "Shopping and Games",
                cost: "$5–10"
            }
        ],

        budgetNote: "Estimated budget is approximately $40 per person, depending on food choices, shopping, and activities.",

        // 9. Transportation
        transportation: [
            "Take the Taipei Metro Tamsui-Xinyi Red Line to Jiantan Station.",
            "Walk from Jiantan Station to the night market entrance.",
            "Use local buses or taxis for convenient transportation from other parts of Taipei."
        ],

        // 10. Accommodation
        accommodation: [
            "Hotels near Jiantan Station for easy access to the night market.",
            "Mid-range hotels around Shilin District and nearby Taipei neighborhoods.",
            "Budget hostels and guesthouses near Taipei Metro stations."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "5:30 PM",
                activity: "Arrive at Shilin Night Market",
                description: "Explore the market entrance and enjoy the beginning of the evening atmosphere."
            },
            {
                time: "6:00 PM",
                activity: "Discover Street Food",
                description: "Try popular Taiwanese snacks and traditional local dishes."
            },
            {
                time: "7:00 PM",
                activity: "Explore Shopping Stalls",
                description: "Browse clothing, accessories, souvenirs, and local products."
            },
            {
                time: "8:00 PM",
                activity: "Enjoy Night Market Games",
                description: "Experience fun traditional games and entertainment."
            },
            {
                time: "8:30 PM",
                activity: "Taste Taiwanese Desserts",
                description: "Enjoy bubble tea, sweet treats, and refreshing drinks."
            },
            {
                time: "9:00 PM",
                activity: "Explore the Nightlife",
                description: "Walk through the colorful market streets and enjoy the lively atmosphere."
            },
            {
                time: "10:00 PM",
                activity: "End the Visit",
                description: "Finish the night with your favorite snacks before returning to your accommodation."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Visit in the evening for the liveliest atmosphere.",
            "Bring cash because some small vendors may not accept cards.",
            "Try famous Taiwanese street foods and local desserts.",
            "Share different dishes with friends to enjoy more food varieties.",
            "Keep your belongings secure in crowded areas.",
            "Wear comfortable shoes for walking around the market.",
            "Check individual stall opening hours before visiting.",
            "Bring a reusable bag for shopping and souvenirs."
        ]
    }
];
