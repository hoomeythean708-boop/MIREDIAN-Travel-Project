// ===================================
//  MIREDIAN - AFRICA
// ===================================

const africaDestinations = [

    //===================================
    // I. EGYPT
    // ===================================

    // ===================================
    // 1. PYRAMIDS OF GIZA
    // ===================================

    {
        name: "Pyramids of Giza",
        country: "Egypt",
        category: "Ancient History & Cultural Tourism",
        image: "images/Pyramids of Giza.jpg",
        budget: 100,
        featured: true,

        // 1. Overview
        description: "The Pyramids of Giza are among the world's most famous ancient monuments and one of Egypt's greatest historical treasures. Located on the Giza Plateau near Cairo, these remarkable structures were built as royal tombs for ancient Egyptian pharaohs and continue to amaze visitors with their enormous size, engineering, and mysterious history.",

        // 2. Location
        location: "Giza Plateau, Giza, near Cairo, Egypt.",

        // 3. History
        history: "The Pyramids of Giza were constructed during Egypt's Fourth Dynasty of the Old Kingdom, approximately 4,500 years ago. The three main pyramids were built for Pharaoh Khufu, Pharaoh Khafre, and Pharaoh Menkaure. The Great Pyramid of Khufu is the largest and is the only surviving Wonder of the Ancient World.",

        // 4. Top Attractions
        attractions: [
            {
                name: "Great Pyramid of Khufu",
                description: "Explore the largest pyramid at Giza, an extraordinary ancient structure built for Pharaoh Khufu."
            },
            {
                name: "Pyramid of Khafre",
                description: "Admire the second-largest pyramid, recognizable for the remaining casing stones near its summit."
            },
            {
                name: "Pyramid of Menkaure",
                description: "Discover the smallest of the three main pyramids, built for Pharaoh Menkaure."
            },
            {
                name: "Great Sphinx",
                description: "See the enormous limestone statue with the body of a lion and a human head, standing guard near the pyramids."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Witness one of the world's most extraordinary ancient monuments.",
            "Discover the fascinating civilization of ancient Egypt.",
            "Explore the only surviving Wonder of the Ancient World.",
            "Admire impressive ancient engineering and architecture.",
            "Experience unforgettable views of the pyramids and the Great Sphinx."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "Autumn and Winter",
            weather: "Generally cooler and more comfortable than the hot summer months.",
            recommendation: "October to April is ideal for exploring the pyramids and enjoying outdoor sightseeing."
        },

        // 7. Special Experiences
        specialExperience: {
            title: "Discover the Ancient Wonders of Egypt",
            experience: "Explore the Giza Plateau, admire the enormous pyramids, visit the Great Sphinx, and learn about the fascinating stories of ancient Egyptian kings.",
            culturalSignificance: "The pyramids represent the extraordinary engineering, religious beliefs, royal traditions, and architectural achievements of ancient Egyptian civilization.",
            recommendation: "Visit early in the morning with a knowledgeable local guide to learn about the pyramids' history and avoid the strongest afternoon heat."
        },

        // 8. Budget Details
        budgetDetails: [
            {
                item: "Accommodation",
                cost: "$30–$70 per night"
            },
            {
                item: "Food",
                cost: "$10–$20 per day"
            },
            {
                item: "Transportation",
                cost: "$10–$25"
            },
            {
                item: "Attractions",
                cost: "$15–$40"
            }
        ],

        budgetNote: "An estimated budget of $100 per person, excluding international flights. Actual expenses depend on accommodation, entrance tickets, guided tours, and optional activities.",

        // 9. Transportation
        transportation: [
            "Fly into Cairo International Airport, which serves the Giza and Cairo region.",
            "Take a taxi or ride-hailing service from Cairo to the Giza Plateau.",
            "Use licensed local guides or organized tours to explore the archaeological site."
        ],

        // 10. Accommodation
        accommodation: [
            "Stay in Giza for convenient access to the pyramids and nearby attractions.",
            "Choose a hotel with pyramid views for a memorable experience.",
            "Consider accommodation in central Cairo for access to museums, restaurants, and city attractions."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "7:00 AM",
                activity: "Arrive at the Giza Plateau",
                description: "Begin the day early and enjoy the impressive views of the ancient pyramids."
            },
            {
                time: "8:00 AM",
                activity: "Explore the Great Pyramid",
                description: "Discover the history and remarkable construction of the Pyramid of Khufu."
            },
            {
                time: "9:30 AM",
                activity: "Visit the Pyramid of Khafre",
                description: "Admire the second-largest pyramid and learn about Pharaoh Khafre."
            },
            {
                time: "10:30 AM",
                activity: "Discover the Great Sphinx",
                description: "See the famous limestone monument and learn about its historical significance."
            },
            {
                time: "12:00 PM",
                activity: "Traditional Egyptian Lunch",
                description: "Enjoy local Egyptian dishes at a nearby restaurant."
            },
            {
                time: "1:30 PM",
                activity: "Explore the Pyramid of Menkaure",
                description: "Visit the smallest of the three main pyramids and discover more ancient history."
            },
            {
                time: "3:00 PM",
                activity: "Panoramic Photography",
                description: "Enjoy the magnificent pyramid landscape and capture memorable photographs."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Visit early in the morning to avoid the strongest heat and larger crowds.",
            "Wear comfortable walking shoes for exploring the sandy archaeological site.",
            "Bring sunscreen, sunglasses, and a hat.",
            "Carry drinking water throughout your visit.",
            "Hire a licensed guide if you want to learn more about ancient Egyptian history.",
            "Check entrance fees and opening hours before visiting.",
            "Respect archaeological structures and follow visitor regulations.",
            "Agree on transportation and service prices in advance."
        ]
    },

    // ===================================
    // 2. KARNAK TEMPLE
    // ===================================

    {
        name: "Karnak Temple",
        country: "Egypt",
        category: "Ancient History & Religious Heritage",
        image: "images/Karnak Temple.jpg",
        budget: 90,
        featured: false,

        // 1. Overview
        description: "Karnak Temple is one of the largest and most impressive religious complexes of ancient Egypt. Located near Luxor, it features enormous stone columns, magnificent temples, towering obelisks, and detailed hieroglyphic carvings. Its remarkable architecture offers visitors a glimpse into the religious beliefs and achievements of ancient Egyptian civilization.",

        // 2. Location
        location: "East Bank of the Nile River, near Luxor, Upper Egypt.",

        // 3. History
        history: "Karnak Temple developed over more than 2,000 years, beginning around the Middle Kingdom. Successive pharaohs expanded the complex by constructing temples, monuments, and sacred structures. It became one of ancient Egypt's most important religious centers, particularly dedicated to the god Amun-Ra.",

        // 4. Top Attractions
        attractions: [
            {
                name: "Great Hypostyle Hall",
                description: "Explore an extraordinary hall containing 134 massive stone columns decorated with detailed ancient carvings."
            },
            {
                name: "Precinct of Amun-Ra",
                description: "Discover the main religious area dedicated to Amun-Ra, one of ancient Egypt's most important gods."
            },
            {
                name: "Sacred Lake",
                description: "Visit the large rectangular lake once used for religious purification ceremonies."
            },
            {
                name: "Obelisks of Hatshepsut",
                description: "Admire impressive ancient stone monuments erected during the reign of Queen Hatshepsut."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Discover one of the world's largest ancient religious complexes.",
            "Admire extraordinary columns, temples, and hieroglyphic carvings.",
            "Learn about ancient Egyptian gods and religious traditions.",
            "Explore monuments built by generations of Egyptian pharaohs.",
            "Experience the remarkable history of ancient Thebes."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "Autumn and Winter",
            weather: "Generally cooler and more comfortable for exploring the outdoor archaeological complex.",
            recommendation: "October to April is ideal for sightseeing, especially during the cooler morning hours."
        },

        // 7. Special Experiences
        specialExperience: {
            title: "Walk Through the Great Hypostyle Hall",
            experience: "Walk among enormous ancient columns, admire their detailed carvings, and discover the sacred spaces of one of Egypt's greatest temple complexes.",
            culturalSignificance: "Karnak was a major center of worship dedicated to Amun-Ra and reflects the religious beliefs, political power, and artistic achievements of ancient Egyptian society.",
            recommendation: "Consider joining a guided historical tour to understand the stories behind the temples, inscriptions, and monuments."
        },

        // 8. Budget Details
        budgetDetails: [
            {
                item: "Accommodation",
                cost: "$25–$60 per night"
            },
            {
                item: "Food",
                cost: "$10–$20 per day"
            },
            {
                item: "Transportation",
                cost: "$5–$15"
            },
            {
                item: "Attractions",
                cost: "$10–$30"
            }
        ],

        budgetNote: "An estimated budget of $90 per person, excluding international flights. Actual expenses depend on accommodation, entrance tickets, transportation, and guided tours.",

        // 9. Transportation
        transportation: [
            "Fly into Luxor International Airport or travel to Luxor by train from Cairo.",
            "Take a taxi or local transportation from Luxor city center to Karnak Temple.",
            "Consider an organized sightseeing tour to explore Karnak and other nearby historical landmarks."
        ],

        // 10. Accommodation
        accommodation: [
            "Stay in East Luxor for convenient access to Karnak Temple and other attractions.",
            "Choose a hotel near the Nile River for beautiful river views.",
            "Consider West Bank guesthouses for a quieter atmosphere near Luxor's archaeological sites."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "7:00 AM",
                activity: "Arrive at Karnak Temple",
                description: "Begin your visit early and enjoy the peaceful atmosphere of the ancient complex."
            },
            {
                time: "8:00 AM",
                activity: "Explore the Great Hypostyle Hall",
                description: "Walk among the enormous columns and admire their detailed hieroglyphic decorations."
            },
            {
                time: "9:30 AM",
                activity: "Visit the Precinct of Amun-Ra",
                description: "Discover the main temple area and learn about its religious importance."
            },
            {
                time: "10:30 AM",
                activity: "Discover the Sacred Lake",
                description: "Explore the historic lake and learn about its role in ancient religious ceremonies."
            },
            {
                time: "11:30 AM",
                activity: "Admire the Ancient Obelisks",
                description: "See the impressive stone monuments associated with Egypt's royal history."
            },
            {
                time: "12:30 PM",
                activity: "Egyptian Lunch",
                description: "Enjoy traditional Egyptian food at a nearby restaurant."
            },
            {
                time: "2:00 PM",
                activity: "Explore Luxor",
                description: "Continue discovering the city's historic atmosphere and beautiful Nile surroundings."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Visit early in the morning to avoid high temperatures.",
            "Wear comfortable shoes for walking across the large temple complex.",
            "Bring water, sunscreen, and a hat.",
            "Hire a knowledgeable guide to understand the temple's history.",
            "Take photographs while respecting site regulations.",
            "Check ticket prices and opening hours before visiting.",
            "Respect ancient monuments and avoid touching delicate carvings.",
            "Allow enough time to explore the enormous complex."
        ]
    },

    // ===================================
    // 3. VALLEY OF THE KINGS
    // ===================================

    {
        name: "Valley of the Kings",
        country: "Egypt",
        category: "Ancient History & Archaeological Heritage",
        image: "images/Valley of the Kings.jpg",
        budget: 110,
        featured: false,

        // 1. Overview
        description: "The Valley of the Kings is one of Egypt's most remarkable archaeological sites. Located on the west bank of the Nile near Luxor, it contains the richly decorated tombs of ancient Egyptian pharaohs and royal figures.",

        // 2. Location
        location: "West Bank of the Nile River, near Luxor, Egypt.",

        // 3. History
        history: "The Valley of the Kings served as a royal burial ground mainly during Egypt's New Kingdom period, from approximately the 16th to the 11th century BCE. Pharaohs were buried in hidden rock-cut tombs decorated with colorful paintings, hieroglyphics, and religious texts describing beliefs about the afterlife. Famous discoveries include the tomb of Tutankhamun.",

        // 4. Main Attractions
        attractions: [
            {
                name: "Tomb of Tutankhamun",
                description: "Visit the famous tomb of the young pharaoh whose burial treasures became one of the most celebrated archaeological discoveries in history. Entry may require a separate ticket."
            },
            {
                name: "Tomb of Ramesses VI",
                description: "Explore a beautifully decorated royal tomb featuring colorful ceilings and detailed scenes from ancient Egyptian religious texts."
            },
            {
                name: "Tomb of Seti I",
                description: "Discover one of the valley's most impressive tombs, known for its elaborate decorations. Access may depend on special ticket arrangements."
            },
            {
                name: "Royal Burial Valley",
                description: "Walk through the dramatic desert landscape and learn how ancient Egyptians created hidden burial places for their rulers."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Discover the burial place of ancient Egyptian pharaohs.",
            "See remarkable wall paintings and hieroglyphics.",
            "Learn about ancient Egyptian beliefs concerning the afterlife.",
            "Explore one of the world's most important archaeological sites.",
            "Experience the history and atmosphere of the Luxor West Bank."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "October to April",
            weather: "The cooler months offer more comfortable conditions for exploring the tombs and surrounding desert landscape.",
            recommendation: "Visit early in the morning to avoid the strongest afternoon heat and allow enough time to explore several tombs."
        },

        // 7. Special Experience
        specialExperience: {
            title: "Explore the Tombs of the Pharaohs",
            experience: "Enter selected ancient tombs and admire their colorful artwork, mysterious symbols, and detailed scenes depicting the journey into the afterlife.",
            culturalSignificance: "The tombs reveal the religious beliefs, burial traditions, artistic achievements, and royal history of ancient Egyptian civilization.",
            recommendation: "Choose your tomb visits in advance and check which tombs are open, as access and ticket arrangements can vary."
        },

        // 8. Estimated Budget
        budgetDetails: [
            {
                item: "Accommodation",
                cost: "$35 - $45"
            },
            {
                item: "Food and Drinks",
                cost: "$15 - $20"
            },
            {
                item: "Local Transportation",
                cost: "$15 - $20"
            },
            {
                item: "Entrance and Activities",
                cost: "$25 - $30"
            }
        ],

        budgetNote: "The estimated budget is approximately $110 per person for a short visit, excluding international flights. Actual costs depend on accommodation, transportation, ticket choices, and optional tomb access.",
        // 9. Transportation
        transportation: [
            "Fly to Luxor International Airport from Cairo or other available connecting destinations.",
            "Travel from Luxor's East Bank to the West Bank by ferry or road transport.",
            "Use a taxi, private driver, or organized tour to reach the Valley of the Kings."
        ],

        // 10. Accommodation
        accommodation: [
            "Budget guesthouses and hostels in Luxor.",
            "Comfortable hotels near the Nile River.",
            "Luxury resorts and hotels offering views of the river or surrounding landscapes."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "7:00 AM",
                activity: "Arrive at the Valley",
                description: "Start early and enjoy the peaceful desert surroundings before the busiest visiting hours."
            },
            {
                time: "8:00 AM",
                activity: "Explore the Royal Tombs",
                description: "Visit selected open tombs and admire their ancient decorations and historical details."
            },
            {
                time: "10:00 AM",
                activity: "Discover the Tomb of Tutankhamun",
                description: "Learn about the famous young pharaoh and his remarkable archaeological discovery, if you choose the additional entry ticket."
            },
            {
                time: "11:00 AM",
                activity: "Explore the Valley",
                description: "Walk through the archaeological landscape and learn more about royal burial traditions."
            },
            {
                time: "12:00 PM",
                activity: "Lunch and Rest",
                description: "Enjoy lunch and take a break after exploring the tombs."
            },
            {
                time: "1:00 PM",
                activity: "Visit Nearby Historical Sites",
                description: "Continue exploring the West Bank with a visit to nearby ancient monuments, depending on your schedule."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Visit early in the morning to avoid extreme heat.",
            "Wear comfortable walking shoes.",
            "Bring drinking water and sun protection.",
            "Check which tombs are open before your visit.",
            "Some famous tombs require separate entrance tickets.",
            "Follow photography rules because restrictions may apply inside certain tombs.",
            "Avoid touching ancient paintings and decorations.",
            "Respect the archaeological site and its preservation rules."
        ]
    },

    // ===================================
    // 4. ABU SIMBEL
    // ===================================

    {
        name: "Abu Simbel",
        country: "Egypt",
        category: "Ancient Monuments & Cultural Heritage",
        image: "images/Abu Simbel.jpg",
        budget: 160,
        featured: false,

        // 1. Overview
        description: "Abu Simbel is a spectacular archaeological site in southern Egypt, famous for its enormous rock-cut temples and colossal statues. Located beside Lake Nasser, it is one of the country's most impressive ancient landmarks.",

        // 2. Location
        location: "Abu Simbel, southern Egypt, near the border with Sudan.",

        // 3. History
        history: "The temples of Abu Simbel were built during the reign of Pharaoh Ramesses II in the 13th century BCE. The Great Temple was dedicated primarily to Ramesses II and several Egyptian gods, while the Small Temple honored Queen Nefertari and the goddess Hathor. In the 1960s and early 1970s, an international rescue project relocated the temples to higher ground to protect them from the rising waters of Lake Nasser after the construction of the Aswan High Dam.",

        // 4. Main Attractions
        attractions: [
            {
                name: "Great Temple of Ramesses II",
                description: "Admire the enormous rock-cut temple guarded by four seated statues of Ramesses II, each carved into the mountainside."
            },
            {
                name: "Small Temple of Nefertari",
                description: "Explore the beautiful temple dedicated to Queen Nefertari and the goddess Hathor, decorated with impressive royal statues."
            },
            {
                name: "Colossal Statues",
                description: "Discover the magnificent ancient statues that display the power, artistic skill, and royal image of Ramesses II."
            },
            {
                name: "Lake Nasser",
                description: "Enjoy the peaceful scenery around one of the world's largest artificial lakes, created by the Aswan High Dam."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "See some of Egypt's most impressive ancient temples.",
            "Learn about the achievements and legacy of Ramesses II.",
            "Discover the remarkable rescue and relocation of the temples.",
            "Admire extraordinary ancient Egyptian architecture and sculpture.",
            "Enjoy the beautiful desert and Lake Nasser scenery."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "October to April",
            weather: "The cooler months provide more comfortable temperatures for exploring the temples and surrounding desert.",
            recommendation: "Arrive early in the morning to enjoy the site before the strongest heat and larger visitor groups."
        },

        // 7. Special Experience
        specialExperience: {
            title: "Discover the Temples of Ramesses II",
            experience: "Walk through the monumental entrance, admire the ancient carvings, and explore the interiors decorated with colorful reliefs and religious scenes.",
            culturalSignificance: "Abu Simbel represents the political power, religious beliefs, artistic achievements, and engineering abilities of ancient Egypt. Its relocation also became an important example of international cooperation in cultural heritage preservation.",
            recommendation: "Consider joining an organized day trip from Aswan or staying overnight nearby to experience the temples at a quieter time."
        },

        // 8. Estimated Budget
        budgetDetails: [
            {
                item: "Accommodation",
                cost: "$45 - $55"
            },
            {
                item: "Food and Drinks",
                cost: "$20 - $25"
            },
            {
                item: "Local Transportation",
                cost: "$45 - $55"
            },
            {
                item: "Entrance and Activities",
                cost: "$25 - $30"
            }
        ],

        budgetNote: "The estimated budget is approximately $160 per person for a short visit, excluding international flights. Costs vary depending on transportation from Aswan, accommodation, and ticket arrangements.",
        // 9. Transportation
        transportation: [
            "Fly into Aswan International Airport from Cairo or another available connecting destination.",
            "Travel from Aswan to Abu Simbel by organized road transfer, private vehicle, or available domestic flight.",
            "Use local transport or an organized tour to explore the temple complex."
        ],

        // 10. Accommodation
        accommodation: [
            "Budget guesthouses and small hotels in Abu Simbel.",
            "Comfortable hotels near Lake Nasser.",
            "Hotels and resorts in Aswan for visitors taking a day trip to the temples."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "5:00 AM",
                activity: "Depart from Aswan",
                description: "Begin an early journey toward Abu Simbel by organized road transfer or another available transport option."
            },
            {
                time: "8:00 AM",
                activity: "Arrive at Abu Simbel",
                description: "Enjoy the dramatic desert scenery and approach the famous temple complex."
            },
            {
                time: "8:30 AM",
                activity: "Explore the Great Temple",
                description: "Admire the colossal statues and discover the history of Ramesses II."
            },
            {
                time: "10:00 AM",
                activity: "Visit the Small Temple",
                description: "Explore the temple dedicated to Queen Nefertari and the goddess Hathor."
            },
            {
                time: "11:00 AM",
                activity: "Enjoy Lake Nasser Views",
                description: "Take photographs and appreciate the beautiful landscape surrounding the temples."
            },
            {
                time: "12:00 PM",
                activity: "Lunch and Rest",
                description: "Enjoy a meal and take a short break before returning to Aswan or continuing your stay."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Plan transportation in advance because Abu Simbel is far from Aswan.",
            "Visit during the cooler months for a more comfortable experience.",
            "Wear comfortable walking shoes and lightweight clothing.",
            "Bring drinking water, sunscreen, and a hat.",
            "Check transportation schedules and temple opening hours before traveling.",
            "Respect photography rules inside the temples.",
            "Avoid touching ancient carvings and wall decorations.",
            "Allow enough travel time for the return journey to Aswan."
        ]
    },

    // ===================================
    // 5. EGYPTIAN MUSEUM
    // ===================================

    {
        name: "Egyptian Museum",
        country: "Egypt",
        category: "History & Museum Tourism",
        image: "images/Egyptian Museum.jpg",
        budget: 85,
        featured: false,

        // 1. Overview
        description: "The Egyptian Museum in Cairo is one of the most famous museums dedicated to ancient Egyptian civilization. Located in the historic Tahrir Square, it houses an extensive collection of statues, mummies, jewelry, pottery, and other archaeological treasures.",

        // 2. Location
        location: "Tahrir Square, Downtown Cairo, Egypt.",

        // 3. History
        history: "The Egyptian Museum officially opened in 1902 in a purpose-built building designed by French architect Marcel Dourgnon. It was established to preserve and display the extraordinary archaeological heritage of ancient Egypt. Its collections include artifacts from different periods of Egyptian history, although some famous objects have since been transferred to other museums, including the Grand Egyptian Museum.",

        // 4. Main Attractions
        attractions: [
            {
                name: "Ancient Royal Statues",
                description: "Discover impressive statues of pharaohs, queens, and important figures from different periods of ancient Egyptian history."
            },
            {
                name: "Ancient Egyptian Jewelry",
                description: "Admire beautifully crafted jewelry, ornaments, and precious objects that demonstrate the artistic skills of ancient Egyptian craftsmen."
            },
            {
                name: "Royal Mummies and Funerary Artifacts",
                description: "Explore selected preserved remains and burial objects that reveal ancient Egyptian beliefs and royal burial traditions. Specific displays may change."
            },
            {
                name: "Papyrus and Everyday Objects",
                description: "See ancient writing materials, pottery, tools, and household objects that offer insight into daily life along the Nile."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Discover thousands of years of ancient Egyptian history.",
            "See remarkable archaeological objects and royal artifacts.",
            "Learn about ancient Egyptian art, religion, and daily life.",
            "Explore one of Cairo's most historic cultural institutions.",
            "Understand how museums help preserve Egypt's cultural heritage."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "October to April",
            weather: "The cooler months are comfortable for exploring Cairo and combining a museum visit with other city attractions.",
            recommendation: "Visit in the morning when the museum opens to allow plenty of time to explore its collections."
        },

        // 7. Special Experience
        specialExperience: {
            title: "Journey Through Ancient Egyptian Civilization",
            experience: "Walk through the museum galleries and discover ancient statues, jewelry, funerary objects, and everyday items from different periods of Egyptian history.",
            culturalSignificance: "The museum preserves important evidence of ancient Egyptian civilization and helps visitors understand its achievements, traditions, beliefs, and artistic legacy.",
            recommendation: "Consider hiring a knowledgeable guide or using a museum guidebook to understand the stories behind important artifacts."
        },

        // 8. Estimated Budget
        budgetDetails: [
            {
                item: "Accommodation",
                cost: "$30 - $35"
            },
            {
                item: "Food and Drinks",
                cost: "$15 - $20"
            },
            {
                item: "Local Transportation",
                cost: "$10 - $15"
            },
            {
                item: "Entrance and Activities",
                cost: "$15 - $20"
            }
        ],
        budgetNote: "The estimated budget is approximately $85 per person for a short visit, excluding international flights. Actual costs depend on accommodation, museum ticket prices, transport, and optional guide services.",

        // 9. Transportation
        transportation: [
            "Fly into Cairo International Airport, which connects the city with international destinations.",
            "Use the Cairo Metro and get off at a nearby station serving the Tahrir Square area.",
            "Travel by taxi or ride-hailing service to reach the museum and other downtown attractions."
        ],

        // 10. Accommodation
        accommodation: [
            "Budget hostels and guesthouses in Downtown Cairo.",
            "Comfortable hotels near Tahrir Square and the Nile River.",
            "Luxury hotels offering views of the Nile and convenient access to major attractions."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "9:00 AM",
                activity: "Arrive at the Museum",
                description: "Begin your visit at the historic museum building in Tahrir Square."
            },
            {
                time: "9:30 AM",
                activity: "Explore Ancient Statues",
                description: "Discover impressive sculptures and representations of ancient Egyptian rulers and important figures."
            },
            {
                time: "10:30 AM",
                activity: "Discover Jewelry and Treasures",
                description: "Admire the craftsmanship of ancient jewelry, ornaments, and precious objects."
            },
            {
                time: "11:30 AM",
                activity: "Explore Funerary Collections",
                description: "Learn about burial traditions, religious beliefs, and selected funerary artifacts."
            },
            {
                time: "12:30 PM",
                activity: "Lunch and Rest",
                description: "Enjoy lunch at a nearby restaurant in Downtown Cairo."
            },
            {
                time: "1:30 PM",
                activity: "Explore Tahrir Square",
                description: "Take a walk around the historic square and enjoy the atmosphere of central Cairo."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Check current opening hours and entrance fees before visiting.",
            "Arrive early to give yourself enough time to explore.",
            "Wear comfortable shoes because the museum has many galleries.",
            "Bring a camera only if photography is permitted under current museum rules.",
            "Read exhibit descriptions to understand the historical background.",
            "Consider hiring a guide for a deeper cultural experience.",
            "Respect museum rules and avoid touching displayed artifacts.",
            "Remember that some famous collections are now displayed at other museums, including the Grand Egyptian Museum."
        ]
    },

    // ===================================
    // II. SOUTH AFRICA
    // ===================================

    // ===================================
    // 1. TABLE MOUNTAIN
    // ===================================

    {
        name: "Table Mountain",
        country: "South Africa",
        category: "Nature & Adventure Tourism",
        image: "images/Table Mountain.jpg",
        budget: 130,
        featured: true,

        // 1. Overview
        description: "Table Mountain is one of South Africa's most iconic natural landmarks. Famous for its flat-topped summit, dramatic cliffs, and breathtaking views, it overlooks Cape Town and the Atlantic Ocean.",

        // 2. Location
        location: "Cape Town, Western Cape, South Africa.",

        // 3. History
        history: "Table Mountain is an ancient natural formation shaped over millions of years through geological processes. It forms part of the Table Mountain National Park and is recognized as an important natural and cultural landmark. The mountain has long been significant to local communities and became a symbol of Cape Town and South Africa.",

        // 4. Main Attractions
        attractions: [
            {
                name: "Table Mountain Aerial Cableway",
                description: "Enjoy a scenic cable car journey to the summit, offering spectacular views of Cape Town and the surrounding coastline."
            },
            {
                name: "Table Mountain Summit",
                description: "Explore the famous flat-topped summit and admire panoramic views of the city, ocean, and nearby mountains."
            },
            {
                name: "Maclear's Beacon",
                description: "Visit the highest point of Table Mountain, marked by a historic stone cairn built by astronomer Thomas Maclear."
            },
            {
                name: "Platteklip Gorge",
                description: "Discover one of the best-known hiking routes to the summit, featuring steep paths and impressive mountain scenery."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Enjoy spectacular panoramic views of Cape Town.",
            "Experience one of South Africa's most famous natural landmarks.",
            "Explore beautiful hiking trails and unique mountain vegetation.",
            "Ride the aerial cableway for an unforgettable mountain journey.",
            "Discover the natural beauty of Table Mountain National Park."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "October to April",
            weather: "The warmer months generally offer pleasant conditions, although mountain weather can change quickly throughout the year.",
            recommendation: "Choose a clear, calm day for the best views and check cableway operating conditions before traveling."
        },

        // 7. Special Experience
        specialExperience: {
            title: "Ride Above Cape Town",
            experience: "Take the rotating aerial cable car to the summit, walk along scenic mountain paths, and enjoy unforgettable views over Cape Town and the Atlantic coastline.",
            culturalSignificance: "Table Mountain is a powerful symbol of Cape Town and forms part of a region with rich natural, geological, and cultural heritage. Its distinctive landscape and biodiversity make it internationally significant.",
            recommendation: "Visit early in the day when weather conditions are favorable, and allow extra time for exploring the summit."
        },

        // 8. Estimated Budget
        budgetDetails: [
            {
                item: "Accommodation",
                cost: "$45 - $50"
            },
            {
                item: "Food and Drinks",
                cost: "$20 - $25"
            },
            {
                item: "Local Transportation",
                cost: "$15 - $20"
            },
            {
                item: "Cableway and Activities",
                cost: "$35 - $40"
            }
        ],

        budgetNote: "The estimated budget is approximately $130 per person for a short visit, excluding international flights. Actual costs depend on accommodation, cableway ticket prices, transport, and optional activities.",

        // 9. Transportation
        transportation: [
            "Fly into Cape Town International Airport from domestic or international destinations.",
            "Travel from central Cape Town to the Lower Cableway Station by taxi, ride-hailing service, or tour transport.",
            "Use the aerial cableway or a suitable hiking route to reach the summit, depending on weather and operating conditions."
        ],

        // 10. Accommodation
        accommodation: [
            "Budget hostels and guesthouses in central Cape Town.",
            "Comfortable hotels near the city center and waterfront.",
            "Luxury hotels with mountain, city, or ocean views."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Arrive at Table Mountain",
                description: "Reach the Lower Cableway Station early and check weather and operating conditions."
            },
            {
                time: "9:00 AM",
                activity: "Ride the Aerial Cableway",
                description: "Enjoy the scenic cable car journey toward the mountain summit."
            },
            {
                time: "9:30 AM",
                activity: "Explore the Summit",
                description: "Walk along the paths and admire panoramic views of Cape Town."
            },
            {
                time: "10:30 AM",
                activity: "Visit Maclear's Beacon",
                description: "Explore the summit's highest point and learn about its history."
            },
            {
                time: "12:00 PM",
                activity: "Lunch and Rest",
                description: "Enjoy refreshments while taking in the spectacular mountain scenery."
            },
            {
                time: "1:00 PM",
                activity: "Return to Cape Town",
                description: "Take the cableway back down when operating conditions allow and continue exploring the city."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Check the weather forecast before planning your visit.",
            "Check cableway operating status because strong winds may cause closures.",
            "Wear comfortable walking shoes.",
            "Bring a jacket because summit temperatures can be cooler.",
            "Carry drinking water and sun protection.",
            "Stay on marked paths and follow park safety instructions.",
            "Book cableway tickets in advance when possible.",
            "Allow extra time in case weather conditions affect your schedule."
        ]
    },

    // ===================================
// 2. KRUGER NATIONAL PARK
// ===================================

    {
        name: "Kruger National Park",
        country: "South Africa",
        category: "Wildlife & Safari Tourism",
        image: "images/Kruger National Park.jpg",
        budget: 180,
        featured: false,

        // 1. Overview
        description: "Kruger National Park is one of Africa's largest and most famous wildlife reserves. It offers incredible safari experiences, diverse landscapes, and opportunities to observe elephants, lions, leopards, rhinos, and buffalo in their natural habitats.",

        // 2. Location
        location: "Northeastern South Africa, across parts of Limpopo and Mpumalanga provinces.",

        // 3. History
        history: "Kruger National Park was officially established in 1926 by combining the former Sabie and Shingwedzi game reserves. Its origins go back to the late 19th century, when efforts were made to protect South Africa's wildlife. Today, it forms part of the Great Limpopo Transfrontier Park conservation area.",

        // 4. Main Attractions
        attractions: [
            {
                name: "Big Five Wildlife",
                description: "Look for lions, leopards, elephants, rhinoceroses, and African buffalo during guided or self-drive safari experiences."
            },
            {
                name: "Skukuza Rest Camp",
                description: "Visit one of the park's main camps, offering accommodation, restaurants, visitor services, and access to wildlife viewing routes."
            },
            {
                name: "Crocodile Bridge",
                description: "Explore the southern entrance area, known for wildlife viewing opportunities and access to nearby safari routes."
            },
            {
                name: "Olifants River Viewpoint",
                description: "Enjoy scenic views over the Olifants River and surrounding landscapes, where animals may gather near the water."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Experience an unforgettable African safari.",
            "Observe diverse wildlife in natural surroundings.",
            "Discover one of Africa's most important conservation areas.",
            "Enjoy beautiful savannas, rivers, and woodland landscapes.",
            "Learn about wildlife protection and environmental conservation."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "May to September",
            weather: "The dry winter season generally offers pleasant daytime temperatures and thinner vegetation, which can make wildlife easier to spot.",
            recommendation: "Visit during the early morning or late afternoon when many animals are active. Wildlife sightings are never guaranteed."
        },

        // 7. Special Experience
        specialExperience: {
            title: "African Big Five Safari",
            experience: "Join a guided game drive or explore approved self-drive routes to observe elephants, lions, leopards, rhinos, and buffalo in their natural environment.",
            culturalSignificance: "Kruger National Park is internationally important for biodiversity conservation and wildlife protection. It also reflects the complex history of conservation and land use in the region.",
            recommendation: "Choose a guided safari with an experienced ranger for a safer and more informative wildlife experience."
        },

        // 8. Estimated Budget
        budgetDetails: [
            {
                item: "Accommodation",
                cost: "$60 - $70"
            },
            {
                item: "Food and Drinks",
                cost: "$25 - $30"
            },
            {
                item: "Local Transportation",
                cost: "$35 - $40"
            },
            {
                item: "Safari and Activities",
                cost: "$40 - $45"
            }
        ],

        budgetNote: "The estimated budget is approximately $180 per person for a short visit, excluding international flights. Costs vary depending on accommodation, park fees, vehicle arrangements, and guided safari activities.",
        // 9. Transportation
        transportation: [
            "Fly into Kruger Mpumalanga International Airport or another suitable regional airport.",
            "Rent a vehicle or arrange a transfer to reach the park's entrance gates.",
            "Use approved park roads for self-drive wildlife viewing or join guided safari vehicles."
        ],

        // 10. Accommodation
        accommodation: [
            "Budget campsites and basic accommodation inside or near the park.",
            "Comfortable rest camps and lodges with convenient safari access.",
            "Luxury private safari lodges offering guided wildlife experiences."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "5:30 AM",
                activity: "Early Morning Safari",
                description: "Begin the day with a guided game drive when many animals are active."
            },
            {
                time: "8:00 AM",
                activity: "Breakfast at the Camp",
                description: "Enjoy breakfast and take a short break at a designated rest camp."
            },
            {
                time: "9:00 AM",
                activity: "Wildlife Exploration",
                description: "Travel along approved routes and look for elephants, giraffes, zebras, and other wildlife."
            },
            {
                time: "12:00 PM",
                activity: "Lunch and Rest",
                description: "Stop at an approved camp or picnic area for lunch and relaxation."
            },
            {
                time: "2:30 PM",
                activity: "Afternoon Safari",
                description: "Continue exploring the park with opportunities to observe animals near rivers and open grasslands."
            },
            {
                time: "5:00 PM",
                activity: "Return to Camp",
                description: "Return before the applicable gate closing time and enjoy a relaxing evening."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Book accommodation and safari activities in advance.",
            "Bring binoculars and a camera with a zoom lens.",
            "Wear comfortable clothing in neutral colors.",
            "Carry drinking water, sunscreen, and insect repellent.",
            "Never leave your vehicle outside designated areas.",
            "Keep a safe distance from wild animals.",
            "Follow park speed limits and gate closing times.",
            "Respect wildlife and never feed or disturb animals."
        ]
    },

    // ===================================
    // 3. BOULDERS BEACH
    // ===================================

    {
        name: "Boulders Beach",
        country: "South Africa",
        category: "Wildlife & Coastal Tourism",
        image: "images/Boulders Beach.jpg",
        budget: 120,
        featured: false,

        // 1. Overview
        description: "Boulders Beach is a beautiful coastal destination near Cape Town, famous for its sheltered sandy beaches, enormous granite boulders, and colony of African penguins. Visitors can enjoy scenic ocean views while observing these charming birds in their natural habitat.",

        // 2. Location
        location: "Simon's Town, Cape Peninsula, Western Cape, South Africa.",

        // 3. History
        history: "Boulders Beach became internationally known for its African penguin colony, which established itself in the area during the 1980s. The beach is part of Table Mountain National Park and is protected to support penguin conservation and preserve the surrounding coastal environment.",

        // 4. Main Attractions
        attractions: [
            {
                name: "African Penguin Colony",
                description: "Observe African penguins from designated viewing areas and learn about their behavior and conservation."
            },
            {
                name: "Boulders Beach",
                description: "Enjoy the sheltered sandy beach surrounded by large granite boulders and clear coastal waters."
            },
            {
                name: "Penguin Viewing Boardwalks",
                description: "Walk along wooden pathways that provide excellent views of penguins without disturbing their habitat."
            },
            {
                name: "Foxy Beach",
                description: "Explore another nearby penguin-viewing area with boardwalks and beautiful coastal scenery."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "See African penguins in their natural coastal habitat.",
            "Enjoy beautiful beaches and unique granite rock formations.",
            "Learn about marine wildlife and conservation efforts.",
            "Take memorable photographs of the coastline and wildlife.",
            "Experience one of Cape Town's most distinctive nature attractions."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "November to March",
            weather: "The summer months generally offer warmer weather and pleasant conditions for enjoying the coast.",
            recommendation: "Visit in the morning for a quieter experience, and remember that penguin sightings and activity can vary throughout the year."
        },

        // 7. Special Experience
        specialExperience: {
            title: "Meet the African Penguins",
            experience: "Walk along designated boardwalks to observe African penguins swimming, resting, and moving around their protected colony.",
            culturalSignificance: "Boulders Beach is an important conservation area for the endangered African penguin and highlights the importance of protecting South Africa's coastal biodiversity.",
            recommendation: "Follow wildlife guidelines carefully and enjoy watching the penguins from designated viewing areas."
        },

        // 8. Estimated Budget
        budgetDetails: [
            {
                item: "Accommodation",
                cost: "$40 - $45"
            },
            {
                item: "Food and Drinks",
                cost: "$20 - $25"
            },
            {
                item: "Local Transportation",
                cost: "$30 - $35"
            },
            {
                item: "Entrance and Activities",
                cost: "$15 - $20"
            }
        ],

        budgetNote: "The estimated budget is approximately $120 per person for a short visit, excluding international flights. Actual expenses depend on accommodation, transport, entrance fees, and personal activities.",

        // 9. Transportation
        transportation: [
            "Fly into Cape Town International Airport.",
            "Travel from Cape Town to Simon's Town by rental car, taxi, or organized tour.",
            "Use local transport or walk from Simon's Town to reach the Boulders Beach entrance."
        ],
        // 10. Accommodation
        accommodation: [
            "Budget guesthouses and hostels in Simon's Town.",
            "Comfortable hotels and seaside guesthouses near False Bay.",
            "Luxury coastal accommodation around Cape Town and the Cape Peninsula."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "9:00 AM",
                activity: "Arrive at Boulders Beach",
                description: "Begin your visit and enjoy the beautiful coastal scenery."
            },
            {
                time: "9:30 AM",
                activity: "Visit the Penguin Boardwalks",
                description: "Walk along the designated pathways and observe the African penguin colony."
            },
            {
                time: "10:30 AM",
                activity: "Explore Boulders Beach",
                description: "Enjoy the sandy beach and admire the impressive granite formations."
            },
            {
                time: "11:30 AM",
                activity: "Wildlife Photography",
                description: "Capture photographs of the coastline and penguins while maintaining a respectful distance."
            },
            {
                time: "12:30 PM",
                activity: "Lunch and Rest",
                description: "Enjoy lunch at a nearby café or restaurant in Simon's Town."
            },
            {
                time: "2:00 PM",
                activity: "Explore Simon's Town",
                description: "Take a relaxing walk through this historic coastal town before continuing your journey."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Visit early to enjoy a quieter atmosphere.",
            "Bring sunscreen, sunglasses, and a hat.",
            "Wear comfortable walking shoes.",
            "Bring a camera or binoculars for wildlife observation.",
            "Never touch, feed, or approach the penguins.",
            "Stay on designated boardwalks and viewing paths.",
            "Check current entrance fees and opening hours before visiting.",
            "Help protect the beach by keeping the environment clean."
        ]
    },

    // ===================================
    // 4. CAPE OF GOOD HOPE
    // ===================================

    {
        name: "Cape of Good Hope",
        country: "South Africa",
        category: "Coastal Nature & Adventure Tourism",
        image: "images/Cape of Good Hope.jpg",
        budget: 140,
        featured: false,

        // 1. Overview
        description: "The Cape of Good Hope is a spectacular rocky headland located within Table Mountain National Park. Famous for its dramatic cliffs, ocean views, and rich biodiversity, it is one of South Africa's most memorable coastal destinations.",

        // 2. Location
        location: "Cape Peninsula, southwest of Cape Town, Western Cape, South Africa.",

        // 3. History
        history: "The Cape of Good Hope became an important landmark during the Age of Exploration. Portuguese navigator Bartolomeu Dias rounded the nearby cape in 1488 and originally named it the Cape of Storms. It was later renamed by King John II of Portugal. The area has a long maritime history and remains an important natural heritage site.",

        // 4. Main Attractions
        attractions: [
            {
                name: "Cape Point",
                description: "Explore the dramatic cliffs and enjoy panoramic views of the Atlantic Ocean from one of the peninsula's most famous viewpoints."
            },
            {
                name: "Cape of Good Hope Sign",
                description: "Visit the famous landmark sign and take photographs surrounded by beautiful coastal scenery."
            },
            {
                name: "Old Lighthouse",
                description: "Discover the historic lighthouse above Cape Point, accessible by a scenic walking route or funicular."
            },
            {
                name: "Dias Beach",
                description: "Enjoy the breathtaking coastline and admire the dramatic cliffs surrounding this beautiful beach."
            }
        ],

        // 5. Reasons to Visit
        reasons: [
            "Experience one of South Africa's most famous coastal landmarks.",
            "Enjoy breathtaking ocean views and dramatic cliffs.",
            "Explore beautiful hiking trails and natural landscapes.",
            "Discover the region's maritime exploration history.",
            "Observe wildlife and unique coastal vegetation."
        ],

        // 6. Best Time to Visit
        bestTime: {
            season: "October to April",
            weather: "The warmer months generally offer pleasant conditions for outdoor exploration, although strong coastal winds can occur.",
            recommendation: "Choose a clear day for scenic views and begin your visit early to explore the peninsula comfortably."
        },

        // 7. Special Experience
        specialExperience: {
            title: "Explore the Southern Cape Peninsula",
            experience: "Walk along scenic coastal paths, admire the towering cliffs, visit the famous Cape of Good Hope sign, and enjoy the spectacular views around Cape Point.",
            culturalSignificance: "The Cape of Good Hope is an important landmark in the history of maritime exploration and forms part of a protected natural area with exceptional biodiversity.",
            recommendation: "Take a scenic drive through the Cape Peninsula and allow time for both Cape Point and the Cape of Good Hope."
        },

        // 8. Estimated Budget
        budgetDetails: [
            {
                item: "Accommodation",
                cost: "$45 - $50"
            },
            {
                item: "Food and Drinks",
                cost: "$20 - $25"
            },
            {
                item: "Local Transportation",
                cost: "$40 - $45"
            },
            {
                item: "Entrance and Activities",
                cost: "$20 - $25"
            }
        ],

        budgetNote: "The estimated budget is approximately $140 per person for a short visit, excluding international flights. Actual expenses depend on accommodation, park entrance fees, transport, and optional activities.",

        // 9. Transportation
        transportation: [
            "Fly into Cape Town International Airport.",
            "Rent a car, hire a private driver, or join an organized Cape Peninsula tour from Cape Town.",
            "Use the park's designated roads and parking areas to reach Cape Point and the Cape of Good Hope."
        ],

        // 10. Accommodation
        accommodation: [
            "Budget hostels and guesthouses in Cape Town.",
            "Comfortable hotels and guesthouses in Simon's Town.",
            "Luxury coastal accommodation around the Cape Peninsula."
        ],

        // 11. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Depart from Cape Town",
                description: "Begin a scenic journey along the Cape Peninsula toward the national park."
            },
            {
                time: "9:30 AM",
                activity: "Arrive at Cape Point",
                description: "Explore the spectacular coastal landscape and enjoy the ocean views."
            },
            {
                time: "10:30 AM",
                activity: "Visit the Old Lighthouse",
                description: "Walk or take the funicular toward the historic lighthouse viewpoint."
            },
            {
                time: "11:30 AM",
                activity: "Explore Cape of Good Hope",
                description: "Visit the famous sign and admire the dramatic cliffs and surrounding scenery."
            },
            {
                time: "12:30 PM",
                activity: "Lunch and Rest",
                description: "Enjoy lunch and relax while taking in the beautiful natural surroundings."
            },
            {
                time: "2:00 PM",
                activity: "Scenic Coastal Drive",
                description: "Enjoy the return journey with opportunities to stop at other scenic viewpoints."
            }
        ],

        // 12. Travel Tips
        tips: [
            "Check national park opening hours and entrance fees before visiting.",
            "Bring a jacket because coastal winds can be strong.",
            "Wear comfortable walking shoes.",
            "Carry drinking water, sunscreen, and a hat.",
            "Stay behind safety barriers near cliffs.",
            "Watch for wildlife and never feed wild animals.",
            "Allow enough time to explore Cape Point and the surrounding area.",
            "Respect nature and take all rubbish with you."
        ]
    },

    // ===================================
// 5. ROBBEN ISLAND
// ===================================

{
    name: "Robben Island",
    country: "South Africa",
    category: "History & Cultural Heritage Tourism",
    image: "images/Robben Island.jpg",
    budget: 150,
    featured: false,

    // 1. Overview
    description: "Robben Island is a historic island off the coast of Cape Town, internationally recognized for its role in South Africa's struggle against apartheid. It is best known as the place where Nelson Mandela and other political prisoners were incarcerated. Today, it serves as a museum and UNESCO World Heritage Site.",

    // 2. Location
    location: "Table Bay, approximately 7 kilometers off the coast of Cape Town, Western Cape, South Africa.",

    // 3. History
    history: "Robben Island has served different purposes throughout its history, including as a prison, hospital, and military facility. During apartheid, it became a prison for political opponents of the government. Nelson Mandela spent 18 of his 27 years in prison there. The island became a UNESCO World Heritage Site in 1999 in recognition of its significance in the struggle for democracy and human rights.",

    // 4. Main Attractions
    attractions: [
        {
            name: "Nelson Mandela's Prison Cell",
            description: "Visit the small cell where Nelson Mandela was imprisoned and learn about his experiences during his years of incarceration."
        },
        {
            name: "Maximum Security Prison",
            description: "Explore the former prison complex and discover the conditions experienced by political prisoners."
        },
        {
            name: "Robben Island Museum",
            description: "Learn about the island's history, apartheid, political resistance, and the journey toward democracy in South Africa."
        },
        {
            name: "Island Landscapes",
            description: "Enjoy views of the ocean, Cape Town, and the surrounding natural environment during the island visit."
        }
    ],

    // 5. Reasons to Visit
    reasons: [
        "Learn about Nelson Mandela and South Africa's struggle for freedom.",
        "Discover an important chapter in the history of apartheid.",
        "Explore a UNESCO World Heritage Site.",
        "Understand the importance of equality, justice, and human rights.",
        "Experience a meaningful historical tour led by knowledgeable guides."
    ],

    // 6. Best Time to Visit
    bestTime: {
        season: "October to April",
        weather: "The warmer months generally provide pleasant conditions for visiting Cape Town and taking a ferry to the island, although sea conditions can change.",
        recommendation: "Book an early ferry tour and check departure information because trips may be affected by weather."
    },

    // 7. Special Experience
    specialExperience: {
        title: "Discover the Story of Freedom",
        experience: "Take a ferry from Cape Town to Robben Island, explore the former prison, and learn about the experiences of political prisoners through a guided historical tour.",
        culturalSignificance: "Robben Island represents the struggle against apartheid and the importance of human dignity, equality, reconciliation, and democracy.",
        recommendation: "Listen carefully to the guides and allow time to reflect on the stories and historical experiences shared during the visit."
    },

    // 8. Estimated Budget
    budgetDetails: [
        {
            item: "Accommodation",
            cost: "$50 - $55"
        },
        {
            item: "Food and Drinks",
            cost: "$20 - $25"
        },
        {
            item: "Local Transportation",
            cost: "$15 - $20"
        },
        {
            item: "Ferry Tour and Entrance",
            cost: "$50 - $55"
        }
    ],

    budgetNote: "The estimated budget is approximately $150 per person for a short visit, excluding international flights. Actual costs depend on accommodation, ferry tour prices, and personal expenses.",
    // 9. Transportation
    transportation: [
        "Fly into Cape Town International Airport.",
        "Travel to the Nelson Mandela Gateway at the V&A Waterfront in Cape Town.",
        "Take an authorized ferry service to Robben Island as part of an organized museum tour."
    ],

    // 10. Accommodation
    accommodation: [
        "Budget hostels and guesthouses in central Cape Town.",
        "Comfortable hotels near the V&A Waterfront.",
        "Luxury hotels with views of Table Bay and the surrounding coastline."
    ],

    // 11. Suggested Itinerary
    itinerary: [
        {
            time: "8:00 AM",
            activity: "Arrive at the V&A Waterfront",
            description: "Reach the Nelson Mandela Gateway and prepare for your scheduled ferry departure."
        },
        {
            time: "9:00 AM",
            activity: "Ferry Journey",
            description: "Enjoy the boat journey across Table Bay toward Robben Island."
        },
        {
            time: "10:00 AM",
            activity: "Explore the Island",
            description: "Discover important historical locations and learn about the island's past."
        },
        {
            time: "11:00 AM",
            activity: "Visit the Former Prison",
            description: "Explore the prison complex and hear stories about political prisoners."
        },
        {
            time: "12:00 PM",
            activity: "Learn About Nelson Mandela",
            description: "Visit the area associated with Mandela's imprisonment and reflect on his journey."
        },
        {
            time: "1:00 PM",
            activity: "Return to Cape Town",
            description: "Take the ferry back to the waterfront and enjoy the rest of the afternoon."
        }
    ],

    // 12. Travel Tips
    tips: [
        "Book ferry tours in advance, especially during busy travel seasons.",
        "Check ferry schedules and weather conditions before departure.",
        "Arrive early at the Nelson Mandela Gateway.",
        "Wear comfortable walking shoes.",
        "Bring sunscreen, water, and a light jacket.",
        "Follow the museum guide's instructions throughout the tour.",
        "Be respectful when visiting historical prison areas.",
        "Allow enough time for the complete ferry and museum experience."
    ]
}
];