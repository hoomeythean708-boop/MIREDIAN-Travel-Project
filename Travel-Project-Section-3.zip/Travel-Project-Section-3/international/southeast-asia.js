// ===================================
// MIREDIAN - SOUTHEAST ASIA DESTINATIONS
// ===================================

const southeastAsiaDestinations = [

    // ===================================
    // I. MALAYSIA 
    // ===================================

     // ===================================
    // 1. PETRONAS TWIN TOWERS
    // ===================================

    {
        name: "Petronas Twin Towers",
        country: "Malaysia",
        category: "City & Architecture",
        image: "images/Petronas Twin Towers.jpg",
        budget: 80,
        featured: true,

        // 1. Overview
        description:
            "The Petronas Twin Towers are iconic skyscrapers located in Kuala Lumpur, Malaysia. Standing at 452 meters, they are famous for their impressive modern architecture and breathtaking city views.",

        location: "Kuala Lumpur",

        history:
            "Completed in 1998, the Petronas Twin Towers were once the tallest buildings in the world. Designed by architect César Pelli, they represent Malaysia's economic development, modern identity, and architectural achievements.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Skybridge",
                description:
                    "Visit the connecting bridge between the two towers and enjoy views of Kuala Lumpur from above."
            },
            {
                name: "Observation Deck",
                description:
                    "Experience panoramic views of the city from the observation deck on the upper floors."
            },
            {
                name: "KLCC Park",
                description:
                    "Relax in the beautiful landscaped park surrounding the towers, with walking paths and fountains."
            },
            {
                name: "Suria KLCC",
                description:
                    "Explore the shopping mall located beneath the towers, featuring shops, restaurants, and entertainment."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "See one of Malaysia's most famous architectural landmarks.",
            "Enjoy spectacular panoramic views of Kuala Lumpur.",
            "Experience modern Malaysian culture and city life.",
            "Take memorable photographs of the iconic twin skyscrapers.",
            "Explore nearby shopping, dining, and recreational attractions."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "May to July and December to February",
            weather:
                "Kuala Lumpur has a tropical climate with warm temperatures and rainfall throughout the year.",
            recommendation:
                "Visit in the late afternoon or evening to enjoy the city views and see the towers illuminated at night."
        },

        // 5. Special Experience
        specialExperience: {
            title: "A Sky-High Kuala Lumpur Experience",
            experience:
                "Walk across the famous Skybridge, explore the observation deck, and admire the impressive Kuala Lumpur skyline.",
            culturalSignificance:
                "The Petronas Twin Towers symbolize Malaysia's modernization, national pride, and ambition to become an important global destination.",
            recommendation:
                "Book observation deck tickets in advance and arrive early for your scheduled visit."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Observation Deck Admission", cost: "Varies by ticket type" },
            { item: "Local Transportation", cost: "$3–$10" },
            { item: "Food and Drinks", cost: "$5–$15" },
            { item: "Shopping and Personal Expenses", cost: "$10–$30" }
        ],

        budgetNote:
            "Estimated daily spending is approximately $30–$80 per person, depending on activities, meals, and shopping. Accommodation is not included.",

        // 7. Transportation and Accommodation
        transportation: [
            "Take the Kuala Lumpur Light Rail Transit (LRT) to KLCC Station.",
            "Use taxis or ride-hailing services such as Grab.",
            "Walk from nearby hotels and attractions in the KLCC area."
        ],

        accommodation: [
            "Luxury hotels around Kuala Lumpur City Centre.",
            "Mid-range hotels near KLCC and Bukit Bintang.",
            "Budget hostels and guesthouses in central Kuala Lumpur."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "9:00 AM",
                activity: "Explore Suria KLCC",
                description:
                    "Visit the shopping mall and enjoy breakfast or coffee."
            },
            {
                time: "11:00 AM",
                activity: "Visit the Observation Deck",
                description:
                    "Discover the Skybridge and enjoy panoramic views of Kuala Lumpur."
            },
            {
                time: "1:00 PM",
                activity: "Lunch at KLCC",
                description:
                    "Try Malaysian food at one of the nearby restaurants."
            },
            {
                time: "3:00 PM",
                activity: "Relax at KLCC Park",
                description:
                    "Walk around the park and enjoy the surrounding architecture."
            },
            {
                time: "7:00 PM",
                activity: "Enjoy the Night View",
                description:
                    "Photograph the illuminated Petronas Twin Towers and enjoy the evening atmosphere."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Book observation deck tickets in advance.",
            "Check visiting hours and ticket availability before your trip.",
            "Bring a camera or smartphone for photographs.",
            "Wear comfortable walking shoes.",
            "Carry an umbrella because rain can occur throughout the year.",
            "Use public transportation to avoid heavy city traffic."
        ]
    },

    // ===================================
    // 2. BATU CAVES
    // ===================================

    {
        name: "Batu Caves",
        country: "Malaysia",
        category: "Cultural & Historical",
        image: "images/Batu Caves.jpg",
        budget: 35,
        featured: false,

        // 1. Overview
        description:
            "Batu Caves is a famous limestone hill and Hindu religious site located near Kuala Lumpur, Malaysia. It is known for its colorful staircase, impressive golden statue, ancient caves, and beautiful natural surroundings.",

        location: "Gombak, Selangor",

        history:
            "Batu Caves is believed to have formed around 400 million years ago. The site became an important Hindu place of worship in the late 19th century after Indian trader K. Thamboosamy Pillai helped establish a temple dedicated to Lord Murugan. Today, it is one of Malaysia's most recognized cultural and religious landmarks.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Rainbow Staircase",
                description:
                    "Climb the famous 272 colorful steps leading to the main cave and enjoy views of the surrounding landscape."
            },
            {
                name: "Lord Murugan Statue",
                description:
                    "Admire the enormous golden statue of Lord Murugan standing at the entrance to Batu Caves."
            },
            {
                name: "Temple Cave",
                description:
                    "Explore the large limestone cave containing Hindu shrines, religious sculptures, and impressive natural formations."
            },
            {
                name: "Dark Cave",
                description:
                    "Discover the natural environment of a limestone cave known for its unique rock formations and cave wildlife. Access and tours may vary."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Experience one of Malaysia's most important Hindu religious landmarks.",
            "Admire the colorful staircase and impressive golden statue.",
            "Explore ancient limestone caves and natural formations.",
            "Learn about Hindu traditions and Malaysian cultural diversity.",
            "Enjoy beautiful photography opportunities."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "May to September",
            weather:
                "The area has a tropical climate with warm temperatures, high humidity, and rainfall throughout the year.",
            recommendation:
                "Visit early in the morning to avoid the strongest afternoon heat and larger crowds."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Discover Hindu Culture and Sacred Caves",
            experience:
                "Climb the colorful staircase, explore the Temple Cave, admire Hindu religious sculptures, and experience the peaceful atmosphere of this sacred site.",
            culturalSignificance:
                "Batu Caves is an important center of Hindu worship in Malaysia and is especially significant during the annual Thaipusam festival, when thousands of devotees and visitors gather at the site.",
            recommendation:
                "Dress respectfully, follow temple guidelines, and be prepared to climb 272 steps."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Main Temple Cave Admission", cost: "Free" },
            { item: "Local Transportation", cost: "$3–$10" },
            { item: "Food and Drinks", cost: "$5–$12" },
            { item: "Optional Cave Activities", cost: "Varies" }
        ],

        budgetNote:
            "Estimated daily spending is approximately $10–$35 per person, depending on transportation, meals, and optional activities. Accommodation is not included.",

        // 7. Transportation and Accommodation
        transportation: [
            "Take the KTM Komuter train to Batu Caves Station.",
            "Use taxis or ride-hailing services such as Grab from Kuala Lumpur.",
            "Travel by local bus services connecting nearby areas."
        ],

        accommodation: [
            "Hotels in central Kuala Lumpur with convenient transport connections.",
            "Mid-range hotels around Gombak and nearby neighborhoods.",
            "Budget hostels and guesthouses in Kuala Lumpur."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Arrive at Batu Caves",
                description:
                    "Begin your visit early and admire the golden Lord Murugan statue."
            },
            {
                time: "9:00 AM",
                activity: "Climb the Rainbow Staircase",
                description:
                    "Walk up the 272 colorful steps and enjoy views of the surrounding area."
            },
            {
                time: "10:00 AM",
                activity: "Explore Temple Cave",
                description:
                    "Discover Hindu shrines, religious sculptures, and impressive limestone formations."
            },
            {
                time: "11:30 AM",
                activity: "Explore the Surroundings",
                description:
                    "Take photographs, learn about the site's cultural importance, and visit nearby areas."
            },
            {
                time: "12:30 PM",
                activity: "Enjoy Local Food",
                description:
                    "Try Malaysian and Indian-inspired dishes at nearby restaurants."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Wear comfortable shoes because there are 272 steps to climb.",
            "Dress modestly when visiting religious areas.",
            "Bring drinking water and stay hydrated.",
            "Visit early to avoid heat and crowds.",
            "Keep personal belongings secure around monkeys.",
            "Avoid feeding or disturbing the wildlife.",
            "Check festival schedules and visitor guidelines before traveling."
        ]
    },

    // ===================================
    // 3. LANGKAWI
    // ===================================

    {
        name: "Langkawi",
        country: "Malaysia",
        category: "Island & Natural",
        image: "images/Langkawi Island.jpg",
        budget: 75,
        featured: false,

        // 1. Overview
        description:
            "Langkawi is a beautiful tropical archipelago located in the Andaman Sea, off the northwest coast of Malaysia. It is famous for its sandy beaches, turquoise waters, green mountains, waterfalls, and relaxing island atmosphere.",

        location: "Kedah",

        history:
            "Langkawi has a rich history influenced by Malay traditions, maritime trade, and local legends. The archipelago became an important tourist destination after receiving UNESCO Global Geopark recognition in 2007 for its remarkable geological heritage.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Langkawi Sky Bridge",
                description:
                    "Walk across an impressive curved pedestrian bridge suspended above the rainforest, offering breathtaking mountain and sea views."
            },
            {
                name: "Pantai Cenang",
                description:
                    "Relax on one of Langkawi's most popular beaches, known for its soft sand, restaurants, and beautiful sunsets."
            },
            {
                name: "Kilim Karst Geoforest Park",
                description:
                    "Explore mangrove forests, limestone formations, and diverse wildlife through guided boat tours."
            },
            {
                name: "Seven Wells Waterfall",
                description:
                    "Discover a beautiful natural waterfall surrounded by tropical rainforest and natural pools."
            },
            {
                name: "Eagle Square",
                description:
                    "Visit the famous landmark featuring a large eagle statue overlooking the waterfront in Kuah."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Enjoy beautiful tropical beaches and clear blue waters.",
            "Experience breathtaking views from the Langkawi Sky Bridge.",
            "Explore mangrove forests and unique geological landscapes.",
            "Discover waterfalls and peaceful natural surroundings.",
            "Enjoy island activities, local seafood, and relaxing sunsets."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "November to April",
            weather:
                "Langkawi has a tropical climate with warm temperatures throughout the year. The drier season generally offers more suitable conditions for outdoor activities.",
            recommendation:
                "Visit between November and April for beach activities, island hopping, and sightseeing with generally less rainfall."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Island Adventure and Sky-High Views",
            experience:
                "Take a cable car ride up Gunung Mat Cincang, walk across the Langkawi Sky Bridge, explore mangrove forests, and enjoy the beautiful beaches.",
            culturalSignificance:
                "Langkawi reflects Malaysia's natural heritage, local Malay culture, maritime traditions, and conservation efforts. Its UNESCO Global Geopark status highlights the importance of protecting its geological and ecological landscapes.",
            recommendation:
                "Plan a full day for sightseeing and outdoor activities, and take a boat tour to discover the surrounding islands and mangroves."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$15–$35" },
            { item: "Local Transportation", cost: "$5–$15" },
            { item: "Food and Drinks", cost: "$8–$15" },
            { item: "Cable Car and Sky Bridge", cost: "Varies by ticket type" },
            { item: "Island Activities", cost: "$10–$25" }
        ],

        budgetNote:
            "Estimated daily spending is approximately $50–$75 per person, depending on accommodation, transportation, meals, and activities.",
            // 7. Transportation and Accommodation
        transportation: [
            "Fly to Langkawi International Airport from selected Malaysian cities.",
            "Use taxis or ride-hailing services such as Grab where available.",
            "Rent a car or motorbike to explore the island.",
            "Take local boat tours for island hopping and mangrove exploration."
        ],

        accommodation: [
            "Beachfront resorts around Pantai Cenang.",
            "Mid-range hotels in Kuah and nearby coastal areas.",
            "Budget guesthouses and hostels around Pantai Cenang.",
            "Private villas and nature retreats in quieter parts of the island."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Explore Pantai Cenang",
                description:
                    "Start the day with a relaxing walk along the beach and enjoy breakfast near the sea."
            },
            {
                time: "10:00 AM",
                activity: "Visit the SkyCab and Sky Bridge",
                description:
                    "Take the cable car up the mountain and admire spectacular views from the Sky Bridge."
            },
            {
                time: "1:00 PM",
                activity: "Enjoy Local Seafood",
                description:
                    "Have lunch at a local restaurant and experience Malaysian island cuisine."
            },
            {
                time: "3:00 PM",
                activity: "Explore Kilim Geoforest Park",
                description:
                    "Discover mangrove forests, limestone cliffs, and wildlife during a guided boat tour."
            },
            {
                time: "6:00 PM",
                activity: "Watch the Sunset",
                description:
                    "Return to Pantai Cenang and enjoy a beautiful sunset by the beach."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Visit during the drier season for better outdoor conditions.",
            "Book popular cable car and island tours in advance.",
            "Bring sunscreen, sunglasses, and comfortable walking shoes.",
            "Carry drinking water during outdoor activities.",
            "Consider renting a vehicle to explore different parts of the island.",
            "Respect marine life and avoid leaving rubbish on beaches.",
            "Check boat tour and weather conditions before departure."
        ]
    },

    // ===================================
    // 4. GEORGE TOWN, PENANG
    // ===================================

    {
        name: "George Town, Penang",
        country: "Malaysia",
        category: "Cultural & Historical",
        image: "images/George Town.jpg",
        budget: 65,
        featured: false,

        // 1. Overview
        description:
            "George Town is the historic capital of Penang, Malaysia, known for its colonial architecture, traditional shophouses, colorful street art, multicultural communities, and famous local food. It is one of Southeast Asia's most fascinating heritage destinations.",

        location: "Penang Island",

        history:
            "George Town was established as a British trading settlement in 1786 by Captain Francis Light. Over time, it developed into an important port influenced by Malay, Chinese, Indian, and European cultures. In 2008, George Town was recognized as a UNESCO World Heritage Site for its outstanding historic architecture and multicultural heritage.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Armenian Street",
                description:
                    "Explore a historic street filled with traditional buildings, local shops, cafes, and famous street art."
            },
            {
                name: "Khoo Kongsi",
                description:
                    "Visit an impressive Chinese clanhouse decorated with detailed carvings, traditional architecture, and cultural artwork."
            },
            {
                name: "Pinang Peranakan Mansion",
                description:
                    "Discover the lifestyle, traditions, furniture, and decorative objects of the historic Peranakan community."
            },
            {
                name: "Cheong Fatt Tze Blue Mansion",
                description:
                    "Admire the famous blue historic mansion, recognized for its distinctive architecture and cultural history."
            },
            {
                name: "Penang Street Art",
                description:
                    "Discover creative murals and interactive street artworks that reflect the history and everyday life of George Town."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Explore a UNESCO World Heritage Site with remarkable historic architecture.",
            "Experience the multicultural heritage of Malaysia.",
            "Discover traditional streets, temples, and historic mansions.",
            "Enjoy famous Penang street food and local specialties.",
            "Take photographs of colorful murals and beautiful heritage buildings."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "December to February",
            weather:
                "George Town has a tropical climate with warm temperatures, high humidity, and rainfall throughout the year.",
            recommendation:
                "Visit during the relatively drier months and explore the historic streets in the morning or late afternoon to avoid the strongest heat."
        },

        // 5. Special Experience
        specialExperience: {
            title: "A Journey Through Multicultural Heritage",
            experience:
                "Walk through historic streets, admire traditional architecture, discover colorful street art, visit heritage mansions, and taste authentic Penang street food.",
            culturalSignificance:
                "George Town represents centuries of cultural exchange between Malay, Chinese, Indian, and European communities. Its historic buildings, religious landmarks, and traditional neighborhoods demonstrate the multicultural identity of Malaysia.",
            recommendation:
                "Explore the heritage district on foot and consider joining a guided walking tour to learn more about the city's history and architecture."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Heritage Attractions and Museums", cost: "$5–$15" },
            { item: "Local Transportation", cost: "$3–$10" },
            { item: "Food and Drinks", cost: "$8–$15" },
            { item: "Shopping and Personal Expenses", cost: "$5–$20" }
        ],

        budgetNote:
        "Estimated daily spending is approximately $30–$65 per person, depending on accommodation, meals, transportation, and activities. Accommodation costs may vary.",

        // 7. Transportation and Accommodation
        transportation: [
            "Fly to Penang International Airport and travel to George Town.",
            "Use local buses operated by Rapid Penang to explore the island.",
            "Use taxis or ride-hailing services such as Grab.",
            "Walk or rent a bicycle to explore the historic city center."
        ],

        accommodation: [
            "Heritage boutique hotels inside George Town's historic district.",
            "Mid-range hotels around Georgetown and nearby shopping areas.",
            "Budget hostels and guesthouses near Armenian Street.",
            "Luxury hotels along the waterfront and nearby coastal areas."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Explore Armenian Street",
                description:
                    "Begin the day by walking through the historic streets and discovering local cafes and traditional buildings."
            },
            {
                time: "10:00 AM",
                activity: "Visit Khoo Kongsi",
                description:
                    "Admire the detailed architecture and learn about the history of Chinese clan communities."
            },
            {
                time: "12:00 PM",
                activity: "Enjoy Penang Street Food",
                description:
                    "Try local specialties such as char kway teow, assam laksa, and other traditional dishes."
            },
            {
                time: "2:00 PM",
                activity: "Visit the Peranakan Mansion",
                description:
                    "Discover the cultural traditions and historical lifestyle of the Peranakan community."
            },
            {
                time: "4:00 PM",
                activity: "Discover Street Art",
                description:
                    "Explore famous murals and take photographs around George Town's heritage streets."
            },
            {
                time: "6:00 PM",
                activity: "Enjoy the Evening Atmosphere",
                description:
                    "Relax at a local cafe or explore the city's evening food and cultural scene."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Wear comfortable walking shoes for exploring the historic district.",
            "Visit popular street art locations early to avoid crowds.",
            "Bring sunscreen and drinking water.",
            "Try local food from reputable food stalls and restaurants.",
            "Respect religious sites and traditional cultural practices.",
            "Carry some cash for small shops and street food vendors.",
            "Consider joining a guided heritage walking tour."
        ]
    },

    // ===================================
    // 5. MOUNT KINABALU
    // ===================================

    {
        name: "Mount Kinabalu",
        country: "Malaysia",
        category: "Nature & Adventure",
        image: "images/Mount Kinabalu.jpg",
        budget: 150,
        featured: false,

        // 1. Overview
        description:
            "Mount Kinabalu is the highest mountain in Malaysia, located in Sabah on the island of Borneo. Standing at approximately 4,095 meters above sea level, it is famous for its dramatic granite peaks, rich biodiversity, cool mountain climate, and breathtaking natural scenery.",

        location: "Sabah, Malaysian Borneo",

        history:
            "Mount Kinabalu has long been an important natural and cultural landmark for local communities, especially the Indigenous Kadazan-Dusun people. Kinabalu Park was established in 1964 to protect the mountain's unique ecosystems and was recognized as a UNESCO World Heritage Site in 2000.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Mount Kinabalu Summit",
                description:
                    "Experience a challenging mountain climb toward the summit and enjoy spectacular views above the clouds."
            },
            {
                name: "Kinabalu Park",
                description:
                    "Explore a UNESCO World Heritage Site known for its remarkable biodiversity, mountain landscapes, and walking trails."
            },
            {
                name: "Poring Hot Springs",
                description:
                    "Relax in natural hot spring pools surrounded by tropical rainforest."
            },
            {
                name: "Canopy Walkway",
                description:
                    "Walk along elevated suspension bridges and observe the rainforest from above."
            },
            {
                name: "Kundasang",
                description:
                    "Visit a beautiful mountain town known for its cool climate, scenic valleys, farms, and views of Mount Kinabalu."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Discover Malaysia's highest mountain and its remarkable landscapes.",
            "Experience one of Southeast Asia's most famous mountain adventures.",
            "Explore a UNESCO World Heritage Site with exceptional biodiversity.",
            "Enjoy cool mountain weather and beautiful natural scenery.",
            "Learn about the cultural importance of Mount Kinabalu to local communities."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "February to April",
            weather:
                "Mount Kinabalu has cooler temperatures at higher elevations, while the surrounding lower areas are tropical and humid. Weather conditions can change quickly, especially near the summit.",
            recommendation:
                "Consider climbing during the relatively drier months, but always check official weather conditions and park advisories before planning a trip."
        },

        // 5. Special Experience
        specialExperience: {
            title: "A Mountain Journey Above the Clouds",
            experience:
                "Join an organized climb through mountain forests, experience the changing landscapes, and watch the sunrise from the upper slopes when weather conditions allow.",
            culturalSignificance:
                "Mount Kinabalu is deeply respected by the Kadazan-Dusun people and holds an important place in local cultural traditions. Its name and surrounding heritage reflect the mountain's significance to communities in Sabah.",
            recommendation:
                "Book an authorized climbing package in advance, follow your mountain guide's instructions, and prepare for cold temperatures at higher elevations."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Climbing Permit and Park Fees", cost: "Varies by visitor category" },
            { item: "Mountain Guide and Climbing Package", cost: "$80–$150+" },
            { item: "Accommodation", cost: "$20–$60" },
            { item: "Food and Drinks", cost: "$10–$20" },
            { item: "Local Transportation", cost: "$10–$25" }
        ],

        budgetNote:
        "Estimated spending can range from approximately $150–$300 or more per person for a climbing trip, depending on permits, guide services, accommodation, meals, and package arrangements. Confirm current official fees before traveling.",

        // 7. Transportation and Accommodation
        transportation: [
            "Fly to Kota Kinabalu International Airport in Sabah.",
            "Travel by road from Kota Kinabalu to Kinabalu Park.",
            "Use organized tour transportation for climbing arrangements.",
            "Use local taxis or ride-hailing services where available."
        ],

        accommodation: [
            "Mountain lodges and guesthouses near Kinabalu Park.",
            "Hotels and resorts in Kundasang.",
            "Official mountain accommodation for registered climbers, subject to availability.",
            "Hotels in Kota Kinabalu for visitors exploring the wider Sabah region."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Arrive at Kinabalu Park",
                description:
                    "Explore the park headquarters, learn about the mountain environment, and prepare for your adventure."
            },
            {
                time: "10:00 AM",
                activity: "Discover Mountain Nature",
                description:
                    "Enjoy selected walking trails and observe the diverse plants and wildlife around the park."
            },
            {
                time: "12:00 PM",
                activity: "Lunch in Kundasang",
                description:
                    "Enjoy a meal while taking in the beautiful mountain scenery."
            },
            {
                time: "2:00 PM",
                activity: "Explore Poring Hot Springs",
                description:
                    "Relax in the hot spring area or explore the surrounding rainforest attractions."
            },
            {
                time: "4:00 PM",
                activity: "Enjoy Kundasang Views",
                description:
                    "Visit scenic viewpoints and photograph the mountain landscape."
            },
            {
                time: "Next Morning",
                activity: "Begin Authorized Mountain Climb",
                description:
                    "Registered climbers follow their official climbing schedule with an authorized guide. A summit climb requires a separate multi-day arrangement."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Reserve climbing permits and accommodation well in advance.",
            "Use an authorized mountain guide for climbing activities.",
            "Prepare warm clothing because summit temperatures can be very cold.",
            "Bring suitable hiking boots and rain protection.",
            "Carry sufficient water and follow your guide's instructions.",
            "Check weather conditions and park announcements before climbing.",
            "Respect local cultural traditions and protected natural environments.",
            "Choose a suitable fitness preparation plan before attempting the climb."
        ]
        },

    // ===================================
    // II. INDONESIA
    // ===================================

    // ===================================
    // 6. BOROBUDUR TEMPLE
    // ===================================

    {
        name: "Borobudur Temple",
        country: "Indonesia",
        category: "Historical & Cultural",
        image: "images/Borobudur Temple.jpg",
        budget: 50,
        featured: true,

        // 1. Overview
        description:
            "Borobudur Temple is a magnificent Buddhist monument located in Central Java, Indonesia. Famous for its impressive stone architecture, detailed carvings, and peaceful atmosphere, it is one of Southeast Asia's most remarkable historical landmarks.",

        location: "Magelang, Central Java",

        history:
            "Borobudur was built during the 8th and 9th centuries under the Sailendra dynasty. The monument reflects the development of Mahayana Buddhism in ancient Java and was later rediscovered in the 19th century. It became a UNESCO World Heritage Site in 1991.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Main Temple Structure",
                description:
                    "Explore the impressive multi-level stone monument, designed to represent the Buddhist path toward enlightenment."
            },
            {
                name: "Stone Relief Panels",
                description:
                    "Discover thousands of detailed carvings illustrating Buddhist teachings, stories, and everyday life in ancient Java."
            },
            {
                name: "Buddha Statues",
                description:
                    "Observe the numerous Buddha statues placed throughout the temple's terraces and upper levels."
            },
            {
                name: "Central Stupa",
                description:
                    "Admire the large central stupa surrounded by smaller bell-shaped stupas at the monument's highest level."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Discover one of the world's most important Buddhist monuments.",
            "Explore remarkable ancient stone architecture and carvings.",
            "Learn about Indonesia's religious and cultural heritage.",
            "Enjoy beautiful views of the surrounding landscapes.",
            "Experience a UNESCO World Heritage Site."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "May to September",
            weather:
                "Central Java has a tropical climate with warm temperatures throughout the year. The dry season generally provides better conditions for outdoor sightseeing.",
            recommendation:
                "Visit early in the morning to enjoy cooler temperatures and a more peaceful atmosphere."
        },

        // 5. Special Experience
        specialExperience: {
            title: "A Journey Through Ancient Buddhist Heritage",
            experience:
                "Walk through the temple's different levels, admire the detailed stone reliefs, observe the Buddha statues, and appreciate the impressive central stupa.",
            culturalSignificance:
                "Borobudur represents the religious, artistic, and architectural achievements of ancient Java. It remains an important Buddhist pilgrimage destination and a symbol of Indonesia's cultural heritage.",
            recommendation:
                "Wear comfortable walking shoes, respect religious traditions, and check the official visitor rules before exploring the monument."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Temple Admission", cost: "Varies by ticket type" },
            { item: "Local Transportation", cost: "$5–$15" },
            { item: "Food and Drinks", cost: "$5–$12" },
            { item: "Guide Services", cost: "Varies" },
            { item: "Personal Expenses", cost: "$5–$10" }
        ],

        budgetNote:
        "Estimated daily spending is approximately $25–$50 per person, depending on admission tickets, transportation, meals, and activities. Accommodation is not included.",

        // 7. Transportation and Accommodation
        transportation: [
            "Travel by road from Yogyakarta to Borobudur.",
            "Use taxis or ride-hailing services where available.",
            "Join organized tours from Yogyakarta.",
            "Use local buses connecting nearby towns."
        ],

        accommodation: [
            "Hotels and resorts near Borobudur.",
            "Mid-range hotels in Magelang.",
            "Budget guesthouses and homestays in nearby villages.",
            "Hotels in Yogyakarta for visitors exploring Central Java."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "7:00 AM",
                activity: "Arrive at Borobudur",
                description:
                    "Begin your visit early and enjoy the peaceful surroundings of the temple."
            },
            {
                time: "8:00 AM",
                activity: "Explore the Temple Levels",
                description:
                    "Discover the impressive architecture, Buddha statues, and stone terraces."
            },
            {
                time: "10:00 AM",
                activity: "Admire the Stone Reliefs",
                description:
                    "Learn about Buddhist stories and ancient Javanese life through the detailed carvings."
            },
            {
                time: "12:00 PM",
                activity: "Enjoy Local Food",
                description:
                    "Try traditional Indonesian dishes at a nearby restaurant."
            },
            {
                time: "2:00 PM",
                activity: "Explore the Surrounding Area",
                description:
                    "Discover nearby villages, local culture, and beautiful countryside views."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Check ticket availability and visiting rules before your trip.",
            "Wear comfortable shoes for walking around the monument.",
            "Bring sunscreen, a hat, and drinking water.",
            "Dress respectfully when visiting this religious landmark.",
            "Consider hiring a guide to understand the temple's history.",
            "Respect the ancient structures and avoid touching protected carvings.",
            "Follow official visitor restrictions when accessing the upper levels."
        ]
    },

    // ===================================
    // 7. MOUNT BROMO
    // ===================================

    {
        name: "Mount Bromo",
        country: "Indonesia",
        category: "Nature & Adventure",
        image: "images/Mount Bromo.jpg",
        budget: 90,
        featured: false,

        // 1. Overview
        description:
            "Mount Bromo is an active volcano located in East Java, Indonesia. Famous for its dramatic volcanic landscape, vast sea of sand, and spectacular sunrise views, it is one of Indonesia's most popular natural attractions.",

        location: "Bromo Tengger Semeru National Park, East Java",

        history:
            "Mount Bromo is part of the Tengger volcanic complex and has long been culturally significant to the Tenggerese people. The mountain is closely associated with the annual Yadnya Kasada ceremony, during which offerings are made to honor local traditions.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Mount Bromo Crater",
                description:
                    "Observe the impressive volcanic crater and surrounding volcanic landscape from designated viewing areas."
            },
            {
                name: "Sea of Sand",
                description:
                    "Explore the enormous sandy volcanic plain surrounding Mount Bromo."
            },
            {
                name: "Penanjakan Viewpoint",
                description:
                    "Enjoy breathtaking sunrise views over Mount Bromo and the surrounding mountains."
            },
            {
                name: "Whispering Sands",
                description:
                    "Experience the quiet atmosphere of the volcanic sand landscape shaped by wind."
            },
            {
                name: "Savanna Hills",
                description:
                    "Discover beautiful green hills and open landscapes within the national park."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Experience one of Indonesia's most famous volcanic landscapes.",
            "Enjoy spectacular sunrise views over the mountains.",
            "Explore the vast Sea of Sand.",
            "Discover the natural beauty of East Java.",
            "Learn about the cultural traditions of the Tenggerese community."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "April to October",
            weather:
                "The dry season generally offers clearer skies and more suitable conditions for sightseeing. Temperatures can be cold during early morning visits.",
            recommendation:
                "Visit during the dry season and arrive before sunrise for the best chance of enjoying the mountain views."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Sunrise Above the Volcano",
            experience:
                "Travel to a mountain viewpoint before sunrise, admire the changing colors of the sky, and explore the dramatic volcanic landscape around Mount Bromo.",
            culturalSignificance:
                "Mount Bromo is sacred to the Tenggerese people and plays an important role in their spiritual traditions, particularly during the annual Yadnya Kasada ceremony.",
            recommendation:
                "Bring warm clothing, follow park regulations, and check volcanic activity and access restrictions before visiting."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "National Park Admission", cost: "Varies by visitor category" },
            { item: "Local Jeep Tour", cost: "$20–$40" },
            { item: "Local Transportation", cost: "$10–$20" },
            { item: "Food and Drinks", cost: "$5–$15" },
            { item: "Accommodation", cost: "$15–$35" }
        ],

        budgetNote:
        "Estimated daily spending is approximately $50–$90 per person, depending on transportation, park admission, accommodation, and activities. Prices may vary by season and tour package.",

        // 7. Transportation and Accommodation
        transportation: [
            "Travel from Surabaya or Malang toward the Mount Bromo area.",
            "Join an organized jeep tour to explore the volcanic landscape.",
            "Use local transportation to reach nearby villages.",
            "Arrange transportation with your accommodation or tour provider."
        ],

        accommodation: [
            "Guesthouses in Cemoro Lawang near Mount Bromo.",
            "Hotels and homestays around Probolinggo.",
            "Budget accommodation in nearby mountain villages.",
            "Hotels in Malang for visitors exploring East Java."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "3:00 AM",
                activity: "Depart for the Sunrise Viewpoint",
                description:
                    "Travel by jeep toward a designated viewpoint before sunrise."
            },
            {
                time: "5:00 AM",
                activity: "Watch the Sunrise",
                description:
                    "Enjoy the beautiful sunrise and panoramic views of the surrounding volcanic mountains."
            },
            {
                time: "7:00 AM",
                activity: "Explore the Sea of Sand",
                description:
                    "Travel across the volcanic sand plain and admire the unusual landscape."
            },
            {
                time: "8:00 AM",
                activity: "Visit Mount Bromo Crater",
                description:
                    "Explore the designated visitor area around the volcano, following current safety restrictions."
            },
            {
                time: "11:00 AM",
                activity: "Return and Enjoy Local Food",
                description:
                    "Return to your accommodation area and enjoy a local Indonesian meal."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Bring a warm jacket because early mornings can be very cold.",
            "Wear comfortable shoes suitable for walking on volcanic sand.",
            "Book an authorized jeep tour in advance.",
            "Bring a face mask or scarf to protect yourself from dust.",
            "Carry drinking water and personal essentials.",
            "Check official volcanic activity reports before visiting.",
            "Follow park safety instructions and restricted-area notices.",
            "Respect the local culture and Tenggerese traditions."
        ]
    },

    // ===================================
    // 8. BALI
    // ===================================

    {
        name: "Bali",
        country: "Indonesia",
        category: "Island & Cultural",
        image: "images/Bali.jpg",
        budget: 100,
        featured: false,

        // 1. Overview
        description:
            "Bali is a beautiful Indonesian island famous for its tropical beaches, green rice terraces, ancient temples, traditional arts, and vibrant culture. It offers visitors a combination of relaxation, adventure, and cultural experiences.",

        location: "Bali, Indonesia",

        history:
            "Bali has a rich history influenced by Hindu traditions, local kingdoms, and centuries of cultural development. Its temples, traditional dances, ceremonies, and architecture continue to reflect the island's unique cultural identity.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Uluwatu Temple",
                description:
                    "Visit a beautiful sea temple located on a dramatic cliff overlooking the Indian Ocean."
            },
            {
                name: "Tegallalang Rice Terraces",
                description:
                    "Admire the famous green rice terraces and traditional agricultural landscapes."
            },
            {
                name: "Ubud",
                description:
                    "Explore Bali's cultural center, known for its art galleries, traditional markets, and natural surroundings."
            },
            {
                name: "Tanah Lot Temple",
                description:
                    "Discover an iconic sea temple built on a rock formation surrounded by ocean water."
            },
            {
                name: "Nusa Penida",
                description:
                    "Enjoy spectacular coastal scenery, cliffs, and beautiful beaches on this nearby island."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Experience Bali's unique Hindu culture and traditions.",
            "Relax on beautiful tropical beaches.",
            "Explore green rice terraces and natural landscapes.",
            "Discover historic temples and traditional architecture.",
            "Enjoy local Indonesian food, arts, and cultural performances."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "April to October",
            weather:
                "The dry season generally offers sunny weather and lower rainfall, making it suitable for outdoor activities and sightseeing.",
            recommendation:
                "Visit during the dry season for beach activities, temple visits, and exploring the island."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Experience Traditional Balinese Culture",
            experience:
                "Watch a traditional Balinese dance performance, visit beautiful temples, explore local villages, and enjoy the island's peaceful natural scenery.",
            culturalSignificance:
                "Balinese culture is strongly influenced by Hindu traditions, which are reflected in its religious ceremonies, temple architecture, traditional arts, and daily community life.",
            recommendation:
                "Dress respectfully when visiting temples, follow local customs, and consider joining a guided cultural experience."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$20–$40" },
            { item: "Food and Drinks", cost: "$10–$20" },
            { item: "Local Transportation", cost: "$10–$20" },
            { item: "Attraction Fees", cost: "$10–$15" },
            { item: "Activities", cost: "$15–$30" }
        ],

        budgetNote:
            "Estimated daily spending is approximately $65–$125 per person, depending on accommodation, transportation, activities, and dining choices. Prices may vary by season.",
            // 7. Transportation and Accommodation
        transportation: [
            "Arrive through Ngurah Rai International Airport in Denpasar.",
            "Use taxis or ride-hailing services to travel around the island.",
            "Rent a scooter only if legally permitted and properly licensed.",
            "Use local boats or organized tours to visit nearby islands such as Nusa Penida."
        ],

        accommodation: [
            "Hotels and resorts in Kuta and Seminyak.",
            "Guesthouses and villas in Ubud.",
            "Beachfront accommodation in Canggu.",
            "Resorts and hotels in Nusa Dua."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Explore Ubud",
                description:
                    "Visit local markets, art shops, and cultural attractions in Ubud."
            },
            {
                time: "10:30 AM",
                activity: "Visit Tegallalang Rice Terraces",
                description:
                    "Enjoy the beautiful green landscape and learn about traditional rice farming."
            },
            {
                time: "1:00 PM",
                activity: "Enjoy Local Indonesian Food",
                description:
                    "Try traditional Balinese dishes at a local restaurant."
            },
            {
                time: "3:00 PM",
                activity: "Visit Tanah Lot Temple",
                description:
                    "Explore the famous sea temple and enjoy the surrounding coastal scenery."
            },
            {
                time: "5:30 PM",
                activity: "Enjoy the Sunset",
                description:
                    "Relax and admire the beautiful sunset along Bali's coastline."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Bring sunscreen, comfortable clothing, and drinking water.",
            "Dress respectfully when visiting temples.",
            "Check temple opening hours and entrance requirements.",
            "Book popular activities and accommodation in advance.",
            "Carry some Indonesian Rupiah for small purchases.",
            "Respect local religious ceremonies and traditions.",
            "Use reputable transportation services.",
            "Keep the beaches and natural environment clean."
        ]
        },

    // ===================================
    // 9. KOMODO NATIONAL PARK
    // ===================================

    {
        name: "Komodo National Park",
        country: "Indonesia",
        category: "Wildlife & Nature",
        image: "images/Komodo National Park.jpg",
        budget: 150,
        featured: false,

        // 1. Overview
        description:
            "Komodo National Park is a remarkable natural destination in Indonesia, famous for its Komodo dragons, beautiful islands, coral reefs, and diverse marine wildlife. It offers visitors opportunities to explore unique ecosystems and spectacular coastal landscapes.",

        location: "East Nusa Tenggara, Indonesia",

        history:
            "Komodo National Park was established in 1980 to protect the Komodo dragon and its natural habitat. It was later recognized as a UNESCO World Heritage Site in 1991 because of its outstanding biodiversity and ecological importance.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Komodo Island",
                description:
                    "Explore the natural habitat of the world's largest living lizard with an authorized park guide."
            },
            {
                name: "Padar Island",
                description:
                    "Hike to a famous viewpoint overlooking beautiful bays and dramatic island landscapes."
            },
            {
                name: "Pink Beach",
                description:
                    "Discover a unique beach known for its pink-colored sand and clear surrounding waters."
            },
            {
                name: "Manta Point",
                description:
                    "Visit a popular marine area where visitors may observe manta rays under suitable conditions."
            },
            {
                name: "Rinca Island",
                description:
                    "Explore another important habitat of Komodo dragons and other wildlife with park supervision."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Observe Komodo dragons in their natural environment.",
            "Explore beautiful islands and coastal landscapes.",
            "Discover colorful coral reefs and marine biodiversity.",
            "Enjoy snorkeling and diving experiences.",
            "Learn about wildlife conservation and protected ecosystems."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "April to October",
            weather:
                "The dry season generally provides better conditions for island exploration, boat trips, and outdoor activities.",
            recommendation:
                "Visit during the dry season and check sea conditions before arranging boat tours."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Meet the Komodo Dragons",
            experience:
                "Join an authorized ranger-guided walk to observe Komodo dragons safely in their natural habitat and discover the unique wildlife of the national park.",
            culturalSignificance:
                "The park is internationally important for protecting Komodo dragons and preserving the natural ecosystems of the Lesser Sunda Islands.",
            recommendation:
                "Always stay with an authorized park ranger, follow safety instructions, and never approach or feed wild animals."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Park Admission and Fees", cost: "Varies by visitor category and regulations" },
            { item: "Boat Tour", cost: "$40–$80" },
            { item: "Accommodation", cost: "$20–$40" },
            { item: "Food and Drinks", cost: "$10–$20" },
            { item: "Snorkeling Activities", cost: "$15–$30" }
        ],

        budgetNote:
        "Estimated daily spending is approximately $85–$170 per person, depending on boat tours, park fees, accommodation, and activities. Prices and conservation fees may change.",

        // 7. Transportation and Accommodation
        transportation: [
            "Fly to Komodo International Airport in Labuan Bajo.",
            "Use local taxis or hotel transportation to reach the harbor.",
            "Join an authorized boat tour to visit the islands.",
            "Arrange guided wildlife activities through licensed operators."
        ],

        accommodation: [
            "Hotels and resorts in Labuan Bajo.",
            "Guesthouses near Labuan Bajo town.",
            "Budget hostels for independent travelers.",
            "Liveaboard boats offering multi-day island trips."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "7:00 AM",
                activity: "Depart from Labuan Bajo",
                description:
                    "Board an organized boat tour and travel toward the national park."
            },
            {
                time: "9:00 AM",
                activity: "Visit Padar Island",
                description:
                    "Hike to the viewpoint and enjoy panoramic views of the surrounding islands."
            },
            {
                time: "11:00 AM",
                activity: "Explore Komodo Island",
                description:
                    "Join an authorized ranger-guided walk to observe Komodo dragons safely."
            },
            {
                time: "1:00 PM",
                activity: "Relax at Pink Beach",
                description:
                    "Enjoy the unique pink sand and explore the coastal scenery."
            },
            {
                time: "3:00 PM",
                activity: "Snorkeling Experience",
                description:
                    "Discover the underwater environment at an approved snorkeling location."
            },
            {
                time: "5:00 PM",
                activity: "Return to Labuan Bajo",
                description:
                    "Travel back to the harbor after a day exploring the national park."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Always follow the instructions of authorized park rangers.",
            "Never approach, touch, or feed Komodo dragons.",
            "Wear comfortable shoes for island hikes.",
            "Bring sunscreen, a hat, and drinking water.",
            "Check boat schedules and sea conditions before traveling.",
            "Use licensed tour operators and authorized guides.",
            "Respect marine wildlife and avoid touching coral reefs.",
            "Check current park entry fees and visitor regulations before your trip."
        ]
    },

    // ===================================
    // 10. RAJA AMPAT
    // ===================================

    {
        name: "Raja Ampat",
        country: "Indonesia",
        category: "Island & Marine Nature",
        image: "images/Raja Ampat.jpg",
        budget: 150,
        featured: false,

        // 1. Overview
        description:
            "Raja Ampat is a spectacular archipelago in Southwest Papua, Indonesia, famous for its turquoise waters, limestone islands, coral reefs, and extraordinary marine biodiversity. It is considered one of the world's most remarkable marine destinations.",

        location: "Southwest Papua, Indonesia",

        history:
            "Raja Ampat has a long history of coastal communities, traditional fishing practices, and maritime trade. Its name means Four Kings, referring to a traditional legend about four kingdoms in the region. Today, the area is internationally recognized for its ecological importance and marine conservation.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Wayag Islands",
                description:
                    "Admire dramatic limestone islands surrounded by brilliant turquoise water and beautiful lagoons."
            },
            {
                name: "Piaynemo",
                description:
                    "Climb to a famous viewpoint overlooking small karst islands and crystal-clear lagoons."
            },
            {
                name: "Arborek Village",
                description:
                    "Visit a traditional island village known for its welcoming community and nearby snorkeling areas."
            },
            {
                name: "Misool Island",
                description:
                    "Explore beautiful limestone formations, hidden lagoons, and rich marine environments."
            },
            {
                name: "Cape Kri",
                description:
                    "Discover a famous diving location known for its exceptional variety of tropical marine life."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Discover one of the world's richest marine biodiversity regions.",
            "Explore beautiful tropical islands and lagoons.",
            "Enjoy snorkeling and scuba diving.",
            "Experience traditional island communities.",
            "Admire spectacular limestone landscapes and clear waters."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "October to April",
            weather:
                "These months are generally popular for visiting Raja Ampat, although sea conditions and rainfall vary between months and locations.",
            recommendation:
                "Plan boat trips according to local weather forecasts and sea conditions."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Explore a Tropical Marine Paradise",
            experience:
                "Take a boat trip through the limestone islands, snorkel above colorful coral reefs, and discover the extraordinary underwater world of Raja Ampat.",
            culturalSignificance:
                "Raja Ampat is home to traditional coastal communities whose cultural heritage is closely connected to the sea, fishing, and island life.",
            recommendation:
                "Choose responsible tour operators, respect local communities, and avoid touching coral or disturbing marine wildlife."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$30–$60" },
            { item: "Food and Drinks", cost: "$10–$20" },
            { item: "Boat Transportation", cost: "$30–$50" },
            { item: "Snorkeling Activities", cost: "$15–$30" },
            { item: "Local Fees and Permits", cost: "Varies" }
        ],

        budgetNote:
        "Estimated daily spending is approximately $85–$160 per person, depending on accommodation, boat transportation, activities, and local fees. Travel costs can be higher because of the remote location.",

        // 7. Transportation and Accommodation
        transportation: [
            "Fly to Domine Eduard Osok Airport in Sorong, Southwest Papua.",
            "Travel from Sorong to Waisai by ferry.",
            "Arrange local boat transportation to nearby islands and accommodations.",
            "Use organized tours for remote snorkeling and diving locations."
        ],

        accommodation: [
            "Traditional homestays on local islands.",
            "Eco-resorts near popular marine areas.",
            "Guesthouses around Waisai.",
            "Specialized diving resorts and accommodation packages."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "7:00 AM",
                activity: "Depart for Island Exploration",
                description:
                    "Begin a guided boat trip to explore the beautiful islands and surrounding waters."
            },
            {
                time: "9:00 AM",
                activity: "Visit Piaynemo",
                description:
                    "Climb to the viewpoint and enjoy panoramic views of the limestone islands."
            },
            {
                time: "11:00 AM",
                activity: "Explore a Snorkeling Site",
                description:
                    "Discover colorful coral reefs and tropical marine life with a responsible guide."
            },
            {
                time: "1:00 PM",
                activity: "Enjoy Local Food",
                description:
                    "Have lunch and experience local food in the island region."
            },
            {
                time: "2:30 PM",
                activity: "Visit a Traditional Village",
                description:
                    "Learn about local island life and appreciate the community's cultural heritage."
            },
            {
                time: "4:30 PM",
                activity: "Return to Accommodation",
                description:
                    "Travel back and enjoy the peaceful island atmosphere."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Plan transportation in advance because Raja Ampat is remote.",
            "Bring sunscreen, a hat, and drinking water.",
            "Carry Indonesian Rupiah for local purchases.",
            "Check boat schedules and weather conditions.",
            "Respect local communities and cultural customs.",
            "Use reef-safe sunscreen where possible.",
            "Never touch or stand on coral reefs.",
            "Follow marine park regulations and conservation guidelines."
        ]
    },

    // ===================================
    // III. PHILPPINES
    // ===================================

    // ===================================
    // 11. CHOCOLATE HILLS
    // ===================================

    {
        name: "Chocolate Hills",
        country: "Philippines",
        category: "Nature & Landscape",
        image: "images/Chocolate Hills.jpg",
        budget: 60,
        featured: true,

        // 1. Overview
        description:
            "The Chocolate Hills are one of the Philippines' most famous natural attractions, located in Bohol. This extraordinary landscape consists of more than a thousand cone-shaped hills spread across the countryside. During the dry season, the grass covering the hills turns brown, creating their famous chocolate-like appearance.",

        location: "Bohol, Central Visayas, Philippines",

        history:
            "The Chocolate Hills are a natural geological formation shaped over millions of years through geological processes. They are an important natural landmark of Bohol and a symbol of the island's unique landscape and tourism.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Chocolate Hills Complex",
                description:
                    "Visit the main viewing area and enjoy panoramic views of the unusual hills."
            },
            {
                name: "Sagbayan Peak",
                description:
                    "Enjoy another scenic viewpoint overlooking the Chocolate Hills and surrounding countryside."
            },
            {
                name: "Carmen Countryside",
                description:
                    "Explore the rural landscape surrounding the famous geological formations."
            },
            {
                name: "Loboc River",
                description:
                    "Experience a scenic river surrounded by tropical greenery and local communities."
            },
            {
                name: "Philippine Tarsier Sanctuary",
                description:
                    "Learn about the conservation of the tiny Philippine tarsier and its natural habitat."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "See one of the Philippines' most famous natural landmarks.",
            "Enjoy beautiful panoramic countryside views.",
            "Discover the unique geological formations of Bohol.",
            "Explore nearby cultural and nature attractions.",
            "Experience the peaceful atmosphere of the island."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "December to May",
            weather:
                "These months generally offer drier weather and better conditions for outdoor sightseeing. The hills often turn brown during the dry season.",
            recommendation:
                "Visit during the dry season for clearer views and the best chance of seeing the hills in their chocolate-brown appearance."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Panoramic Views of the Chocolate Hills",
            experience:
                "Climb to a designated viewing platform and admire the extraordinary landscape of hundreds of rounded hills stretching across the horizon.",
            culturalSignificance:
                "The Chocolate Hills are an important natural symbol of Bohol and contribute to the region's cultural identity, local tourism, and environmental heritage.",
            recommendation:
                "Respect viewing-area rules, avoid damaging vegetation, and keep the natural environment clean."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$15–$30" },
            { item: "Food and Drinks", cost: "$8–$15" },
            { item: "Local Transportation", cost: "$10–$20" },
            { item: "Attraction Fees", cost: "$2–$5" },
            { item: "Additional Activities", cost: "$10–$20" }
        ],

        budgetNote:
        "Estimated daily spending is approximately $45–$90 per person, depending on accommodation, transportation, food, and activities. Prices may vary by season and travel arrangements.",

        // 7. Transportation and Accommodation
        transportation: [
            "Fly to Bohol-Panglao International Airport.",
            "Use local taxis, vans, or organized tours to reach the Chocolate Hills.",
            "Rent a vehicle with a licensed driver for countryside sightseeing.",
            "Arrange local transportation through your accommodation."
        ],

        accommodation: [
            "Hotels and resorts around Panglao Island.",
            "Guesthouses in Tagbilaran City.",
            "Local accommodations near Carmen.",
            "Eco-friendly stays around Bohol's countryside."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Travel to Chocolate Hills",
                description:
                    "Begin the journey through Bohol's beautiful countryside."
            },
            {
                time: "9:30 AM",
                activity: "Visit Chocolate Hills Complex",
                description:
                    "Enjoy panoramic views of the hills from the designated viewing platform."
            },
            {
                time: "11:00 AM",
                activity: "Explore Sagbayan Peak",
                description:
                    "Discover another scenic viewpoint and appreciate the surrounding landscape."
            },
            {
                time: "1:00 PM",
                activity: "Enjoy Local Food",
                description:
                    "Take a break and experience traditional Filipino dishes."
            },
            {
                time: "2:30 PM",
                activity: "Visit Loboc River",
                description:
                    "Relax beside the river and enjoy the tropical scenery."
            },
            {
                time: "4:00 PM",
                activity: "Discover Bohol's Countryside",
                description:
                    "Explore nearby attractions before returning to your accommodation."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Wear comfortable shoes for walking and sightseeing.",
            "Bring sunscreen, a hat, and drinking water.",
            "Visit early in the morning to avoid crowds and midday heat.",
            "Bring a camera to capture the panoramic landscape.",
            "Check weather conditions before planning outdoor activities.",
            "Respect designated viewing areas and environmental rules.",
            "Arrange transportation in advance for countryside visits.",
            "Keep the natural environment clean."
        ]
        },

    // ===================================
    // 12. EL NIDO, PALAWAN
    // ===================================

    {
        name: "El Nido, Palawan",
        country: "Philippines",
        category: "Island & Beach",
        image: "images/El Nido Palawan.jpg",
        budget: 100,
        featured: false,

        // 1. Overview
        description:
            "El Nido is a beautiful coastal destination in Palawan, Philippines, famous for its turquoise lagoons, white-sand beaches, limestone cliffs, and clear tropical waters. It is one of the country's most popular destinations for island hopping and marine adventures.",

        location: "Palawan, Mimaropa, Philippines",

        history:
            "El Nido has a long history of fishing and coastal communities. Its name comes from the edible swiftlet nests found in the area's limestone cliffs. Today, it is internationally recognized for its natural beauty and important marine ecosystems.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Big Lagoon",
                description:
                    "Explore a spectacular turquoise lagoon surrounded by towering limestone cliffs."
            },
            {
                name: "Small Lagoon",
                description:
                    "Discover a peaceful lagoon with clear water and dramatic rock formations."
            },
            {
                name: "Secret Lagoon",
                description:
                    "Visit a hidden lagoon accessible through a small opening in the surrounding limestone rocks."
            },
            {
                name: "Seven Commandos Beach",
                description:
                    "Relax on a beautiful white-sand beach surrounded by tropical scenery."
            },
            {
                name: "Nacpan Beach",
                description:
                    "Enjoy a long stretch of golden sand and beautiful ocean views."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Discover beautiful tropical lagoons and beaches.",
            "Enjoy island-hopping and boat adventures.",
            "Explore impressive limestone cliffs and rock formations.",
            "Experience snorkeling and marine wildlife.",
            "Relax in one of the Philippines' most scenic coastal destinations."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "December to May",
            weather:
                "These months generally offer drier weather and better conditions for island hopping and beach activities.",
            recommendation:
                "Visit during the dry season and check sea conditions before arranging boat trips."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Island Hopping Through Tropical Lagoons",
            experience:
                "Join a boat tour through El Nido's beautiful islands, swim in clear lagoons, discover hidden beaches, and admire the dramatic limestone landscape.",
            culturalSignificance:
                "El Nido is home to coastal communities whose livelihoods and traditions are closely connected to fishing, island life, and the surrounding marine environment.",
            recommendation:
                "Choose responsible tour operators, respect local communities, and avoid touching coral reefs or disturbing marine wildlife."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$20–$40" },
            { item: "Food and Drinks", cost: "$10–$20" },
            { item: "Island-Hopping Tour", cost: "$20–$35" },
            { item: "Local Transportation", cost: "$10–$15" },
            { item: "Additional Activities", cost: "$10–$20" }
        ],

        budgetNote:
            "Estimated daily spending is approximately $70–$130 per person, depending on accommodation, tours, transportation, and activities. Environmental and tourism fees may be charged separately.",
            // 7. Transportation and Accommodation
        transportation: [
            "Fly to El Nido Airport or travel through Puerto Princesa.",
            "Use local tricycles or vans to travel around El Nido town.",
            "Join organized boat tours to explore nearby islands and lagoons.",
            "Arrange airport transfers through your accommodation."
        ],

        accommodation: [
            "Beachfront resorts near El Nido town.",
            "Guesthouses and budget hostels in the town center.",
            "Hotels near Corong Corong Beach.",
            "Private villas and resorts around Nacpan Beach."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Depart for Island Hopping",
                description:
                    "Board a local boat tour and begin exploring El Nido's beautiful islands."
            },
            {
                time: "9:00 AM",
                activity: "Visit Big Lagoon",
                description:
                    "Enjoy the turquoise water and impressive limestone cliffs."
            },
            {
                time: "11:00 AM",
                activity: "Explore Small Lagoon",
                description:
                    "Discover another peaceful lagoon surrounded by natural rock formations."
            },
            {
                time: "1:00 PM",
                activity: "Enjoy Lunch by the Beach",
                description:
                    "Relax and enjoy a local meal during the island-hopping tour."
            },
            {
                time: "2:30 PM",
                activity: "Visit Secret Lagoon",
                description:
                    "Explore the hidden lagoon and admire its unique natural surroundings."
            },
            {
                time: "4:30 PM",
                activity: "Return to El Nido Town",
                description:
                    "Travel back to town and enjoy the coastal atmosphere."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Bring sunscreen, a hat, and drinking water.",
            "Wear comfortable clothing and suitable footwear.",
            "Book popular island-hopping tours in advance.",
            "Bring waterproof bags for electronic devices.",
            "Check weather and sea conditions before boat trips.",
            "Respect marine conservation rules.",
            "Avoid touching or stepping on coral reefs.",
            "Carry some Philippine pesos for local purchases."
        ]
    },

    // ===================================
    // 13. MAYON VOLCANO
    // ===================================

    {
        name: "Mayon Volcano",
        country: "Philippines",
        category: "Nature & Adventure",
        image: "images/Mayon Volcano.jpg",
        budget: 80,
        featured: false,

        // 1. Overview
        description:
            "Mayon Volcano is one of the Philippines' most famous natural landmarks, located in Albay province. It is widely known for its remarkably symmetrical cone shape, green surroundings, and dramatic volcanic landscape. Visitors can admire its beauty from several viewpoints around the region.",

        location: "Albay, Bicol Region, Philippines",

        history:
            "Mayon Volcano has shaped the history and landscape of the Bicol Region through repeated volcanic eruptions. It is an important natural landmark and is closely connected to local history, traditions, and community life.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Cagsawa Ruins",
                description:
                    "Visit the historic church ruins with the famous Mayon Volcano in the background."
            },
            {
                name: "Mayon Skyline",
                description:
                    "Enjoy impressive views of the volcano and surrounding landscapes from an elevated viewpoint, subject to current access conditions."
            },
            {
                name: "Daraga Church",
                description:
                    "Discover a historic church built on a hill overlooking the surrounding countryside and Mayon Volcano."
            },
            {
                name: "Legazpi Boulevard",
                description:
                    "Relax along the waterfront and enjoy views of Mayon Volcano when weather conditions are clear."
            },
            {
                name: "Ligñon Hill Nature Park",
                description:
                    "Enjoy panoramic views of Legazpi City and the surrounding volcanic landscape."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Admire one of the world's most recognizable volcanic cone shapes.",
            "Explore the natural beauty of the Bicol Region.",
            "Discover historic sites and local heritage.",
            "Enjoy beautiful photography opportunities.",
            "Learn about volcanoes and geological activity."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "March to May",
            weather:
                "These months are generally warmer and may provide clearer sightseeing conditions, although tropical weather can change quickly.",
            recommendation:
                "Check local weather forecasts and official volcano advisories before planning your visit."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Admire the Perfect Cone of Mayon",
            experience:
                "Visit scenic viewpoints around Albay to admire Mayon's impressive shape and capture photographs of the surrounding landscape.",
            culturalSignificance:
                "Mayon Volcano is an important natural symbol of Albay and has influenced local traditions, stories, livelihoods, and community history.",
            recommendation:
                "Observe the volcano only from authorized safe locations and follow all official access restrictions."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$20–$35" },
            { item: "Food and Drinks", cost: "$8–$15" },
            { item: "Local Transportation", cost: "$10–$20" },
            { item: "Attraction Fees", cost: "$2–$5" },
            { item: "Additional Activities", cost: "$10–$20" }
        ],

        budgetNote:
        "Estimated daily spending is approximately $50–$95 per person, depending on accommodation, transportation, food, and activities. Prices may vary by season.",

        // 7. Transportation and Accommodation
        transportation: [
            "Fly to Bicol International Airport near Legazpi City.",
            "Use local tricycles, jeepneys, or taxis to explore nearby attractions.",
            "Arrange guided countryside tours through reputable local operators.",
            "Check road access and official safety restrictions before traveling near the volcano."
        ],

        accommodation: [
            "Hotels in Legazpi City.",
            "Guesthouses near Daraga.",
            "Budget hotels around Albay.",
            "Resorts and accommodations in nearby countryside areas."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Visit Cagsawa Ruins",
                description:
                    "Explore the historic ruins and enjoy views of Mayon Volcano from a designated visitor area."
            },
            {
                time: "10:00 AM",
                activity: "Discover Daraga Church",
                description:
                    "Admire the historic architecture and surrounding countryside."
            },
            {
                time: "12:00 PM",
                activity: "Enjoy Bicolano Food",
                description:
                    "Try traditional regional dishes at a local restaurant."
            },
            {
                time: "2:00 PM",
                activity: "Visit Ligñon Hill",
                description:
                    "Enjoy panoramic views of Legazpi City and the surrounding landscape."
            },
            {
                time: "4:00 PM",
                activity: "Relax at Legazpi Boulevard",
                description:
                    "Enjoy the waterfront atmosphere and views of Mayon when the sky is clear."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Check official volcano activity advisories before traveling.",
            "Respect restricted zones and evacuation boundaries.",
            "Bring sunscreen, comfortable shoes, and drinking water.",
            "Check the weather because clouds may cover the volcano.",
            "Carry some Philippine pesos for local purchases.",
            "Use authorized local guides for organized activities.",
            "Respect historical sites and local communities.",
            "Follow instructions from local authorities at all times."
        ]
    },

    // ===================================
    // 14. BANAUE RICE TERRACES
    // ===================================

    {
        name: "Banaue Rice Terraces",
        country: "Philippines",
        category: "Cultural & Nature",
        image: "images/Banaue Rice Terraces.jpg",
        budget: 70,
        featured: false,

        // 1. Overview
        description:
            "The Banaue Rice Terraces are a remarkable landscape of ancient rice fields carved into the mountains of Ifugao in the northern Philippines. Surrounded by lush green mountains and traditional villages, they reflect generations of agricultural knowledge and the close relationship between people and nature.",

        location: "Banaue, Ifugao, Philippines",

        history:
            "The rice terraces of the Philippine Cordilleras were developed by Indigenous communities over many generations. They demonstrate traditional farming knowledge, community cooperation, and cultural heritage passed down through generations.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Banaue Viewpoint",
                description:
                    "Admire the sweeping view of the rice terraces stretching across the mountains."
            },
            {
                name: "Batad Rice Terraces",
                description:
                    "Explore the famous amphitheater-shaped terraces surrounded by mountain scenery."
            },
            {
                name: "Tappiya Falls",
                description:
                    "Discover a beautiful waterfall near Batad after a challenging hike."
            },
            {
                name: "Banga-an Village",
                description:
                    "Visit a traditional Ifugao village and learn about local architecture and community life."
            },
            {
                name: "Local Cultural Experiences",
                description:
                    "Discover traditional crafts, farming practices, and the cultural heritage of Ifugao communities."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Experience one of the Philippines' most impressive mountain landscapes.",
            "Discover traditional Ifugao culture and heritage.",
            "Enjoy scenic hiking and photography opportunities.",
            "Learn about traditional rice farming methods.",
            "Explore peaceful mountain villages and natural surroundings."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "April to May",
            weather:
                "These months are generally warmer and can offer beautiful green landscapes, although conditions vary.",
            recommendation:
                "Check local weather conditions before traveling. The appearance of the terraces changes throughout the farming seasons."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Explore the Ancient Mountain Terraces",
            experience:
                "Walk along designated terrace trails, admire the mountain scenery, and learn about the traditional farming culture of Ifugao.",
            culturalSignificance:
                "The Rice Terraces of the Philippine Cordilleras are recognized as a UNESCO World Heritage Site and represent the living cultural traditions and agricultural knowledge of Indigenous communities.",
            recommendation:
                "Consider hiring a local guide to learn more about the terraces and respect local customs and private farmland."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$15–$30" },
            { item: "Food and Drinks", cost: "$8–$15" },
            { item: "Local Transportation", cost: "$10–$20" },
            { item: "Guide and Activities", cost: "$10–$20" },
            { item: "Additional Expenses", cost: "$5–$10" }
        ],

        budgetNote:
        "Estimated daily spending is approximately $48–$95 per person, depending on accommodation, transportation, and activities. Prices may vary.",

        // 7. Transportation and Accommodation
        transportation: [
            "Travel by bus from Manila or nearby cities toward Banaue.",
            "Use local jeepneys or tricycles to reach nearby villages and viewpoints.",
            "Arrange local guided hikes for destinations such as Batad.",
            "Check road and trail conditions before traveling."
        ],

        accommodation: [
            "Guesthouses in Banaue town.",
            "Family-run homestays in nearby villages.",
            "Small hotels overlooking the mountain landscape.",
            "Local lodges near Batad."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Visit Banaue Viewpoint",
                description:
                    "Enjoy panoramic views of the famous rice terraces and surrounding mountains."
            },
            {
                time: "10:00 AM",
                activity: "Explore Local Villages",
                description:
                    "Discover traditional Ifugao homes and learn about local culture."
            },
            {
                time: "12:00 PM",
                activity: "Enjoy a Local Lunch",
                description:
                    "Taste traditional Filipino and Ifugao dishes at a local restaurant."
            },
            {
                time: "1:30 PM",
                activity: "Explore Batad",
                description:
                    "Discover the impressive amphitheater-shaped rice terraces with a local guide."
            },
            {
                time: "3:30 PM",
                activity: "Enjoy Mountain Scenery",
                description:
                    "Take photographs and appreciate the peaceful mountain environment."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Wear comfortable hiking shoes.",
            "Bring drinking water and sun protection.",
            "Prepare for long and winding mountain journeys.",
            "Hire local guides for unfamiliar hiking routes.",
            "Respect Indigenous traditions and local communities.",
            "Avoid stepping on crops or damaging terrace walls.",
            "Carry some Philippine pesos for local purchases.",
            "Check weather and trail conditions before hiking."
        ]
    },

    // ===================================
    // 15. INTRAMUROS, MANILA
    // ===================================

    {
        name: "Intramuros, Manila",
        country: "Philippines",
        category: "Historical & Cultural",
        image: "images/Intramuros Manila.jpg",
        budget: 65,
        featured: false,

        // 1. Overview
        description:
            "Intramuros is the historic walled district of Manila, known for its Spanish colonial architecture, old churches, cobblestone streets, and historic landmarks. Often called the Walled City, it offers visitors a glimpse into the Philippines' colonial past and cultural heritage.",

        location: "Manila, Metro Manila, Philippines",

        history:
            "Intramuros was established by Spanish colonial authorities in the late 16th century and became the political, religious, and military center of Spanish Manila. Despite suffering extensive damage during World War II, many historic landmarks have been preserved and restored.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Fort Santiago",
                description:
                    "Explore the historic fortress that played an important role in Manila's colonial and wartime history."
            },
            {
                name: "San Agustin Church",
                description:
                    "Visit one of the oldest stone churches in the Philippines and admire its historic architecture."
            },
            {
                name: "Casa Manila",
                description:
                    "Discover a reconstructed Spanish colonial house displaying traditional furniture and interior design."
            },
            {
                name: "Manila Cathedral",
                description:
                    "Admire the impressive cathedral located in the historic heart of Intramuros."
            },
            {
                name: "Baluarte de San Diego",
                description:
                    "Explore the remains of an old Spanish defensive structure and its surrounding gardens."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Discover the history of Spanish colonial Manila.",
            "Explore centuries-old churches and historic buildings.",
            "Learn about important events in Philippine history.",
            "Enjoy beautiful architecture and photography opportunities.",
            "Experience the cultural atmosphere of the Walled City."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "November to February",
            weather:
                "These months are generally cooler and more comfortable for walking around historic outdoor attractions.",
            recommendation:
                "Visit in the morning to avoid the strongest afternoon heat and allow enough time to explore."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Walk Through the Historic Walled City",
            experience:
                "Explore Intramuros on foot or through a guided heritage tour, discovering historic streets, churches, fortifications, and colonial-era buildings.",
            culturalSignificance:
                "Intramuros preserves important parts of Philippine history and reflects the country's colonial experience, religious traditions, and cultural development.",
            recommendation:
                "Take a guided walking tour to understand the stories behind the historic landmarks and respect the heritage buildings."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$20–$35" },
            { item: "Food and Drinks", cost: "$10–$15" },
            { item: "Local Transportation", cost: "$5–$10" },
            { item: "Attraction Fees", cost: "$5–$10" },
            { item: "Guided Tour and Activities", cost: "$5–$15" }
        ],

        budgetNote:
        "Estimated daily spending is approximately $45–$85 per person, depending on accommodation, transportation, and activities. Prices may vary.",

        // 7. Transportation and Accommodation
        transportation: [
            "Travel to Manila through Ninoy Aquino International Airport.",
            "Use taxis, ride-hailing services, jeepneys, or other public transportation to reach Intramuros.",
            "Explore most historic attractions on foot.",
            "Consider joining an authorized guided walking or heritage tour."
        ],

        accommodation: [
            "Hotels near Intramuros.",
            "Budget hotels around Ermita and Manila.",
            "Guesthouses near the historic district.",
            "Hotels in nearby Manila city-center areas."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Explore Fort Santiago",
                description:
                    "Walk through the historic fortress and discover its important role in Philippine history."
            },
            {
                time: "10:00 AM",
                activity: "Visit Manila Cathedral",
                description:
                    "Admire the cathedral's architecture and explore the surrounding historic plaza."
            },
            {
                time: "11:00 AM",
                activity: "Discover Casa Manila",
                description:
                    "Learn about Spanish colonial lifestyle through its traditional interiors and exhibits."
            },
            {
                time: "12:30 PM",
                activity: "Enjoy Filipino Food",
                description:
                    "Have lunch at a restaurant inside or near Intramuros."
            },
            {
                time: "2:00 PM",
                activity: "Visit San Agustin Church",
                description:
                    "Explore the historic church and learn about its religious and architectural heritage."
            },
            {
                time: "3:30 PM",
                activity: "Walk Around the Walled City",
                description:
                    "Enjoy the historic streets, old walls, and beautiful colonial architecture."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Wear comfortable walking shoes.",
            "Bring water, sunscreen, and a hat.",
            "Visit outdoor attractions earlier in the day.",
            "Check attraction opening hours and entrance fees.",
            "Respect religious sites and local customs.",
            "Bring some Philippine pesos for small purchases.",
            "Keep personal belongings secure in crowded areas.",
            "Consider a guided tour to learn more about the district's history."
        ]
    },

    // ===================================
    // IV. MYANMAR
    // ===================================

    // ===================================
    // 16. SHWEDAGON PAGODA
    // ===================================

    {
        name: "Shwedagon Pagoda",
        country: "Myanmar",
        category: "Historical & Cultural",
        image: "images/Shwedagon Pagoda.jpg",
        budget: 75,
        featured: true,

        // 1. Overview
        description:
            "Shwedagon Pagoda is one of Myanmar's most famous religious and cultural landmarks. Located on Singuttara Hill in Yangon, this magnificent golden Buddhist stupa is admired for its impressive architecture, spiritual atmosphere, and beautiful decorations.",

        location: "Yangon, Myanmar",

        history:
            "Shwedagon Pagoda has a long history and is one of the most important Buddhist pilgrimage sites in Myanmar. It has been expanded and restored by generations of rulers and devotees and remains a powerful symbol of Myanmar's religious and cultural heritage.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Golden Main Stupa",
                description:
                    "Admire the enormous golden stupa that dominates the pagoda complex."
            },
            {
                name: "Planetary Posts",
                description:
                    "Discover the traditional posts associated with the days of the week and Buddhist customs."
            },
            {
                name: "Prayer Halls",
                description:
                    "Explore the peaceful prayer spaces and observe local religious traditions respectfully."
            },
            {
                name: "Sacred Shrines",
                description:
                    "Discover the smaller shrines and Buddha images surrounding the main stupa."
            },
            {
                name: "Evening Pagoda Views",
                description:
                    "Admire the golden pagoda illuminated beautifully after sunset."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Discover one of Myanmar's most important Buddhist landmarks.",
            "Admire remarkable golden architecture and craftsmanship.",
            "Learn about Myanmar's religious traditions and cultural heritage.",
            "Experience a peaceful and spiritual atmosphere.",
            "Capture beautiful photographs of the historic pagoda."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "November to February",
            weather:
                "These months are generally cooler and more comfortable for exploring Yangon.",
            recommendation:
                "Visit in the late afternoon to enjoy the pagoda in daylight and see its golden structure illuminated after sunset."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Experience the Golden Pagoda",
            experience:
                "Walk around the main stupa, admire the detailed decorations, and observe the peaceful atmosphere of one of Myanmar's most sacred Buddhist sites.",
            culturalSignificance:
                "Shwedagon Pagoda is a major symbol of Myanmar's Buddhist faith, history, and national cultural identity.",
            recommendation:
                "Dress modestly, remove your shoes and socks before entering the pagoda grounds, and respect worshippers and religious ceremonies."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$20–$35" },
            { item: "Food and Drinks", cost: "$8–$15" },
            { item: "Local Transportation", cost: "$5–$10" },
            { item: "Entrance and Activities", cost: "$5–$10" },
            { item: "Additional Expenses", cost: "$5–$10" }
        ],

        budgetNote:
            "Estimated daily spending is approximately $43–$80 per person. Actual costs may vary depending on accommodation, transportation, exchange rates, and current visitor arrangements.",
            // 7. Transportation and Accommodation
        transportation: [
            "Yangon International Airport is the main international gateway to Yangon.",
            "Use taxis or reputable ride-hailing services to reach the pagoda.",
            "Local buses and other public transportation may be available for exploring the city.",
            "Check local travel conditions and transportation availability before your visit."
        ],

        accommodation: [
            "Hotels in central Yangon.",
            "Guesthouses near downtown Yangon.",
            "Mid-range hotels around the city.",
            "Accommodation in areas with convenient access to major attractions."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "3:00 PM",
                activity: "Arrive at Shwedagon Pagoda",
                description:
                    "Enter the pagoda complex and take time to appreciate its impressive architecture."
            },
            {
                time: "3:30 PM",
                activity: "Explore the Main Stupa",
                description:
                    "Walk around the golden stupa and discover the surrounding shrines."
            },
            {
                time: "4:30 PM",
                activity: "Discover Buddhist Traditions",
                description:
                    "Observe the prayer areas and learn about local religious customs."
            },
            {
                time: "5:30 PM",
                activity: "Enjoy the Sunset Atmosphere",
                description:
                    "Experience the changing light across the golden pagoda."
            },
            {
                time: "6:00 PM",
                activity: "Admire the Illuminated Pagoda",
                description:
                    "Enjoy the beautiful golden stupa as it lights up in the evening."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Check current travel advisories and local security conditions before planning a trip to Myanmar.",
            "Dress modestly when visiting religious sites.",
            "Remove shoes and socks before entering the pagoda grounds.",
            "Bring drinking water and stay hydrated.",
            "Respect worshippers and avoid disturbing religious ceremonies.",
            "Ask permission before photographing people.",
            "Follow local instructions and site regulations.",
            "Check current entrance arrangements before visiting."
        ]
        },

    // ===================================
    // 17. BAGAN ANCIENT CITY
    // ===================================

    {
        name: "Bagan Ancient City",
        country: "Myanmar",
        category: "Historical & Cultural",
        image: "images/Bagan Ancient City.jpg",
        budget: 75,
        featured: false,

        // 1. Overview
        description:
            "Bagan is an extraordinary ancient city in central Myanmar, famous for its thousands of Buddhist temples, pagodas, and stupas spread across a vast archaeological landscape. Its historic architecture, peaceful countryside, and beautiful sunrise views make it one of Myanmar's most remarkable cultural destinations.",

        location: "Bagan, Mandalay Region, Myanmar",

        history:
            "Bagan flourished as the capital of the Pagan Kingdom between the 9th and 13th centuries. During this period, thousands of Buddhist religious monuments were constructed, reflecting the kingdom's artistic, architectural, and religious achievements.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Ananda Temple",
                description:
                    "Visit one of Bagan's most admired temples, known for its impressive architecture and Buddha statues."
            },
            {
                name: "Shwezigon Pagoda",
                description:
                    "Discover a magnificent golden pagoda that played an important role in the development of Burmese Buddhist architecture."
            },
            {
                name: "Dhammayangyi Temple",
                description:
                    "Explore one of Bagan's largest temples, recognized for its massive brick structure."
            },
            {
                name: "Thatbyinnyu Temple",
                description:
                    "Admire one of Bagan's tallest historic temples and its distinctive architectural design."
            },
            {
                name: "Bagan Archaeological Zone",
                description:
                    "Explore the wider archaeological landscape filled with ancient monuments and historic remains."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Discover thousands of ancient Buddhist monuments.",
            "Learn about the history of the Pagan Kingdom.",
            "Admire traditional Burmese architecture and craftsmanship.",
            "Enjoy beautiful countryside and archaeological scenery.",
            "Experience one of Southeast Asia's most remarkable historic landscapes."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "November to February",
            weather:
                "These months are generally cooler and drier than the hotter months of the year.",
            recommendation:
                "Early mornings are often more comfortable for exploring the temples and enjoying the scenery."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Discover the Ancient Temple Landscape",
            experience:
                "Explore Bagan's historic monuments, admire the detailed brickwork, and discover the stories behind the ancient Buddhist kingdom.",
            culturalSignificance:
                "Bagan represents an important period in Myanmar's history and is recognized as a UNESCO World Heritage Site for its outstanding collection of religious monuments and cultural heritage.",
            recommendation:
                "Visit permitted temples and viewpoints, dress respectfully at religious sites, and follow local conservation rules."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$20–$35" },
            { item: "Food and Drinks", cost: "$8–$15" },
            { item: "Local Transportation", cost: "$10–$15" },
            { item: "Entrance and Activities", cost: "$5–$10" },
            { item: "Additional Expenses", cost: "$5–$15" }
        ],

        budgetNote:
        "Estimated daily spending is approximately $48–$90 per person. Actual costs may vary depending on accommodation, transportation, exchange rates, and current visitor arrangements.",

        // 7. Transportation and Accommodation
        transportation: [
            "Check current travel availability before planning a journey to Bagan.",
            "Domestic flights may connect nearby airports with Bagan through Nyaung U Airport when operating.",
            "Local taxis and authorized tour services can help visitors explore the archaeological area.",
            "Bicycles or electric bicycles may be available locally, subject to current conditions and safety."
        ],

        accommodation: [
            "Hotels in Nyaung U.",
            "Guesthouses near Bagan's archaeological area.",
            "Hotels around New Bagan.",
            "Small locally operated accommodations."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "7:00 AM",
                activity: "Explore Ananda Temple",
                description:
                    "Begin the day by visiting one of Bagan's most famous and beautiful temples."
            },
            {
                time: "9:00 AM",
                activity: "Discover Shwezigon Pagoda",
                description:
                    "Admire the golden pagoda and learn about its religious importance."
            },
            {
                time: "11:00 AM",
                activity: "Visit Dhammayangyi Temple",
                description:
                    "Explore the impressive brick architecture of this historic monument."
            },
            {
                time: "12:30 PM",
                activity: "Enjoy Local Cuisine",
                description:
                    "Try traditional Burmese food at a local restaurant."
            },
            {
                time: "2:00 PM",
                activity: "Explore the Archaeological Zone",
                description:
                    "Discover more historic temples and enjoy the surrounding landscape."
            },
            {
                time: "4:30 PM",
                activity: "Enjoy a Scenic Viewpoint",
                description:
                    "End the day at an authorized viewpoint and admire the ancient temple landscape."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Check current travel advisories and local security conditions before visiting Myanmar.",
            "Wear comfortable shoes for exploring temple grounds.",
            "Dress modestly at religious sites.",
            "Remove footwear where required by local rules.",
            "Bring drinking water, sunscreen, and a hat.",
            "Respect historic structures and avoid climbing restricted monuments.",
            "Use authorized local guides and transportation.",
            "Check which temples and attractions are currently open before traveling."
        ]
    },

    // ===================================
    // 18. INLE LAKE
    // ===================================

    {
        name: "Inle Lake",
        country: "Myanmar",
        category: "Nature & Culture",
        image: "images/Inle Lake.jpg",
        budget: 65,
        featured: false,

        // 1. Overview
        description:
            "Inle Lake is a beautiful freshwater lake surrounded by mountains, traditional stilt-house villages, and floating gardens. It is famous for its unique fishing culture, traditional boat transportation, and peaceful natural scenery.",

        location: "Shan State, Myanmar",

        history:
            "Inle Lake has been home to the Intha people for generations. Their traditional way of life, including floating agriculture, boat transportation, and distinctive one-leg rowing techniques, has made the lake an important cultural destination.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Traditional Floating Gardens",
                description:
                    "Discover floating gardens where local communities grow vegetables and other crops on the lake."
            },
            {
                name: "Stilt-House Villages",
                description:
                    "Explore traditional wooden houses built above the water and learn about the local lakeside lifestyle."
            },
            {
                name: "Phaung Daw Oo Pagoda",
                description:
                    "Visit one of the lake's most important Buddhist religious landmarks."
            },
            {
                name: "Local Floating Markets",
                description:
                    "Discover traditional markets where local communities trade food, crafts, and everyday goods."
            },
            {
                name: "Traditional Intha Fishing",
                description:
                    "Observe the distinctive fishing techniques and one-leg rowing style associated with Inle Lake."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Experience the unique culture of the Intha people.",
            "Explore beautiful floating gardens and traditional villages.",
            "Enjoy peaceful boat trips across the lake.",
            "Discover traditional crafts and local markets.",
            "Admire the surrounding mountains and natural scenery."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "November to February",
            weather:
                "These months are generally cooler and drier, making outdoor exploration more comfortable.",
            recommendation:
                "Plan a morning boat trip to enjoy the lake scenery and explore its villages and floating gardens."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Explore Life on the Water",
            experience:
                "Take a traditional boat trip across Inle Lake, observe local fishing techniques, explore floating gardens, and discover the unique lifestyle of lakeside communities.",
            culturalSignificance:
                "Inle Lake represents the cultural heritage and traditional way of life of the Intha people, particularly their fishing, farming, and boat-making traditions.",
            recommendation:
                "Respect local communities, ask permission before photographing residents, and bring sun protection for boat trips."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$15–$30" },
            { item: "Food and Drinks", cost: "$8–$15" },
            { item: "Boat Trip", cost: "$10–$20" },
            { item: "Local Transportation", cost: "$5–$10" },
            { item: "Entrance and Activities", cost: "$5–$10" }
        ],

        budgetNote:
        "Estimated daily spending is approximately $43–$85 per person. Actual costs may vary depending on accommodation, transportation, boat services, exchange rates, and current visitor arrangements.",

        // 7. Transportation and Accommodation
        transportation: [
            "Heho Airport is the nearest airport serving the Inle Lake area.",
            "Arrange road transportation from the airport to Nyaungshwe or nearby accommodation.",
            "Use traditional long-tail boats to explore the lake and surrounding villages.",
            "Taxis and private vehicles may be used for local journeys.",
            "Check current travel conditions and transportation availability before planning your visit."
        ],

        accommodation: [
            "Lakeside Resorts — enjoy scenic views and peaceful surroundings.",
            "Boutique Hotels — comfortable accommodation near the lake.",
            "Guesthouses in Nyaungshwe — affordable options close to restaurants and local markets.",
            "Traditional-Style Lodges — experience local architecture and hospitality."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "7:00 AM",
                activity: "Traditional Boat Ride",
                description:
                    "Start the morning with a boat trip across Inle Lake and enjoy the peaceful scenery."
            },
            {
                time: "8:30 AM",
                activity: "Traditional Intha Fishing",
                description:
                    "Observe traditional fishing techniques and learn about the local fishing culture."
            },
            {
                time: "10:00 AM",
                activity: "Explore Floating Gardens",
                description:
                    "Discover the floating gardens and learn about traditional farming methods."
            },
            {
                time: "11:30 AM",
                activity: "Visit Stilt-House Villages",
                description:
                    "Explore traditional lakeside communities and discover their distinctive way of life."
            },
            {
                time: "1:00 PM",
                activity: "Lunch by the Lake",
                description:
                    "Enjoy local Burmese dishes at a restaurant near the lake."
            },
            {
                time: "2:30 PM",
                activity: "Visit Phaung Daw Oo Pagoda",
                description:
                    "Discover one of the lake's important religious landmarks and appreciate its cultural significance."
            },
            {
                time: "4:00 PM",
                activity: "Enjoy the Lake Scenery",
                description:
                    "Take in the surrounding mountains and peaceful atmosphere before returning."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Check current travel advisories and local security conditions before planning a trip to Myanmar.",
            "Bring sunscreen, sunglasses, and a hat for boat trips.",
            "Wear comfortable clothing and shoes.",
            "Bring drinking water and stay hydrated.",
            "Respect local customs when visiting religious sites.",
            "Ask permission before photographing local residents.",
            "Follow boat safety instructions and local regulations.",
            "Check current transportation and visitor arrangements before traveling."
        ]
    },

    // ===================================
    // 19. MANDALAY PALACE
    // ===================================

    {
        name: "Mandalay Palace",
        country: "Myanmar",
        category: "Historical & Cultural",
        image: "images/Mandalay Palace.jpg",
        budget: 65,
        featured: false,

        // 1. Overview
        description:
            "Mandalay Palace is a historic royal palace surrounded by a large moat and fortified walls. Located in the heart of Mandalay, it is famous for its traditional Burmese architecture, golden palace buildings, and important connection to Myanmar's royal history.",

        location: "Mandalay, Myanmar",

        history:
            "Mandalay Palace was built in the 19th century during the reign of King Mindon of the Konbaung Dynasty. It served as the royal residence until the British annexation of Upper Burma in 1885. Much of the original palace was destroyed during World War II and later reconstructed.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Golden Palace Buildings",
                description:
                    "Explore the reconstructed royal buildings decorated with traditional Burmese architectural details and golden designs."
            },
            {
                name: "Palace Watchtower",
                description:
                    "Climb the historic watchtower and enjoy views of the palace grounds and surrounding city."
            },
            {
                name: "Royal Audience Hall",
                description:
                    "Discover the ceremonial space where royal activities and important palace gatherings once took place."
            },
            {
                name: "Surrounding Moat",
                description:
                    "Admire the large moat and fortified walls that surround the historic palace complex."
            },
            {
                name: "Palace Grounds",
                description:
                    "Walk through the spacious grounds and discover the layout of the former royal residence."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Discover the history of Myanmar's last royal dynasty.",
            "Admire traditional Burmese palace architecture.",
            "Learn about the reign of King Mindon.",
            "Explore an important historical landmark in Mandalay.",
            "Enjoy views of the palace grounds and surrounding moat."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "November to February",
            weather:
                "These months are generally cooler and more comfortable for exploring Mandalay.",
            recommendation:
                "Visit in the morning or late afternoon to explore the palace grounds in more comfortable temperatures."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Discover Myanmar's Royal Heritage",
            experience:
                "Explore the reconstructed palace buildings, admire traditional Burmese decorations, and discover the history of the Konbaung Dynasty.",
            culturalSignificance:
                "Mandalay Palace represents an important chapter in Myanmar's royal history and is closely associated with the country's last monarchy.",
            recommendation:
                "Wear comfortable walking shoes, dress respectfully, and allow enough time to explore the palace grounds."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$20–$35" },
            { item: "Food and Drinks", cost: "$8–$15" },
            { item: "Local Transportation", cost: "$5–$10" },
            { item: "Entrance and Activities", cost: "$5–$10" },
            { item: "Additional Expenses", cost: "$5–$10" }
        ],

        budgetNote:
        "Estimated daily spending is approximately $43–$80 per person. Actual costs may vary depending on accommodation, transportation, exchange rates, and current visitor arrangements.",

        // 7. Transportation and Accommodation
        transportation: [
            "Mandalay International Airport is the main airport serving the city.",
            "Use taxis or reputable transportation services to reach the palace.",
            "Local taxis and private vehicles may be used to explore Mandalay.",
            "Some nearby attractions may be reached by bicycle or on foot.",
            "Check current travel advisories, road conditions, and transportation availability before your visit."
        ],

        accommodation: [
            "Hotels in central Mandalay with convenient access to the palace.",
            "Boutique Hotels offering comfortable city accommodation.",
            "Guesthouses with affordable rooms and basic facilities.",
            "Mid-range Hotels near restaurants and other city attractions."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Arrive at Mandalay Palace",
                description:
                    "Begin your visit by exploring the palace entrance and surrounding historic walls."
            },
            {
                time: "8:30 AM",
                activity: "Explore the Golden Palace Buildings",
                description:
                    "Discover the traditional Burmese architecture and reconstructed royal buildings."
            },
            {
                time: "9:30 AM",
                activity: "Visit the Royal Audience Hall",
                description:
                    "Learn about royal ceremonies and the historical role of the palace."
            },
            {
                time: "10:30 AM",
                activity: "Climb the Palace Watchtower",
                description:
                    "Enjoy views of the palace grounds and surrounding city from the watchtower."
            },
            {
                time: "11:30 AM",
                activity: "Explore the Palace Grounds",
                description:
                    "Walk around the historic complex and admire the surrounding moat and walls."
            },
            {
                time: "12:30 PM",
                activity: "Finish Your Visit",
                description:
                    "Take time for photographs and conclude your exploration of Myanmar's royal heritage."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Check current travel advisories and local security conditions before planning a trip to Myanmar.",
            "Confirm current palace opening arrangements and visitor access.",
            "Wear comfortable walking shoes for exploring the grounds.",
            "Bring drinking water and stay hydrated.",
            "Dress respectfully when visiting cultural and religious landmarks.",
            "Ask permission before photographing local residents.",
            "Follow site regulations and instructions from local authorities.",
            "Allow extra time for transportation and changing local conditions."
        ]
    },

    // ===================================
    // 20. GOLDEN ROCK — KYAIKTIYO PAGODA
    // ===================================

    {
        name: "Golden Rock (Kyaiktiyo Pagoda)",
        country: "Myanmar",
        category: "Religious & Cultural",
        image: "images/Golden Rock.jpg",
        budget: 75,
        featured: false,

        // 1. Overview
        description:
            "Golden Rock is one of Myanmar's most remarkable religious landmarks. Located on Mount Kyaiktiyo, this enormous golden boulder appears to balance on the edge of a mountain. It is an important Buddhist pilgrimage destination known for its spiritual atmosphere and spectacular mountain scenery.",

        location: "Kyaiktiyo, Mon State, Myanmar",

        history:
            "Kyaiktiyo Pagoda has been an important Buddhist pilgrimage site for generations. According to Buddhist tradition, the golden boulder is believed to remain balanced because it rests upon a sacred hair relic of the Buddha. The site continues to hold deep religious and cultural significance for Buddhist devotees.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Golden Rock",
                description:
                    "Admire the enormous golden boulder balanced dramatically near the edge of the mountain."
            },
            {
                name: "Kyaiktiyo Pagoda",
                description:
                    "Discover the small pagoda built on top of the famous golden boulder."
            },
            {
                name: "Mountain Viewpoints",
                description:
                    "Enjoy beautiful views of the surrounding mountains and natural landscapes."
            },
            {
                name: "Pilgrimage Areas",
                description:
                    "Observe the religious activities and traditions of Buddhist pilgrims visiting the sacred site."
            },
            {
                name: "Surrounding Mountain Scenery",
                description:
                    "Experience the peaceful atmosphere and scenic environment around Mount Kyaiktiyo."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "See one of Myanmar's most recognizable religious landmarks.",
            "Admire the extraordinary golden boulder balanced on a mountain.",
            "Discover important Buddhist traditions and beliefs.",
            "Experience the spiritual atmosphere of a famous pilgrimage destination.",
            "Enjoy beautiful mountain scenery and viewpoints."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "November to February",
            weather:
                "These months are generally cooler and more comfortable for exploring the mountain area.",
            recommendation:
                "Plan your visit during daylight hours to enjoy the mountain scenery and allow enough time for transportation."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Discover the Sacred Golden Rock",
            experience:
                "Visit the famous golden boulder, admire the small pagoda built upon it, and experience the atmosphere of one of Myanmar's important Buddhist pilgrimage sites.",
            culturalSignificance:
                "Golden Rock is deeply connected to Myanmar's Buddhist faith and religious traditions. It is an important place of pilgrimage for devotees from across the country.",
            recommendation:
                "Dress modestly, respect religious customs, and follow local instructions when visiting the sacred area."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$20–$35" },
            { item: "Food and Drinks", cost: "$8–$15" },
            { item: "Local Transportation", cost: "$10–$20" },
            { item: "Entrance and Activities", cost: "$5–$10" },
            { item: "Additional Expenses", cost: "$5–$10" }
        ],

        budgetNote:
        "Estimated daily spending is approximately $48–$90 per person. Actual costs may vary depending on accommodation, transportation, exchange rates, and current visitor arrangements.",

        // 7. Transportation and Accommodation
        transportation: [
            "Travel by road toward Kyaikto, the town commonly used as a gateway to Golden Rock.",
            "Use local taxis or private vehicles to reach the mountain's transportation area.",
            "Mountain transport services may be available for reaching the upper pilgrimage area.",
            "Some sections may require walking depending on current transportation arrangements.",
            "Check current travel advisories, road conditions, and mountain transportation availability before your visit."
        ],

        accommodation: [
            "Hotels in Kyaikto with convenient access to the mountain area.",
            "Guesthouses offering basic and affordable accommodation.",
            "Hotels near the pilgrimage route for easier access to the site.",
            "Mountain-area accommodation where available and operating."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "7:00 AM",
                activity: "Depart for Mount Kyaiktiyo",
                description:
                    "Begin your journey toward the mountain transportation area after checking local travel conditions."
            },
            {
                time: "8:30 AM",
                activity: "Travel Toward the Mountain",
                description:
                    "Continue toward the upper mountain area using available local transportation."
            },
            {
                time: "10:00 AM",
                activity: "Arrive at Golden Rock",
                description:
                    "Explore the pilgrimage area and admire the remarkable golden boulder."
            },
            {
                time: "11:00 AM",
                activity: "Visit Kyaiktiyo Pagoda",
                description:
                    "Discover the pagoda and learn about the religious traditions associated with the sacred site."
            },
            {
                time: "12:30 PM",
                activity: "Lunch and Rest",
                description:
                    "Enjoy a meal and take a break while experiencing the mountain atmosphere."
            },
            {
                time: "2:00 PM",
                activity: "Explore Mountain Viewpoints",
                description:
                    "Enjoy the surrounding scenery and take photographs from permitted viewpoints."
            },
            {
                time: "3:30 PM",
                activity: "Return Journey",
                description:
                    "Begin the return journey using available transportation and follow local travel instructions."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Check current travel advisories and local security conditions before planning a trip to Myanmar.",
            "Confirm that mountain transportation and visitor facilities are operating before traveling.",
            "Wear comfortable walking shoes for mountain paths.",
            "Dress modestly when visiting Buddhist religious sites.",
            "Bring drinking water and stay hydrated.",
            "Carry suitable clothing for cooler mountain conditions.",
            "Respect worshippers and local religious traditions.",
            "Follow local instructions and transportation safety regulations."
        ]
    },

    // ===================================
    // V. BRUNIE
    // ===================================

    // ===================================
    // 21. SULTAN OMAR ALI SAIFUDDIEN MOSQUE
    // ===================================

    {
        name: "Sultan Omar Ali Saifuddien Mosque",
        country: "Brunei",
        category: "Religious & Cultural",
        image: "images/Sultan Omar Ali Saifuddien Mosque.jpg",
        budget: 60,
        featured: true,

        // 1. Overview
        description:
            "Sultan Omar Ali Saifuddien Mosque is one of Brunei's most famous landmarks and a beautiful example of Islamic architecture. Located in the capital city of Bandar Seri Begawan, the mosque is admired for its golden dome, elegant marble structure, and peaceful lagoon. It represents the country's Islamic heritage and cultural identity.",

        location: "Bandar Seri Begawan, Brunei",

        history:
            "The mosque was named after Sultan Omar Ali Saifuddien III, the 28th Sultan of Brunei. Construction began in 1954, and the mosque was officially opened in 1958. Designed with a combination of Islamic and modern architectural influences, it became an important symbol of Brunei's religious and national identity.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Golden Dome",
                description:
                    "Admire the mosque's magnificent golden dome, one of its most recognizable architectural features."
            },
            {
                name: "Marble Minarets",
                description:
                    "Explore the elegant exterior featuring beautiful marble details and impressive minarets."
            },
            {
                name: "Reflecting Lagoon",
                description:
                    "Enjoy the peaceful lagoon surrounding the mosque, which creates beautiful reflections of the building."
            },
            {
                name: "Royal Barge",
                description:
                    "See the traditional ceremonial barge displayed near the mosque, inspired by a royal vessel from Brunei's history."
            },
            {
                name: "Mosque Gardens",
                description:
                    "Walk around the landscaped grounds and enjoy views of the mosque and surrounding city."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Discover one of Brunei's most recognizable national landmarks.",
            "Admire beautiful Islamic architecture and detailed craftsmanship.",
            "Learn about Brunei's Islamic heritage and royal history.",
            "Enjoy peaceful surroundings and scenic lagoon views.",
            "Capture memorable photographs of the golden dome and mosque."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "February to April",
            weather:
                "These months are generally suitable for outdoor sightseeing, although Brunei has a tropical climate and rainfall can occur throughout the year.",
            recommendation:
                "Visit in the morning or late afternoon for comfortable sightseeing and beautiful natural lighting."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Admire Brunei's Golden Architectural Landmark",
            experience:
                "Walk around the mosque grounds, admire its golden dome, and enjoy the peaceful views across the lagoon. Visitors can also learn about the mosque's architectural and cultural significance.",
            culturalSignificance:
                "The mosque represents Brunei's Islamic faith, royal heritage, and national identity. It remains an important place of worship and a symbol of the country.",
            recommendation:
                "Dress modestly, respect worshippers, and check visitor access arrangements before entering the mosque."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$25–$40" },
            { item: "Food and Drinks", cost: "$8–$15" },
            { item: "Local Transportation", cost: "$5–$10" },
            { item: "Entrance and Activities", cost: "$0–$5" },
            { item: "Additional Expenses", cost: "$5–$10" }
        ],

        budgetNote:
            "Estimated daily spending is approximately $43–$80 per person. The mosque grounds can generally be enjoyed without an admission fee, but costs may vary depending on accommodation, transportation, and personal spending.",

        // 7. Transportation and Accommodation
        transportation: [
            "Take a taxi or local ride service to reach the mosque in Bandar Seri Begawan.",
            "Use local buses where routes and schedules are suitable.",
            "Walk from nearby city attractions when weather and distance permit.",
            "Arrange private transportation for a more flexible sightseeing schedule."
        ],

        accommodation: [
            "Hotels in central Bandar Seri Begawan with convenient access to the mosque.",
            "Comfortable city hotels offering restaurants and basic visitor facilities.",
            "Budget guesthouses and affordable accommodation options around the capital."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Arrive at the Mosque",
                description:
                    "Begin your visit by admiring the mosque's impressive exterior and peaceful surroundings."
            },
            {
                time: "9:00 AM",
                activity: "Explore the Mosque Grounds",
                description:
                    "Walk around the landscaped grounds and appreciate the architectural details."
            },
            {
                time: "10:00 AM",
                activity: "Visit the Lagoon",
                description:
                    "Enjoy views of the reflecting lagoon and the traditional royal barge."
            },
            {
                time: "11:00 AM",
                activity: "Photography and Sightseeing",
                description:
                    "Capture photographs of the golden dome and surrounding scenery from permitted areas."
            },
            {
                time: "12:00 PM",
                activity: "Lunch",
                description:
                    "Enjoy local Bruneian food at a nearby restaurant."
            },
            {
                time: "1:30 PM",
                activity: "Explore Bandar Seri Begawan",
                description:
                    "Continue discovering the capital's nearby cultural and historical attractions."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Dress modestly when visiting the mosque.",
            "Check visiting hours and access arrangements before entering.",
            "Respect prayer times and avoid disturbing worshippers.",
            "Remove footwear when required by mosque regulations.",
            "Ask permission before photographing people.",
            "Bring drinking water and sun protection for outdoor sightseeing.",
            "Follow photography restrictions and local religious customs.",
            "Keep the surroundings clean and peaceful."
        ]
    },

    // ===================================
    // 22. ULU TEMBURONG NATIONAL PARK
    // ===================================

    {
        name: "Ulu Temburong National Park",
        country: "Brunei",
        category: "Nature & Adventure",
        image: "images/Ulu Temburong National Park.jpg",
        budget: 85,
        featured: false,

        // 1. Overview
        description:
            "Ulu Temburong National Park is one of Brunei's most remarkable natural treasures. Located in the Temburong District, the park protects a vast area of tropical rainforest filled with diverse wildlife, rivers, and beautiful landscapes. It is an ideal destination for nature lovers and travelers seeking an unforgettable rainforest adventure.",

        location: "Temburong District, Brunei",

        history:
            "Ulu Temburong National Park was established in 1991 to protect Brunei's valuable tropical rainforest and biodiversity. It is part of the country's efforts to conserve its natural environment. The park has become an important destination for eco-tourism, scientific research, and environmental education.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Canopy Walkway",
                description:
                    "Climb the elevated canopy structure for breathtaking views above the rainforest and an opportunity to observe the forest from a different perspective."
            },
            {
                name: "Temburong River",
                description:
                    "Experience the beautiful river that flows through the rainforest and supports the area's natural ecosystem."
            },
            {
                name: "Tropical Rainforest",
                description:
                    "Explore one of Brunei's protected rainforest environments, home to many species of plants and animals."
            },
            {
                name: "Rainforest Waterfalls",
                description:
                    "Discover scenic waterfalls and natural pools in the surrounding forest areas where access is permitted."
            },
            {
                name: "Wildlife and Biodiversity",
                description:
                    "Look out for tropical birds, insects, monkeys, and other wildlife living within the protected rainforest."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Explore one of Brunei's most important protected rainforest areas.",
            "Experience the excitement of walking above the rainforest canopy.",
            "Discover the country's rich biodiversity and natural ecosystems.",
            "Enjoy river journeys and beautiful tropical landscapes.",
            "Learn about rainforest conservation and sustainable tourism."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "February to April",
            weather:
                "These months are generally considered more suitable for outdoor activities, although rainfall is possible throughout the year because of Brunei's tropical climate.",
            recommendation:
                "Choose a day with suitable weather for rainforest activities and check river and tour conditions before departure."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Experience the Rainforest Canopy",
            experience:
                "Travel through the rainforest by river and explore the elevated canopy walkway. Enjoy the peaceful sounds of nature while discovering the forest from above.",
            culturalSignificance:
                "Ulu Temburong represents Brunei's commitment to protecting its natural heritage. The rainforest also forms part of the wider environment and traditional landscapes of the Temburong region.",
            recommendation:
                "Join an authorized local eco-tour with an experienced guide to explore the park safely and responsibly."
        },
        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$30–$50" },
            { item: "Food and Drinks", cost: "$10–$15" },
            { item: "Local Transportation", cost: "$10–$20" },
            { item: "Guided Tours and Activities", cost: "$25–$50" },
            { item: "Additional Expenses", cost: "$5–$10" }
        ],

        budgetNote:
            "Estimated daily spending is approximately $80–$145 per person. Guided tours, boat transfers, and accommodation packages can affect the total cost. Confirm current tour prices and included services before booking.",

        // 7. Transportation and Accommodation
        transportation: [
            "Travel from Bandar Seri Begawan toward Temburong using available land or water transportation.",
            "The Sultan Haji Omar Ali Saifuddien Bridge provides a road connection to Temburong District.",
            "Arrange local transportation to the park's visitor access points through an authorized tour operator.",
            "Use guided boat transfers where required for river and rainforest activities.",
            "Confirm transportation arrangements and tour availability before departure."
        ],

        accommodation: [
            "Eco-lodges and nature retreats in or near Temburong District where available.",
            "Guesthouses and local accommodation in Bangar.",
            "Hotels in Bandar Seri Begawan for travelers planning a day trip.",
            "Organized rainforest tour packages that may include overnight accommodation."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "7:00 AM",
                activity: "Depart for Temburong",
                description:
                    "Begin your journey from Bandar Seri Begawan using pre-arranged transportation."
            },
            {
                time: "8:30 AM",
                activity: "Arrive in Temburong",
                description:
                    "Meet your local guide and prepare for the rainforest excursion."
            },
            {
                time: "9:00 AM",
                activity: "River Journey",
                description:
                    "Travel along the river and enjoy views of the surrounding tropical rainforest."
            },
            {
                time: "10:00 AM",
                activity: "Explore the Rainforest",
                description:
                    "Follow your guide through permitted forest trails and discover the local environment."
            },
            {
                time: "11:00 AM",
                activity: "Visit the Canopy Walkway",
                description:
                    "Experience elevated views of the rainforest from the canopy structure, subject to access and weather conditions."
            },
            {
                time: "12:30 PM",
                activity: "Lunch and Rest",
                description:
                    "Enjoy a meal and take a break during your rainforest adventure."
            },
            {
                time: "2:00 PM",
                activity: "Return Journey",
                description:
                    "Travel back with your guide and enjoy the final views of the rainforest and river."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Arrange an authorized guided tour before visiting.",
            "Check weather conditions and river safety before departure.",
            "Wear comfortable walking shoes with good grip.",
            "Bring insect repellent and sun protection.",
            "Carry drinking water and a waterproof bag for personal belongings.",
            "Follow your guide's instructions throughout the trip.",
            "Avoid feeding or disturbing wild animals.",
            "Do not leave rubbish in the rainforest.",
            "Respect the park's conservation rules and protected environment."
        ]
    },

    // ===================================
    // 23. KAMPONG AYER
    // ===================================

    {
        name: "Kampong Ayer",
        country: "Brunei",
        category: "Cultural & Historical",
        image: "images/Kampong Ayer.jpg",
        budget: 55,
        featured: false,

        // 1. Overview
        description:
            "Kampong Ayer is a historic water village located along the Brunei River in Bandar Seri Begawan. Known for its traditional houses built on stilts above the water, the village represents an important part of Brunei's cultural heritage. Visitors can explore its wooden walkways, discover traditional lifestyles, and enjoy beautiful views of the river.",

        location: "Brunei River, Bandar Seri Begawan, Brunei",

        history:
            "Kampong Ayer has a history stretching back many centuries and was once the center of settlement and daily life in Brunei. The water village developed into a large community with homes, schools, mosques, and other facilities built above the river. It played an important role in the country's history, trade, and cultural development.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Traditional Stilt Houses",
                description:
                    "Discover the traditional wooden homes built above the river, showcasing the unique architecture of the water village."
            },
            {
                name: "Wooden Walkways",
                description:
                    "Walk along elevated wooden pathways connecting different parts of the village and its communities."
            },
            {
                name: "Kampong Ayer Cultural and Tourism Gallery",
                description:
                    "Learn about the history, traditional lifestyles, and cultural importance of Kampong Ayer through exhibits and displays."
            },
            {
                name: "Brunei River",
                description:
                    "Enjoy beautiful river views and observe the boats that connect the water village with the surrounding city."
            },
            {
                name: "Traditional Water Village Lifestyle",
                description:
                    "Experience the daily life of local residents and discover how the community maintains its traditions while adapting to modern living."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Discover one of Brunei's most historic and distinctive communities.",
            "Explore traditional houses built above the water.",
            "Learn about Brunei's history, culture, and traditional lifestyle.",
            "Experience a unique village environment along the Brunei River.",
            "Enjoy boat rides and scenic views of the water village."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "February to April",
            weather:
                "Brunei has a tropical climate with warm temperatures and rainfall throughout the year. These months are generally suitable for outdoor sightseeing, although weather conditions can vary.",
            recommendation:
                "Visit in the morning or late afternoon for more comfortable temperatures and pleasant river views."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Discover Life on the Water",
            experience:
                "Take a traditional water taxi along the Brunei River, explore the village walkways, and observe the unique homes and community spaces built above the water.",
            culturalSignificance:
                "Kampong Ayer represents centuries of Brunei's settlement history and traditional river-based lifestyle. It remains an important symbol of the country's cultural identity.",
            recommendation:
                "Consider visiting the cultural gallery and taking a guided boat tour to learn more about the village's history and traditions."
        },
        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$25–$40" },
            { item: "Food and Drinks", cost: "$8–$15" },
            { item: "Water Taxi and Transportation", cost: "$5–$10" },
            { item: "Entrance and Activities", cost: "$0–$5" },
            { item: "Additional Expenses", cost: "$5–$10" }
        ],

        budgetNote:
            "Estimated daily spending is approximately $43–$80 per person. Actual costs depend on accommodation, water taxi arrangements, meals, and personal activities.",

        // 7. Transportation and Accommodation
        transportation: [
            "Take a water taxi from the waterfront area in Bandar Seri Begawan to reach different parts of Kampong Ayer.",
            "Use local taxis or ride services to reach the main waterfront.",
            "Explore connected sections of the village using the wooden walkways.",
            "Arrange a local boat tour for a closer look at the water village and surrounding river."
        ],

        accommodation: [
            "Hotels in central Bandar Seri Begawan with convenient access to the waterfront.",
            "Budget guesthouses and affordable city accommodation.",
            "Comfortable hotels near the main attractions and shopping areas.",
            "Local accommodation options in the capital for visitors exploring Kampong Ayer."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Arrive at the Waterfront",
                description:
                    "Begin your visit at the Bandar Seri Begawan waterfront and enjoy views of the Brunei River."
            },
            {
                time: "8:30 AM",
                activity: "Take a Water Taxi",
                description:
                    "Travel across the river by local water taxi and enjoy views of the traditional village."
            },
            {
                time: "9:00 AM",
                activity: "Explore the Water Village",
                description:
                    "Discover the traditional stilt houses, wooden walkways, and community surroundings."
            },
            {
                time: "10:00 AM",
                activity: "Visit the Cultural Gallery",
                description:
                    "Learn about the history and cultural significance of Kampong Ayer through its exhibits."
            },
            {
                time: "11:00 AM",
                activity: "Enjoy River Views",
                description:
                    "Take photographs and appreciate the scenery along the Brunei River."
            },
            {
                time: "12:00 PM",
                activity: "Lunch",
                description:
                    "Enjoy local Bruneian food at a nearby restaurant in the capital."
            },
            {
                time: "1:30 PM",
                activity: "Return to the Waterfront",
                description:
                    "Complete your visit and explore other nearby attractions in Bandar Seri Begawan."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Wear comfortable shoes when exploring the wooden walkways.",
            "Use a licensed or trusted local water taxi service.",
            "Bring drinking water and sun protection.",
            "Ask permission before photographing residents or private homes.",
            "Respect local customs and the privacy of the community.",
            "Be careful when walking along elevated pathways.",
            "Check the cultural gallery's current opening hours before visiting.",
            "Keep the village clean and avoid disturbing local residents."
        ]
    },

    // ===================================
    // 24. ROYAL REGALIA MUSEUM
    // ===================================

    {
        name: "Royal Regalia Museum",
        country: "Brunei",
        category: "Historical & Cultural",
        image: "images/Royal Regalia Museum.jpg",
        budget: 60,
        featured: false,

        // 1. Overview
        description:
            "The Royal Regalia Museum is one of Brunei's most important cultural attractions. Located in the heart of Bandar Seri Begawan, the museum displays royal treasures, ceremonial objects, historical photographs, and gifts presented to the Sultan. It offers visitors an opportunity to discover Brunei's royal heritage and the history of its monarchy.",

        location: "Bandar Seri Begawan, Brunei",

        history:
            "The museum was originally established as the Churchill Memorial Building and was later transformed into the Royal Regalia Exhibition Hall. It was officially opened as the Royal Regalia Museum in 1992 to commemorate the Silver Jubilee of Sultan Hassanal Bolkiah's reign. The museum preserves important objects connected to the Sultan, the royal family, and Brunei's national history.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Royal Chariot",
                description:
                    "Discover the magnificent ceremonial royal chariot used during important royal celebrations and processions."
            },
            {
                name: "Royal Crowns and Regalia",
                description:
                    "Explore displays of royal crowns, ceremonial ornaments, and other objects associated with Brunei's monarchy."
            },
            {
                name: "Royal Ceremonial Weapons",
                description:
                    "View traditional ceremonial weapons and decorative objects representing the country's royal traditions."
            },
            {
                name: "Royal Gifts Exhibition",
                description:
                    "Discover gifts and valuable objects presented to the Sultan by foreign leaders and visitors."
            },
            {
                name: "Historical Photographs and Displays",
                description:
                    "Learn about important moments in Brunei's royal history through photographs, documents, and museum exhibits."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Discover Brunei's royal history and national heritage.",
            "See impressive ceremonial objects and royal treasures.",
            "Learn about the country's monarchy and important historical events.",
            "Admire traditional craftsmanship and royal decorations.",
            "Experience one of Bandar Seri Begawan's most interesting cultural museums."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "February to April",
            weather:
                "Brunei has a tropical climate with warm temperatures and rainfall throughout the year. Since the museum is indoors, it can be visited throughout the year.",
            recommendation:
                "Visit in the morning or early afternoon to allow enough time to explore the exhibitions at a comfortable pace. Check current opening hours before arriving."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Discover Brunei's Royal Treasures",
            experience:
                "Explore the museum's impressive collection of royal regalia, admire the ceremonial royal chariot, and discover objects that tell the story of Brunei's royal traditions.",
            culturalSignificance:
                "The museum preserves important objects connected to Brunei's monarchy and national identity. Its collections help visitors understand the country's royal traditions, historical development, and cultural heritage.",
            recommendation:
            "Take your time exploring the exhibitions and read the displays to understand the stories behind the royal objects."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$25–$40" },
            { item: "Food and Drinks", cost: "$8–$15" },
            { item: "Local Transportation", cost: "$5–$10" },
            { item: "Museum Admission", cost: "$0–$5" },
            { item: "Additional Expenses", cost: "$5–$10" }
        ],

        budgetNote:
            "Estimated daily spending is approximately $43–$80 per person. Museum admission arrangements and other expenses should be checked before visiting. Actual costs depend on accommodation, transportation, and personal spending.",

        // 7. Transportation and Accommodation
        transportation: [
            "Take a taxi or local ride service to reach the museum in central Bandar Seri Begawan.",
            "Walk from nearby city attractions when weather and distance permit.",
            "Use local buses where routes and schedules are suitable.",
            "Arrange private transportation for a flexible sightseeing schedule."
        ],

        accommodation: [
            "Hotels in central Bandar Seri Begawan near the museum and other city attractions.",
            "Budget guesthouses offering affordable accommodation.",
            "Comfortable city hotels with restaurants and visitor facilities.",
            "Accommodation near the waterfront for convenient access to cultural attractions."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:30 AM",
                activity: "Arrive at the Museum",
                description:
                    "Begin your visit at the Royal Regalia Museum and admire its exterior architecture."
            },
            {
                time: "9:00 AM",
                activity: "Explore the Royal Chariot",
                description:
                    "Discover the impressive ceremonial chariot and learn about its role in royal celebrations."
            },
            {
                time: "10:00 AM",
                activity: "View Royal Regalia",
                description:
                    "Explore the crowns, ceremonial ornaments, and other objects associated with Brunei's monarchy."
            },
            {
                time: "11:00 AM",
                activity: "Discover Historical Exhibitions",
                description:
                    "Learn about the Sultan, royal traditions, and important moments in Brunei's history."
            },
            {
                time: "12:00 PM",
                activity: "Lunch",
                description:
                    "Enjoy local Bruneian food at a nearby restaurant in Bandar Seri Begawan."
            },
            {
                time: "1:30 PM",
                activity: "Explore Nearby Attractions",
                description:
                    "Continue sightseeing around the capital and discover other cultural and historical landmarks."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Check the museum's current opening hours before visiting.",
            "Allow enough time to explore the different exhibitions.",
            "Follow museum rules regarding photography.",
            "Do not touch displayed objects or exhibition materials.",
            "Read the information panels to learn about the historical collections.",
            "Wear comfortable clothing and shoes.",
            "Respect other visitors and maintain a quiet environment.",
            "Keep personal belongings secure while exploring."
        ]
    },

    // ===================================
    // 25. TASEK MERIMBUN HERITAGE PARK
    // ===================================

    {
        name: "Tasek Merimbun Heritage Park",
        country: "Brunei",
        category: "Nature & Wildlife",
        image: "images/Tasek Merimbun Heritage Park.jpg",
        budget: 70,
        featured: false,

        // 1. Overview
        description:
            "Tasek Merimbun Heritage Park is one of Brunei's most beautiful natural attractions. Located in Tutong District, it is famous for its large blackwater lake, surrounding wetlands, and rich biodiversity. Recognized as an ASEAN Heritage Park, the destination offers visitors a peaceful environment to explore nature, discover wildlife, and learn about traditional Dusun culture.",

        location: "Tutong District, Brunei",

        history:
            "Tasek Merimbun was declared an ASEAN Heritage Park on November 29, 1984. It is an important natural and cultural heritage area in Brunei, serving as a wildlife sanctuary, recreational destination, and place for scientific research and environmental education. The surrounding region is also associated with the traditional heritage of the Dusun community.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Tasek Merimbun Blackwater Lake",
                description:
                    "Discover Brunei's largest natural lake, known for its distinctive dark-colored water and peaceful natural surroundings."
            },
            {
                name: "Pulau Jeludong",
                description:
                    "Explore the island area connected by a walkway and discover its archaeological and cultural significance."
            },
            {
                name: "Wooden Walkways",
                description:
                    "Walk along elevated wooden pathways that provide scenic views of the lake and surrounding wetlands."
            },
            {
                name: "Rainforest and Wetland Trails",
                description:
                    "Explore the natural environment and discover the variety of plants and wildlife found within the protected park."
            },
            {
                name: "Traditional Dusun Heritage",
                description:
                    "Learn about the traditions and cultural heritage of the Dusun community through traditional displays and local heritage features."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Discover Brunei's largest natural lake.",
            "Explore an internationally recognized ASEAN Heritage Park.",
            "Experience beautiful wetlands and tropical forest landscapes.",
            "Learn about the traditional culture of the Dusun community.",
            "Enjoy nature walks, birdwatching, and peaceful outdoor activities.",
            "Discover the area's important biodiversity and conservation value."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "February to April",
            weather:
                "Brunei has a tropical climate with warm temperatures and rainfall throughout the year. Drier periods can make outdoor exploration more comfortable, although conditions may change.",
            recommendation:
                "Visit in the morning when temperatures are generally more comfortable for walking and wildlife observation. Check weather conditions and park access before traveling."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Discover Brunei's Beautiful Blackwater Lake",
            experience:
                "Enjoy the peaceful scenery of Tasek Merimbun, explore the wooden walkways, and discover the surrounding wetlands. Visitors may also enjoy a lake cruise or boat experience when available.",
            culturalSignificance:
            "Tasek Merimbun represents both the natural and cultural heritage of Brunei. The area is connected to the traditional heritage of the Dusun community and plays an important role in wildlife conservation and environmental education.",
            recommendation:
                "Take time to explore the lake surroundings, learn about the local heritage, and observe wildlife without disturbing its natural habitat."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$25–$40" },
            { item: "Food and Drinks", cost: "$8–$15" },
            { item: "Local Transportation", cost: "$15–$25" },
            { item: "Entrance and Activities", cost: "$0–$10" },
            { item: "Additional Expenses", cost: "$5–$10" }
        ],

        budgetNote:
            "Estimated daily spending is approximately $53–$100 per person. Actual costs may vary depending on accommodation, transportation, boat activities, and current park services.",

        // 7. Transportation and Accommodation
        transportation: [
            "Travel by private car or arranged transportation from Bandar Seri Begawan toward Tutong District.",
            "Arrange a taxi or local ride service for the journey to the heritage park.",
            "Allow sufficient travel time when planning a visit from the capital.",
            "Check road conditions and arrange return transportation before departure.",
            "Confirm the availability of boat rides and other activities with local park authorities."
        ],

        accommodation: [
            "Hotels and guesthouses in Tutong District.",
            "Hotels in Bandar Seri Begawan for visitors planning a day trip.",
            "Local accommodation options offering convenient access to nearby attractions.",
            "Nature-oriented accommodation in the surrounding region where available."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Depart for Tasek Merimbun",
                description:
                    "Begin your journey toward Tutong District using pre-arranged transportation."
            },
            {
                time: "9:30 AM",
                activity: "Arrive at the Heritage Park",
                description:
                    "Explore the visitor area and enjoy your first views of the surrounding natural landscape."
            },
            {
                time: "10:00 AM",
                activity: "Explore the Blackwater Lake",
                description:
                    "Discover the beautiful lake and observe its unique dark-colored water."
            },
            {
                time: "11:00 AM",
                activity: "Walk Along the Wooden Pathways",
                description:
                    "Enjoy the scenery and explore accessible walkways around the lake."
            },
            {
                time: "12:00 PM",
                activity: "Lunch and Rest",
                description:
                    "Enjoy a meal and take a break before continuing your nature exploration."
            },
            {
                time: "1:00 PM",
                activity: "Discover Local Heritage",
                description:
                    "Learn about the natural environment and traditional Dusun heritage through available cultural displays."
            },
            {
                time: "2:00 PM",
                activity: "Nature Observation",
                description:
                    "Enjoy birdwatching and observe the surrounding wetlands without disturbing wildlife."
            },
            {
                time: "3:00 PM",
                activity: "Return Journey",
                description:
                    "Complete your visit and travel back using your arranged transportation."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Check park opening hours and visitor access before traveling.",
            "Arrange transportation in advance, especially when traveling from Bandar Seri Begawan.",
            "Wear comfortable walking shoes suitable for outdoor trails.",
            "Bring drinking water and insect repellent.",
            "Carry sun protection and suitable clothing for outdoor activities.",
            "Check whether boat rides and lake activities are operating before planning them.",
            "Avoid disturbing wildlife or damaging plants.",
            "Do not leave rubbish in the park.",
            "Respect the natural environment and local cultural heritage."
        ]
    },
    
    // ===================================
    // VI. VIETNAM
    // ===================================

    // ===================================
    // 26. HA LONG BAY
    // ===================================
    {

    name: "Ha Long Bay",
    country: "Vietnam",
    category: "Nature & Landscape",
    image: "images/Ha Long Bay.jpg",
    budget: 120,
    featured: true,

    // 1. Overview
    description: "Ha Long Bay is one of Vietnam's most famous natural wonders, known for its emerald-green waters and thousands of towering limestone islands. Visitors can explore beautiful caves, floating villages, and peaceful beaches while enjoying breathtaking scenery.",
    location: "Quang Ninh Province, northeastern Vietnam.",
    history: "Ha Long Bay has a long history connected to Vietnamese legends and maritime culture. Its name means 'Descending Dragon Bay,' inspired by a legend in which dragons protected Vietnam by creating the islands with jewels and pearls. It was recognized as a UNESCO World Heritage Site in 1994.",

    // 2. Main Attractions
    attractions: [
        {
            name: "Sung Sot Cave",
            description: "One of the largest and most impressive caves in Ha Long Bay, featuring enormous chambers and beautiful limestone formations."
        },
        {
            name: "Ti Top Island",
            description: "A scenic island with a sandy beach and a viewpoint offering panoramic views of the bay."
        },
        {
            name: "Luon Cave",
            description: "A peaceful water cave surrounded by limestone cliffs, commonly explored by kayak or bamboo boat."
        },
        {
            name: "Floating Fishing Villages",
            description: "Traditional communities where visitors can learn about the fishing lifestyle and local culture."
        }
        ],

    // 3. Why Visit?
    reasons: [
        "Experience one of Vietnam's most beautiful natural landscapes.",
        "Explore impressive limestone caves and islands.",
        "Enjoy kayaking, swimming, and boat cruises.",
        "Discover traditional floating fishing villages.",
        "Capture unforgettable photographs of the emerald waters and dramatic scenery."
        ],

    // 4. Best Time to Visit
    bestTime: {
        season: "October to April.",
        weather: "The weather is generally cooler and more comfortable, although conditions can vary throughout the season.",
        recommendation: "October to November and March to April are popular periods for sightseeing and outdoor activities. Always check weather and cruise conditions before traveling."
    },

    // 5. Special Experience
    specialExperience: {
        title: "Overnight Cruise Through Ha Long Bay",
        experience: "Enjoy an overnight cruise surrounded by limestone islands, with opportunities for kayaking, cave exploration, sunset viewing, and relaxing on the water.",
        culturalSignificance: "Ha Long Bay represents Vietnam's natural heritage and is closely connected to local legends, fishing traditions, and coastal life.",
        recommendation: "Choose a reputable cruise that includes guided activities and enough time to explore the bay."
    },

    // 6. Estimated Budget
    budgetDetails: [
        { item: "Accommodation", cost: "$20–$50 per night" },
        { item: "Food and Drinks", cost: "$10–$20 per day" },
        { item: "Transportation", cost: "$10–$30" },
        { item: "Cruise and Activities", cost: "$30–$100+" },
        { item: "Entrance Fees", cost: "$5–$15" }
        ],
    budgetNote: "A basic day visit may cost less, while overnight cruises and premium experiences can increase the total budget. Prices vary by season and service provider.",

    // 7. Transportation and Accommodation
    transportation: [
        "Travel from Hanoi to Ha Long City by bus, limousine van, or private car.",
        "Join a boat cruise to explore the islands and caves.",
        "Use local taxis or shuttle services to reach nearby attractions."
        ],
    accommodation: [
        "Budget hostels and guesthouses in Ha Long City.",
        "Mid-range hotels near Bai Chay Beach.",
        "Luxury hotels and overnight cruise accommodations."
        ],

    // 8. Suggested Itinerary
    itinerary: [
        {
            time: "8:00 AM",
            activity: "Travel to Ha Long Bay",
            description: "Depart from Hanoi and enjoy the journey toward the beautiful coastal region."
        },
        {
            time: "11:30 AM",
            activity: "Begin the Bay Cruise",
            description: "Board a cruise boat and enjoy the spectacular limestone island scenery."
        },
        {
            time: "1:00 PM",
            activity: "Explore Sung Sot Cave",
            description: "Discover impressive rock formations inside one of the bay's most famous caves."
        },
        {
            time: "3:00 PM",
            activity: "Visit Ti Top Island",
            description: "Relax on the beach or climb to the viewpoint for panoramic views."
        },
        {
            time: "4:30 PM",
            activity: "Kayaking at Luon Cave",
            description: "Enjoy a peaceful kayaking or bamboo boat experience surrounded by limestone cliffs."
        }
        ],

    // 9. Travel Tips
    tips: [
        "Book cruises with reputable operators.",
        "Bring sunscreen, sunglasses, and a hat.",
        "Wear comfortable shoes for cave exploration.",
        "Carry a camera to capture the beautiful scenery.",
        "Check weather conditions because cruises may be changed or canceled during storms.",
        "Respect the environment and avoid leaving litter in the bay."
        ]
    },

    // ===================================
    // 27. HOI AN ANCIENT TOWN
    // ===================================

    {
        name: "Hoi An Ancient Town",
        country: "Vietnam",
        category: "Historical & Cultural",
        image: "images/Hoi An Ancient Town.jpg",
        budget: 90,
        featured: false,

        // 1. Overview
        description: "Hoi An Ancient Town is a charming historic town famous for its colorful lanterns, traditional architecture, and peaceful riverside atmosphere. Once an important international trading port, it preserves a unique blend of Vietnamese, Chinese, Japanese, and European influences.",
        location: "Quang Nam Province, central Vietnam.",
        history: "Hoi An became an important trading port between the 15th and 19th centuries, attracting merchants from different countries. Its historic buildings and cultural traditions reflect centuries of international trade. It was designated a UNESCO World Heritage Site in 1999.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Japanese Covered Bridge",
                description: "A famous historic bridge built by the Japanese community, recognized for its distinctive architecture and cultural importance."
            },
            {
                name: "Hoi An Ancient Houses",
                description: "Traditional wooden houses that preserve the architectural style and lifestyle of the town's former merchant families."
            },
            {
                name: "Hoi An Night Market",
                description: "A lively market filled with colorful lanterns, local food, handmade souvenirs, and traditional crafts."
            },
            {
                name: "Thu Bon River",
                description: "A beautiful riverside area where visitors can enjoy boat rides and admire the town's lantern-lit scenery."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Experience one of Vietnam's most beautiful historic towns.",
            "Discover traditional Vietnamese architecture and cultural heritage.",
            "Enjoy colorful lanterns and romantic riverside views.",
            "Explore local markets, handmade crafts, and traditional food.",
            "Learn about the town's history as an international trading port."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "February to April.",
            weather: "The weather is generally warm, pleasant, and suitable for walking around the ancient town.",
            recommendation: "Visit during the dry season for comfortable sightseeing. Evening visits are especially beautiful when the lanterns illuminate the streets and river."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Lantern Boat Ride on the Thu Bon River",
            experience: "Take a traditional boat ride along the Thu Bon River at night, admire the glowing lanterns, and release a small floating lantern as part of a local tradition.",
            culturalSignificance: "Lanterns symbolize hope, happiness, and good fortune. They have become an important part of Hoi An's cultural identity and nighttime atmosphere.",
            recommendation: "Visit in the evening to enjoy the lantern-lit streets and river. Ask local boat operators about safe and respectful lantern activities."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$15–$40 per night" },
            { item: "Food and Drinks", cost: "$8–$15 per day" },
            { item: "Transportation", cost: "$5–$15" },
            { item: "Entrance Ticket", cost: "$5–$10" },
            { item: "Boat Ride and Activities", cost: "$5–$20" }
        ],
        budgetNote: "A comfortable visit can be affordable, especially when staying in guesthouses and enjoying local food. Costs vary depending on accommodation and activities.",
        // 7. Transportation and Accommodation
        transportation: [
            "Fly to Da Nang International Airport and travel to Hoi An by taxi, shuttle, or private car.",
            "Explore the ancient town on foot because many central streets are pedestrian-friendly.",
            "Rent a bicycle to visit nearby villages and beaches.",
            "Use local taxis or ride-hailing services for longer journeys."
        ],
        accommodation: [
            "Budget hostels and guesthouses near the ancient town.",
            "Mid-range hotels with traditional Vietnamese design.",
            "Riverside resorts and boutique hotels for a relaxing stay."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Explore the Ancient Town",
                description: "Walk through historic streets and admire the traditional architecture."
            },
            {
                time: "10:00 AM",
                activity: "Visit the Japanese Covered Bridge",
                description: "Discover one of Hoi An's most famous historic landmarks."
            },
            {
                time: "12:00 PM",
                activity: "Enjoy Local Vietnamese Food",
                description: "Try traditional dishes such as Cao Lau noodles and Hoi An chicken rice."
            },
            {
                time: "2:00 PM",
                activity: "Explore Traditional Houses and Markets",
                description: "Visit historic merchant houses and browse local handicrafts."
            },
            {
                time: "6:00 PM",
                activity: "Enjoy the Lantern-lit Evening",
                description: "Visit the night market and take a boat ride along the Thu Bon River."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Wear comfortable shoes because the ancient town is best explored on foot.",
            "Visit early in the morning to avoid large crowds.",
            "Bring cash for small shops, markets, and local activities.",
            "Try traditional Hoi An dishes during your visit.",
            "Respect historic buildings and local cultural traditions.",
            "Bring an umbrella or raincoat during the rainy season."
        ]
    },

    // ===================================
    // 28. HANOI OLD QUARTER
    // ===================================

    {
        name: "Hanoi Old Quarter",
        country: "Vietnam",
        category: "Historical & Cultural",
        image: "images/Hanoi Old Quarter.jpg",
        budget: 80,
        featured: false,

        // 1. Overview
        description: "Hanoi Old Quarter is one of Vietnam's most lively and historic neighborhoods, famous for its narrow streets, traditional shop houses, street food, and busy local markets. It offers visitors a glimpse into everyday Vietnamese life while preserving the city's rich cultural heritage.",
        location: "Hoan Kiem District, central Hanoi, Vietnam.",
        history: "The Old Quarter developed over many centuries as a center for trade and traditional craftsmanship. Its streets were historically associated with different trades and products, giving the neighborhood its distinctive character. Today, it remains an important cultural and commercial area of Hanoi.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Hoan Kiem Lake",
                description: "A beautiful lake in the heart of Hanoi, surrounded by walking paths, historic landmarks, and peaceful green spaces."
            },
            {
                name: "St. Joseph's Cathedral",
                description: "A historic Gothic-style cathedral known for its impressive architecture and connection to Hanoi's colonial history."
            },
            {
                name: "Dong Xuan Market",
                description: "One of Hanoi's largest traditional markets, offering clothing, souvenirs, household goods, and local products."
            },
            {
                name: "Ta Hien Street",
                description: "A popular and energetic street known for its food stalls, local restaurants, and lively evening atmosphere."
            },
            {
                name: "Train Street",
                description: "A narrow railway street where residential buildings stand close to the railway tracks. Visitors should follow official access rules and safety instructions."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Experience the traditional lifestyle and atmosphere of Hanoi.",
            "Explore historic streets and distinctive Vietnamese architecture.",
            "Discover delicious Vietnamese street food and local coffee.",
            "Shop for souvenirs, handmade products, and traditional goods.",
            "Visit famous landmarks and learn about the city's history."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "September to November and March to April.",
            weather: "Autumn and spring generally offer comfortable temperatures and pleasant conditions for walking around the city.",
            recommendation: "Visit during autumn for cooler weather and beautiful city scenery. Early mornings and evenings are especially enjoyable for exploring the neighborhood."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Hanoi Street Food and Walking Tour",
            experience: "Explore the narrow streets with a local guide, taste traditional Vietnamese dishes, enjoy authentic Vietnamese coffee, and discover hidden shops and historic corners.",
            culturalSignificance: "Street food, traditional shops, and neighborhood markets are important parts of Hanoi's everyday culture. The Old Quarter reflects generations of craftsmanship, commerce, and community life.",
            recommendation: "Try local specialties such as Pho, Bun Cha, Banh Mi, and Vietnamese egg coffee while exploring the area."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$15–$40 per night" },
            { item: "Food and Drinks", cost: "$8–$15 per day" },
            { item: "Transportation", cost: "$3–$10" },
            { item: "Sightseeing and Entrance Fees", cost: "$5–$15" },
            { item: "Shopping and Activities", cost: "$10–$25" }
        ],
        budgetNote: "Hanoi Old Quarter is suitable for budget travelers because many attractions can be explored on foot and local street food is affordable. Actual costs depend on accommodation, shopping, and activities.",

        // 7. Transportation and Accommodation
        transportation: [
            "Travel from Noi Bai International Airport to the Old Quarter by airport bus, shuttle, taxi, or private transfer.",
            "Walk around the neighborhood to explore its narrow streets and historic attractions.",
            "Use local buses or ride-hailing services for destinations farther away.",
            "Rent a bicycle or use other local transportation options where available."
        ],
        accommodation: [
            "Budget hostels and guesthouses in the Old Quarter.",
            "Mid-range hotels near Hoan Kiem Lake.",
            "Boutique hotels with traditional Vietnamese design.",
            "Luxury hotels offering convenient access to central Hanoi."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Visit Hoan Kiem Lake",
                description: "Enjoy a peaceful morning walk around the lake and admire the surrounding scenery."
            },
            {
                time: "9:30 AM",
                activity: "Explore the Old Quarter Streets",
                description: "Discover traditional shop houses, local businesses, and historic streets."
            },
            {
                time: "11:00 AM",
                activity: "Visit Dong Xuan Market",
                description: "Browse local products, souvenirs, clothing, and traditional goods."
            },
            {
                time: "12:30 PM",
                activity: "Enjoy Vietnamese Street Food",
                description: "Taste famous local dishes such as Pho, Bun Cha, and Banh Mi."
            },
            {
                time: "3:00 PM",
                activity: "Visit St. Joseph's Cathedral",
                description: "Admire the historic architecture and explore the surrounding neighborhood."
            },
            {
                time: "6:00 PM",
                activity: "Experience the Evening Atmosphere",
                description: "Explore Ta Hien Street, enjoy local food, and experience the lively nighttime atmosphere."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Wear comfortable shoes because walking is the best way to explore the Old Quarter.",
            "Be careful when crossing busy streets and watch for motorbikes.",
            "Carry small amounts of cash for street food and local markets.",
            "Try local dishes and traditional Vietnamese coffee.",
            "Keep personal belongings secure in crowded areas.",
            "Respect local residents and avoid entering private properties.",
            "Follow official safety rules when visiting railway areas such as Train Street."
        ]
    },

    // ===================================
    // 29. GOLDEN BRIDGE
    // ===================================

    {
        name: "Golden Bridge",
        country: "Vietnam",
        category: "Architecture & Sightseeing",
        image: "images/Golden Bridge.jpg",
        budget: 100,
        featured: false,

        // 1. Overview
        description: "The Golden Bridge is a remarkable pedestrian bridge located in the Ba Na Hills mountain resort. Famous for its golden walkway supported by two enormous stone-like hands, the bridge offers breathtaking views of the surrounding mountains and forests. Its unique design has made it one of Vietnam's most recognizable attractions.",
        location: "Ba Na Hills, near Da Nang City, central Vietnam.",
        history: "The Golden Bridge opened to visitors in June 2018 as part of the Ba Na Hills tourism development project. Designed by Vietnamese architecture firm TA Landscape Architecture, it quickly gained international attention for its unusual design and dramatic mountain setting.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Golden Bridge",
                description: "The main attraction, featuring a curved golden walkway held by two enormous sculpted hands above the mountains."
            },
            {
                name: "Ba Na Hills Cable Car",
                description: "A scenic cable car journey offering spectacular views of mountains, forests, and waterfalls."
            },
            {
                name: "French Village",
                description: "A European-inspired village featuring impressive architecture, cobblestone streets, restaurants, and entertainment."
            },
            {
                name: "Le Jardin D'Amour",
                description: "A collection of beautiful themed gardens with colorful flowers, decorative landscapes, and peaceful walking paths."
            },
            {
                name: "Fantasy Park",
                description: "An indoor entertainment complex offering games, rides, and activities for visitors of different ages."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "See one of Vietnam's most distinctive architectural attractions.",
            "Enjoy panoramic views of the surrounding mountains and forests.",
            "Experience the famous giant stone hands supporting the bridge.",
            "Explore the beautiful gardens and attractions of Ba Na Hills.",
            "Take memorable photographs of the spectacular scenery."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "February to May.",
            weather: "The weather is generally more comfortable during this period, with relatively favorable conditions for sightseeing.",
            recommendation: "Visit early in the morning to enjoy clearer views and avoid some of the larger crowds. Mountain weather can change quickly, so check the forecast before traveling."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Walking Above the Mountains",
            experience: "Walk along the beautiful golden pathway while enjoying the impressive mountain scenery. Take photographs of the giant hands and experience the unique atmosphere above the clouds.",
            culturalSignificance: "The Golden Bridge represents modern Vietnamese creativity and architectural innovation. It has also become an international symbol of Vietnam's growing tourism industry.",
            recommendation: "Take the cable car to Ba Na Hills early in the day and allow enough time to explore the bridge and surrounding attractions."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$20–$50 per night" },
            { item: "Food and Drinks", cost: "$10–$20 per day" },
            { item: "Transportation", cost: "$5–$20" },
            { item: "Ba Na Hills Entrance and Cable Car", cost: "$35–$50" },
            { item: "Additional Activities", cost: "$5–$20" }
        ],
        budgetNote: "Most visitors explore the Golden Bridge as part of a Ba Na Hills day trip. Ticket prices and additional activity costs may change depending on the season and ticket package.",

        // 7. Transportation and Accommodation
        transportation: [
            "Fly to Da Nang International Airport and travel toward Ba Na Hills by taxi, shuttle, or private car.",
            "Use the Ba Na Hills cable car system to reach the mountain resort.",
            "Explore the Golden Bridge and nearby attractions on foot.",
            "Book an organized tour from Da Nang or Hoi An for convenient transportation."
        ],
        accommodation: [
            "Budget hotels and guesthouses in Da Nang City.",
            "Mid-range hotels near My Khe Beach.",
            "Boutique hotels in Hoi An for visitors exploring central Vietnam.",
            "Resort accommodation within the Ba Na Hills area for a special mountain stay."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "7:30 AM",
                activity: "Travel to Ba Na Hills",
                description: "Depart from Da Nang and enjoy the scenic journey toward the mountain resort."
            },
            {
                time: "9:00 AM",
                activity: "Take the Cable Car",
                description: "Enjoy beautiful views of the mountains and forests during the cable car journey."
            },
            {
                time: "10:00 AM",
                activity: "Visit the Golden Bridge",
                description: "Walk across the famous golden pathway and take photographs of the giant hands."
            },
            {
                time: "11:30 AM",
                activity: "Explore Le Jardin D'Amour",
                description: "Discover the colorful gardens and enjoy the peaceful mountain scenery."
            },
            {
                time: "1:00 PM",
                activity: "Enjoy Lunch",
                description: "Relax and enjoy a meal at one of the restaurants in Ba Na Hills."
            },
            {
                time: "2:30 PM",
                activity: "Explore French Village and Fantasy Park",
                description: "Discover the European-inspired architecture and enjoy indoor entertainment."
            },
            {
                time: "4:30 PM",
                activity: "Return to Da Nang",
                description: "Take the cable car back down and travel to the city."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Arrive early to avoid large crowds at the Golden Bridge.",
            "Bring a light jacket because mountain temperatures can be cooler.",
            "Wear comfortable shoes for walking around the resort.",
            "Check weather conditions because fog and rain can affect visibility.",
            "Bring a camera or phone to capture the mountain scenery.",
            "Check current entrance ticket prices before visiting.",
            "Allow a full day to explore Ba Na Hills comfortably."
        ]
    },
    
    // ===================================
    // 30. PHONG NHA-KE BANG NATIONAL PARK
    // ===================================

    {
        name: "Phong Nha-Ke Bang National Park",
        country: "Vietnam",
        category: "Nature & Adventure",
        image: "images/Phong Nha-Ke Bang National Park.jpg",
        budget: 85,
        featured: false,

        // 1. Overview
        description: "Phong Nha-Ke Bang National Park is a spectacular natural destination famous for its enormous limestone mountains, ancient caves, underground rivers, and rich biodiversity. It is home to some of the world's most impressive cave systems, including Son Doong Cave, the largest known cave passage by volume.",
        location: "Quang Binh Province, central Vietnam.",
        history: "The national park protects an ancient limestone landscape formed over millions of years. Its remarkable geological features and biodiversity led to its recognition as a UNESCO World Heritage Site in 2003, with its protected area later expanded in 2015. The region is also known for its important historical connections to the Ho Chi Minh Trail.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Phong Nha Cave",
                description: "A beautiful underground cave featuring impressive limestone formations and an underground river that visitors can explore by boat."
            },
            {
                name: "Paradise Cave",
                description: "A magnificent dry cave known for its enormous chambers, spectacular stalactites, and impressive stalagmites."
            },
            {
                name: "Son Doong Cave",
                description: "The world's largest known cave passage by volume, featuring enormous chambers, underground forests, and unique natural landscapes. Visits require special permits and organized expeditions."
            },
            {
                name: "Dark Cave",
                description: "An adventurous cave experience offering activities such as kayaking, swimming, and guided exploration."
            },
            {
                name: "Botanical Garden",
                description: "A peaceful natural area with forest trails, waterfalls, and opportunities to discover the region's diverse plant life."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Discover some of the world's most impressive cave systems.",
            "Explore ancient limestone mountains and underground rivers.",
            "Experience exciting outdoor activities and guided adventures.",
            "Enjoy the beautiful forests and natural biodiversity.",
            "Learn about the geological and environmental importance of the region."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "February to August.",
            weather: "The dry season generally offers warmer weather and more favorable conditions for cave exploration and outdoor activities.",
            recommendation: "March to May is a popular period for comfortable sightseeing. Avoid planning outdoor activities during heavy rainfall because flooding can affect cave access and transportation."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Exploring the Underground Cave World",
            experience: "Join a guided cave exploration to discover enormous underground chambers, impressive rock formations, and hidden natural landscapes. Depending on the chosen tour, visitors can also enjoy kayaking, hiking, and swimming.",
            culturalSignificance: "Phong Nha-Ke Bang represents Vietnam's remarkable natural heritage. Its caves, forests, and ecosystems provide valuable insight into the country's geological history and biodiversity.",
            recommendation: "Choose a guided tour that matches your fitness level and experience. Book specialized expeditions in advance, especially for restricted caves such as Son Doong."
        },
        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$15–$40 per night" },
            { item: "Food and Drinks", cost: "$8–$15 per day" },
            { item: "Transportation", cost: "$5–$20" },
            { item: "Cave Entrance Fees", cost: "$5–$20" },
            { item: "Guided Tours and Activities", cost: "$15–$60+" }
        ],
        budgetNote: "A basic visit to the national park can be affordable, while specialized cave expeditions may cost significantly more. Son Doong Cave expeditions are particularly expensive and require advance booking.",

        // 7. Transportation and Accommodation
        transportation: [
            "Travel to Dong Hoi Airport or Dong Hoi Railway Station from major Vietnamese cities.",
            "Take a taxi, bus, or private transfer from Dong Hoi to Phong Nha town.",
            "Rent a bicycle or motorbike where legally permitted to explore nearby areas.",
            "Join organized tours for cave visits and activities inside the national park."
        ],
        accommodation: [
            "Budget hostels and guesthouses in Phong Nha town.",
            "Mid-range hotels and homestays near the Son River.",
            "Eco-lodges surrounded by natural landscapes.",
            "Comfortable riverside resorts for a relaxing stay."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Explore Phong Nha Cave",
                description: "Take a boat along the Son River and enter the cave to admire its impressive underground formations."
            },
            {
                time: "10:30 AM",
                activity: "Visit Paradise Cave",
                description: "Walk through the enormous cave chambers and discover beautiful stalactites and stalagmites."
            },
            {
                time: "12:30 PM",
                activity: "Enjoy Local Vietnamese Food",
                description: "Relax at a local restaurant and enjoy traditional dishes from the region."
            },
            {
                time: "2:00 PM",
                activity: "Explore the Botanical Garden",
                description: "Enjoy forest trails, natural scenery, and the peaceful surroundings of the national park."
            },
            {
                time: "4:00 PM",
                activity: "Relax by the Son River",
                description: "Return to Phong Nha town and enjoy the beautiful riverside atmosphere."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Wear comfortable walking shoes with good grip.",
            "Bring insect repellent, sunscreen, and drinking water.",
            "Carry a light rain jacket because weather conditions can change.",
            "Follow your guide's instructions during cave exploration.",
            "Check cave access and weather conditions before visiting.",
            "Book special cave expeditions well in advance.",
            "Avoid littering and respect the national park's wildlife and natural environment."
        ]
    },
    

    // ===================================
    // VII. SINGAPORE
    // ===================================

    // ===================================
    // 31. GARDENS BY THE BAY
    // ===================================

    {
        name: "Gardens by the Bay",
        country: "Singapore",
        category: "Nature & Architecture",
        image: "images/Gardens By The Bay.jpg",
        budget: 100,
        featured: true,

        // 1. Overview
        description: "Gardens by the Bay is a world-famous nature park known for its futuristic architecture, beautiful gardens, and impressive Supertrees. Located in the heart of Singapore, it combines nature, technology, and sustainable design to create one of the country's most iconic attractions.",
        location: "Marina Bay, central Singapore.",
        history: "Gardens by the Bay opened in 2012 as part of Singapore's vision to transform itself into a City in a Garden. The project was designed to create an attractive green space while showcasing innovative horticulture, environmental technology, and sustainable urban development.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Supertree Grove",
                description: "A collection of enormous tree-like structures covered with plants, creating a futuristic garden landscape. Visitors can also enjoy the spectacular evening light and music show."
            },
            {
                name: "Flower Dome",
                description: "A large climate-controlled conservatory displaying plants and flowers from different regions around the world."
            },
            {
                name: "Cloud Forest",
                description: "An impressive indoor tropical mountain featuring a tall waterfall, lush vegetation, and fascinating displays about biodiversity."
            },
            {
                name: "OCBC Skyway",
                description: "An elevated walkway connecting several Supertrees and offering beautiful views of the gardens and surrounding city."
            },
            {
                name: "Floral Fantasy",
                description: "A colorful indoor attraction featuring creative floral displays, hanging gardens, and artistic arrangements."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Experience one of Singapore's most iconic attractions.",
            "Admire the futuristic Supertrees and impressive architecture.",
            "Discover plants and flowers from different parts of the world.",
            "Enjoy spectacular indoor waterfalls and garden landscapes.",
            "Learn about sustainable design and environmental conservation."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "February to April.",
            weather: "Singapore has a tropical climate with warm temperatures and humidity throughout the year. Rain showers can occur in any season.",
            recommendation: "Gardens by the Bay can be visited throughout the year. Visit in the late afternoon to explore the gardens during daylight and enjoy the illuminated Supertrees in the evening."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Garden Rhapsody Light and Music Show",
            experience: "Watch the Supertrees illuminate with colorful lights synchronized to music during the Garden Rhapsody show. The experience creates a magical atmosphere beneath the towering structures.",
            culturalSignificance: "Gardens by the Bay represents Singapore's commitment to combining urban development, environmental sustainability, and green spaces. It has become an important symbol of the country's modern identity.",
            recommendation: "Find a comfortable viewing spot around Supertree Grove before the evening show begins. Check the official schedule before visiting."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$50–$120 per night" },
            { item: "Food and Drinks", cost: "$10–$25 per day" },
            { item: "Transportation", cost: "$5–$15" },
            { item: "Flower Dome and Cloud Forest", cost: "$20–$40" },
            { item: "Additional Attractions", cost: "$5–$15" }
        ],
        budgetNote: "Some outdoor garden areas are free to explore, while conservatories and selected attractions require tickets. Prices vary depending on ticket packages and visitor eligibility.",

        // 7. Transportation and Accommodation
        transportation: [
            "Take the MRT to Bayfront Station and follow the signs to Gardens by the Bay.",
            "Use Singapore's public bus network to reach nearby entrances.",
            "Walk from Marina Bay Sands through the connecting pedestrian routes.",
            "Use taxis or ride-hailing services for convenient transportation."
        ],
        accommodation: [
            "Budget hostels and hotels in central Singapore.",
            "Mid-range hotels near Marina Bay and Chinatown.",
            "Luxury hotels around Marina Bay for convenient access to major attractions.",
            "Serviced apartments for longer stays."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "9:00 AM",
                activity: "Explore the Outdoor Gardens",
                description: "Walk through the beautiful landscaped gardens and admire the impressive Supertrees."
            },
            {
                time: "10:30 AM",
                activity: "Visit Flower Dome",
                description: "Discover colorful flowers and plants from different climate zones."
            },
            {
                time: "12:00 PM",
                activity: "Explore Cloud Forest",
                description: "Experience the indoor tropical mountain, impressive waterfall, and lush greenery."
            },
            {
                time: "2:00 PM",
                activity: "Enjoy Lunch",
                description: "Relax and enjoy a meal at one of the nearby dining areas."
            },
            {
                time: "4:00 PM",
                activity: "Walk Along OCBC Skyway",
                description: "Enjoy elevated views of the gardens and Singapore's impressive skyline."
            },
            {
                time: "7:45 PM",
                activity: "Watch Garden Rhapsody",
                description: "Enjoy the spectacular evening light and music show at Supertree Grove. Check the current showtime before your visit."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Wear comfortable shoes because the gardens cover a large area.",
            "Bring drinking water and stay hydrated in Singapore's warm climate.",
            "Carry an umbrella in case of tropical rain.",
            "Book conservatory tickets in advance during busy periods.",
            "Visit Supertree Grove in the evening for the light show.",
            "Check attraction opening hours and show schedules before visiting.",
            "Respect the plants and avoid damaging the garden displays."
        ]
    },

    // ===================================
    // 32. MARINA BAY SANDS
    // ===================================

    {
        name: "Marina Bay Sands",
        country: "Singapore",
        category: "Modern Architecture & Luxury",
        image: "images/Marina Bay Sands.jpg",
        budget: 180,
        featured: false,

        // 1. Overview
        description: "Marina Bay Sands is one of Singapore's most recognizable landmarks, famous for its three elegant hotel towers connected by the spectacular SkyPark rooftop. Overlooking Marina Bay, this world-famous integrated resort features luxury accommodation, shopping, restaurants, entertainment, and breathtaking city views.",
        location: "Marina Bay, central Singapore.",
        history: "Marina Bay Sands officially opened in 2010 and became a major part of Singapore's modern waterfront development. Designed by architect Moshe Safdie, its distinctive three-tower structure and rooftop SkyPark quickly became internationally recognized symbols of the city.",

        // 2. Main Attractions
        attractions: [
            {
                name: "SkyPark Observation Deck",
                description: "An elevated observation area offering panoramic views of Singapore's skyline, Marina Bay, and surrounding landmarks."
            },
            {
                name: "Infinity Pool",
                description: "A spectacular rooftop swimming pool overlooking the city. Access is generally reserved for registered hotel guests."
            },
            {
                name: "The Shoppes at Marina Bay Sands",
                description: "A luxury shopping destination featuring international fashion brands, restaurants, and beautiful waterfront surroundings."
            },
            {
                name: "ArtScience Museum",
                description: "A distinctive lotus-inspired museum featuring exhibitions that connect art, science, technology, and culture."
            },
            {
                name: "Spectra Light and Water Show",
                description: "A free outdoor evening show featuring colorful lights, water effects, and music along the Marina Bay waterfront."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "See one of Singapore's most famous architectural landmarks.",
            "Enjoy spectacular panoramic views from the rooftop observation deck.",
            "Explore luxury shopping and international dining experiences.",
            "Discover creative exhibitions at the ArtScience Museum.",
            "Watch the impressive evening light and water show."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "February to April.",
            weather: "Singapore has a warm tropical climate throughout the year, with high humidity and occasional rainfall.",
            recommendation: "Visit in the late afternoon to enjoy daylight views from the observation deck and experience the beautiful city lights after sunset. Check the weather before planning outdoor activities."
        },

        // 5. Special Experience
        specialExperience: {
            title: "SkyPark Observation Deck Experience",
            experience: "Visit the rooftop observation deck and enjoy breathtaking views of Singapore's skyline, Gardens by the Bay, and Marina Bay. The experience is especially beautiful around sunset and after dark.",
            culturalSignificance: "Marina Bay Sands represents Singapore's transformation into a modern international destination for tourism, architecture, business, and entertainment.",
            recommendation: "Reserve observation deck tickets in advance and check the official website for current opening hours and admission options."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$150–$400+ per night" },
            { item: "Food and Drinks", cost: "$15–$40 per day" },
            { item: "Transportation", cost: "$5–$15" },
            { item: "Observation Deck", cost: "$20–$35" },
            { item: "Shopping and Entertainment", cost: "$20–$100+" }
        ],
        budgetNote: "Marina Bay Sands offers both premium and more accessible experiences. Visitors do not need to stay at the hotel to enjoy many public areas and selected attractions. Prices vary by season and activity.",

        // 7. Transportation and Accommodation
        transportation: [
            "Take the MRT to Bayfront Station, which provides convenient access to the resort.",
            "Use local buses to reach the Marina Bay area.",
            "Walk from nearby attractions such as Gardens by the Bay and the ArtScience Museum.",
            "Use taxis or ride-hailing services for convenient transportation."
        ],
        accommodation: [
            "Marina Bay Sands Hotel for a luxury stay and convenient access to the attractions.",
            "Mid-range hotels around Marina Bay and nearby central districts.",
            "Budget hotels and hostels in Chinatown and other central neighborhoods.",
            "Serviced apartments for longer visits to Singapore."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "10:00 AM",
                activity: "Explore The Shoppes",
                description: "Discover luxury stores, restaurants, and the impressive indoor shopping environment."
            },
            {
                time: "12:00 PM",
                activity: "Enjoy Lunch",
                description: "Choose from the many restaurants and dining options around the resort."
            },
            {
                time: "2:00 PM",
                activity: "Visit ArtScience Museum",
                description: "Explore creative exhibitions combining art, science, and technology."
            },
            {
                time: "4:30 PM",
                activity: "Visit SkyPark Observation Deck",
                description: "Enjoy panoramic views of Marina Bay and Singapore's famous skyline."
            },
            {
                time: "6:30 PM",
                activity: "Explore the Waterfront",
                description: "Walk around Marina Bay and admire the beautiful architecture as the city lights begin to appear."
            },
            {
                time: "8:00 PM",
                activity: "Watch Spectra Light and Water Show",
                description: "Enjoy the colorful outdoor show along the waterfront. Check the official schedule for the current performance times."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Book observation deck tickets ahead of time during busy travel periods.",
            "Bring a camera to capture the impressive skyline.",
            "Wear comfortable clothing and shoes for walking.",
            "Check the weather before planning outdoor sightseeing.",
            "Remember that the rooftop infinity pool is generally reserved for hotel guests.",
            "Check current show schedules and attraction opening hours.",
            "Keep personal belongings secure in crowded shopping and tourist areas."
        ]
    },

    // ===================================
    // 33. SENTOSA ISLAND
    // ===================================

    {
        name: "Sentosa Island",
        country: "Singapore",
        category: "Island & Entertainment",
        image: "images/Sentosa Island.jpg",
        budget: 150,
        featured: false,

        // 1. Overview
        description: "Sentosa Island is a popular resort destination in Singapore, famous for its beautiful beaches, exciting attractions, entertainment venues, and family-friendly activities. The island offers a combination of relaxation, adventure, and luxury experiences, making it one of Singapore's most visited tourist destinations.",
        location: "Southern coast of Singapore, near the HarbourFront area.",
        history: "Sentosa was formerly known as Pulau Blakang Mati and served as a military base during the colonial period. It was renamed Sentosa in 1970, meaning 'peace and tranquility,' and later developed into a major resort and entertainment destination.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Universal Studios Singapore",
                description: "A famous theme park featuring exciting rides, movie-inspired attractions, entertainment shows, and themed zones."
            },
            {
                name: "Palawan Beach",
                description: "A beautiful sandy beach known for its relaxing atmosphere, clear views, and family-friendly activities."
            },
            {
                name: "Siloso Beach",
                description: "A lively beach popular for water sports, beach activities, restaurants, and seaside entertainment."
            },
            {
                name: "S.E.A. Aquarium",
                description: "A major marine attraction where visitors can discover a wide variety of underwater animals and marine habitats."
            },
            {
                name: "SkyHelix Sentosa",
                description: "An open-air panoramic ride that lifts visitors above the island for impressive views of Sentosa and the surrounding sea."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Enjoy beautiful beaches and tropical island scenery.",
            "Experience exciting rides and attractions at Universal Studios Singapore.",
            "Discover fascinating marine life at the aquarium.",
            "Enjoy outdoor adventures and relaxing seaside activities.",
            "Explore one of Singapore's most popular entertainment destinations."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "February to April.",
            weather: "Sentosa has a warm tropical climate throughout the year, with sunny periods, high humidity, and occasional rainfall.",
            recommendation: "Visit on weekdays when possible to avoid some weekend crowds. Plan outdoor and beach activities earlier in the day and check attraction schedules before visiting."
        },

        // 5. Special Experience
        specialExperience: {
            title: "A Day of Island Adventure",
            experience: "Spend a full day exploring Sentosa's attractions, relaxing on its sandy beaches, enjoying exciting rides, and watching the sunset by the sea.",
            culturalSignificance: "Sentosa reflects Singapore's development as an international tourism destination, combining natural coastal landscapes with modern entertainment and recreation.",
            recommendation: "Choose a few main attractions in advance because the island has many activities and may require a full day or more to explore comfortably."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$40–$120 per night" },
            { item: "Food and Drinks", cost: "$15–$30 per day" },
            { item: "Transportation", cost: "$5–$15" },
            { item: "Attraction Tickets", cost: "$30–$80+" },
            { item: "Additional Activities", cost: "$10–$40" }
        ],
        budgetNote: "Some beaches and public areas are free to visit, while theme parks and selected attractions require separate tickets. Total expenses depend on the activities chosen.",

        // 7. Transportation and Accommodation
        transportation: [
            "Take the MRT to HarbourFront Station and enter Sentosa through VivoCity.",
            "Use the Sentosa Express monorail to travel between selected island stations.",
            "Walk across the Sentosa Boardwalk from VivoCity.",
            "Use island buses, cable cars, or local transport services to reach attractions.",
            "Taxis and ride-hailing services are available for convenient travel."
        ],
        accommodation: [
            "Budget hotels and hostels near HarbourFront and central Singapore.",
            "Mid-range hotels around Sentosa's resort areas.",
            "Luxury beachfront resorts and hotels on the island.",
            "Family-friendly hotels offering convenient access to major attractions."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "9:00 AM",
                activity: "Arrive at Sentosa Island",
                description: "Travel to the island and enjoy the beautiful coastal surroundings."
            },
            {
                time: "10:00 AM",
                activity: "Visit Universal Studios Singapore",
                description: "Experience exciting rides, themed attractions, and entertainment shows."
            },
            {
                time: "1:00 PM",
                activity: "Enjoy Lunch",
                description: "Relax and choose from the island's restaurants and food options."
            },
            {
                time: "2:00 PM",
                activity: "Explore the S.E.A. Aquarium",
                description: "Discover fascinating marine animals and underwater environments."
            },
            {
                time: "4:00 PM",
                activity: "Relax at Palawan or Siloso Beach",
                description: "Enjoy the sandy beaches, coastal scenery, and seaside atmosphere."
            },
            {
                time: "6:00 PM",
                activity: "Enjoy the Island Views",
                description: "Take photographs, explore the waterfront, and enjoy the evening atmosphere before leaving."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Wear comfortable clothing and shoes for walking around the island.",
            "Bring sunscreen, sunglasses, and drinking water.",
            "Book popular attraction tickets in advance.",
            "Check opening hours and activity schedules before visiting.",
            "Bring swimwear if you plan to enjoy the beaches.",
            "Allow enough time to travel between different attractions.",
            "Keep the beaches clean and respect the natural environment."
        ]
    },

    // ===================================
    // 34. JEWEL CHANGI AIRPORT
    // ===================================

    {
        name: "Jewel Changi Airport",
        country: "Singapore",
        category: "Architecture & Shopping",
        image: "images/Jewel Changi Airport.jpg",
        budget: 90,
        featured: false,

        // 1. Overview
        description: "Jewel Changi Airport is a spectacular lifestyle and entertainment complex connected to Singapore Changi Airport. Famous for its enormous indoor waterfall, lush indoor gardens, impressive glass architecture, shopping areas, and dining experiences, it is a destination where nature and modern design come together.",
        location: "Changi Airport, eastern Singapore.",
        history: "Jewel Changi Airport officially opened in April 2019. Designed by architect Moshe Safdie, the complex was developed to transform the airport experience into a destination for shopping, entertainment, and nature. Its iconic Rain Vortex became one of Singapore's most recognizable attractions.",

        // 2. Main Attractions
        attractions: [
            {
                name: "HSBC Rain Vortex",
                description: "The world's tallest indoor waterfall, cascading from the roof through the center of Jewel's impressive glass structure."
            },
            {
                name: "Shiseido Forest Valley",
                description: "A beautiful indoor garden featuring thousands of plants, walking trails, and peaceful green spaces surrounding the waterfall."
            },
            {
                name: "Canopy Park",
                description: "An entertainment area on the top level featuring creative gardens, walking attractions, and family-friendly activities."
            },
            {
                name: "Canopy Bridge",
                description: "A suspended glass-bottomed bridge offering unique views of the indoor gardens and Rain Vortex."
            },
            {
                name: "Jewel Shopping and Dining",
                description: "A large collection of international brands, local shops, restaurants, cafés, and food experiences."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "See one of the world's most impressive indoor waterfalls.",
            "Experience a unique combination of nature and modern architecture.",
            "Explore beautiful indoor gardens and walking trails.",
            "Enjoy shopping, restaurants, and entertainment activities.",
            "Discover why Singapore Changi Airport is famous for its visitor experience."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "Throughout the year.",
            weather: "Jewel is an indoor complex with air-conditioned shopping and entertainment areas, making it comfortable to visit regardless of outdoor weather.",
            recommendation: "Visit during the daytime to explore the gardens and shopping areas. Stay into the evening to enjoy the Rain Vortex light and music presentation. Check the current show schedule before visiting."
        },

        // 5. Special Experience
        specialExperience: {
            title: "The HSBC Rain Vortex Experience",
            experience: "Stand beneath the enormous indoor waterfall and admire the water cascading through Jewel's glass roof. Explore the surrounding Forest Valley and enjoy the spectacular atmosphere when the waterfall is illuminated in the evening.",
            culturalSignificance: "Jewel represents Singapore's innovation in architecture, urban greenery, and tourism. It demonstrates how modern infrastructure can combine transportation, nature, shopping, and public spaces.",
            recommendation: "Visit the Rain Vortex during its operating hours and check the official website for current light and music showtimes."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$50–$120 per night" },
            { item: "Food and Drinks", cost: "$10–$25 per day" },
            { item: "Transportation", cost: "$5–$15" },
            { item: "Canopy Park Attractions", cost: "$5–$25" },
            { item: "Shopping and Additional Activities", cost: "$10–$50+" }
        ],
        budgetNote: "Access to many public areas, including the Rain Vortex viewing areas and Forest Valley, is free. Selected Canopy Park attractions and activities require tickets. Shopping expenses depend on personal preferences.",

        // 7. Transportation and Accommodation
        transportation: [
            "Take the MRT to Changi Airport Station and follow the signs to Jewel.",
            "Walk from the airport terminals using the connecting pedestrian links.",
            "Use airport shuttle services where available between terminals.",
            "Take a taxi or ride-hailing service directly to Jewel's entrance."
        ],
        accommodation: [
            "Budget hotels and hostels around the Changi and Tampines areas.",
            "Mid-range hotels near Changi Airport.",
            "Luxury airport hotels for convenient overnight stays.",
            "Hotels in central Singapore for visitors exploring other major attractions."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "9:00 AM",
                activity: "Arrive at Jewel Changi Airport",
                description: "Enter the impressive complex and admire its modern glass architecture."
            },
            {
                time: "9:30 AM",
                activity: "Visit the HSBC Rain Vortex",
                description: "Enjoy the spectacular indoor waterfall and take photographs from different viewing areas."
            },
            {
                time: "10:30 AM",
                activity: "Explore Shiseido Forest Valley",
                description: "Walk through the lush indoor gardens and enjoy the peaceful green surroundings."
            },
            {
                time: "12:00 PM",
                activity: "Enjoy Lunch",
                description: "Choose from the many restaurants and local food options inside Jewel."
            },
            {
                time: "1:30 PM",
                activity: "Explore Canopy Park",
                description: "Discover the creative gardens, attractions, and suspended walking experiences."
            },
            {
                time: "3:30 PM",
                activity: "Shopping and Relaxation",
                description: "Browse international stores, visit cafés, and enjoy the shopping environment."
            },
            {
                time: "7:30 PM",
                activity: "Enjoy the Evening Waterfall Show",
                description: "Return to the Rain Vortex viewing area to enjoy its illuminated evening presentation, subject to the current schedule."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Check the Rain Vortex operating hours and evening show schedule.",
            "Wear comfortable shoes for exploring the large complex.",
            "Bring a camera to capture the indoor waterfall and gardens.",
            "Allow several hours if you plan to explore Canopy Park and shopping areas.",
            "Check ticket requirements for selected attractions before visiting.",
            "Keep track of your airport terminal if you are visiting during a flight connection.",
            "Respect the indoor gardens and avoid damaging plants."
        ]
    },

    // ===================================
    // 35. SINGAPORE ZOO
    // ===================================

    {
        name: "Singapore Zoo",
        country: "Singapore",
        category: "Wildlife & Nature",
        image: "images/Singapore Zoo.jpg",
        budget: 100,
        featured: false,

        // 1. Overview
        description: "Singapore Zoo is a world-renowned wildlife park famous for its naturalistic habitats, open-concept exhibits, and diverse collection of animals. Located within a lush tropical rainforest environment, the zoo provides visitors with opportunities to discover wildlife while learning about animal conservation and environmental protection.",
        location: "Mandai, northern Singapore.",
        history: "Singapore Zoo officially opened in 1973 and became internationally recognized for its open-concept approach to wildlife habitats. Over the years, it has developed educational programs, breeding initiatives, and conservation efforts to support wildlife protection.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Orangutan Habitat",
                description: "A popular exhibit where visitors can observe orangutans in a carefully designed environment that encourages natural behaviors."
            },
            {
                name: "Elephant Habitat",
                description: "An area dedicated to Asian elephants, where visitors can learn about their behavior, care, and conservation."
            },
            {
                name: "Fragile Forest",
                description: "An immersive rainforest environment featuring butterflies, birds, and other small animals living among tropical vegetation."
            },
            {
                name: "Great Rift Valley of Ethiopia",
                description: "A habitat inspired by the landscapes of Ethiopia, featuring animals such as baboons and other African wildlife."
            },
            {
                name: "Wildlife Presentations",
                description: "Educational presentations that introduce visitors to animal behaviors, wildlife conservation, and responsible care."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Discover a wide variety of animals from different parts of the world.",
            "Experience the zoo's famous naturalistic and open-concept habitats.",
            "Learn about wildlife conservation and endangered species.",
            "Enjoy educational activities suitable for families and animal lovers.",
            "Explore a beautiful tropical environment while discovering nature."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "Throughout the year.",
            weather: "Singapore has a warm tropical climate with high humidity and occasional rainfall throughout the year.",
            recommendation: "Visit early in the morning when temperatures are generally more comfortable and many animals are active. Check weather conditions and animal presentation schedules before your visit."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Discover Wildlife in Naturalistic Habitats",
            experience: "Explore the zoo's different animal habitats, observe fascinating wildlife, and attend educational presentations to learn more about the animals and their natural behaviors.",
            culturalSignificance: "Singapore Zoo represents the country's commitment to wildlife education, environmental awareness, and conservation. It provides visitors with opportunities to understand the importance of protecting biodiversity.",
            recommendation: "Plan your visit around the animal presentation schedule and allow enough time to explore the different habitats without rushing."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$50–$120 per night" },
            { item: "Food and Drinks", cost: "$10–$25 per day" },
            { item: "Transportation", cost: "$5–$15" },
            { item: "Zoo Admission", cost: "$30–$45" },
            { item: "Additional Activities", cost: "$5–$20" }
        ],
        budgetNote: "Admission prices and additional activity costs may vary depending on ticket type, age, promotions, and visitor eligibility. Check the official Mandai Wildlife Reserve website for current prices.",

        // 7. Transportation and Accommodation
        transportation: [
            "Take the MRT to Khatib Station and use the Mandai Khatib Shuttle service.",
            "Travel by public bus to the Mandai Wildlife Reserve area.",
            "Use a taxi or ride-hailing service for direct transportation.",
            "Follow the signs to Singapore Zoo after arriving at the Mandai Wildlife Reserve."
        ],
        accommodation: [
            "Budget hotels and hostels in central Singapore.",
            "Mid-range hotels near northern Singapore and surrounding districts.",
            "Luxury hotels in central Singapore for convenient access to other attractions.",
            "Hotels near Mandai for visitors planning to explore multiple wildlife parks."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:30 AM",
                activity: "Arrive at Singapore Zoo",
                description: "Enter the zoo early and prepare for a full day of wildlife exploration."
            },
            {
                time: "9:00 AM",
                activity: "Explore the Orangutan Habitat",
                description: "Observe the orangutans and learn about their natural behaviors and conservation."
            },
            {
                time: "10:30 AM",
                activity: "Visit the Elephant Habitat",
                description: "Discover Asian elephants and learn about wildlife protection."
            },
            {
                time: "12:00 PM",
                activity: "Enjoy Lunch",
                description: "Take a break at one of the zoo's dining areas."
            },
            {
                time: "1:00 PM",
                activity: "Explore Fragile Forest",
                description: "Walk through the rainforest environment and discover its fascinating smaller animals."
            },
            {
                time: "2:30 PM",
                activity: "Attend a Wildlife Presentation",
                description: "Enjoy an educational presentation and learn more about animal behavior and conservation."
            },
            {
                time: "4:00 PM",
                activity: "Explore More Animal Habitats",
                description: "Visit the remaining exhibits and enjoy the zoo's beautiful natural surroundings."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Arrive early to enjoy cooler temperatures and more active animals.",
            "Wear comfortable walking shoes because the zoo covers a large area.",
            "Bring sunscreen, insect repellent, and drinking water.",
            "Carry an umbrella or raincoat because tropical showers are common.",
            "Check animal presentation times before starting your visit.",
            "Follow all safety instructions and avoid feeding animals.",
            "Respect wildlife and keep the zoo clean."
        ]
    },

    // ===================================
    // VIII. LAOS
    // ===================================

    // ===================================
    // 36. LUANG PRABANG
    // ===================================

    {
        name: "Luang Prabang",
        country: "Laos",
        category: "Historical & Cultural",
        image: "images/Luang Prabang.jpg",
        budget: 90,
        featured: true,

        // 1. Overview
        description: "Luang Prabang is a beautiful historic town in northern Laos, famous for its golden temples, traditional wooden houses, French colonial architecture, and peaceful atmosphere along the Mekong River. Surrounded by mountains and lush greenery, it offers visitors a wonderful combination of history, culture, spirituality, and natural beauty.",
        location: "Luang Prabang Province, northern Laos, at the meeting point of the Mekong and Nam Khan rivers.",
        history: "Luang Prabang was once the royal capital of the Kingdom of Laos and has a long history as an important center of Buddhism and Lao culture. Its historic architecture and religious traditions earned it recognition as a UNESCO World Heritage Site in 1995.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Wat Xieng Thong",
                description: "One of the most famous Buddhist temples in Laos, admired for its traditional Lao architecture, golden decorations, and beautiful glass mosaics."
            },
            {
                name: "Mount Phousi",
                description: "A scenic hill in the center of town offering panoramic views of Luang Prabang, the surrounding mountains, and the Mekong River."
            },
            {
                name: "Royal Palace Museum",
                description: "A former royal residence displaying historical objects, royal collections, and important cultural artifacts from Laos."
            },
            {
                name: "Kuang Si Falls",
                description: "A spectacular multi-level waterfall surrounded by tropical forest, with beautiful turquoise pools and natural scenery."
            },
            {
                name: "Luang Prabang Night Market",
                description: "A lively evening market where visitors can discover handmade crafts, traditional textiles, local food, and souvenirs."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Explore a UNESCO World Heritage town with remarkable architecture and history.",
            "Discover beautiful Buddhist temples and traditional Lao culture.",
            "Enjoy peaceful scenery along the Mekong and Nam Khan rivers.",
            "Experience local markets, traditional food, and handmade crafts.",
            "Visit nearby waterfalls and enjoy the natural beauty of northern Laos."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "November to February.",
            weather: "The cool and dry season generally offers pleasant temperatures and lower rainfall, making it comfortable for sightseeing and outdoor activities.",
            recommendation: "Visit during the cooler months for comfortable walks around the historic town, temple visits, and trips to nearby waterfalls."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Experience the Traditional Alms-Giving Ceremony",
            experience: "Wake up early to respectfully observe the traditional Buddhist alms-giving ceremony, during which local monks walk through the streets collecting offerings from residents.",
            culturalSignificance: "The ceremony reflects the importance of Theravada Buddhism in Lao society and represents generosity, spiritual discipline, and community traditions.",
            recommendation: "Observe quietly from a respectful distance, dress modestly, and avoid disturbing monks or local residents."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$15–$50 per night" },
            { item: "Food and Drinks", cost: "$5–$15 per day" },
            { item: "Transportation", cost: "$5–$15" },
            { item: "Attraction Fees", cost: "$5–$20" },
            { item: "Additional Activities", cost: "$5–$15" }
        ],
        budgetNote: "The estimated daily budget is approximately $30–$90 per person, depending on accommodation, transportation, meals, and activities. Some attractions have separate admission fees.",

        // 7. Transportation and Accommodation
        transportation: [
            "Fly to Luang Prabang International Airport from selected regional destinations.",
            "Travel by train using the Laos-China Railway to reach Luang Prabang.",
            "Use tuk-tuks or local transportation to explore areas around town.",
            "Walk around the historic center because many attractions are close to one another.",
            "Hire a local driver or join a tour to visit Kuang Si Falls."
        ],
        accommodation: [
            "Budget guesthouses and hostels around the historic town.",
            "Traditional Lao-style boutique hotels near the Mekong River.",
            "Mid-range hotels within walking distance of temples and markets.",
            "Luxury riverside resorts offering scenic views and relaxing experiences."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "7:00 AM",
                activity: "Observe the Alms-Giving Ceremony",
                description: "Experience this important Buddhist tradition respectfully in the early morning."
            },
            {
                time: "8:30 AM",
                activity: "Visit Wat Xieng Thong",
                description: "Explore one of the town's most beautiful and historically significant temples."
            },
            {
                time: "10:00 AM",
                activity: "Explore the Royal Palace Museum",
                description: "Discover royal history and important cultural collections from Laos."
            },
            {
                time: "12:00 PM",
                activity: "Enjoy Traditional Lao Food",
                description: "Take a lunch break and try local dishes at a nearby restaurant."
            },
            {
                time: "2:00 PM",
                activity: "Visit Kuang Si Falls",
                description: "Enjoy the turquoise pools, waterfalls, and surrounding tropical forest."
            },
            {
                time: "5:00 PM",
                activity: "Climb Mount Phousi",
                description: "Enjoy beautiful views of the town and surrounding rivers as the day comes to an end."
            },
            {
                time: "6:30 PM",
                activity: "Explore the Night Market",
                description: "Browse local crafts, traditional textiles, souvenirs, and street food."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Dress modestly when visiting temples and religious sites.",
            "Remove your shoes before entering temple buildings when required.",
            "Respect local Buddhist traditions and religious ceremonies.",
            "Bring comfortable walking shoes for exploring the historic town.",
            "Carry sunscreen, drinking water, and insect repellent.",
            "Bring cash because smaller shops and local markets may not accept cards.",
            "Keep the environment clean and respect local communities."
        ]
    },

    // ===================================
    // 37. KUANG SI FALLS
    // ===================================

    {
        name: "Kuang Si Falls",
        country: "Laos",
        category: "Nature & Landscape",
        image: "images/Kuang Si Falls.jpg",
        budget: 60,
        featured: false,

        // 1. Overview
        description: "Kuang Si Falls is one of the most beautiful natural attractions in Laos, famous for its cascading turquoise waterfalls, limestone formations, and peaceful tropical forest. Located near Luang Prabang, this stunning destination offers visitors a refreshing escape into nature, with scenic walking paths and picturesque pools surrounded by lush greenery.",
        location: "About 29 kilometers southwest of Luang Prabang, Luang Prabang Province, Laos.",
        history: "Kuang Si Falls has long been appreciated by local communities as a natural landmark and recreational area. Over time, it became one of the most popular attractions near Luang Prabang, attracting visitors interested in waterfalls, forest landscapes, and nature conservation.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Main Waterfall",
                description: "The impressive multi-level waterfall is the main highlight, with water flowing over limestone cliffs into beautiful turquoise pools."
            },
            {
                name: "Turquoise Natural Pools",
                description: "Several naturally formed pools create striking blue-green scenery surrounded by tropical forest."
            },
            {
                name: "Wooden Viewing Bridges",
                description: "Wooden bridges and pathways provide beautiful viewpoints where visitors can admire the cascading water and take photographs."
            },
            {
                name: "Forest Walking Trails",
                description: "Shaded trails allow visitors to explore the surrounding forest and enjoy the peaceful natural environment."
            },
            {
                name: "Tat Kuang Si Bear Rescue Centre",
                description: "A nearby sanctuary that cares for rescued Asiatic black bears and helps raise awareness about wildlife protection."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Admire one of Laos's most famous and beautiful waterfalls.",
            "Enjoy the stunning turquoise pools and limestone scenery.",
            "Explore tropical forest trails and peaceful natural surroundings.",
            "Learn about wildlife rescue and conservation efforts.",
            "Take memorable photographs of the waterfall and its natural landscape."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "November to April.",
            weather: "The dry season generally provides clearer weather and easier access to walking trails. Water flow and color can change depending on rainfall and seasonal conditions.",
            recommendation: "Visit during the dry season for comfortable outdoor exploration. Arriving in the morning can help you enjoy the scenery before the busiest visitor hours."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Explore the Turquoise Waterfall Pools",
            experience: "Walk along the forest paths, admire the cascading waterfalls, and enjoy the beautiful turquoise pools. Visitors may swim in designated areas when conditions and local rules allow.",
            culturalSignificance: "Kuang Si Falls reflects the natural beauty of northern Laos and highlights the importance of protecting forests, freshwater ecosystems, and local wildlife.",
            recommendation: "Bring swimwear and a towel if swimming is permitted, wear suitable walking shoes, and always follow safety signs around the water."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$15–$35 per night" },
            { item: "Food and Drinks", cost: "$5–$12 per day" },
            { item: "Transportation", cost: "$5–$15" },
            { item: "Entrance Fee", cost: "$2–$5" },
            { item: "Additional Activities", cost: "$5–$10" }
        ],
        budgetNote: "The estimated budget is approximately $30–$60 per person for a day trip from Luang Prabang, depending on transportation, meals, and additional activities. Entrance fees and transport prices may change.",

        // 7. Transportation and Accommodation
        transportation: [
            "Travel from Luang Prabang by tuk-tuk or private vehicle.",
            "Join a shared minivan or organized day tour from the town center.",
            "Arrange a local driver for a flexible visit and additional stops.",
            "Follow the marked walking paths from the entrance to the waterfall viewing areas."
        ],
        accommodation: [
            "Budget guesthouses and hostels in Luang Prabang.",
            "Mid-range hotels near the historic town and local markets.",
            "Traditional boutique guesthouses along the Mekong River.",
            "Luxury riverside resorts for visitors seeking a relaxing stay."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Travel to Kuang Si Falls",
                description: "Leave Luang Prabang and enjoy the scenic journey through the surrounding countryside."
            },
            {
                time: "9:00 AM",
                activity: "Explore the Bear Rescue Centre",
                description: "Learn about rescued bears and the importance of wildlife conservation."
            },
            {
                time: "10:00 AM",
                activity: "Walk Through the Forest Trails",
                description: "Follow the shaded paths and discover the natural beauty surrounding the waterfalls."
            },
            {
                time: "11:00 AM",
                activity: "Visit the Main Waterfall",
                description: "Admire the impressive waterfall, limestone formations, and turquoise pools."
            },
            {
                time: "12:00 PM",
                activity: "Enjoy Lunch",
                description: "Take a break and enjoy local food near the waterfall entrance."
            },
            {
                time: "1:00 PM",
                activity: "Relax by the Natural Pools",
                description: "Enjoy the peaceful scenery or swim in designated areas when permitted."
            },
            {
                time: "3:00 PM",
                activity: "Return to Luang Prabang",
                description: "Travel back to town after a refreshing day surrounded by nature."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Arrive early to enjoy a quieter experience.",
            "Wear comfortable shoes for walking on forest trails.",
            "Bring swimwear and a towel if you plan to swim in permitted areas.",
            "Be careful around wet rocks because they can be slippery.",
            "Bring sunscreen, insect repellent, and drinking water.",
            "Respect wildlife and never feed or disturb the animals.",
            "Follow all swimming restrictions and safety instructions.",
            "Avoid leaving rubbish in the forest or near the waterfalls."
        ]
    },

    // ===================================
    // 38. VANG VIENG
    // ===================================

    {
        name: "Vang Vieng",
        country: "Laos",
        category: "Nature & Adventure",
        image: "images/Vang Vieng.jpg",
        budget: 70,
        featured: false,

        // 1. Overview
        description: "Vang Vieng is a scenic town in central Laos, surrounded by dramatic limestone mountains, green rice fields, caves, and the beautiful Nam Song River. Known for its outdoor adventures and peaceful countryside, it is a popular destination for travelers who enjoy nature, photography, and exciting activities.",
        location: "Vientiane Province, central Laos, along the Nam Song River.",
        history: "Vang Vieng developed from a small riverside settlement into a well-known travel destination. Its surrounding karst mountains, caves, and river landscapes have made it an important location for nature tourism and outdoor recreation in Laos.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Nam Song River",
                description: "A beautiful river flowing through the town, surrounded by limestone mountains and green countryside. Visitors can enjoy kayaking, river views, and relaxing riverside activities."
            },
            {
                name: "Blue Lagoon",
                description: "A popular natural swimming area with clear blue-green water, surrounded by trees and limestone scenery."
            },
            {
                name: "Tham Chang Cave",
                description: "A well-known limestone cave offering interesting rock formations and scenic views of the surrounding landscape."
            },
            {
                name: "Pha Ngern Viewpoint",
                description: "A mountain viewpoint reached by a challenging hike, rewarding visitors with panoramic views of Vang Vieng and its surrounding countryside."
            },
            {
                name: "Hot Air Balloon Experience",
                description: "A memorable way to admire the limestone mountains, rivers, and countryside from above, depending on weather and operator availability."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Enjoy spectacular views of limestone mountains and green countryside.",
            "Experience outdoor adventures such as kayaking, hiking, and cave exploration.",
            "Relax beside beautiful rivers and natural swimming areas.",
            "Discover fascinating caves and scenic viewpoints.",
            "Capture unforgettable photographs of Laos's natural landscapes."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "November to February.",
            weather: "The cool and dry season generally offers comfortable temperatures and less rainfall, making outdoor activities more enjoyable.",
            recommendation: "Visit during the dry season for hiking, kayaking, and exploring the countryside. Check weather conditions before booking outdoor adventures."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Explore Vang Vieng from the River",
            experience: "Enjoy a kayaking trip along the Nam Song River while taking in the beautiful limestone mountains and peaceful countryside. Visitors can also explore nearby caves and viewpoints.",
            culturalSignificance: "Vang Vieng highlights the natural beauty and rural landscapes of Laos, while tourism provides opportunities for local communities through accommodation, food, guiding, and outdoor activities.",
            recommendation: "Choose a responsible local tour operator, wear a life jacket during water activities, and follow safety instructions."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$10–$35 per night" },
            { item: "Food and Drinks", cost: "$5–$15 per day" },
            { item: "Transportation", cost: "$5–$15" },
            { item: "Outdoor Activities", cost: "$10–$30" },
            { item: "Additional Expenses", cost: "$5–$15" }
        ],
        budgetNote: "The estimated daily budget is approximately $30–$70 per person, depending on accommodation, transportation, meals, and selected activities. Adventure tour prices vary by provider.",

        // 7. Transportation and Accommodation
        transportation: [
            "Travel by train to Vang Vieng using the Laos-China Railway.",
            "Take a bus or minivan from Vientiane or Luang Prabang.",
            "Use tuk-tuks or local transportation to reach nearby attractions.",
            "Rent a bicycle or motorbike where legally permitted and with appropriate safety equipment.",
            "Join organized tours for cave exploration, kayaking, and outdoor activities."
        ],
        accommodation: [
            "Budget hostels and guesthouses in the town center.",
            "Mid-range hotels near the Nam Song River.",
            "Boutique resorts with mountain and countryside views.",
            "Riverside accommodation for visitors seeking a peaceful atmosphere."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Enjoy Breakfast in Town",
                description: "Start the day with breakfast before exploring Vang Vieng's natural attractions."
            },
            {
                time: "9:00 AM",
                activity: "Visit Tham Chang Cave",
                description: "Explore the limestone cave and enjoy views of the surrounding landscape."
            },
            {
                time: "10:30 AM",
                activity: "Relax at Blue Lagoon",
                description: "Enjoy the beautiful natural swimming area and peaceful forest environment."
            },
            {
                time: "12:00 PM",
                activity: "Enjoy Local Food",
                description: "Take a lunch break at a local restaurant in the area."
            },
            {
                time: "1:30 PM",
                activity: "Kayak Along the Nam Song River",
                description: "Experience the river scenery and admire the limestone mountains from the water."
            },
            {
                time: "3:30 PM",
                activity: "Explore the Countryside",
                description: "Discover the surrounding rice fields and enjoy the beautiful rural scenery."
            },
            {
                time: "5:00 PM",
                activity: "Enjoy the Mountain Views",
                description: "Relax and admire the scenery as the sun begins to set."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Wear comfortable shoes for hiking and cave exploration.",
            "Bring sunscreen, insect repellent, and enough drinking water.",
            "Carry swimwear and a towel if visiting swimming areas.",
            "Always wear a life jacket during kayaking and river activities.",
            "Check weather conditions before hiking or booking outdoor tours.",
            "Respect local communities and natural environments.",
            "Avoid swimming in restricted or unsafe river areas.",
            "Keep the countryside clean and take rubbish with you."
        ]
    },

    // ===================================
    // 39. PLAIN OF JARS
    // ===================================

    {
        name: "Plain of Jars",
        country: "Laos",
        category: "Archaeological & Historical",
        image: "images/Plain of Jars.jpg",
        budget: 65,
        featured: false,

        // 1. Overview
        description: "The Plain of Jars is one of the most mysterious archaeological sites in Laos, famous for thousands of enormous ancient stone jars scattered across grassy plateaus and rolling hills. These remarkable stone structures create a fascinating landscape that offers visitors a glimpse into the ancient history and traditions of the region.",
        location: "Xieng Khouang Plateau, near Phonsavan, Xieng Khouang Province, northeastern Laos.",
        history: "The stone jars are believed to date from the Iron Age, approximately 500 BCE to 500 CE. Archaeologists have studied the sites to understand their possible roles in ancient burial practices and ceremonies. The Plain of Jars was added to the UNESCO World Heritage List in 2019.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Site 1",
                description: "The largest and most accessible jar site, featuring hundreds of ancient stone jars across an open grassy landscape."
            },
            {
                name: "Site 2",
                description: "A scenic archaeological area surrounded by trees and rolling hills, containing groups of impressive stone jars."
            },
            {
                name: "Site 3",
                description: "A beautiful site located among green fields and wooded surroundings, offering a peaceful atmosphere for exploring the ancient structures."
            },
            {
                name: "Ancient Stone Jars",
                description: "Massive stone containers of different shapes and sizes that remain the most fascinating feature of the archaeological landscape."
            },
            {
                name: "Phonsavan Town",
                description: "The nearby town provides opportunities to learn about local culture, regional history, and the archaeological importance of the area."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Discover one of Southeast Asia's most fascinating archaeological landscapes.",
            "See thousands of mysterious ancient stone jars.",
            "Learn about the Iron Age history and burial traditions of Laos.",
            "Explore beautiful plateaus, grassy fields, and rolling hills.",
            "Experience an important UNESCO World Heritage Site."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "November to February.",
            weather: "The cool and dry season generally offers comfortable temperatures and clearer conditions for exploring the archaeological sites.",
            recommendation: "Visit during the dry season when walking conditions are generally more comfortable. Morning visits are especially pleasant for exploring the open landscapes."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Discover the Mystery of the Ancient Stone Jars",
            experience: "Walk along designated paths through the archaeological sites and observe the enormous stone jars while learning about their possible historical and ceremonial purposes.",
            culturalSignificance: "The Plain of Jars is an important part of Laos's archaeological heritage. It provides evidence of ancient communities and their burial traditions, helping researchers understand the region's early history.",
            recommendation: "Visit with a knowledgeable local guide to learn more about the archaeological discoveries and the history of the sites. Always remain on marked, cleared paths because unexploded ordnance remains a serious hazard in the region."
        },
        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$15–$35 per night" },
            { item: "Food and Drinks", cost: "$5–$12 per day" },
            { item: "Transportation", cost: "$10–$20" },
            { item: "Site Entrance Fees", cost: "$2–$5" },
            { item: "Local Guide", cost: "$10–$20" }
        ],
        budgetNote: "The estimated daily budget is approximately $35–$65 per person, depending on accommodation, transportation, meals, and guided activities. Entrance fees and transport costs may vary.",

        // 7. Transportation and Accommodation
        transportation: [
            "Fly to Xieng Khouang Airport when suitable regional flights are available.",
            "Travel by bus or minivan from Vientiane or Luang Prabang to Phonsavan.",
            "Hire a local driver or join an organized tour to visit the different jar sites.",
            "Use local transportation around Phonsavan town.",
            "Visit only officially accessible archaeological areas and follow local safety instructions."
        ],
        accommodation: [
            "Budget guesthouses and small hotels in Phonsavan.",
            "Mid-range hotels near the town center.",
            "Local guesthouses offering opportunities to experience regional hospitality.",
            "Comfortable hotels for visitors planning several days of archaeological exploration."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Depart from Phonsavan",
                description: "Start the day with a local guide and travel toward the archaeological sites."
            },
            {
                time: "9:00 AM",
                activity: "Explore Site 1",
                description: "Visit the largest jar site and discover its impressive collection of ancient stone structures."
            },
            {
                time: "10:30 AM",
                activity: "Visit Site 2",
                description: "Explore the scenic landscape and learn about the archaeological discoveries."
            },
            {
                time: "12:00 PM",
                activity: "Enjoy Local Lunch",
                description: "Take a break in the Phonsavan area and enjoy traditional Lao food."
            },
            {
                time: "1:30 PM",
                activity: "Explore Site 3",
                description: "Discover another collection of ancient jars surrounded by beautiful countryside."
            },
            {
                time: "3:00 PM",
                activity: "Learn About Regional History",
                description: "Visit a suitable local historical or cultural information center to understand more about the region."
            },
            {
                time: "4:30 PM",
                activity: "Return to Phonsavan",
                description: "Travel back to town after a day of archaeological and cultural exploration."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Always stay on marked and officially cleared paths.",
            "Never touch, move, or approach suspicious metal objects because unexploded ordnance remains a serious danger.",
            "Consider hiring a knowledgeable local guide.",
            "Wear comfortable walking shoes for exploring grassy and uneven terrain.",
            "Bring sunscreen, a hat, and drinking water.",
            "Carry some cash for local transportation and entrance fees.",
            "Respect archaeological structures and never climb on the ancient jars.",
            "Follow all instructions from local authorities and site staff."
        ]
    },

    // ===================================
    // 40. WAT PHOU
    // ===================================

    {
        name: "Wat Phou",
        country: "Laos",
        category: "Historical & Religious",
        image: "images/Wat Phou.jpg",
        budget: 65,
        featured: false,

        // 1. Overview
        description: "Wat Phou is an ancient Khmer temple complex located at the foot of Mount Phou Kao in southern Laos. Famous for its sandstone architecture, historic stairways, beautiful carvings, and mountain scenery, this remarkable site reflects the cultural and religious influence of the ancient Khmer civilization. It is one of Southeast Asia's most important archaeological destinations.",
        location: "Champasak Province, southern Laos, near the Mekong River.",
        history: "Wat Phou developed over many centuries, with important structures dating from the 7th to 12th centuries. The complex was originally associated with Hinduism, particularly the worship of Shiva, and became an important center within the Khmer cultural and political world. Buddhist traditions later became prominent at the site. It was recognized as a UNESCO World Heritage Site in 2001.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Main Sanctuary",
                description: "The historic sanctuary at the upper part of the complex features ancient stone architecture and religious carvings, reflecting the site's Hindu origins and later Buddhist traditions."
            },
            {
                name: "Ancient Khmer Stairway",
                description: "A historic stone staircase lined with trees leads visitors toward the upper temple area, offering beautiful views of the surrounding landscape."
            },
            {
                name: "Nandi Hall",
                description: "An ancient structure traditionally associated with Nandi, the sacred bull connected with the Hindu god Shiva."
            },
            {
                name: "Mount Phou Kao",
                description: "A distinctive mountain overlooking the temple complex, considered sacred in the site's historical Hindu landscape."
            },
            {
                name: "Ancient Reservoirs and Waterworks",
                description: "Historic water-management structures that demonstrate the engineering skills and planning of ancient Khmer communities."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Discover an important historical site connected to the ancient Khmer civilization.",
            "Admire traditional Khmer sandstone architecture and intricate carvings.",
            "Explore a UNESCO World Heritage cultural landscape.",
            "Learn about the historical relationship between Hinduism and Buddhism in the region.",
            "Enjoy beautiful views of ancient ruins, mountains, and the surrounding countryside."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "November to February.",
            weather: "The cool and dry season generally offers comfortable temperatures and less rainfall, making it suitable for walking around the temple complex.",
            recommendation: "Visit during the cooler months and arrive early in the morning to explore the temple comfortably and enjoy the surrounding scenery."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Walk Through an Ancient Khmer Temple Complex",
            experience: "Follow the historic stone pathways and stairways toward the main sanctuary, discovering ancient carvings, temple structures, and beautiful views of the Champasak landscape.",
            culturalSignificance: "Wat Phou represents an important part of the shared history of mainland Southeast Asia. Its architecture and cultural landscape provide remarkable evidence of the Khmer Empire and its Hindu religious traditions.",
            recommendation: "Take time to explore the different terraces, observe the stone carvings, and learn about the site's Khmer heritage. Dress respectfully because Wat Phou remains an important religious place."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$15–$35 per night" },
            { item: "Food and Drinks", cost: "$5–$12 per day" },
            { item: "Transportation", cost: "$10–$20" },
            { item: "Entrance Fee", cost: "$2–$5" },
            { item: "Local Guide", cost: "$10–$15" }
        ],
        budgetNote: "The estimated daily budget is approximately $35–$65 per person, depending on accommodation, transportation, meals, and guided activities. Actual entrance fees and travel costs may vary.",

        // 7. Transportation and Accommodation
        transportation: [
            "Fly to Pakse International Airport and travel onward to Champasak.",
            "Travel by bus or minivan from nearby towns to the Champasak area.",
            "Hire a local driver or tuk-tuk to reach the temple complex.",
            "Rent a bicycle where available to explore the surrounding countryside.",
            "Follow official visitor routes and marked paths within the archaeological site."
        ],
        accommodation: [
            "Budget guesthouses in Champasak and nearby towns.",
            "Mid-range hotels near the Mekong River.",
            "Traditional guesthouses offering local hospitality.",
            "Comfortable riverside resorts in the surrounding region.",
            "Hotels in Pakse for visitors who prefer staying in a larger town."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Arrive at Wat Phou",
                description: "Begin the visit early and enjoy the peaceful atmosphere of the ancient temple complex."
            },
            {
                time: "8:30 AM",
                activity: "Explore the Lower Temple Area",
                description: "Discover the ancient structures and archaeological remains near the entrance."
            },
            {
                time: "9:30 AM",
                activity: "Visit Nandi Hall",
                description: "Learn about the religious symbolism and historical significance of this ancient structure."
            },
            {
                time: "10:30 AM",
                activity: "Walk Along the Ancient Stairway",
                description: "Follow the historic pathway toward the upper sanctuary while enjoying the surrounding scenery."
            },
            {
                time: "11:30 AM",
                activity: "Explore the Main Sanctuary",
                description: "Admire the ancient Khmer architecture, religious carvings, and mountain views."
            },
            {
                time: "12:30 PM",
                activity: "Enjoy Local Lunch",
                description: "Take a break and enjoy traditional Lao food in the nearby area."
            },
            {
                time: "2:00 PM",
                activity: "Explore the Champasak Landscape",
                description: "Discover more about the ancient settlements, historic waterworks, and cultural landscape."
            },
            {
                time: "3:30 PM",
                activity: "Return to Accommodation",
                description: "Finish the visit and enjoy the peaceful scenery of southern Laos."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Wear comfortable walking shoes because the temple has uneven stone pathways and stairways.",
            "Dress modestly when visiting religious structures.",
            "Bring sunscreen, a hat, and drinking water.",
            "Visit early in the morning to avoid the strongest afternoon heat.",
            "Consider hiring a local guide to understand the Khmer history and architecture.",
            "Respect religious traditions and avoid disturbing worshippers.",
            "Do not climb on fragile or restricted archaeological structures.",
            "Keep the site clean and protect its historic environment."
        ]
    },

    // ===================================
    // IX. TIMOR-LESTE
    // ===================================

    // ===================================
    // 41. CRISTO REI OF DILI
    // ===================================

    {
        name: "Cristo Rei of Dili",
        country: "Timor-Leste",
        category: "Religious & Sightseeing",
        image: "images/Cristo Rei of Dili.jpg",
        budget: 60,
        featured: true,

        // 1. Overview
        description: "Cristo Rei of Dili is one of the most recognizable landmarks in Timor-Leste, featuring a magnificent statue of Jesus Christ standing on a globe overlooking the beautiful coastline of Dili. Located on a scenic hill, this iconic monument offers breathtaking ocean views, peaceful surroundings, and a meaningful cultural and religious experience.",
        location: "Cape Fatucama, east of Dili, Timor-Leste.",
        history: "Cristo Rei of Dili was inaugurated in 1996 and became an important religious and national landmark. The monument features a 27-meter statue of Jesus Christ standing above a globe, symbolizing faith and hope. Today, it is one of the most visited attractions in the country's capital.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Cristo Rei Statue",
                description: "The impressive statue of Jesus Christ standing with outstretched arms above a globe, overlooking the ocean and surrounding coastline."
            },
            {
                name: "Scenic Stairway",
                description: "A long staircase leading visitors up the hillside toward the statue, providing beautiful views along the way."
            },
            {
                name: "Cape Fatucama",
                description: "A picturesque coastal area featuring rocky landscapes, ocean views, and peaceful natural surroundings."
            },
            {
                name: "Backside Beach",
                description: "A beautiful beach near the monument where visitors can enjoy the sea, coastal scenery, and relaxing atmosphere."
            },
            {
                name: "Sunset Viewpoint",
                description: "A wonderful location to admire the changing colors of the sky as the sun sets over the ocean."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "See one of the most famous landmarks in Timor-Leste.",
            "Enjoy breathtaking views of the coastline and surrounding ocean.",
            "Discover an important religious and cultural monument.",
            "Experience a peaceful atmosphere away from the busy city center.",
            "Capture beautiful photographs, especially during sunrise and sunset."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "May to October.",
            weather: "The dry season generally offers sunny weather, lower rainfall, and comfortable conditions for outdoor sightseeing.",
            recommendation: "Visit early in the morning or during the late afternoon to avoid the strongest heat. Sunset is especially beautiful for photography and ocean views."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Watch the Sunset Over Dili Bay",
            experience: "Climb the scenic staircase toward the Cristo Rei statue and enjoy panoramic views of the ocean. During sunset, the sky can transform into beautiful shades of orange, pink, and gold, creating a memorable atmosphere around the monument.",
            culturalSignificance: "Cristo Rei represents the importance of Christianity in Timor-Leste and has become a recognizable symbol of the country's religious identity and national landscape.",
            recommendation: "Bring a camera and visit in the late afternoon to enjoy the beautiful coastal scenery and sunset. Dress respectfully because the monument is an important religious site."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$20–$40 per night" },
            { item: "Food and Drinks", cost: "$8–$15 per day" },
            { item: "Transportation", cost: "$5–$15" },
            { item: "Monument Visit", cost: "Generally free" },
            { item: "Additional Activities", cost: "$5–$10" }
        ],
        budgetNote: "The estimated daily budget is approximately $40–$60 per person, depending on accommodation, meals, and transportation. Prices may vary depending on travel arrangements and personal preferences.",

        // 7. Transportation and Accommodation
        transportation: [
            "Fly into Presidente Nicolau Lobato International Airport in Dili.",
            "Travel from central Dili by taxi or local transportation.",
            "Hire a private driver for a convenient visit to Cape Fatucama.",
            "Walk up the staircase to reach the statue and enjoy the surrounding viewpoints.",
            "Arrange local transportation when visiting nearby beaches."
        ],
        accommodation: [
            "Budget guesthouses and hostels in central Dili.",
            "Mid-range hotels near the city center and waterfront.",
            "Comfortable hotels offering ocean and city views.",
            "Beachside accommodation for visitors seeking a relaxing coastal stay."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "3:00 PM",
                activity: "Travel to Cristo Rei",
                description: "Leave central Dili and enjoy the scenic coastal journey toward Cape Fatucama."
            },
            {
                time: "3:30 PM",
                activity: "Explore the Monument Area",
                description: "Discover the surroundings and admire the impressive statue from below."
            },
            {
                time: "4:00 PM",
                activity: "Climb the Staircase",
                description: "Walk along the scenic staircase toward the monument while enjoying views of the coastline."
            },
            {
                time: "4:45 PM",
                activity: "Visit the Cristo Rei Statue",
                description: "Admire the landmark and learn about its religious and cultural significance."
            },
            {
                time: "5:15 PM",
                activity: "Enjoy the Sunset",
                description: "Relax and photograph the beautiful colors of the sky reflecting over Dili Bay."
            },
            {
                time: "6:00 PM",
                activity: "Return to Central Dili",
                description: "Finish the visit and enjoy the evening atmosphere in the capital."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Wear comfortable shoes because the staircase involves many steps.",
            "Bring drinking water, sunscreen, and a hat.",
            "Visit early in the morning or late afternoon to avoid excessive heat.",
            "Dress respectfully when visiting the religious monument.",
            "Bring a camera to capture the ocean views and sunset.",
            "Be careful on the stairs, especially after rain.",
            "Respect local visitors and religious traditions.",
            "Keep the monument and surrounding environment clean."
        ]
    },

    // ===================================
    // 42. ATAURO ISLAND
    // ===================================

    {
        name: "Atauro Island",
        country: "Timor-Leste",
        category: "Island & Marine Nature",
        image: "images/Atauro Island.jpg",
        budget: 85,
        featured: false,

        // 1. Overview
        description: "Atauro Island is a beautiful tropical island north of Dili, famous for its crystal-clear waters, colorful coral reefs, peaceful beaches, and traditional coastal villages. Surrounded by rich marine biodiversity and dramatic mountain scenery, the island is an excellent destination for visitors who enjoy snorkeling, diving, nature, and relaxing by the sea.",
        location: "Approximately 25 kilometers north of Dili, in the Wetar Strait, Timor-Leste.",
        history: "Atauro Island has a long history of traditional coastal communities, fishing, and local cultural practices. Its villages have maintained distinctive traditions and ways of life, while the island has increasingly attracted visitors interested in marine conservation and community-based tourism.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Beloi Beach",
                description: "A beautiful coastal area with clear water and scenic views, popular for swimming, snorkeling, and relaxing by the sea."
            },
            {
                name: "Adara Beach",
                description: "A peaceful beach surrounded by natural scenery, offering visitors a relaxing escape and beautiful coastal views."
            },
            {
                name: "Atauro Coral Reefs",
                description: "The surrounding waters contain remarkable coral reefs and diverse marine life, making the island attractive for snorkeling and diving."
            },
            {
                name: "Traditional Fishing Villages",
                description: "Explore local coastal communities and discover traditional fishing practices, handmade crafts, and everyday island life."
            },
            {
                name: "Mount Manucoco",
                description: "The island's highest mountain offers challenging hiking opportunities and beautiful views of the surrounding landscape."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Discover beautiful tropical beaches and clear blue ocean water.",
            "Explore coral reefs and fascinating marine biodiversity.",
            "Enjoy snorkeling, diving, and other ocean activities.",
            "Experience traditional island communities and local hospitality.",
            "Escape busy city life and enjoy a peaceful natural environment."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "May to October.",
            weather: "The dry season generally brings sunny conditions and less rainfall, making it suitable for beach activities and outdoor exploration.",
            recommendation: "Visit during the dry season for comfortable island activities. Always check sea conditions and local boat schedules before traveling."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Discover the Underwater World of Atauro",
            experience: "Explore the island's beautiful marine environment through snorkeling or diving, where visitors can discover colorful coral reefs and a variety of tropical fish.",
            culturalSignificance: "Atauro Island represents the close relationship between local communities and the ocean. Traditional fishing, island customs, and marine resources remain important parts of local life.",
            recommendation: "Join a responsible local snorkeling or diving guide, use reef-safe sunscreen, and avoid touching or standing on coral reefs."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Accommodation", cost: "$20–$40 per night" },
            { item: "Food and Drinks", cost: "$8–$15 per day" },
            { item: "Boat Transportation", cost: "$10–$25" },
            { item: "Snorkeling or Diving", cost: "$15–$30" },
            { item: "Additional Activities", cost: "$5–$15" }
        ],
        budgetNote: "The estimated daily budget is approximately $50–$85 per person, depending on accommodation, boat transportation, meals, and selected activities. Boat schedules and activity prices may vary by season and provider.",

        // 7. Transportation and Accommodation
        transportation: [
            "Travel from Dili to Atauro Island by passenger ferry or another available boat service.",
            "Check departure schedules and sea conditions before planning the journey.",
            "Use local transportation or arrange a pickup with your accommodation.",
            "Explore nearby beaches and villages with local guides.",
            "Arrange boat trips with responsible local operators for snorkeling and diving."
        ],
        accommodation: [
            "Budget guesthouses and simple island lodges.",
            "Beachside bungalows near local villages.",
            "Eco-friendly accommodation offering peaceful ocean views.",
            "Community-based guesthouses where visitors can experience local hospitality.",
            "Small resorts and diving lodges for visitors interested in marine activities."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "7:00 AM",
                activity: "Depart from Dili",
                description: "Travel to the departure point and board a scheduled boat to Atauro Island."
            },
            {
                time: "9:00 AM",
                activity: "Arrive at Atauro Island",
                description: "Enjoy the first views of the island and settle into your accommodation."
            },
            {
                time: "10:00 AM",
                activity: "Explore Beloi Beach",
                description: "Walk along the beautiful coastline and enjoy the peaceful island atmosphere."
            },
            {
                time: "11:30 AM",
                activity: "Snorkeling Experience",
                description: "Discover colorful tropical fish and coral reefs with a responsible local guide."
            },
            {
                time: "1:00 PM",
                activity: "Enjoy Local Seafood",
                description: "Take a lunch break and experience fresh local island food."
            },
            {
                time: "2:30 PM",
                activity: "Visit a Traditional Village",
                description: "Learn about local traditions, fishing practices, and community life."
            },
            {
                time: "4:00 PM",
                activity: "Relax by the Beach",
                description: "Enjoy the ocean views and peaceful surroundings before returning to your accommodation."
            },
            {
                time: "5:30 PM",
                activity: "Enjoy the Island Sunset",
                description: "Relax and admire the beautiful evening colors over the sea."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Check boat schedules before traveling because services may be limited.",
            "Bring enough cash because some island businesses may not accept cards.",
            "Pack sunscreen, insect repellent, and drinking water.",
            "Bring swimwear, a towel, and comfortable footwear.",
            "Check sea conditions before swimming, snorkeling, or diving.",
            "Use reef-safe sunscreen and never touch or damage coral reefs.",
            "Respect local customs and ask permission before photographing residents.",
            "Take your rubbish with you and help protect the island's natural environment."
        ]
    },

    // ===================================
    // 43. JACO ISLAND
    // ===================================

    {
        name: "Jaco Island",
        country: "Timor-Leste",
        category: "Island & Beach",
        image: "images/Jaco Island.jpg",
        budget: 85,
        featured: false,

        // 1. Overview
        description: "Jaco Island is a beautiful, uninhabited tropical island located at the easternmost tip of Timor-Leste. Famous for its white sandy beaches, crystal-clear turquoise waters, and peaceful natural surroundings, it is one of the country's most stunning coastal destinations.",

        location: "Tutuala, Lautém Municipality, eastern Timor-Leste.",

        history: "Jaco Island is part of the Nino Konis Santana National Park, an important protected area known for its rich marine and terrestrial biodiversity. The island also holds cultural and spiritual significance for local communities, who traditionally regard it as a sacred place.",

        // 2. Main Attractions
        attractions: [
            {
                name: "White Sandy Beaches",
                description: "Enjoy beautiful white-sand beaches surrounded by clear turquoise water and untouched tropical scenery."
            },
            {
                name: "Crystal-Clear Ocean",
                description: "Discover the island's peaceful coastal waters, which are ideal for swimming when sea conditions are safe."
            },
            {
                name: "Marine Life",
                description: "Explore the surrounding marine environment, which forms part of a protected area with diverse underwater ecosystems."
            },
            {
                name: "Natural Island Scenery",
                description: "Experience the beauty of an uninhabited island with quiet beaches, tropical vegetation, and breathtaking ocean views."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Discover one of Timor-Leste's most beautiful tropical islands.",
            "Relax on peaceful white-sand beaches away from busy tourist areas.",
            "Enjoy clear turquoise water and beautiful coastal scenery.",
            "Experience the natural beauty of a protected island environment.",
            "Take memorable photographs of an untouched tropical paradise."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "May to November.",
            weather: "The dry season generally brings sunnier weather, lower rainfall, and more comfortable conditions for island visits.",
            recommendation: "Visit during the dry season and check local sea conditions before arranging a boat trip."
        },

        // 5. Special Experience
        specialExperience: {
            title: "A Peaceful Escape to a Tropical Island",
            experience: "Take a local boat from the Tutuala area to Jaco Island and spend time enjoying its beautiful beaches, clear water, and peaceful natural surroundings.",
            culturalSignificance: "Jaco Island is traditionally considered sacred by local communities, making respect for local customs and conservation especially important.",
            recommendation: "Enjoy the island responsibly, follow local guidance, and avoid leaving rubbish or disturbing wildlife."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Boat Transportation", cost: "$25 - $35" },
            { item: "Food and Drinks", cost: "$10 - $15" },
            { item: "Local Guide or Assistance", cost: "$15 - $20" },
            { item: "Other Expenses", cost: "$10 - $15" }
        ],

        budgetNote: "Estimated budget is approximately $60 - $85 per person for a day trip. Actual costs may vary depending on boat arrangements, local services, and travel plans.",

        // 7. Transportation and Accommodation
        transportation: [
            "Travel by road from Dili to the Tutuala area, which requires a long journey.",
            "Continue to the local coastal area where boat transportation can be arranged.",
            "Take a local boat to Jaco Island, depending on weather and sea conditions.",
            "Follow local guidance because there are no regular public transportation services directly to the island."
        ],

        accommodation: [
            "Stay in a local guesthouse in Tutuala or nearby communities.",
            "Choose accommodation in Com or other nearby coastal areas.",
            "Return to the mainland for overnight accommodation because Jaco Island is uninhabited and has no regular hotels."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "7:00 AM",
                activity: "Travel to the Coast",
                description: "Arrive at the local departure area and prepare for the boat journey to Jaco Island."
            },
            {
                time: "9:00 AM",
                activity: "Arrive at Jaco Island",
                description: "Enjoy the beautiful white-sand beaches and explore the island's natural scenery."
            },
            {
                time: "11:00 AM",
                activity: "Beach and Ocean Experience",
                description: "Relax by the beach, enjoy the clear water when conditions are safe, and take photographs."
            },
            {
                time: "12:30 PM",
                activity: "Lunch and Relaxation",
                description: "Enjoy a packed lunch and spend some peaceful time surrounded by tropical nature."
            },
            {
                time: "2:00 PM",
                activity: "Explore the Coastline",
                description: "Discover more of the island's beautiful coastal views while respecting its protected environment."
            },
            {
                time: "3:30 PM",
                activity: "Return to the Mainland",
                description: "Take the boat back to the mainland and continue to your accommodation."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Arrange boat transportation with local operators before visiting.",
            "Check weather and sea conditions before departure.",
            "Bring enough drinking water, food, sunscreen, and personal supplies.",
            "Wear comfortable beach footwear and bring sun protection.",
            "Respect the island's cultural and spiritual significance.",
            "Do not leave rubbish or damage the natural environment.",
            "Follow local guidance and avoid swimming when sea conditions are unsafe."
        ]
    },

    // ===================================
    // 44. MOUNT RAMELAU
    // ===================================

    {
        name: "Mount Ramelau",
        country: "Timor-Leste",
        category: "Nature & Adventure",
        image: "images/Mount Ramelau.jpg",
        budget: 75,
        featured: false,

        // 1. Overview
        description: "Mount Ramelau, also known as Tatamailau, is the highest mountain in Timor-Leste. Rising above the surrounding landscapes, it is famous for its breathtaking mountain views, peaceful atmosphere, and beautiful sunrise experiences. It is a popular destination for hikers, nature lovers, and travelers seeking adventure.",

        location: "Ainaro Municipality, central Timor-Leste, near the town of Hato Builico.",

        history: "Mount Ramelau has deep cultural and spiritual importance for the people of Timor-Leste. At its summit stands a statue of the Virgin Mary, installed in 1997, which has made the mountain an important pilgrimage destination. It is also a symbol of national identity and pride.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Mount Ramelau Summit",
                description: "Reach the highest point in Timor-Leste, approximately 2,986 meters above sea level, and enjoy spectacular panoramic mountain views."
            },
            {
                name: "Virgin Mary Statue",
                description: "Visit the famous statue near the summit, an important religious landmark and pilgrimage site."
            },
            {
                name: "Sunrise Viewpoint",
                description: "Experience a beautiful sunrise above the mountain ranges, often accompanied by a sea of clouds."
            },
            {
                name: "Mountain Hiking Trails",
                description: "Explore scenic hiking routes surrounded by cool mountain air, natural landscapes, and peaceful countryside."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Stand on the highest mountain in Timor-Leste.",
            "Enjoy breathtaking sunrise and panoramic mountain views.",
            "Experience one of the country's most meaningful cultural and religious landmarks.",
            "Challenge yourself with an unforgettable mountain hike.",
            "Discover the peaceful beauty of Timor-Leste's highland landscapes."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "May to November.",
            weather: "The dry season generally offers clearer skies and better hiking conditions, although temperatures at the summit can be cold, especially before sunrise.",
            recommendation: "Plan your hike during the dry season and begin early enough to reach the summit before sunrise."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Watching the Sunrise from the Highest Mountain",
            experience: "Take an early-morning hike toward the summit and watch the sun rise over the surrounding mountain ranges. Enjoy the peaceful atmosphere and incredible views from the top of Timor-Leste.",
            culturalSignificance: "The summit's Virgin Mary statue represents an important place of Catholic devotion and pilgrimage. Mount Ramelau also holds a special place in Timor-Leste's cultural identity.",
            recommendation: "Bring warm clothing, travel with a local guide if possible, and take time to appreciate both the natural scenery and the mountain's cultural significance."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Transportation", cost: "$25 - $30" },
            { item: "Local Guide", cost: "$15 - $20" },
            { item: "Food and Drinks", cost: "$10 - $15" },
            { item: "Accommodation or Other Expenses", cost: "$10 - $15" }
        ],

        budgetNote: "Estimated budget is approximately $60 - $75 per person, depending on transportation, guide arrangements, and whether an overnight stay is needed.",
        // 7. Transportation and Accommodation
        transportation: [
            "Travel from Dili toward Ainaro Municipality by road.",
            "Continue to Hato Builico, the common starting area for Mount Ramelau hikes.",
            "Arrange local transportation or a guide for the mountain route.",
            "Hike from the trailhead to the summit, allowing enough time for the climb."
        ],

        accommodation: [
            "Stay in a local guesthouse around Hato Builico.",
            "Choose simple accommodation in nearby villages.",
            "Return to Dili or another nearby town after the hike if your travel schedule allows."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "2:00 AM",
                activity: "Begin the Mountain Hike",
                description: "Start the climb with a local guide and follow the mountain trail toward the summit."
            },
            {
                time: "5:00 AM",
                activity: "Reach the Summit",
                description: "Arrive near the summit and prepare to enjoy the beautiful early-morning mountain scenery."
            },
            {
                time: "6:00 AM",
                activity: "Watch the Sunrise",
                description: "Experience the sunrise above the surrounding mountains and clouds."
            },
            {
                time: "7:00 AM",
                activity: "Visit the Virgin Mary Statue",
                description: "Explore the summit landmark and learn about its religious and cultural significance."
            },
            {
                time: "8:00 AM",
                activity: "Enjoy the Mountain Views",
                description: "Take photographs and appreciate the peaceful highland landscape."
            },
            {
                time: "9:00 AM",
                activity: "Descend the Mountain",
                description: "Begin the return hike and enjoy the natural scenery along the trail."
            },
            {
                time: "12:00 PM",
                activity: "Return to Hato Builico",
                description: "Rest, enjoy a meal, and continue your journey or return to your accommodation."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Wear comfortable hiking shoes with good grip.",
            "Bring warm clothing because summit temperatures can be very cold.",
            "Carry enough drinking water and snacks for the hike.",
            "Start early to enjoy the sunrise and allow enough time for the return journey.",
            "Consider hiring a local guide who knows the mountain trails.",
            "Check weather conditions before beginning the hike.",
            "Respect the religious significance of the summit and its landmarks.",
            "Take your rubbish with you and protect the natural environment."
        ]
    },

    // ===================================
    // 45. TAIS MARKET DILI
    // ===================================

    {
        name: "Tais Market Dili",
        country: "Timor-Leste",
        category: "Culture & Traditional Crafts",
        image: "images/Tais Market Dili.jpg",
        budget: 45,
        featured: false,

        // 1. Overview
        description: "Tais Market Dili is a cultural shopping destination where visitors can discover traditional Timorese woven textiles known as Tais. These colorful handmade fabrics represent the country's cultural identity, artistic creativity, and traditional craftsmanship. The market offers a wonderful opportunity to explore local culture and support Timorese artisans.",

        location: "Dili, the capital city of Timor-Leste.",

        history: "Tais is a traditional woven textile that has been part of Timorese culture for generations. Different communities create distinctive patterns, colors, and designs that reflect their local traditions and identities. Traditionally used for ceremonies, celebrations, and important cultural occasions, Tais remains an important symbol of Timor-Leste's heritage.",

        // 2. Main Attractions
        attractions: [
            {
                name: "Traditional Tais Textiles",
                description: "Discover colorful handmade fabrics featuring traditional patterns, geometric designs, and meaningful cultural symbols."
            },
            {
                name: "Local Handicraft Stalls",
                description: "Explore stalls selling traditional textiles, handmade accessories, bags, and other locally produced crafts."
            },
            {
                name: "Traditional Weaving Designs",
                description: "Learn about the different weaving styles and patterns created by Timorese communities across the country."
            },
            {
                name: "Local Artisan Culture",
                description: "Meet local sellers and discover the skills, creativity, and traditions behind Timor-Leste's textile craftsmanship."
            }
        ],

        // 3. Why Visit?
        reasons: [
            "Discover one of the most recognizable traditional crafts of Timor-Leste.",
            "Learn about the country's cultural identity through handmade textiles.",
            "Explore colorful fabrics and unique traditional patterns.",
            "Support local artisans and traditional craftsmanship.",
            "Find meaningful handmade souvenirs to remember your visit."
        ],

        // 4. Best Time to Visit
        bestTime: {
            season: "May to November.",
            weather: "The dry season generally offers sunny and comfortable conditions for exploring Dili's outdoor markets and cultural attractions.",
            recommendation: "Visit in the morning when the market is generally more comfortable to explore, and check local opening times before traveling."
        },

        // 5. Special Experience
        specialExperience: {
            title: "Discovering the Art of Traditional Tais Weaving",
            experience: "Explore the market's colorful textile displays, learn about traditional weaving patterns, and purchase a handmade Tais product directly from local sellers.",
            culturalSignificance: "Tais represents the cultural identity, heritage, and artistic traditions of Timor-Leste. It is commonly used during ceremonies, celebrations, and important cultural events.",
            recommendation: "Ask local sellers about the meaning of different patterns and the communities associated with their weaving traditions."
        },

        // 6. Estimated Budget
        budgetDetails: [
            { item: "Traditional Tais Souvenir", cost: "$10 - $20" },
            { item: "Food and Drinks", cost: "$5 - $10" },
            { item: "Local Transportation", cost: "$5 - $10" },
            { item: "Other Expenses", cost: "$5" }
        ],
        budgetNote: "Estimated budget is approximately $25 - $45 per person for a market visit, depending on transportation, food choices, and the souvenirs purchased. Larger handmade textiles may cost more.",

        // 7. Transportation and Accommodation
        transportation: [
            "Travel by taxi or local public transportation to the market area in Dili.",
            "Use local transportation services to explore other attractions around the capital.",
            "Walking is also a convenient way to explore nearby shops and cultural areas when staying in central Dili."
        ],

        accommodation: [
            "Choose a hotel or guesthouse in central Dili for convenient access to the market.",
            "Stay near the city's main attractions, restaurants, and shopping areas.",
            "Budget guesthouses and small hotels are available throughout the capital."
        ],

        // 8. Suggested Itinerary
        itinerary: [
            {
                time: "9:00 AM",
                activity: "Arrive at Tais Market",
                description: "Begin your visit by exploring the market and viewing the colorful traditional textiles."
            },
            {
                time: "9:30 AM",
                activity: "Discover Traditional Fabrics",
                description: "Look at different Tais patterns, colors, and weaving styles from various Timorese communities."
            },
            {
                time: "10:30 AM",
                activity: "Meet Local Sellers",
                description: "Talk with local sellers and learn more about the cultural meaning and craftsmanship behind Tais."
            },
            {
                time: "11:30 AM",
                activity: "Shop for Handmade Souvenirs",
                description: "Browse traditional fabrics, accessories, and handmade products while supporting local artisans."
            },
            {
                time: "12:30 PM",
                activity: "Enjoy Local Food",
                description: "Take a break and enjoy a meal or refreshments at a nearby local restaurant."
            },
            {
                time: "1:30 PM",
                activity: "Explore Dili",
                description: "Continue discovering the capital's nearby cultural attractions and local shopping areas."
            }
        ],

        // 9. Travel Tips
        tips: [
            "Bring cash because some local sellers may not accept cards.",
            "Ask permission before photographing sellers or their products.",
            "Respect local traditions and cultural practices.",
            "Ask about the meaning of traditional patterns when purchasing Tais.",
            "Compare prices and quality before buying handmade textiles.",
            "Support local artisans by purchasing authentic handmade products.",
            "Bring a reusable shopping bag for your purchases.",
            "Check market opening times before visiting."
        ]
    }
]