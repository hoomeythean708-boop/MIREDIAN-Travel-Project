// ===================================
// MIREDIAN - SOUTH AMERICA
// ===================================

const southAmericaDestinations = [

    // ===================================
    // I. BRAZIL
    // ===================================

    // ===================================
    // 1. CHRIST THE REDEEMER
    // ===================================

    {
        name: "Christ the Redeemer",
        country: "Brazil",
        category: "Landmark",
        image: "images/Christ the Redeemer.jpg",
        budget: 150,
        featured: true,

        // 1. DESCRIPTION
        description: "Christ the Redeemer is one of the world's most recognizable monuments, standing high above Rio de Janeiro with magnificent views of the city, mountains, and Atlantic coastline.",

        // 2. LOCATION
        location: "Corcovado Mountain, Rio de Janeiro, Brazil",

        // 3. HISTORY
        history: "The statue was completed in 1931 and designed by Brazilian engineer Heitor da Silva Costa, with French-Polish sculptor Paul Landowski contributing to its creation. It stands approximately 30 meters tall, excluding its pedestal, and became a symbol of Brazil.",

        // 4. ATTRACTIONS
        attractions: [
            {
                name: "Christ the Redeemer Statue",
                description: "Admire the enormous Art Deco statue overlooking Rio de Janeiro."
            },
            {
                name: "Corcovado Mountain",
                description: "Enjoy spectacular views from one of Rio's most famous mountain peaks."
            },
            {
                name: "Tijuca National Park",
                description: "Explore a beautiful urban rainforest filled with tropical plants and wildlife."
            },
            {
                name: "Mirante Dona Marta",
                description: "Discover a scenic viewpoint offering breathtaking views of the statue and city."
            }
        ],

        // 5. REASONS TO VISIT
        reasons: [
            "See one of the New Seven Wonders of the World.",
            "Enjoy panoramic views of Rio de Janeiro.",
            "Discover an important symbol of Brazilian culture.",
            "Explore the natural beauty of Tijuca National Park.",
            "Capture unforgettable photographs of the famous landmark."
        ],

        // 6. BEST TIME TO VISIT
        bestTime: {
            season: "Dry Season",
            weather: "Generally warm and pleasant, with clearer skies during many dry-season days.",
            recommendation: "May to September is often a comfortable period for sightseeing and enjoying mountain views."
        },

        // 7. SPECIAL EXPERIENCE
        specialExperience: {
            title: "Sunrise at Christ the Redeemer",
            experience: "Visit early in the morning to admire the famous statue as daylight spreads across Rio's mountains, beaches, and coastline.",
            culturalSignificance: "The monument represents Christianity and has become an internationally recognized symbol of Rio de Janeiro and Brazil.",
            recommendation: "Book the official train or an authorized transfer in advance and check visibility before your visit."
        },

        // 8. BUDGET DETAILS
        budgetDetails: [
            { item: "Admission and Transport", cost: "$20–$35" },
            { item: "Food", cost: "$15–$25" },
            { item: "Local Transportation", cost: "$10–$20" },
            { item: "Accommodation", cost: "$60–$100" }
        ],

        // 9. BUDGET NOTE
        budgetNote: "Estimated daily budget per person in US-dollar equivalents. Costs vary by season and transport choice. International flights are excluded.",

        // 10. TRANSPORTATION
        transportation: [
            "Take the official Corcovado train from Cosme Velho Station.",
            "Use authorized vans that travel up Corcovado Mountain.",
            "Use the Rio Metro, buses, or authorized ride services to reach nearby attractions."
        ],

        // 11. ACCOMMODATION
        accommodation: [
            "Stay in Copacabana for beach access and convenient transportation.",
            "Choose hotels in Ipanema for a lively coastal atmosphere.",
            "Consider accommodation in Botafogo for beautiful views and city connections."
        ],

        // 12. ITINERARY
        itinerary: [
            {
                time: "7:00 AM",
                activity: "Journey to Corcovado",
                description: "Travel toward the mountain and enjoy the beautiful surroundings."
            },
            {
                time: "8:00 AM",
                activity: "Christ the Redeemer",
                description: "Admire the famous statue and panoramic views of Rio."
            },
            {
                time: "10:00 AM",
                activity: "Tijuca National Park",
                description: "Explore the rainforest and appreciate its natural beauty."
            },
            {
                time: "12:00 PM",
                activity: "Lunch Break",
                description: "Enjoy traditional Brazilian food at a nearby restaurant."
            },
            {
                time: "2:00 PM",
                activity: "Mirante Dona Marta",
                description: "Visit a scenic viewpoint for unforgettable city photographs."
            },
            {
                time: "4:00 PM",
                activity: "Explore Rio de Janeiro",
                description: "Finish the day discovering the city's lively neighborhoods."
            }
        ],

        // 13. TIPS
        tips: [
            "Book admission and transportation in advance.",
            "Visit early to avoid large crowds.",
            "Check the weather because clouds can affect visibility.",
            "Wear comfortable walking shoes.",
            "Bring sunscreen and drinking water.",
            "Keep personal belongings secure.",
            "Respect the religious and cultural significance of the monument.",
            "Allow extra time for transportation and queues."
        ]
    },
    // ===================================
    // 2. IGUAZU FALLS
    // ===================================
    
    {
        name: "Iguazu Falls",
        country: "Brazil",
        category: "Nature",
        image: "images/Iguazu Falls.jpg",
        budget: 140,
        featured: false,

        // 1. DESCRIPTION
        description: "Iguazu Falls is one of the world's most spectacular waterfall systems, featuring hundreds of powerful cascades surrounded by lush subtropical rainforest along the border of Brazil and Argentina.",

        // 2. LOCATION
        location: "Foz do Iguaçu, Paraná, Brazil",

        // 3. HISTORY
        history: "The waterfalls have been part of the natural and cultural landscape of the region for centuries. They were described by Spanish explorer Álvar Núñez Cabeza de Vaca in 1541 and later became protected through national parks on both sides of the border. Iguazu National Park in Brazil is a UNESCO World Heritage Site.",

        // 4. ATTRACTIONS
        attractions: [
            {
                name: "Devil's Throat",
                description: "Witness the immense power of the largest and most dramatic section of the waterfall system."
            },
            {
                name: "Brazilian Falls Trail",
                description: "Walk along scenic paths offering panoramic views of the magnificent waterfalls."
            },
            {
                name: "Iguazu National Park",
                description: "Explore protected rainforest filled with diverse plants, birds, and wildlife."
            },
            {
                name: "Macuco Safari",
                description: "Experience an exciting boat excursion near the waterfalls, subject to operating conditions."
            }
        ],

        // 5. REASONS TO VISIT
        reasons: [
            "Experience one of the world's most impressive waterfall systems.",
            "Enjoy breathtaking panoramic natural scenery.",
            "Discover the biodiversity of the Atlantic rainforest.",
            "Take unforgettable photographs of powerful waterfalls.",
            "Experience exciting nature and boat excursions."
        ],

        // 6. BEST TIME TO VISIT
        bestTime: {
            season: "Spring and Autumn",
            weather: "Generally warm, with water flow and rainfall varying throughout the year.",
            recommendation: "March to May and August to October are popular periods for comfortable sightseeing."
        },

        // 7. SPECIAL EXPERIENCE
        specialExperience: {
            title: "Panoramic Waterfall Experience",
            experience: "Walk along the Brazilian-side trails and admire the spectacular waterfalls from wide viewpoints overlooking the river and rainforest.",
            culturalSignificance: "The name Iguazu comes from Indigenous Guarani words commonly translated as 'big water,' reflecting the importance of the falls in the region's natural and cultural heritage.",
            recommendation: "Wear waterproof clothing and protect your camera from the mist."
        },

        // 8. BUDGET DETAILS
        budgetDetails: [
            { item: "Park Admission", cost: "$15–$25" },
            { item: "Food", cost: "$15–$25" },
            { item: "Local Transportation", cost: "$5–$15" },
            { item: "Accommodation", cost: "$60–$100" }
        ],

        // 9. BUDGET NOTE
        budgetNote: "Estimated daily budget per person in US-dollar equivalents. Costs vary by season and activities. International flights are excluded.",

        // 10. TRANSPORTATION
        transportation: [
            "Take local buses from Foz do Iguaçu to the national park entrance.",
            "Use authorized taxis or ride-sharing services for convenient travel.",
            "Join organized tours for visits to attractions on both sides of the border."
        ],

        // 11. ACCOMMODATION
        accommodation: [
            "Stay in hotels in Foz do Iguaçu for convenient park access.",
            "Choose accommodation near the city center for restaurants and transport.",
            "Consider hotels near the national park entrance for a nature-focused stay."
        ],

        // 12. ITINERARY
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Iguazu National Park",
                description: "Arrive early and begin exploring the protected rainforest."
            },
            {
                time: "9:00 AM",
                activity: "Brazilian Falls Trail",
                description: "Walk along scenic paths and enjoy panoramic waterfall views."
            },
            {
                time: "11:00 AM",
                activity: "Devil's Throat Viewpoints",
                description: "Admire the dramatic waterfalls and powerful rushing water."
            },
            {
                time: "12:30 PM",
                activity: "Lunch Break",
                description: "Enjoy a relaxing meal near the park."
            },
            {
                time: "2:00 PM",
                activity: "Macuco Safari",
                description: "Enjoy an optional boat adventure when available and conditions permit."
            },
            {
                time: "4:00 PM",
                activity: "Rainforest Exploration",
                description: "Take in the surrounding scenery and look for local wildlife."
            }
        ],

        // 13. TIPS
        tips: [
            "Arrive early to make the most of your visit.",
            "Wear comfortable shoes with good grip.",
            "Bring a raincoat because waterfall mist can be heavy.",
            "Protect cameras and electronic devices from water.",
            "Carry drinking water and sunscreen.",
            "Follow park rules and stay on marked trails.",
            "Keep a safe distance from wildlife.",
            "Check border crossing requirements if visiting the Argentinian side."
        ]
    },

    // ===================================
    // 3. AMAZON RAINFOREST
    // ===================================

    {
        name: "Amazon Rainforest",
        country: "Brazil",
        category: "Nature",
        image: "images/Amazon Rainforest.jpg",
        budget: 180,
        featured: false,

        // 1. DESCRIPTION
        description: "The Amazon Rainforest is the world's largest tropical rainforest, famous for its extraordinary biodiversity, winding rivers, Indigenous cultures, and breathtaking natural landscapes.",

        // 2. LOCATION
        location: "Amazonas State, Brazil",

        // 3. HISTORY
        history: "The Amazon has been home to Indigenous communities for thousands of years. Its rivers and forests supported complex societies long before European arrival. Today, the region remains globally important for biodiversity, climate regulation, and Indigenous heritage.",

        // 4. ATTRACTIONS
        attractions: [
            {
                name: "Meeting of the Waters",
                description: "See the remarkable natural phenomenon where the dark Rio Negro and sandy-colored Amazon River flow side by side without immediately mixing."
            },
            {
                name: "Anavilhanas Archipelago",
                description: "Explore a vast network of river islands, waterways, and flooded forests."
            },
            {
                name: "Jaú National Park",
                description: "Discover protected rainforest landscapes and remarkable Amazonian wildlife."
            },
            {
                name: "Amazon River",
                description: "Experience one of the world's greatest river systems through guided boat excursions."
            }
        ],

        // 5. REASONS TO VISIT
        reasons: [
            "Discover one of the planet's richest ecosystems.",
            "Observe fascinating tropical plants and wildlife.",
            "Experience unforgettable river and rainforest adventures.",
            "Learn about Indigenous cultures and local traditions.",
            "Explore beautiful landscapes found nowhere else."
        ],

        // 6. BEST TIME TO VISIT
        bestTime: {
            season: "Dryer Season",
            weather: "Hot and humid throughout the year, with seasonal rainfall and changing river levels.",
            recommendation: "June to November is generally a popular period for forest walks and wildlife excursions, although conditions vary by location."
        },

        // 7. SPECIAL EXPERIENCE
        specialExperience: {
            title: "Amazon River Expedition",
            experience: "Join a guided boat journey through Amazonian waterways to discover rainforest scenery, observe wildlife, and learn about the ecosystem.",
            culturalSignificance: "The Amazon is home to many Indigenous peoples whose knowledge, languages, and traditions are deeply connected to the rainforest.",
            recommendation: "Choose a responsible local guide or community-based tour that respects wildlife and Indigenous communities."
        },

        // 8. BUDGET DETAILS
        budgetDetails: [
            { item: "Guided Tours", cost: "$40–$70" },
            { item: "Food", cost: "$15–$25" },
            { item: "Local Transportation", cost: "$15–$30" },
            { item: "Accommodation", cost: "$60–$100" }
        ],

        // 9. BUDGET NOTE
        budgetNote: "Estimated daily budget per person in US-dollar equivalents. Remote lodge stays and multi-day expeditions may cost considerably more. International flights are excluded.",

        // 10. TRANSPORTATION
        transportation: [
            "Fly to Manaus, a major gateway to the Brazilian Amazon.",
            "Use riverboats and organized excursions to reach remote areas.",
            "Arrange guided transfers through reputable local operators."
        ],

        // 11. ACCOMMODATION
        accommodation: [
            "Stay at an eco-lodge surrounded by rainforest.",
            "Choose hotels in Manaus before or after excursions.",
            "Consider community-based lodges for locally guided experiences."
        ],

        // 12. ITINERARY
        itinerary: [
            {
                time: "7:00 AM",
                activity: "Amazon River Excursion",
                description: "Begin the day with a guided boat trip through the beautiful waterways."
            },
            {
                time: "9:00 AM",
                activity: "Meeting of the Waters",
                description: "Witness the striking contrast between two rivers flowing side by side."
            },
            {
                time: "11:00 AM",
                activity: "Rainforest Exploration",
                description: "Walk with a knowledgeable guide and learn about native plants and wildlife."
            },
            {
                time: "1:00 PM",
                activity: "Local Lunch",
                description: "Taste regional Amazonian dishes and fresh local ingredients."
            },
            {
                time: "2:30 PM",
                activity: "Wildlife Observation",
                description: "Explore the waterways and look for birds and other wildlife from a safe distance."
            },
            {
                time: "5:00 PM",
                activity: "River Sunset",
                description: "Enjoy the peaceful atmosphere as the sun sets over the Amazon."
            }
        ],

        // 13. TIPS
        tips: [
            "Travel with experienced local guides.",
            "Bring insect repellent and lightweight long-sleeved clothing.",
            "Carry drinking water and sun protection.",
            "Wear comfortable shoes suitable for humid conditions.",
            "Follow wildlife safety instructions.",
            "Never feed or disturb wild animals.",
            "Respect Indigenous communities and their traditions.",
            "Choose responsible tours that protect the rainforest."
        ]
    },

    // ===================================
    // 4. SUGARLOAF MOUNTAIN
    // ===================================
    
    {
        name: "Sugarloaf Mountain",
        country: "Brazil",
        category: "Nature",
        image: "images/Sugarloaf Mountain.jpg",
        budget: 140,
        featured: false,

        // 1. DESCRIPTION
        description: "Sugarloaf Mountain, known locally as Pão de Açúcar, is one of Rio de Janeiro's most famous natural landmarks. Its distinctive granite peak rises above Guanabara Bay, offering breathtaking views of the city and Atlantic coastline.",

        // 2. LOCATION
        location: "Urca, Rio de Janeiro, Brazil",

        // 3. HISTORY
        history: "Sugarloaf Mountain has been an important natural landmark overlooking Guanabara Bay for centuries. Its famous cable car system opened in 1912, becoming one of the earliest cable car systems in the world and helping establish the mountain as a major tourist attraction.",

        // 4. ATTRACTIONS
        attractions: [
            {
                name: "Sugarloaf Cable Car",
                description: "Enjoy a scenic cable car journey with spectacular views of Rio's coastline and mountains."
            },
            {
                name: "Morro da Urca",
                description: "Explore the first cable car station, featuring viewpoints, gardens, and relaxing spaces."
            },
            {
                name: "Sugarloaf Summit",
                description: "Admire panoramic views of Guanabara Bay, Copacabana, and the surrounding city."
            },
            {
                name: "Urca Neighborhood",
                description: "Discover a charming coastal neighborhood with waterfront scenery and local restaurants."
            }
        ],

        // 5. REASONS TO VISIT
        reasons: [
            "Experience one of Rio de Janeiro's most iconic landmarks.",
            "Enjoy spectacular views from the cable car.",
            "Discover beautiful beaches and coastal landscapes.",
            "Explore the charming Urca neighborhood.",
            "Capture unforgettable photographs of Rio's skyline."
        ],

        // 6. BEST TIME TO VISIT
        bestTime: {
            season: "Dry Season",
            weather: "Generally warm and pleasant, with clearer days offering better visibility.",
            recommendation: "May to September is often a comfortable period for sightseeing. Late afternoons are especially popular for sunset views."
        },

        // 7. SPECIAL EXPERIENCE
        specialExperience: {
            title: "Sunset Cable Car Journey",
            experience: "Ride the cable car to the summit and watch the sun set over Guanabara Bay while the lights of Rio begin to shine.",
            culturalSignificance: "Sugarloaf Mountain is a defining symbol of Rio de Janeiro and an important part of the city's natural and tourism heritage.",
            recommendation: "Arrive before sunset to explore both cable car stations and find a good viewpoint."
        },

        // 8. BUDGET DETAILS
        budgetDetails: [
            { item: "Cable Car Admission", cost: "$25–$40" },
            { item: "Food", cost: "$15–$25" },
            { item: "Local Transportation", cost: "$5–$15" },
            { item: "Accommodation", cost: "$60–$100" }
        ],

        // 9. BUDGET NOTE
        budgetNote: "Estimated daily budget per person in US-dollar equivalents. Cable car tickets and accommodation prices vary by season. International flights are excluded.",

        // 10. TRANSPORTATION
        transportation: [
            "Take a taxi or ride service to the Sugarloaf cable car entrance in Urca.",
            "Use local buses to reach the Urca neighborhood.",
            "Ride the official cable car between Praia Vermelha, Morro da Urca, and Sugarloaf Mountain."
        ],

        // 11. ACCOMMODATION
        accommodation: [
            "Stay in Copacabana for convenient beach access and transportation.",
            "Choose hotels in Botafogo for easy access to Urca.",
            "Consider accommodation in Ipanema for a lively coastal atmosphere."
        ],

        // 12. ITINERARY
        itinerary: [
            {
                time: "9:00 AM",
                activity: "Praia Vermelha",
                description: "Begin the day at this beautiful beach near the cable car station."
            },
            {
                time: "10:00 AM",
                activity: "First Cable Car Ride",
                description: "Travel up to Morro da Urca and enjoy the scenic views."
            },
            {
                time: "11:00 AM",
                activity: "Morro da Urca",
                description: "Explore the viewpoints and relaxing areas at the first station."
            },
            {
                time: "12:30 PM",
                activity: "Lunch Break",
                description: "Enjoy a meal while taking in the beautiful coastal atmosphere."
            },
            {
                time: "2:00 PM",
                activity: "Sugarloaf Summit",
                description: "Continue to the summit and admire panoramic views of Rio."
            },
            {
                time: "5:00 PM",
                activity: "Sunset Photography",
                description: "Capture the changing colors of the sky over Guanabara Bay."
            }
        ],

        // 13. TIPS
        tips: [
            "Check the weather before booking your visit.",
            "Arrive early during busy tourist seasons.",
            "Book cable car tickets in advance when possible.",
            "Bring sunscreen and sunglasses.",
            "Wear comfortable shoes for walking around the viewpoints.",
            "Keep personal belongings secure.",
            "Allow extra time to enjoy both cable car stations.",
            "Bring a camera to capture the beautiful city views."
        ]
    },

    // ===================================
    // 5. COPACABANA BEACH
    // ===================================

    {
        name: "Copacabana Beach",
        country: "Brazil",
        category: "Beach",
        image: "images/Copacabana Beach.jpg",
        budget: 135,
        featured: false,

        // 1. DESCRIPTION
        description: "Copacabana Beach is one of the world's most famous urban beaches, celebrated for its golden sand, lively atmosphere, beautiful ocean views, and iconic wave-patterned promenade.",

        // 2. LOCATION
        location: "Copacabana, Rio de Janeiro, Brazil",

        // 3. HISTORY
        history: "Copacabana grew into a popular seaside destination during the late 19th and early 20th centuries as Rio de Janeiro expanded. Its famous beachfront promenade, designed with Portuguese-style wave patterns, became one of the city's most recognizable features.",

        // 4. ATTRACTIONS
        attractions: [
            {
                name: "Copacabana Promenade",
                description: "Walk along the famous black-and-white wave-patterned pavement beside the beach."
            },
            {
                name: "Copacabana Fort",
                description: "Visit a historic coastal fort featuring military exhibits and beautiful ocean views."
            },
            {
                name: "Leme Beach",
                description: "Enjoy a quieter section of coastline at the northern end of Copacabana."
            },
            {
                name: "Avenida Atlântica",
                description: "Explore the lively beachfront avenue filled with restaurants, hotels, and local activity."
            }
        ],

        // 5. REASONS TO VISIT
        reasons: [
            "Relax on one of Brazil's most iconic beaches.",
            "Enjoy beautiful Atlantic Ocean scenery.",
            "Experience Rio's lively beach culture.",
            "Discover famous coastal architecture and landmarks.",
            "Enjoy local food, music, and outdoor activities."
        ],

        // 6. BEST TIME TO VISIT
        bestTime: {
            season: "Spring and Autumn",
            weather: "Warm coastal weather throughout much of the year, with hotter and busier summer months.",
            recommendation: "April to June and September to November are often comfortable periods for beach visits and sightseeing."
        },

        // 7. SPECIAL EXPERIENCE
        specialExperience: {
            title: "Sunset Along Copacabana",
            experience: "Spend the afternoon enjoying the beach before walking along the famous promenade and watching the sunset over the Atlantic Ocean.",
            culturalSignificance: "Copacabana is an important symbol of Rio's beach culture and is internationally famous for its celebrations, especially its New Year's Eve festivities.",
            recommendation: "Visit in the late afternoon to enjoy the beach atmosphere and explore the promenade."
        },

        // 8. BUDGET DETAILS
        budgetDetails: [
            { item: "Beach Activities", cost: "$5–$15" },
            { item: "Food", cost: "$15–$30" },
            { item: "Local Transportation", cost: "$5–$15" },
            { item: "Accommodation", cost: "$60–$100" }
        ],

        // 9. BUDGET NOTE
        budgetNote: "Estimated daily budget per person in US-dollar equivalents. Costs vary by season and accommodation choice. International flights are excluded.",

        // 10. TRANSPORTATION
        transportation: [
            "Use the Rio Metro to reach nearby stations such as Cardeal Arcoverde and Siqueira Campos.",
            "Walk along Avenida Atlântica to explore the beachfront.",
            "Use authorized taxis or ride-sharing services for longer journeys."
        ],

        // 11. ACCOMMODATION
        accommodation: [
            "Stay at beachfront hotels along Avenida Atlântica.",
            "Choose smaller hotels and guesthouses in the Copacabana neighborhood.",
            "Consider nearby Ipanema for additional beach and dining options."
        ],

        // 12. ITINERARY
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Morning Beach Walk",
                description: "Start the day with a relaxing walk along the famous shoreline."
            },
            {
                time: "9:30 AM",
                activity: "Beach Activities",
                description: "Enjoy the ocean scenery and relax on the golden sand."
            },
            {
                time: "11:30 AM",
                activity: "Copacabana Promenade",
                description: "Explore the iconic wave-patterned pavement and nearby shops."
            },
            {
                time: "1:00 PM",
                activity: "Lunch Break",
                description: "Try traditional Brazilian food at a local beachfront restaurant."
            },
            {
                time: "3:00 PM",
                activity: "Copacabana Fort",
                description: "Discover the historic fort and enjoy beautiful coastal views."
            },
            {
                time: "5:00 PM",
                activity: "Beachfront Sunset",
                description: "Finish the day watching the sunset and enjoying Rio's lively beach atmosphere."
            }
        ],

        // 13. TIPS
        tips: [
            "Bring sunscreen and stay hydrated.",
            "Keep valuables secure while enjoying the beach.",
            "Swim only in areas considered safe by local lifeguards.",
            "Follow beach safety flags and ocean conditions.",
            "Wear comfortable footwear for walking along the promenade.",
            "Try fresh coconut water from local vendors.",
            "Be aware of your surroundings in crowded areas.",
            "Respect the beach environment and dispose of rubbish properly."
            ]
    },
];