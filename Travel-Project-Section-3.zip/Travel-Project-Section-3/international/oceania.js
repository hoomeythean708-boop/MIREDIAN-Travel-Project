// ===================================
// MIREDIAN - OCEANIA
// ===================================

const oceaniaDestinations = [
    // ===================================
    // I. AUSTRALIA
    // ===================================

    // ===================================
    // 1. SYDNEY OPERA HOUSE
    // ===================================

    {
        name: "Sydney Opera House",
        country: "Australia",
        category: "Landmark",
        image: "images/Sydney Opera House.jpg",
        budget: 180,
        featured: true,

        // 1. DESCRIPTION
        description: "The Sydney Opera House is one of the world's most recognizable architectural landmarks, famous for its distinctive sail-shaped roof, waterfront location, and world-class performances.",

        // 2. LOCATION
        location: "Bennelong Point, Sydney, New South Wales, Australia",

        // 3. HISTORY
        history: "The Sydney Opera House was officially opened in 1973 by Queen Elizabeth II. Designed by Danish architect Jørn Utzon, its innovative architecture became a symbol of modern Australia. It was added to the UNESCO World Heritage List in 2007.",

        // 4. ATTRACTIONS
        attractions: [
            {
                name: "Concert Hall",
                description: "Discover the largest performance venue inside the Opera House, hosting concerts and major cultural events."
            },
            {
                name: "Joan Sutherland Theatre",
                description: "Experience opera, ballet, and other outstanding theatrical performances."
            },
            {
                name: "Opera House Forecourt",
                description: "Enjoy beautiful outdoor views of the iconic building and Sydney Harbour."
            },
            {
                name: "Sydney Harbour",
                description: "Explore the surrounding waterfront and admire the nearby Harbour Bridge."
            }
        ],

        // 5. REASONS TO VISIT
        reasons: [
            "See one of the world's most famous architectural landmarks.",
            "Discover an internationally recognized UNESCO World Heritage Site.",
            "Experience outstanding music, theatre, and cultural performances.",
            "Enjoy beautiful views of Sydney Harbour.",
            "Explore one of Australia's most photographed destinations."
        ],

        // 6. BEST TIME TO VISIT
        bestTime: {
            season: "Spring and Autumn",
            weather: "Generally mild and pleasant, with comfortable temperatures for sightseeing.",
            recommendation: "September to November and March to May are popular periods for exploring Sydney."
        },

        // 7. SPECIAL EXPERIENCE
        specialExperience: {
            title: "Opera House Guided Tour",
            experience: "Join a guided tour to explore the building's remarkable architecture, performance spaces, and fascinating stories.",
            culturalSignificance: "The Opera House represents Australia's creativity, cultural identity, and connection to the performing arts.",
            recommendation: "Book a guided tour or evening performance in advance for a memorable experience."
        },

        // 8. BUDGET DETAILS
        budgetDetails: [
            { item: "Guided Tour", cost: "$25–$45" },
            { item: "Food", cost: "$20–$35" },
            { item: "Local Transportation", cost: "$10–$20" },
            { item: "Accommodation", cost: "$100–$150" }
        ],

        // 9. BUDGET NOTE
        budgetNote: "Estimated daily budget per person in US-dollar equivalents. Actual costs vary by season, performance, and accommodation. International flights are excluded.",

        // 10. TRANSPORTATION
        transportation: [
            "Take a train to Circular Quay Station and walk to the Opera House.",
            "Use Sydney buses and ferries to explore the surrounding harbour.",
            "Walk from nearby Circular Quay and Royal Botanic Garden."
        ],

        // 11. ACCOMMODATION
        accommodation: [
            "Stay near Circular Quay for convenient access to major landmarks.",
            "Choose hotels in The Rocks for historic surroundings and harbour views.",
            "Consider accommodation in Darling Harbour for restaurants and entertainment."
        ],

        // 12. ITINERARY
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Circular Quay",
                description: "Begin the day exploring Sydney's beautiful waterfront."
            },
            {
                time: "9:00 AM",
                activity: "Sydney Opera House",
                description: "Admire the famous architecture and take photographs outside."
            },
            {
                time: "10:30 AM",
                activity: "Guided Opera House Tour",
                description: "Discover the building's history and remarkable performance spaces."
            },
            {
                time: "12:30 PM",
                activity: "Lunch Break",
                description: "Enjoy a meal at a nearby waterfront restaurant."
            },
            {
                time: "2:00 PM",
                activity: "Royal Botanic Garden",
                description: "Walk through beautiful gardens with spectacular harbour views."
            },
            {
                time: "5:00 PM",
                activity: "Sydney Harbour Sunset",
                description: "Relax by the waterfront and admire the Opera House in the evening light."
            }
        ],

        // 13. TIPS
        tips: [
            "Book guided tours and performances in advance.",
            "Arrive early to enjoy the surrounding waterfront.",
            "Bring a camera for beautiful harbour photographs.",
            "Wear comfortable walking shoes.",
            "Check performance schedules before visiting.",
            "Use public transportation to avoid parking difficulties.",
            "Explore nearby Circular Quay and the Royal Botanic Garden.",
            "Respect performance venue rules and photography restrictions."
        ]
    },

    // ===================================
    // 2. GREAT BARRIER REEF
    // ===================================
    {
        name: "Great Barrier Reef",
        country: "Australia",
        category: "Nature",
        image: "images/Great Barrier Reef.jpg",
        budget: 220,
        featured: false,

        // 1. DESCRIPTION
        description: "The Great Barrier Reef is the world's largest coral reef system, stretching along Australia's northeastern coast. It is famous for its colorful coral formations, tropical marine life, and spectacular underwater scenery.",

        // 2. LOCATION
        location: "Queensland, Australia",

        // 3. HISTORY
        history: "The Great Barrier Reef has developed over thousands of years and is closely connected to the traditions and heritage of Aboriginal and Torres Strait Islander peoples. It was inscribed as a UNESCO World Heritage Site in 1981.",

        // 4. ATTRACTIONS
        attractions: [
            {
                name: "Heart Reef",
                description: "Admire a naturally heart-shaped coral formation in the Whitsunday Islands, best viewed from the air."
            },
            {
                name: "Green Island",
                description: "Explore a beautiful coral cay surrounded by clear tropical waters and marine life."
            },
            {
                name: "Cairns Reef Tours",
                description: "Join boat excursions to outer reef locations for snorkeling and diving experiences."
            },
            {
                name: "Whitsunday Islands",
                description: "Discover stunning tropical islands, turquoise waters, and beautiful white-sand beaches."
            }
        ],

        // 5. REASONS TO VISIT
        reasons: [
            "Discover one of the world's most extraordinary marine ecosystems.",
            "Experience colorful coral reefs and tropical fish.",
            "Enjoy snorkeling, scuba diving, and boat excursions.",
            "Explore beautiful tropical islands and beaches.",
            "Learn about marine conservation and reef protection."
        ],

        // 6. BEST TIME TO VISIT
        bestTime: {
            season: "Dry Season",
            weather: "Generally warm and sunny, with comfortable conditions for many reef excursions.",
            recommendation: "June to October is a popular period for visiting, although conditions vary by location and marine activity."
        },

        // 7. SPECIAL EXPERIENCE
        specialExperience: {
            title: "Snorkeling in the Great Barrier Reef",
            experience: "Explore the underwater world through a guided snorkeling trip and discover colorful corals, tropical fish, and other marine life.",
            culturalSignificance: "The reef holds deep cultural and spiritual significance for many Aboriginal and Torres Strait Islander communities who have cared for these sea Country environments for generations.",
            recommendation: "Choose an environmentally responsible reef operator and follow all marine conservation guidelines."
        },

        // 8. BUDGET DETAILS
        budgetDetails: [
            { item: "Reef Tour", cost: "$100–$160" },
            { item: "Food", cost: "$20–$35" },
            { item: "Local Transportation", cost: "$10–$25" },
            { item: "Accommodation", cost: "$90–$140" }
        ],

        // 9. BUDGET NOTE
        budgetNote: "Estimated daily budget per person in US-dollar equivalents. Reef tours, diving activities, and accommodation vary by location and season. International flights are excluded.",

        // 10. TRANSPORTATION
        transportation: [
            "Fly to Cairns or another regional gateway along Queensland's coast.",
            "Join organized boat tours to reach reef locations.",
            "Use local buses, taxis, or shuttle services to reach tour departure points."
        ],

        // 11. ACCOMMODATION
        accommodation: [
            "Stay in Cairns for convenient access to reef tours.",
            "Choose accommodation in Port Douglas for a quieter tropical atmosphere.",
            "Consider island resorts in the Whitsundays for a scenic reef holiday."
        ],

        // 12. ITINERARY
        itinerary: [
            {
                time: "7:30 AM",
                activity: "Reef Tour Departure",
                description: "Board a tour boat and travel toward the reef."
            },
            {
                time: "9:30 AM",
                activity: "Outer Reef Exploration",
                description: "Discover beautiful coral formations and marine scenery."
            },
            {
                time: "11:00 AM",
                activity: "Snorkeling Experience",
                description: "Explore the underwater world with suitable safety equipment and guidance."
            },
            {
                time: "12:30 PM",
                activity: "Lunch Break",
                description: "Enjoy lunch during the reef excursion."
            },
            {
                time: "2:00 PM",
                activity: "Marine Life Discovery",
                description: "Learn about reef ecosystems and observe marine life responsibly."
            },
            {
                time: "4:30 PM",
                activity: "Return to the Coast",
                description: "Travel back while enjoying the beautiful ocean scenery."
            }
        ],

        // 13. TIPS
        tips: [
            "Book reef tours with licensed and responsible operators.",
            "Wear reef-safe sun protection where appropriate.",
            "Follow snorkeling and diving safety instructions.",
            "Never touch or stand on coral formations.",
            "Avoid feeding or disturbing marine animals.",
            "Bring swimwear, a towel, and drinking water.",
            "Check marine weather conditions before departure.",
            "Respect Indigenous cultural heritage and protected marine environments."
        ]
    },

    // ===================================
    // 3. ULURU
    // ===================================
    {
        name: "Uluru",
        country: "Australia",
        category: "Nature",
        image: "images/Uluru.jpg",
        budget: 200,
        featured: false,

        // 1. DESCRIPTION
        description: "Uluru is a magnificent sandstone monolith rising from the heart of Australia's Red Centre. Famous for its enormous size, deep red color, and spiritual significance, it is one of Australia's most iconic natural landmarks.",

        // 2. LOCATION
        location: "Uluru-Kata Tjuta National Park, Northern Territory, Australia",

        // 3. HISTORY
        history: "Uluru is an ancient geological formation with deep cultural and spiritual importance to the Anangu people, the Traditional Owners of the area. Their stories, traditions, and connection to the land have been passed down through generations. The national park is a UNESCO World Heritage Site.",

        // 4. ATTRACTIONS
        attractions: [
            {
                name: "Uluru Sunrise Viewing Area",
                description: "Watch the enormous sandstone formation change colors as the sun rises over the desert."
            },
            {
                name: "Uluru Base Walk",
                description: "Explore the walking trails around the base and discover the rock's remarkable natural features."
            },
            {
                name: "Kata Tjuta",
                description: "Discover a spectacular group of ancient rock domes located within the national park."
            },
            {
                name: "Cultural Centre",
                description: "Learn about Anangu culture, traditional knowledge, and the importance of protecting the landscape."
            }
        ],

        // 5. REASONS TO VISIT
        reasons: [
            "Witness one of Australia's most remarkable natural landmarks.",
            "Experience unforgettable desert sunrises and sunsets.",
            "Discover the living culture and heritage of the Anangu people.",
            "Explore beautiful desert landscapes and walking trails.",
            "Learn about one of the world's most significant cultural landscapes."
        ],

        // 6. BEST TIME TO VISIT
        bestTime: {
            season: "Autumn and Spring",
            weather: "Generally milder temperatures, although desert conditions can change significantly between day and night.",
            recommendation: "April to May and September to October are popular periods for comfortable sightseeing."
        },

        // 7. SPECIAL EXPERIENCE
        specialExperience: {
            title: "Uluru Sunrise Experience",
            experience: "Watch the first sunlight illuminate the massive sandstone formation, gradually changing its colors across the desert landscape.",
            culturalSignificance: "Uluru is a sacred place for the Anangu people, whose Tjukurpa traditions connect people, land, animals, and ancestral stories.",
            recommendation: "Join an Indigenous-led cultural tour to learn about the area's heritage respectfully. Climbing Uluru is prohibited."
        },

        // 8. BUDGET DETAILS
        budgetDetails: [
            { item: "National Park Entry", cost: "$25–$35" },
            { item: "Food", cost: "$25–$40" },
            { item: "Local Transportation and Tours", cost: "$30–$60" },
            { item: "Accommodation", cost: "$100–$160" }
        ],

        // 9. BUDGET NOTE
        budgetNote: "Estimated daily budget per person in US-dollar equivalents. Park passes, tours, and accommodation vary by season. International flights are excluded.",

        // 10. TRANSPORTATION
        transportation: [
            "Fly to Ayers Rock Airport near Yulara.",
            "Use authorized shuttle services or organized tours to reach park attractions.",
            "Rent a car for greater flexibility when exploring the surrounding region."
        ],

        // 11. ACCOMMODATION
        accommodation: [
            "Stay in Yulara, the main visitor accommodation area near Uluru.",
            "Choose a resort with convenient access to national park tours.",
            "Consider a campground or other approved accommodation option in the region."
        ],

        // 12. ITINERARY
        itinerary: [
            {
                time: "5:30 AM",
                activity: "Uluru Sunrise",
                description: "Enjoy the changing colors of Uluru as daylight reaches the desert."
            },
            {
                time: "7:00 AM",
                activity: "Uluru Base Walk",
                description: "Explore the base trails and admire the rock's natural formations."
            },
            {
                time: "10:00 AM",
                activity: "Cultural Centre",
                description: "Learn about Anangu traditions, stories, and connection to Country."
            },
            {
                time: "12:00 PM",
                activity: "Lunch Break",
                description: "Enjoy a meal and take a break from the desert heat."
            },
            {
                time: "2:00 PM",
                activity: "Kata Tjuta",
                description: "Discover the impressive rock domes and scenic walking areas."
            },
            {
                time: "5:30 PM",
                activity: "Uluru Sunset",
                description: "Finish the day watching the sandstone landscape glow in the evening light."
            }
        ],

        // 13. TIPS
        tips: [
            "Carry plenty of drinking water during outdoor activities.",
            "Wear comfortable walking shoes and sun-protective clothing.",
            "Bring sunscreen, a hat, and sunglasses.",
            "Prepare for large temperature differences between day and night.",
            "Respect Anangu culture and follow all cultural restrictions.",
            "Never climb Uluru.",
            "Stay on designated walking trails.",
            "Check park conditions and tour schedules before visiting."
        ]
    },

    // ===================================
    // 4. GREAT OCEAN ROAD
    // ===================================
    {
        name: "Great Ocean Road",
        country: "Australia",
        category: "Scenic Route",
        image: "images/Great Ocean Road.jpg",
        budget: 190,
        featured: false,

        // 1. DESCRIPTION
        description: "The Great Ocean Road is one of Australia's most spectacular coastal routes, famous for its dramatic cliffs, beautiful beaches, rainforest landscapes, and breathtaking ocean views. It is especially known for the Twelve Apostles limestone formations.",

        // 2. LOCATION
        location: "Victoria, Australia",

        // 3. HISTORY
        history: "The Great Ocean Road was built between 1919 and 1932 by returned soldiers and other workers. It was dedicated as a memorial to those who served in World War I and is recognized as one of the world's largest war memorials.",

        // 4. ATTRACTIONS
        attractions: [
            {
                name: "Twelve Apostles",
                description: "Admire the famous limestone stacks rising dramatically from the Southern Ocean."
            },
            {
                name: "Loch Ard Gorge",
                description: "Discover a beautiful coastal gorge with towering cliffs and a fascinating shipwreck history."
            },
            {
                name: "Great Otway National Park",
                description: "Explore lush rainforests, waterfalls, walking trails, and peaceful natural surroundings."
            },
            {
                name: "London Arch",
                description: "See an impressive natural rock formation shaped by the powerful ocean waves."
            }
        ],

        // 5. REASONS TO VISIT
        reasons: [
            "Enjoy breathtaking views along Australia's southern coastline.",
            "Visit the world-famous Twelve Apostles.",
            "Discover beautiful beaches, cliffs, and coastal landscapes.",
            "Explore rainforests and scenic walking trails.",
            "Experience one of Australia's most memorable road trips."
        ],

        // 6. BEST TIME TO VISIT
        bestTime: {
            season: "Spring and Summer",
            weather: "Generally mild to warm weather, with changing coastal conditions and occasional rain.",
            recommendation: "October to April is popular for road trips and outdoor sightseeing."
        },

        // 7. SPECIAL EXPERIENCE
        specialExperience: {
            title: "Twelve Apostles Sunset",
            experience: "Watch the sunlight illuminate the limestone formations while ocean waves move beneath the dramatic coastal cliffs.",
            culturalSignificance: "The Great Ocean Road is a memorial to World War I service personnel. The surrounding region is also connected to the long-standing cultural heritage of Aboriginal communities.",
            recommendation: "Take a scenic drive, stop at the coastal viewpoints, and allow enough time to explore the attractions safely."
        },

        // 8. BUDGET DETAILS
        budgetDetails: [
            { item: "Car Rental and Fuel", cost: "$50–$80" },
            { item: "Food", cost: "$25–$40" },
            { item: "Activities and Attractions", cost: "$10–$25" },
            { item: "Accommodation", cost: "$80–$130" }
        ],

        // 9. BUDGET NOTE
        budgetNote: "Estimated daily budget per person in US-dollar equivalents. Costs depend on transportation, accommodation, and travel style. International flights are excluded.",

        // 10. TRANSPORTATION
        transportation: [
            "Drive from Melbourne toward the coastal towns along the Great Ocean Road.",
            "Join an organized sightseeing tour from Melbourne.",
            "Use local buses for selected coastal destinations, although services are limited."
        ],

        // 11. ACCOMMODATION
        accommodation: [
            "Stay in Apollo Bay for convenient access to coastal attractions.",
            "Choose accommodation in Lorne for beaches, cafes, and ocean views.",
            "Consider Port Campbell for easy access to the Twelve Apostles."
        ],

        // 12. ITINERARY
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Start the Coastal Drive",
                description: "Begin the journey from Melbourne and enjoy the beautiful coastal scenery."
            },
            {
                time: "10:00 AM",
                activity: "Lorne",
                description: "Explore the charming seaside town and enjoy its beautiful beach."
            },
            {
                time: "12:00 PM",
                activity: "Apollo Bay",
                description: "Stop for lunch and admire the peaceful coastal atmosphere."
            },
            {
                time: "2:00 PM",
                activity: "Great Otway National Park",
                description: "Discover rainforest scenery and beautiful natural surroundings."
            },
            {
                time: "4:00 PM",
                activity: "Twelve Apostles",
                description: "Admire the famous limestone formations from the viewing platforms."
            },
            {
                time: "5:30 PM",
                activity: "Loch Ard Gorge",
                description: "Finish the journey with dramatic coastal views and beautiful scenery."
            }
        ],

        // 13. TIPS
        tips: [
            "Plan enough time for the entire coastal journey.",
            "Drive carefully on winding roads and observe speed limits.",
            "Check weather and road conditions before departure.",
            "Bring a camera for the spectacular coastal scenery.",
            "Wear comfortable shoes for walking and sightseeing.",
            "Keep a safe distance from cliff edges.",
            "Book accommodation early during busy holiday periods.",
            "Respect wildlife and never leave rubbish behind."
        ]
    },

    // ===================================
    // 5. BONDI BEACH
    // ===================================
    {
        name: "Bondi Beach",
        country: "Australia",
        category: "Beach",
        image: "images/Bondi Beach.jpg",
        budget: 170,
        featured: false,

        // 1. DESCRIPTION
        description: "Bondi Beach is one of Australia's most famous beaches, known for its golden sand, turquoise water, lively atmosphere, and beautiful coastal scenery. It is a popular destination for swimming, surfing, relaxing, and enjoying Sydney's beach lifestyle.",

        // 2. LOCATION
        location: "Bondi, Sydney, New South Wales, Australia",

        // 3. HISTORY
        history: "Bondi has a long history connected to the Aboriginal people of the Sydney region. Its name is commonly associated with an Aboriginal word describing the sound of water breaking over rocks. The beach became a popular seaside destination in the late nineteenth century and remains an important part of Sydney's coastal culture.",

        // 4. ATTRACTIONS
        attractions: [
            {
                name: "Bondi Beach",
                description: "Relax on the famous golden beach, swim between the flags, or enjoy the beautiful ocean views."
            },
            {
                name: "Bondi to Coogee Coastal Walk",
                description: "Follow a scenic coastal walking trail featuring dramatic cliffs, beaches, and ocean viewpoints."
            },
            {
                name: "Bondi Icebergs Pool",
                description: "Visit the iconic ocean swimming pool overlooking the beautiful Bondi coastline."
            },
            {
                name: "Bondi Pavilion",
                description: "Explore a historic beachfront landmark featuring cultural events, exhibitions, and community activities."
            }
        ],

        // 5. REASONS TO VISIT
        reasons: [
            "Experience one of Australia's most iconic beaches.",
            "Enjoy swimming, surfing, and relaxing by the ocean.",
            "Discover spectacular coastal walking trails.",
            "Visit the famous Bondi Icebergs ocean pool.",
            "Experience Sydney's lively beach culture and seaside lifestyle."
        ],

        // 6. BEST TIME TO VISIT
        bestTime: {
            season: "Spring and Summer",
            weather: "Warm and sunny weather is common during summer, while spring offers pleasant temperatures and beautiful coastal conditions.",
            recommendation: "September to April is popular for beach activities, although Bondi can be visited throughout the year."
        },

        // 7. SPECIAL EXPERIENCE
        specialExperience: {
            title: "Bondi Coastal Experience",
            experience: "Enjoy a relaxing beach day, try surfing, or walk along the coastline to discover spectacular ocean views and beautiful seaside scenery.",
            culturalSignificance: "Bondi is part of the traditional lands of Aboriginal communities and has developed into an internationally recognized symbol of Australian beach culture.",
            recommendation: "Visit early in the morning for a peaceful beach atmosphere or enjoy the coastal scenery during the afternoon."
        },

        // 8. BUDGET DETAILS
        budgetDetails: [
            { item: "Food and Drinks", cost: "$25–$40" },
            { item: "Local Transportation", cost: "$10–$20" },
            { item: "Surfboard Rental and Activities", cost: "$20–$45" },
            { item: "Accommodation", cost: "$80–$130" }
        ],

        // 9. BUDGET NOTE
        budgetNote: "Estimated daily budget per person in US-dollar equivalents. Costs depend on activities, food, and accommodation choices. International flights are excluded.",

        // 10. TRANSPORTATION
        transportation: [
            "Take a bus from central Sydney to Bondi Beach.",
            "Use Sydney's public transportation network to reach the Bondi area.",
            "Walk or cycle along nearby coastal paths to explore surrounding beaches."
        ],

        // 11. ACCOMMODATION
        accommodation: [
            "Stay in Bondi for convenient access to the beach and local restaurants.",
            "Choose a hostel or budget hotel for affordable accommodation.",
            "Consider nearby areas such as Bondi Junction for additional accommodation options."
        ],
        // 12. ITINERARY
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Morning at Bondi Beach",
                description: "Enjoy the fresh ocean breeze and beautiful morning beach scenery."
            },
            {
                time: "9:00 AM",
                activity: "Swimming and Surfing",
                description: "Experience the waves or relax in designated swimming areas."
            },
            {
                time: "11:00 AM",
                activity: "Bondi Icebergs Pool",
                description: "Visit the famous ocean pool and admire its spectacular coastal setting."
            },
            {
                time: "12:30 PM",
                activity: "Lunch by the Beach",
                description: "Enjoy local food and refreshing drinks near the beachfront."
            },
            {
                time: "2:00 PM",
                activity: "Bondi to Coogee Coastal Walk",
                description: "Explore the stunning coastline and discover beautiful ocean viewpoints."
            },
            {
                time: "5:00 PM",
                activity: "Relax at Bondi Beach",
                description: "Return to the beach and enjoy the peaceful evening atmosphere."
            }
        ],

        // 13. TIPS
        tips: [
            "Apply sunscreen regularly and wear a hat.",
            "Swim between the red and yellow flags.",
            "Follow lifeguard instructions and beach safety signs.",
            "Bring a towel, swimwear, and comfortable footwear.",
            "Check ocean conditions before surfing or swimming.",
            "Visit early to enjoy a quieter beach atmosphere.",
            "Use public transportation to avoid parking difficulties.",
            "Respect the beach environment and keep it clean."
        ]
    },
];  