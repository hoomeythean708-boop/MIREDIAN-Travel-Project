// ===================================
// MIREDIAN - NORTH AMERICA
// ===================================

const northAmericaDestinations = [

    // ===================================
    // I. UNITED STATES
    // ===================================

    // ===================================
    // UNITED STATES
    // ===================================

    // 1. GRAND CANYON
    {
        name: "Grand Canyon",
        country: "United States",
        category: "Nature",
        image: "images/Grand Canyon.jpg",
        budget: 100,
        featured: true,

        // 1. DESCRIPTION
        description: "Grand Canyon is one of the world's most spectacular natural wonders, famous for its enormous colorful cliffs, deep valleys, and breathtaking views.",

        // 2. LOCATION
        location: "Arizona, United States",

        // 3. HISTORY
        history: "The Grand Canyon was shaped over millions of years by the Colorado River and geological processes. It has also been home to Indigenous peoples for thousands of years.",

        // 4. ATTRACTIONS
        attractions: [
            {
                name: "South Rim",
                description: "Enjoy panoramic views and some of the most famous viewpoints in the national park."
            },
            {
                name: "Mather Point",
                description: "A popular viewpoint offering spectacular views of the canyon."
            },
            {
                name: "Bright Angel Trail",
                description: "Explore a famous hiking trail descending into the canyon."
            },
            {
                name: "Desert View Watchtower",
                description: "Visit a historic stone tower with beautiful views of the surrounding landscape."
            }
        ],

        // 5. REASONS TO VISIT
        reasons: [
            "Experience one of the world's greatest natural wonders.",
            "Enjoy breathtaking panoramic landscapes.",
            "Explore scenic hiking trails.",
            "Discover Indigenous history and culture.",
            "Capture unforgettable photographs."
        ],

        // 6. BEST TIME TO VISIT
        bestTime: {
            season: "Spring and Autumn",
            weather: "Mild temperatures and comfortable conditions.",
            recommendation: "March to May and September to November are excellent times to explore the South Rim."
        },

        // 7. SPECIAL EXPERIENCE
        specialExperience: {
            title: "Grand Canyon Sunset",
            experience: "Watch the sunlight transform the canyon walls into beautiful shades of orange, red, and gold.",
            culturalSignificance: "The canyon holds deep cultural and spiritual importance for several Indigenous communities.",
            recommendation: "Visit a scenic viewpoint near sunset for an unforgettable experience."
        },

        // 8. BUDGET DETAILS
        budgetDetails: [
            { item: "Park Entrance", cost: "$20–$35" },
            { item: "Food", cost: "$20–$30" },
            { item: "Local Transportation", cost: "$10–$20" },
            { item: "Accommodation", cost: "$50–$100" }
        ],

        // 9. BUDGET NOTE
        budgetNote: "Estimated daily budget per person. Actual costs vary by season and accommodation. International flights are excluded.",

        // 10. TRANSPORTATION
        transportation: [
            "Drive from nearby cities such as Flagstaff or Las Vegas.",
            "Use the park's free shuttle buses at the South Rim.",
            "Join organized tours for convenient transportation."
        ],

        // 11. ACCOMMODATION
        accommodation: [
            "Stay at lodges inside Grand Canyon National Park.",
            "Choose hotels in Tusayan near the South Entrance.",
            "Consider budget accommodation in nearby Flagstaff."
        ],

        // 12. ITINERARY
        itinerary: [
            {
                time: "7:00 AM",
                activity: "Sunrise Viewing",
                description: "Enjoy the beautiful morning light over the canyon."
            },
            {
                time: "9:00 AM",
                activity: "Mather Point",
                description: "Explore one of the park's most famous viewpoints."
            },
            {
                time: "11:00 AM",
                activity: "Scenic Hiking",
                description: "Walk along a suitable section of the canyon trails."
            },
            {
                time: "1:00 PM",
                activity: "Lunch Break",
                description: "Enjoy lunch and take time to relax."
            },
            {
                time: "3:00 PM",
                activity: "Desert View",
                description: "Explore the eastern part of the South Rim."
            },
            {
                time: "5:30 PM",
                activity: "Sunset Experience",
                description: "Finish the day watching the canyon glow in the evening light."
            }
        ],

        // 13. TIPS
        tips: [
            "Bring enough drinking water.",
            "Wear comfortable hiking shoes.",
            "Apply sunscreen and wear a hat.",
            "Check weather conditions before hiking.",
            "Start outdoor activities early in the morning.",
            "Stay on marked trails and follow park safety rules.",
            "Bring a camera for scenic photography.",
            "Book accommodation early during busy seasons."
        ]
    },

    // ===================================
    // 2. STATUE OF LIBERTY
    // ===================================
    {
        name: "Statue of Liberty",
        country: "United States",
        category: "Landmark",
        image: "images/Statue of Liberty.jpg",
        budget: 120,
        featured: false,

        // 1. DESCRIPTION
        description: "The Statue of Liberty is one of America's most recognizable landmarks, symbolizing freedom, hope, and democracy. It stands proudly on Liberty Island in New York Harbor.",

        // 2. LOCATION
        location: "Liberty Island, New York City, New York, United States",

        // 3. HISTORY
        history: "The Statue of Liberty was a gift from France to the United States. Designed by Frédéric Auguste Bartholdi and engineered with the involvement of Gustave Eiffel, it was dedicated in 1886.",

        // 4. ATTRACTIONS
        attractions: [
            {
                name: "Statue of Liberty",
                description: "Admire the magnificent copper statue representing freedom and friendship."
            },
            {
                name: "Statue Pedestal",
                description: "Explore the pedestal and enjoy impressive views of New York Harbor."
            },
            {
                name: "Statue Crown",
                description: "Experience the crown observation area with a special reservation."
            },
            {
                name: "Liberty Island",
                description: "Walk around the island and discover its history and beautiful surroundings."
            }
        ],

        // 5. REASONS TO VISIT
        reasons: [
            "See one of the world's most famous monuments.",
            "Learn about American history and immigration.",
            "Enjoy beautiful views of New York Harbor.",
            "Discover the friendship between France and the United States.",
            "Take memorable photographs of this iconic landmark."
        ],

        // 6. BEST TIME TO VISIT
        bestTime: {
            season: "Spring and Autumn",
            weather: "Comfortable temperatures and pleasant sightseeing conditions.",
            recommendation: "April to June and September to October are popular times to visit."
        },

        // 7. SPECIAL EXPERIENCE
        specialExperience: {
            title: "Liberty Island Ferry Experience",
            experience: "Take a ferry across New York Harbor and admire the Statue of Liberty from the water.",
            culturalSignificance: "The statue represents freedom and became an important symbol of hope for generations of immigrants.",
            recommendation: "Book ferry tickets in advance, especially if you want access to the pedestal or crown."
        },

        // 8. BUDGET DETAILS
        budgetDetails: [
            { item: "Ferry Admission", cost: "$25–$30" },
            { item: "Food", cost: "$20–$30" },
            { item: "Local Transportation", cost: "$10–$20" },
            { item: "Accommodation", cost: "$65–$120" }
        ],

        // 9. BUDGET NOTE
        budgetNote: "Estimated daily budget per person. Actual costs vary by season and accommodation. International flights are excluded.",

        // 10. TRANSPORTATION
        transportation: [
            "Take an official ferry from Battery Park in Manhattan.",
            "Use the subway or bus to reach the ferry departure area.",
            "Explore Liberty Island on foot after arriving by ferry."
        ],

        // 11. ACCOMMODATION
        accommodation: [
            "Stay in hotels near Battery Park for convenient ferry access.",
            "Choose accommodation in Lower Manhattan.",
            "Consider hotels in nearby Brooklyn for additional options."
        ],

        // 12. ITINERARY
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Ferry Departure",
                description: "Travel across New York Harbor toward Liberty Island."
            },
            {
                time: "9:00 AM",
                activity: "Statue of Liberty",
                description: "Explore the famous monument and its surroundings."
            },
            {
                time: "10:30 AM",
                activity: "Pedestal Visit",
                description: "Discover the statue's history and enjoy harbor views."
            },
            {
                time: "12:00 PM",
                activity: "Lunch Break",
                description: "Enjoy lunch and relax on Liberty Island."
            },
            {
                time: "1:30 PM",
                activity: "Island Exploration",
                description: "Walk around the island and visit the museum."
            },
            {
                time: "3:00 PM",
                activity: "Return Ferry",
                description: "Enjoy the harbor scenery on the way back to Manhattan."
            }
        ],

        // 13. TIPS
        tips: [
            "Purchase official ferry tickets in advance.",
            "Arrive early to allow time for security screening.",
            "Bring comfortable walking shoes.",
            "Check ferry schedules before your visit.",
            "Reserve crown access well in advance if desired.",
            "Bring a camera for harbor views.",
            "Check the weather before departure.",
            "Keep personal belongings secure during the ferry journey."
        ]
    },

    // ===================================
    // 3. YELLOWSTONE NATIONAL PARK
    // ===================================
    {
        name: "Yellowstone National Park",
        country: "United States",
        category: "Nature",
        image: "images/Yellowstone National Park.jpg",
        budget: 130,
        featured: false,

        // 1. DESCRIPTION
        description: "Yellowstone National Park is a world-famous natural destination known for its colorful hot springs, powerful geysers, wildlife, forests, and dramatic landscapes.",

        // 2. LOCATION
        location: "Wyoming, Montana, and Idaho, United States",

        // 3. HISTORY
        history: "Established in 1872, Yellowstone became the world's first national park. The area also has a long history of Indigenous communities who have lived in and traveled through the region.",

        // 4. ATTRACTIONS
        attractions: [
            {
                name: "Old Faithful",
                description: "Watch one of the world's most famous geysers erupt at regular intervals."
            },
            {
                name: "Grand Prismatic Spring",
                description: "Admire a spectacular hot spring known for its vivid rainbow-like colors."
            },
            {
                name: "Grand Canyon of the Yellowstone",
                description: "Discover dramatic canyon walls and the impressive Lower Falls."
            },
            {
                name: "Lamar Valley",
                description: "Explore a scenic wildlife area known for opportunities to spot bison, wolves, and other animals."
            }
        ],

        // 5. REASONS TO VISIT
        reasons: [
            "Experience incredible geothermal wonders.",
            "See colorful hot springs and famous geysers.",
            "Discover diverse wildlife in natural habitats.",
            "Explore beautiful mountains, forests, and waterfalls.",
            "Learn about America's national park history."
        ],

        // 6. BEST TIME TO VISIT
        bestTime: {
            season: "Late Spring to Early Autumn",
            weather: "Generally mild and pleasant during summer, while spring and autumn can be cooler.",
            recommendation: "June to September is popular for road access and outdoor activities. Always check seasonal park conditions."
        },

        // 7. SPECIAL EXPERIENCE
        specialExperience: {
            title: "Old Faithful Geyser Eruption",
            experience: "Watch hot water and steam shoot high into the air during an impressive geothermal eruption.",
            culturalSignificance: "Yellowstone's landscapes hold cultural, spiritual, and historical importance for many Indigenous peoples.",
            recommendation: "Check the predicted eruption time at the visitor center and arrive early for a good viewing spot."
        },

        // 8. BUDGET DETAILS
        budgetDetails: [
            { item: "Park Entrance", cost: "$20–$35" },
            { item: "Food", cost: "$20–$35" },
            { item: "Local Transportation", cost: "$20–$35" },
            { item: "Accommodation", cost: "$70–$120" }
        ],

        // 9. BUDGET NOTE
        budgetNote: "Estimated daily budget per person. Actual costs vary by season and accommodation. International flights are excluded.",

        // 10. TRANSPORTATION
        transportation: [
            "Drive through the park using its scenic road network.",
            "Rent a car from nearby gateway towns such as West Yellowstone.",
            "Join guided tours to explore major attractions without driving."
        ],

        // 11. ACCOMMODATION
        accommodation: [
            "Stay at lodges inside Yellowstone National Park.",
            "Choose hotels in West Yellowstone, Montana.",
            "Consider accommodation in nearby Gardiner or Cody."
        ],

        // 12. ITINERARY
        itinerary: [
            {
                time: "7:00 AM",
                activity: "Morning Wildlife Watching",
                description: "Explore Lamar Valley and look for wildlife from a safe distance."
            },
            {
                time: "9:00 AM",
                activity: "Old Faithful",
                description: "Watch the famous geyser erupt."
            },
            {
                time: "11:00 AM",
                activity: "Grand Prismatic Spring",
                description: "Admire the colorful geothermal landscape."
            },
            {
                time: "1:00 PM",
                activity: "Lunch Break",
                description: "Enjoy lunch and rest before continuing the journey."
            },
            {
                time: "2:30 PM",
                activity: "Grand Canyon of Yellowstone",
                description: "Explore scenic viewpoints overlooking the canyon and waterfalls."
            },
            {
                time: "5:00 PM",
                activity: "Scenic Drive",
                description: "Enjoy the park's beautiful landscapes before returning to your accommodation."
            }
        ],

        // 13. TIPS
        tips: [
            "Check park road and entrance conditions before traveling.",
            "Bring layers of clothing because temperatures can change quickly.",
            "Stay on designated boardwalks near geothermal features.",
            "Never approach or feed wild animals.",
            "Keep a safe distance from bison, bears, and other wildlife.",
            "Carry drinking water and snacks.",
            "Book accommodation early during peak season.",
            "Allow extra travel time because distances inside the park are large."
        ]
    },
    // ===================================
    // 4. NIAGARA FALLS (UNITED STATES SIDE)
    // ===================================
    
    {
    name: "Niagara Falls",
    country: "United States",
    category: "Nature",
    image: "images/Niagara Falls.jpg",
    budget: 120,
    featured: false,

    // 1. DESCRIPTION
    description: "Niagara Falls is a spectacular group of waterfalls on the border between the United States and Canada, famous for its powerful flowing water and breathtaking natural scenery.",

    // 2. LOCATION
    location: "Niagara Falls, New York, United States",

    // 3. HISTORY
    history: "Niagara Falls was formed thousands of years ago during the retreat of glaciers. It has become an important natural landmark, tourism destination, and source of hydroelectric power.",

    // 4. ATTRACTIONS
    attractions: [
        {
            name: "American Falls",
            description: "Admire the powerful waterfall surrounded by impressive rock formations."
        },
        {
            name: "Bridal Veil Falls",
            description: "Discover the smaller waterfall beside American Falls."
        },
        {
            name: "Cave of the Winds",
            description: "Experience close-up views of the waterfalls from specially designed walkways."
        },
        {
            name: "Maid of the Mist",
            description: "Take a famous boat ride toward the base of the waterfalls."
        }
    ],

    // 5. REASONS TO VISIT
    reasons: [
        "Experience one of North America's most famous natural wonders.",
        "Feel the power of the waterfalls up close.",
        "Enjoy beautiful river and gorge scenery.",
        "Explore scenic walking paths and viewpoints.",
        "Create unforgettable memories through boat tours and sightseeing."
    ],

    // 6. BEST TIME TO VISIT
    bestTime: {
        season: "Late Spring to Early Autumn",
        weather: "Generally pleasant temperatures with lively outdoor attractions during warmer months.",
        recommendation: "May to September is a popular period for boat tours and outdoor sightseeing."
    },

    // 7. SPECIAL EXPERIENCE
    specialExperience: {
        title: "Maid of the Mist Boat Tour",
        experience: "Ride a sightseeing boat toward the base of Niagara Falls and experience the powerful mist and rushing water.",
        culturalSignificance: "Niagara Falls has long held cultural significance for Indigenous communities and became an important landmark in the development of tourism and hydroelectric power.",
        recommendation: "Bring a waterproof camera cover and enjoy the view from the boat's outdoor deck."
    },

    // 8. BUDGET DETAILS
    budgetDetails: [
        { item: "Park Admission", cost: "$10–$15" },
        { item: "Food", cost: "$20–$30" },
        { item: "Local Transportation", cost: "$10–$20" },
        { item: "Accommodation", cost: "$60–$100" }
    ],

    // 9. BUDGET NOTE
    budgetNote: "Estimated daily budget per person. Optional boat tours and other activities may cost extra. Actual costs vary by season and accommodation. International flights are excluded.",

    // 10. TRANSPORTATION
    transportation: [
        "Drive to Niagara Falls State Park.",
        "Use local buses and the seasonal Niagara Scenic Trolley.",
        "Walk between major viewpoints and attractions within the park."
    ],

    // 11. ACCOMMODATION
    accommodation: [
        "Stay at hotels near Niagara Falls State Park.",
        "Choose accommodation in downtown Niagara Falls, New York.",
        "Consider nearby hotels in Niagara County."
    ],

    // 12. ITINERARY
    itinerary: [
        {
            time: "8:00 AM",
            activity: "Niagara Falls State Park",
            description: "Begin the day exploring the park and its scenic viewpoints."
        },
        {
            time: "9:30 AM",
            activity: "American Falls",
            description: "Admire the powerful waterfall from the observation areas."
        },
        {
            time: "11:00 AM",
            activity: "Maid of the Mist",
            description: "Enjoy a memorable boat tour toward the waterfalls."
        },
        {
            time: "1:00 PM",
            activity: "Lunch Break",
            description: "Take a break and enjoy lunch near the park."
        },
        {
            time: "2:30 PM",
            activity: "Cave of the Winds",
            description: "Explore the walkways and experience the waterfall mist."
        },
        {
            time: "5:00 PM",
            activity: "Evening View",
            description: "Enjoy the scenery and watch the falls become illuminated after dark when available."
        }
    ],

    // 13. TIPS
    tips: [
        "Wear comfortable walking shoes.",
        "Bring a waterproof jacket for boat tours.",
        "Check seasonal attraction schedules before visiting.",
        "Keep your camera protected from water and mist.",
        "Arrive early to avoid busy periods.",
        "Stay within designated viewing areas.",
        "Bring extra clothing if you plan to get close to the falls.",
        "Check the weather before planning outdoor activities."
    ]
    },

    // ===================================
    // 5. GOLDEN GATE BRIDGE
    // ===================================
    {
        name: "Golden Gate Bridge",
        country: "United States",
        category: "Landmark",
        image: "images/Golden Gate Bridge.jpg",
        budget: 130,
        featured: false,

        // 1. DESCRIPTION
        description: "The Golden Gate Bridge is an iconic suspension bridge in San Francisco, famous for its impressive architecture, distinctive international orange color, and beautiful views of the bay.",

        // 2. LOCATION
        location: "San Francisco, California, United States",

        // 3. HISTORY
        history: "Opened in 1937, the Golden Gate Bridge was once the longest suspension bridge main span in the world. It became an internationally recognized symbol of San Francisco.",

        // 4. ATTRACTIONS
        attractions: [
            {
                name: "Golden Gate Bridge Welcome Center",
                description: "Discover the bridge's history, engineering, and visitor information."
            },
            {
                name: "Battery Spencer",
                description: "Enjoy breathtaking views of the bridge and San Francisco skyline."
            },
            {
                name: "Fort Point",
                description: "Explore a historic coastal fort beneath the southern end of the bridge."
            },
            {
                name: "Crissy Field",
                description: "Relax along a beautiful waterfront area with excellent bridge views."
            }
        ],

        // 5. REASONS TO VISIT
        reasons: [
            "See one of the world's most recognizable bridges.",
            "Admire impressive engineering and architecture.",
            "Enjoy beautiful views of San Francisco Bay.",
            "Walk or cycle across the bridge.",
            "Capture unforgettable photographs of the city."
        ],

        // 6. BEST TIME TO VISIT
        bestTime: {
            season: "Spring and Autumn",
            weather: "Mild temperatures, although fog and wind can occur throughout the year.",
            recommendation: "April to June and September to October are popular periods for sightseeing."
        },

        // 7. SPECIAL EXPERIENCE
        specialExperience: {
            title: "Walking Across the Golden Gate Bridge",
            experience: "Walk along the pedestrian walkway and enjoy spectacular views of the Pacific Ocean, San Francisco Bay, and the city.",
            culturalSignificance: "The bridge represents San Francisco's engineering achievements and has become a lasting symbol of California.",
            recommendation: "Visit in the morning or late afternoon and bring a jacket because the bridge can be windy."
        },

        // 8. BUDGET DETAILS
        budgetDetails: [
            { item: "Bridge Access", cost: "Free for pedestrians" },
            { item: "Food", cost: "$20–$30" },
            { item: "Local Transportation", cost: "$10–$25" },
            { item: "Accommodation", cost: "$70–$120" }
        ],

        // 9. BUDGET NOTE
        budgetNote: "Estimated daily budget per person. Actual costs vary by season and accommodation. International flights are excluded. Pedestrian access to the bridge is free; vehicle tolls may apply.",

        // 10. TRANSPORTATION
        transportation: [
            "Take local buses from downtown San Francisco toward the bridge.",
            "Rent a bicycle and explore the waterfront cycling routes.",
            "Drive to nearby visitor parking areas where spaces are available."
        ],

        // 11. ACCOMMODATION
        accommodation: [
            "Stay in hotels near Fisherman's Wharf.",
            "Choose accommodation in downtown San Francisco.",
            "Consider hotels in nearby Marina District."
        ],

        // 12. ITINERARY
        itinerary: [
            {
                time: "8:00 AM",
                activity: "Welcome Center",
                description: "Learn about the bridge's history and engineering."
            },
            {
                time: "9:30 AM",
                activity: "Bridge Walk",
                description: "Walk along the pedestrian walkway and enjoy the scenery."
            },
            {
                time: "11:00 AM",
                activity: "Battery Spencer",
                description: "Take photographs from a famous viewpoint across the bay."
            },
            {
                time: "1:00 PM",
                activity: "Lunch Break",
                description: "Enjoy lunch at a nearby waterfront area."
            },
            {
                time: "2:30 PM",
                activity: "Fort Point",
                description: "Explore the historic fort beneath the bridge."
            },
            {
                time: "5:00 PM",
                activity: "Crissy Field",
                description: "Relax by the waterfront and enjoy the evening views."
            }
        ],

        // 13. TIPS
        tips: [
            "Bring a jacket because the bridge can be windy.",
            "Check fog conditions before taking photographs.",
            "Use designated pedestrian walkways.",
            "Stay alert around cyclists.",
            "Wear comfortable walking shoes.",
            "Check visitor center opening hours.",
            "Use public transportation to avoid parking difficulties.",
            "Keep personal belongings secure while sightseeing."
        ]
    },
];
